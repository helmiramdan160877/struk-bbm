# SIM IPEKB AI V7 - Master User dan Kas Otomatis

## Perubahan utama

- Master PKB menjadi sumber identitas akun role `PKB` dan `ANGGOTA`.
- Master Kader baru menjadi sumber identitas akun role `KADER`.
- Form pembuatan user menampilkan pilihan master sesuai role dan mengisi identitas serta desa binaan secara otomatis.
- Master Kader wajib terkait ke desa SIGA. Master PKB sekarang dapat menyimpan `village_id` melalui pilihan Desa SIGA.
- Tagihan kas tahun berjalan dihitung hanya dari Januari sampai bulan berjalan. Bulan selanjutnya berstatus `BELUM DITAGIH`.
- Reminder otomatis berjalan setiap tanggal 25 pukul 08.00 zona `Asia/Jakarta`.
- Anggota yang belum lunas menerima notifikasi aplikasi dan percobaan notifikasi WhatsApp.
- Bendahara dan Admin menerima ringkasan jumlah anggota belum lunas serta total tunggakan.
- Bell notifikasi ditambahkan di header.
- UI Master PKB, Master Kader, Manajemen User, Kas, notifikasi, modal, dan dialog konfirmasi dibuat lebih compact.
- Font memakai stack lokal `Aptos`, `Inter`, dan `Segoe UI Variable` agar tetap ringan tanpa ketergantungan font eksternal.

## Migrasi database

Dari folder `backend` jalankan:

```bash
alembic upgrade head
```

Revision terbaru adalah `v7_master_iuran`.

## WhatsApp gateway

Nomor pengirim default:

```text
+62 822-9505-6743
```

Isi konfigurasi berikut pada `backend/.env` sesuai gateway WhatsApp yang digunakan:

```env
WA_GATEWAY_URL=https://gateway-anda.example/send
WA_GATEWAY_API_KEY=token-gateway-anda
WA_SENDER_NUMBER=+62 822-9505-6743
```

Service saat ini mengirim HTTP `POST` JSON dengan struktur:

```json
{
  "sender": "6282295056743",
  "to": "62xxxxxxxxxx",
  "message": "isi reminder"
}
```

Bila gateway belum diatur, notifikasi aplikasi tetap dibuat dan aplikasi tidak gagal. Status WhatsApp akan tercatat `SKIPPED`. Bila provider WhatsApp memakai field atau autentikasi berbeda, sesuaikan hanya fungsi `send_whatsapp` pada `backend/app/services/iuran_notification_service.py`.

## Pemeriksaan yang sudah dilakukan

- `python3 -m compileall -q backend/app backend/alembic/versions`
- `python3 -m alembic heads`
- Unit check periode tagihan Januari sampai bulan berjalan
- `npx tsc --noEmit --project frontend/tsconfig.app.json`
- ESLint melalui entry Node

Build Vite di environment pemeriksaan tidak dapat dilanjutkan karena `node_modules` dalam arsip berasal dari platform berbeda dan optional native binding Rolldown Linux tidak ikut tersedia. Source TypeScript dan lint sudah lolos. Pada mesin deployment jalankan instalasi dependency bersih sebelum build.
