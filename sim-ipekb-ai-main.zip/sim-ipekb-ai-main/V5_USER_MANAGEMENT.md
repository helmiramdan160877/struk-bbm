# SIM IPEKB AI V5 — User Management & Modern UI

## Fitur baru

### 1. Manajemen User
Menu **Manajemen User** tersedia untuk SUPER_ADMIN dan ADMIN.

- SUPER_ADMIN dapat membuat user untuk seluruh role aktif.
- Role ADMIN wajib ditautkan ke satu kecamatan.
- Role PKB, KADER, dan ANGGOTA wajib mempunyai minimal satu desa binaan.
- Satu user dapat mempunyai beberapa desa binaan.
- Wilayah binaan dipilih langsung dari tabel wilayah hasil sinkronisasi SIGA.
- Reset password user.
- Aktif/nonaktif akun.
- Daftar user menampilkan role dan desa binaan.

### 2. Pembatasan ADMIN
ADMIN hanya dapat membuat akun dengan role:

- PKB
- KADER
- ANGGOTA

ADMIN hanya menerima daftar desa yang berada di `district_id` akun ADMIN tersebut. Validasi yang sama dilakukan lagi di backend sehingga manipulasi request dari browser tetap ditolak.

### 3. Multi wilayah binaan
Tabel `user_villages` yang sudah ada digunakan untuk menyimpan lebih dari satu desa per user. Tidak ada migration database baru.

### 4. UI baru

- Sidebar putih.
- Menu menampilkan ikon + nama.
- Menu aktif menggunakan aksen biru ringan.
- Profil user di kanan atas.
- Dropdown profil dan logout.
- Judul header mengikuti menu yang sedang dibuka.
- Judul tab browser juga mengikuti menu, mis. `Manajemen User | SIM IPEKB AI`.

## Cara update

Versi ini tidak membutuhkan `alembic upgrade` baru jika database sudah berada pada V4 Kas & Iuran.

Backend:

```bash
cd backend
source .venv/Scripts/activate
uvicorn app.main:app --reload
```

Frontend (terminal lain):

```bash
cd frontend
npm install
npm run dev
```

## Catatan penting untuk ADMIN
Akun ADMIN wajib mempunyai `district_id`. Jika ADMIN lama belum diberi kecamatan, endpoint wilayah binaan akan mengembalikan pesan **Akun ADMIN belum memiliki kecamatan binaan**. SUPER_ADMIN dapat membuat akun ADMIN baru sekaligus menentukan kecamatannya melalui menu Manajemen User.
