# SIM IPEKB AI V6 — Wilayah Kader & Modul PKB

## Perubahan utama

1. **Manajemen User tetap seperti V5**
   - SUPER_ADMIN tetap dapat mengelola seluruh user/role sesuai kewenangan.
   - ADMIN tetap dapat membuat user PKB/KADER/ANGGOTA hanya pada kecamatan/desa yang menjadi kewenangannya.
   - Multi desa binaan tetap didukung dan sumber desa tetap data SIGA.

2. **Pembatasan wilayah KADER/PKB diperketat di backend**
   - Data keluarga dan individu hanya dikembalikan jika berada pada salah satu desa binaan user.
   - KADER yang mempunyai beberapa desa dapat melihat gabungan data seluruh desa binaannya.
   - KADER/PKB tanpa desa binaan mendapatkan data kosong, bukan seluruh data.
   - Daftar desa dan daftar Kader juga mengikuti cakupan wilayah untuk akun lapangan.
   - Ringkasan dashboard KADER/PKB mengikuti desa binaannya.

3. **Data Keluarga & Individu**
   - Tab Individu dan Keluarga.
   - Tabel mengikuti gaya referensi: background putih, border tipis, header sederhana, pagination dan total di bawah.
   - SUPER_ADMIN mendapat tombol Edit dan Hapus.

4. **Data Kader**
   - Menampilkan seluruh desa binaan Kader.
   - KADER hanya melihat Kader yang memiliki irisan wilayah binaan dengannya.
   - SUPER_ADMIN mendapat tombol Edit dan Hapus.
   - ADMIN/SUPER_ADMIN tetap dapat membuat Kader sesuai aturan Manajemen User yang sudah ada.

5. **Data PKB**
   - SUPER_ADMIN mendapat tombol Edit dan Hapus.
   - Tampilan tabel disederhanakan mengikuti referensi.

6. **Dashboard/Modul PKB**
   - Menu SKP.
   - Menu e-Visum.
   - Menu Arsip Digital.
   - Ketiga menu tersedia sebagai halaman tabel awal dan muncul sebagai akses cepat di dashboard role PKB.

## Instalasi

Tidak ada migration database baru pada V6.

Backend:
```bash
cd backend
source .venv/Scripts/activate
uvicorn app.main:app --reload
```

Frontend:
```bash
cd frontend
npm install
npm run dev
```

Jika frontend sedang berjalan, stop dengan Ctrl+C lalu jalankan kembali `npm run dev` setelah mengganti source.
