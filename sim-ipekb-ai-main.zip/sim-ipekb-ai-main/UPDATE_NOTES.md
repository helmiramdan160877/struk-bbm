# SIM IPEKB AI V3 - PKB, Kader, dan Role Access

## Perubahan utama

- Tambah form **Tambah PKB** di halaman Data PKB.
- Tambah halaman **Data Kader** dan form **Tambah Kader**.
- Kader disimpan sebagai `User` dengan role `KADER`, sesuai struktur backend yang sudah ada.
- Kader dapat diberi desa binaan melalui relasi `user_villages`.
- Sidebar dan route frontend difilter berdasarkan permission role.
- Tombol aksi (Tambah PKB, Tambah Kader, Tambah Keluarga, Sync) mengikuti permission role.
- Endpoint backend penting sekarang memakai role guard sehingga pembatasan tidak hanya terjadi di tampilan.
- Endpoint PKB dirapikan dari `/api/v1/pkb/pkb` menjadi `/api/v1/pkb`.
- `seed_roles.py` dilengkapi dengan role PKB, KADER, PIMPINAN, VIEWER, dan role lain yang dipakai frontend.
- User nonaktif dan role nonaktif ditolak oleh authentication/authorization backend.

## Matriks akses ringkas

| Role | Akses utama |
|---|---|
| SUPER_ADMIN | Semua modul dan semua aksi |
| ADMIN | Administrasi operasional, keluarga, Kader, wilayah, SIGA; tidak dapat mengelola SUPER_ADMIN atau menambah PKB |
| PENGURUS | Monitoring PKB, Kader, capaian, arsip, laporan |
| PKB | Keluarga/anggota pada desa binaan, Kader, modul kerja PKB, laporan |
| KADER | Baca data keluarga/anggota pada desa binaan, data Kader, capaian/laporan |
| OPERATOR | Wilayah, PKB/Kader, akun SIGA, sinkronisasi, laporan |
| BENDAHARA | Kas, arsip, laporan |
| PIMPINAN | Dashboard dan monitoring PKB/Kader/capaian/laporan |
| VIEWER | Dashboard, wilayah, capaian, laporan |
| ANGGOTA | Dashboard, wilayah, laporan |

## Setelah mengganti source

Aktifkan virtual environment backend lalu jalankan:

```bash
cd backend
source .venv/Scripts/activate
python scripts/seed_roles.py
uvicorn app.main:app --reload
```

Buka terminal kedua untuk frontend:

```bash
cd frontend
npm install
npm run dev
```

Jika role KADER belum pernah ada di database, perintah `python scripts/seed_roles.py` wajib dijalankan sebelum mencoba **Tambah Kader**.

## Catatan database

Perubahan ini tidak menambah tabel baru. Field `nip`, `phone`, `role_id`, `district_id`, dan relasi `user_villages` sudah tersedia pada model User project lama. Jadi tidak diperlukan migration baru hanya untuk fitur Kader ini.

## V4 - Kas & Iuran IPKB untuk Anggota

- Role `ANGGOTA` mendapat menu **Kas & Iuran IPKB** (`kas.view`).
- Beranda `ANGGOTA` fokus pada status iuran pribadi, bukan statistik SIGA.
- Anggota hanya dapat membaca iuran miliknya melalui `/api/v1/iuran/me`.
- `BENDAHARA`, `ADMIN`, dan `SUPER_ADMIN` dapat mengatur nominal iuran dan mencatat pembayaran.
- `PENGURUS` dapat melihat rekap iuran anggota, tetapi tidak dapat mengubah pembayaran.
- Data pembayaran disimpan per anggota, tahun, dan bulan dengan constraint unik.
- Tambahan migration Alembic: `a14c2026iuran_create_iuran_tables.py`.

Setelah update backend jalankan:

```bash
alembic upgrade head
```

Kemudian restart backend dan frontend.

## V5 — Manajemen User & Modern UI
- Menu Manajemen User untuk SUPER_ADMIN dan ADMIN.
- SUPER_ADMIN dapat membuat semua role.
- ADMIN hanya dapat membuat PKB/KADER/ANGGOTA pada wilayah kecamatannya.
- Multi desa binaan melalui `user_villages`.
- Pilihan wilayah bersumber dari master hasil sinkronisasi SIGA.
- Reset password dan aktif/nonaktif user.
- Sidebar putih, profil kanan atas, title dinamis.
- Tidak memerlukan migration database baru dari V4.
