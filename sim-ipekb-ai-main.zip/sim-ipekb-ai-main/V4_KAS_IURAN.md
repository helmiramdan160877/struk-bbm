# SIM IPEKB AI V4 — Kas & Iuran IPKB

## Fitur baru

### Role ANGGOTA
- Beranda khusus anggota.
- Melihat nominal iuran per bulan.
- Melihat total iuran tahunan.
- Melihat jumlah yang sudah dibayar.
- Melihat sisa/tunggakan.
- Melihat status Januari–Desember, tanggal bayar, dan metode pembayaran.
- Hanya dapat melihat data iuran miliknya sendiri.

### Role PENGURUS
- Melihat rekap iuran seluruh akun dengan role ANGGOTA.
- Melihat detail status iuran per anggota.
- Tidak dapat mengubah pembayaran.

### Role BENDAHARA / ADMIN / SUPER_ADMIN
- Melihat rekap iuran anggota.
- Mengatur nominal iuran per bulan untuk setiap tahun.
- Mengatur tanggal jatuh tempo.
- Mencatat pembayaran per anggota dan per bulan.
- Metode pembayaran: Tunai, Transfer, QRIS.
- Mencatat nomor referensi/bukti dan catatan.

## Database baru
- `iuran_settings`
- `iuran_payments`

## Instalasi update

Aktifkan virtual environment backend lalu jalankan:

```bash
cd backend
source .venv/Scripts/activate
alembic upgrade head
uvicorn app.main:app --reload
```

Pada terminal kedua:

```bash
cd frontend
npm install
npm run dev
```

Jika role belum lengkap, jalankan sekali:

```bash
cd backend
python scripts/seed_roles.py
```

## Validasi source
- TypeScript compile: PASS
- ESLint: PASS
- Python compile: PASS
