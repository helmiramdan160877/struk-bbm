PATCH LOGO YANG BENAR

Project asli memakai logo desktop di:
frontend/src/layouts/AdminLayout.tsx
bukan Sidebar.tsx.

Pasang:
1. Ganti frontend/src/layouts/AdminLayout.tsx dengan file patch ini.
2. Salin logo-kemendukbangga.png ke frontend/public/
3. Jangan ubah file menu/sidebar lainnya.

Yang berubah hanya kotak logo biru diganti gambar logo yang Anda kirim.
Menu, dropdown, routing, API, dan card tidak diubah.
