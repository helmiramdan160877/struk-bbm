# SIM IPEKB AI — Patch UI Landing, Paket, Profil & Alert

Patch ini melanjutkan project yang sudah memiliki paket FREE/PAID dan sinkronisasi SIGA.

## Yang ditambahkan

1. Landing page publik dengan carousel otomatis dan tombol Masuk.
2. Login menampilkan alert/toast minimalis dan elegan.
3. Logout memakai konfirmasi modal minimalis.
4. Menu profil di pojok kanan atas:
   - Edit profil & akun
   - Ganti foto
   - Ubah nama, email, nomor HP
   - Ubah password (opsional)
5. Foto profil disimpan sebagai data URL di database.
6. SUPER_ADMIN dapat mengatur FREE/PAID pada Manajemen User.
   - FREE: maksimal 1 desa binaan.
   - PAID: multi-desa.
   - PAID dapat diberi tanggal kedaluwarsa.
7. SUPER_ADMIN mendapat tombol hapus akun dengan konfirmasi.
8. Backend endpoint `PATCH /api/v1/auth/me`.
9. Migration `20260903_profile` mengubah kolom users.photo menjadi TEXT agar foto data URL dapat disimpan.

## Setelah mengganti file

Backend:
```bash
cd backend
python -m alembic upgrade head
python -m alembic current
python -m uvicorn app.main:app --reload
```

Frontend:
```bash
cd frontend
npm install
npm run dev
```

Migration terakhir harus:
```text
20260903_profile (head)
```

Catatan: migration ini tidak menghapus data SIGA/keluarga.
