export interface DashboardSigaAccount {
  id: string;
  username: string;
  district_id: string | null;
  last_sync_at: string | null;
}

export interface DashboardSummary {
  username_user: string;
  username_siga: string;
  siga_account_count: number;
  siga_accounts: DashboardSigaAccount[];
  last_sync_at: string | null;

  wilayah: {
    district_id: string;
    siga_province_id: string | null;
    siga_regency_id: string | null;
    siga_district_id: string | null;
  };

  total_family: number;
  total_member: number;
  alive: number;
  dead: number;
  matched: number;
  unmatched: number;

  province: number;
  regency: number;
  district: number;
  village: number;
}

export interface DashboardSigaKbMethod {
  metode_kontrasepsi: string;
  pemerintah: number;
  swasta: number;
  lainnya: number;
  jumlah: number;
}

export interface DashboardSigaBkrVillage {
  village_code: string;
  village_name: string;
  bkr_exists: number;
  bkr_reports: number;
  bkr_report_percent: number;
  meetings: number;
  face_to_face: number;
  virtual: number;
  bkr_families: number;
  bkr_attended: number;
  pkbr_attended: number;
}

export interface DashboardSigaStatsVillage {
  village_id: string;
  village_name: string;
  village_code: string;
  siga_id: string;

  total_family: number;
  total_member: number;

  total_pus: number;
  total_pregnant: number;
  total_unmet_need: number;
  pus_not_kb: number;

  ingin_anak: number;
  ingin_anak_ditunda: number;
  tidak_ingin_anak_lagi: number;

  poktan_target: number;

  bkb_target: number;
  bkr_target: number;
  bkl_target: number;

  bkb_participation: number;
  bkr_participation: number;
  bkl_participation: number;
  uppka_participation: number;
  poktan_participation: number;

  kb_aktif: DashboardSigaKbMethod[];
}

export interface DashboardSigaStats {
  generated_at: string;

  period: {
    bulan: number;
    tahun: number;
  };

  role: string;

  username_user: string;
  username_siga: string;
  siga_account_id: string;

  wilayah: {
    siga_province_id: string | null;
    siga_regency_id: string | null;
    siga_district_id: string | null;
  };

  scope: {
    village_count: number;
    village_names: string[];
  };

  totals: Omit<
    DashboardSigaStatsVillage,
    | "village_id"
    | "village_name"
    | "village_code"
    | "siga_id"
    | "kb_aktif"
  >;

  kb_aktif: DashboardSigaKbMethod[];

  bkr: {
    bkr_exists: number;
    bkr_reports: number;
    report_percent: number;

    meetings: number;
    face_to_face: number;
    virtual: number;

    bkr_families: number;
    bkr_attended: number;
    attendance_percent: number;

    pkbr_attended: number;

    villages: DashboardSigaBkrVillage[];
  };

  villages: DashboardSigaStatsVillage[];
}

export interface DashboardSigaAttendanceVillage {
  village_code: string;
  village_name: string;

  meetings: number;
  members: number;
  attended: number;
  attendance_percent: number;
}

export interface DashboardSigaPoktan {
  nama_poktan: string;
  jenis: string;

  village_code: string;
  village_name: string;

  tanggal_kegiatan: string;

  anggota: number;
  hadir: number;
}

export interface DashboardSigaPoktanAttendance {
  jenis: "bkb" | "bkr" | "bkl" | "uppka" | "pikr";

  label: string;
  report: string;

  meetings: number;
  members: number;
  attended: number;
  attendance_percent: number;

  percentage_available: boolean;

  villages: DashboardSigaAttendanceVillage[];
}

export interface DashboardSigaPoktanAttendanceResponse {
  generated_at: string;

  period: {
    bulan: number;
    tahun: number;
  };

  scope: {
    village_count: number;
    village_names: string[];
  };

  items: DashboardSigaPoktanAttendance[];
}

export interface DashboardSigaPoktanResponse {
  generated_at: string;

  period: {
    bulan: number;
    tahun: number;
  };

  jenis: "bkb" | "bkr" | "bkl" | "uppka" | "pikr";

  label: string;

  scope: {
    village_count: number;
    village_names: string[];
  };

  attendance: {
    jenis: string;
    label: string;
    report: string;

    meetings: number;
    members: number;
    attended: number;
    attendance_percent: number;

    percentage_available: boolean;

    villages: DashboardSigaAttendanceVillage[];
  };

  poktan: DashboardSigaPoktan[];
}

export interface DashboardSigaRecapVillage {
  village_id: string;
  village_name: string;
  village_code: string;
  siga_id: string | null;
  district_id: string;

  total_family: number;
  total_member: number;
  matched: number;
  unmatched: number;
}

export interface DashboardSigaRecap {
  generated_at: string;
  last_sync_at: string | null;

  siga_account_count: number;

  totals: {
    village: number;
    total_family: number;
    total_member: number;
    matched: number;
    unmatched: number;
  };

  villages: DashboardSigaRecapVillage[];
}

export interface Family {
  id: string;
  village_id: string;

  family_card_number: string;
  head_of_family: string;

  address: string;

  rt: string | null;
  rw: string | null;
  postal_code: string | null;

  is_active: boolean;
}

export interface FamilyMember {
  id: string;
  family_id: string;

  nik: string;
  full_name: string;
  gender: string;

  birth_place?: string | null;
  birth_date?: string | null;
  age?: number | null;

  family_card_number?: string | null;

  religion?: string | null;
  education?: string | null;
  occupation?: string | null;
  marital_status?: string | null;

  relationship_to_head: string;

  is_alive: boolean;
}

export interface FamilyListResponse {
  items: Family[];
  total: number;
  page: number;
  limit: number;
  total_pages: number;
}

export interface RegionBase {
  id: string;
  code: string;
  name: string;
  is_active: boolean;
}

export type Province = RegionBase;

export interface Regency extends RegionBase {
  province_id: string;
}

export interface District extends RegionBase {
  regency_id: string;
}

export interface Village extends RegionBase {
  district_id: string;
}

export interface Pkb {
  id: string;

  nip: string;
  nik: string;
  nama: string;

  tempat_lahir?: string | null;
  tanggal_lahir?: string | null;
  jenis_kelamin?: string | null;
  agama?: string | null;
  pendidikan?: string | null;
  jabatan?: string | null;
  status_asn?: string | null;
  golongan?: string | null;

  email?: string | null;
  phone?: string | null;

  alamat?: string | null;

  kecamatan?: string | null;
  desa?: string | null;
  wilayah_binaan?: string | null;

  village_id?: string | null;
  siga_account_id?: string | null;

  status?: string | null;

  created_at: string;
  updated_at: string;
}

export interface SigaAccount {
  id: string;

  district_id: string | null;
  district_name?: string | null;
  siga_district_id?: string | null;

  username: string;

  is_active: boolean;

  last_sync_at: string | null;

  linked_user_id?: string | null;
  linked_username?: string | null;
}

export interface RoleRecord {
  id: string;
  name: string;
  description?: string | null;
  is_active: boolean;
}

export interface UserVillageLink {
  village_id: string;

  village: {
    id: string;
    code: string;
    name: string;
    district_id: string;
    siga_id?: string | null;
  };
}

export interface AppUserRecord {
  id: string;

  username: string;
  email: string;
  full_name: string;

  is_active: boolean;

  nip?: string | null;
  phone?: string | null;

  district_id?: string | null;
  siga_account_id?: string | null;

  pkb_id?: string | null;
  kader_id?: string | null;

  role?: RoleRecord | null;

  user_villages?: UserVillageLink[];

  plan_type?: "FREE" | "PAID" | string;
  plan_expires_at?: string | null;
  plan_active?: boolean;
}

export interface ManageableVillage {
  id: string;
  code: string;
  name: string;

  district_id: string;
  district_name: string;

  siga_id?: string | null;

  source: "SIGA" | string;
}

export interface IuranMonthStatus {
  month: number;
  month_name: string;

  expected_amount: number;
  paid_amount: number;

  status:
    | "LUNAS"
    | "KURANG"
    | "BELUM BAYAR"
    | string;

  paid_at?: string | null;
  payment_method?: string | null;
  reference_no?: string | null;
}

export interface IuranSummary {
  year: number;

  monthly_amount: number;

  total_expected: number;
  total_paid: number;
  total_outstanding: number;

  paid_months: number;
  unpaid_months: number;

  charged_through_month: number;
  charged_through_month_name?: string | null;

  months: IuranMonthStatus[];
}

export interface IuranMemberSummary {
  user_id?: string | null;
  pkb_id?: string | null;

  full_name: string;
  username: string;

  nip?: string | null;
  phone?: string | null;

  year: number;

  total_expected: number;
  total_paid: number;
  total_outstanding: number;

  paid_months: number;
  unpaid_months: number;
}

export interface IuranSetting {
  id: string;

  year: number;

  monthly_amount: number;
  due_day: number;

  is_active: boolean;
}

export interface KaderMaster {
  id: string;

  nik: string;
  nama: string;

  email?: string | null;
  phone?: string | null;

  alamat?: string | null;
  jabatan?: string | null;

  village_id?: string | null;
  village_name?: string | null;
  district_name?: string | null;

  status: string;

  created_at: string;
  updated_at: string;
}

export interface UserMasterSource {
  id: string;

  source_type: "PKB" | "KADER" | string;

  code: string;
  name: string;

  email?: string | null;
  phone?: string | null;

  village_id?: string | null;
  village_name?: string | null;

  district_id?: string | null;
  siga_account_id?: string | null;

  status: string;
}

export interface AppNotification {
  id: string;

  year: number;
  month: number;

  kind: string;

  title: string;
  message: string;

  outstanding_amount: number;

  is_read: boolean;

  whatsapp_status: string;

  created_at: string;
}

export interface NotificationResponse {
  unread_count: number;
  items: AppNotification[];
}