export type Role =
  | "SUPERADMIN"
  | "SUPER_ADMIN"
  | "ADMIN"
  | "PENGURUS"
  | "PKB"
  | "KADER"
  | "OPERATOR"
  | "BENDAHARA"
  | "PIMPINAN"
  | "VIEWER"
  | "ANGGOTA";

export interface UserRole {
  id?: string;
  name: string;
  description?: string | null;
  is_active?: boolean;
}

export interface User {
  id: string;
  username: string;
  email?: string | null;
  full_name: string;
  nip?: string | null;
  phone?: string | null;
  photo?: string | null;
  district_id?: string | null;
  is_active?: boolean;
  role?: Role | string | UserRole | null;
  plan_type?: "FREE" | "PAID" | string;
  plan_expires_at?: string | null;
  plan_active?: boolean;
}

export interface LoginResponse {
  access_token: string;
  token_type?: string;
}
