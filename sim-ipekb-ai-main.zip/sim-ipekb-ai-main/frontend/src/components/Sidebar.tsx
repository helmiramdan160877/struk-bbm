interface SidebarProps {
  activePage: string;
  onNavigate: (page: string) => void;
}

const menus = [
  {
    name: "Dashboard",
    icon: "▦",
    page: "dashboard",
  },
  {
    name: "Data Keluarga",
    icon: "⌂",
    page: "families",
  },
  {
    name: "Wilayah",
    icon: "⌖",
    page: "wilayah",
  },
  {
    name: "PKB",
    icon: "♟",
    page: "pkb",
  },
  {
    name: "SIGA",
    icon: "↻",
    page: "siga",
  },
  {
    name: "Sinkronisasi",
    icon: "⇄",
    page: "sync",
  },
];

export default function Sidebar({
  activePage,
  onNavigate,
}: SidebarProps) {
  return (
    <aside className="flex h-screen w-[240px] flex-col bg-[#101a30] text-white">

      {/* LOGO - menggunakan logo Kemendukbangga/BKKBN */}
      <div className="border-b border-slate-700 px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-white p-1.5">
            <img
              src="/logo-kemendukbangga.png"
              alt="Logo Kemendukbangga/BKKBN"
              className="h-full w-full object-contain"
            />
          </div>
          <div className="min-w-0">
            <h1 className="truncate text-base font-bold text-white">
              SIM IPEKB AI
            </h1>
            <p className="mt-0.5 text-xs text-slate-400">
              Sistem Informasi IPEKB
            </p>
          </div>
        </div>
      </div>

      {/* MENU */}
      <nav className="flex-1 overflow-y-auto px-3 py-5">

        <p className="mb-3 px-3 text-xs font-semibold uppercase tracking-wider text-slate-500">
          Menu Utama
        </p>

        <div className="space-y-1">

          {menus.map((menu) => {

            const active =
              activePage === menu.page;

            return (
              <button
                type="button"
                key={menu.page}
                onClick={() => onNavigate(menu.page)}
                className={`
                  flex
                  w-full
                  items-center
                  gap-3
                  rounded-lg
                  px-3
                  py-3
                  text-left
                  text-sm
                  font-medium
                  transition
                  ${
                    active
                      ? "bg-blue-600 text-white"
                      : "text-slate-300 hover:bg-slate-800 hover:text-white"
                  }
                `}
              >

                <span className="flex w-6 justify-center text-lg">
                  {menu.icon}
                </span>

                <span>
                  {menu.name}
                </span>

              </button>
            );

          })}

        </div>

      </nav>

      {/* FOOTER */}
      <div className="border-t border-slate-700 p-4">

        <p className="text-xs text-slate-500">
          SIM IPEKB AI
        </p>

        <p className="mt-1 text-xs text-slate-600">
          v1.0
        </p>

      </div>

    </aside>
  );
}