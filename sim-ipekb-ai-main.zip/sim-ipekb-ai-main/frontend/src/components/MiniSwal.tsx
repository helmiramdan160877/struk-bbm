import Icon from "./Icon";

interface Props {
  open: boolean;
  title: string;
  text: string;
  tone?: "info" | "danger" | "success";
  confirmText?: string;
  cancelText?: string;
  busy?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export default function MiniSwal({
  open,
  title,
  text,
  tone = "info",
  confirmText = "Ya, lanjutkan",
  cancelText = "Batal",
  busy = false,
  onConfirm,
  onCancel,
}: Props) {
  if (!open) return null;
  const toneClass = tone === "danger" ? "bg-red-50 text-red-600" : tone === "success" ? "bg-emerald-50 text-emerald-600" : "bg-blue-50 text-blue-600";
  const buttonClass = tone === "danger" ? "bg-red-600 hover:bg-red-700" : tone === "success" ? "bg-emerald-600 hover:bg-emerald-700" : "bg-blue-600 hover:bg-blue-700";
  const icon = tone === "danger" ? "alert" : tone === "success" ? "check" : "info";

  return (
    <div className="fixed inset-0 z-[150] grid place-items-center bg-slate-950/35 p-4 backdrop-blur-[2px]">
      <div className="w-full max-w-[340px] rounded-2xl border border-slate-200 bg-white p-4 shadow-2xl shadow-slate-950/15">
        <div className={`grid h-9 w-9 place-items-center rounded-xl ${toneClass}`}><Icon name={icon} size={17}/></div>
        <h3 className="mt-3 text-[13px] font-black text-slate-900">{title}</h3>
        <p className="mt-1.5 text-[11px] leading-5 text-slate-500">{text}</p>
        <div className="mt-4 flex justify-end gap-2">
          <button type="button" onClick={onCancel} disabled={busy} className="h-8 rounded-lg border border-slate-200 bg-white px-3 text-[10px] font-extrabold text-slate-600 hover:bg-slate-50 disabled:opacity-50">{cancelText}</button>
          <button type="button" onClick={onConfirm} disabled={busy} className={`h-8 rounded-lg px-3 text-[10px] font-extrabold text-white disabled:opacity-50 ${buttonClass}`}>{busy ? "Memproses..." : confirmText}</button>
        </div>
      </div>
    </div>
  );
}
