import Icon from "./Icon";

export default function LoadingScreen() {
  return (
    <div className="grid min-h-screen place-items-center bg-[#f3f6fb]">
      <div className="text-center">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-200"><Icon name="sparkles" size={24} /></div>
        <div className="mx-auto mt-5 h-1.5 w-28 overflow-hidden rounded-full bg-blue-100"><div className="h-full w-1/2 animate-pulse rounded-full bg-blue-600" /></div>
        <p className="mt-3 text-xs font-semibold text-slate-500">Menyiapkan SIM IPEKB AI...</p>
      </div>
    </div>
  );
}
