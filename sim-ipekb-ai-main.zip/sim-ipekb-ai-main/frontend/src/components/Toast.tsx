import { useEffect } from "react";
import Icon from "./Icon";

interface ToastProps {
  open: boolean;
  title?: string;
  message: string;
  tone?: "success" | "error" | "info";
  onClose?: () => void;
}

export default function Toast({ open, title, message, tone = "success", onClose }: ToastProps) {
  useEffect(() => {
    if (!open || !onClose) return;
    const t = window.setTimeout(onClose, 3200);
    return () => window.clearTimeout(t);
  }, [open, onClose]);
  if (!open) return null;
  const toneClass = tone === "error" ? "bg-red-50 text-red-600 ring-red-100" : tone === "info" ? "bg-blue-50 text-blue-600 ring-blue-100" : "bg-emerald-50 text-emerald-600 ring-emerald-100";
  const icon = tone === "error" ? "alert" : tone === "info" ? "info" : "check";
  return (
    <div className="fixed right-4 top-4 z-[300] w-[min(360px,calc(100vw-2rem))] animate-[siga-drop_.16s_ease-out]">
      <div className="flex items-start gap-3 rounded-2xl border border-slate-200 bg-white p-3 shadow-2xl shadow-slate-900/10">
        <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ring-1 ${toneClass}`}><Icon name={icon} size={17}/></span>
        <div className="min-w-0 flex-1"><div className="text-[11px] font-black text-slate-900">{title || (tone === "error" ? "Terjadi masalah" : "Berhasil")}</div><div className="mt-0.5 text-[10px] leading-5 text-slate-500">{message}</div></div>
        {onClose && <button type="button" onClick={onClose} className="text-slate-300 hover:text-slate-500"><Icon name="close" size={13}/></button>}
      </div>
    </div>
  );
}
