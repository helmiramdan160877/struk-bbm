interface HeaderProps {
  title: string;
  onLogout: () => void;
}

export default function Header({
  title,
  onLogout,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 flex h-20 items-center justify-between border-b bg-white px-8">

      <div>
        <h2 className="text-xl font-bold text-slate-800">
          {title}
        </h2>

        <p className="text-sm text-slate-500">
          Sistem Informasi IPEKB AI
        </p>
      </div>

      <button
        onClick={onLogout}
        className="rounded-lg bg-[#2161f5] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-[#183153]"
      >
        Keluar
      </button>

    </header>
  );
}