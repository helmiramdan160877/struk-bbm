import { useEffect, useMemo, useState } from "react";

import LoadingScreen from "./components/LoadingScreen";
import AdminLayout from "./layouts/AdminLayout";

import { navSections } from "./config/navigation";
import { hasPermission, isRole } from "./auth/permissions";

import AdminDashboard from "./pages/AdminDashboard";
import MemberDashboard from "./pages/MemberDashboard";
import FamilyRecap from "./pages/FamilyRecap";
import Login from "./pages/Login";
import ModulePlaceholder from "./pages/ModulePlaceholder";
import PkbPage from "./pages/PkbPage";
import PkbWorkModulePage from "./pages/PkbWorkModulePage";
import KaderPage from "./pages/KaderPage";
import AnggotaPage from "./pages/AnggotaPage";
import UserManagementPage from "./pages/UserManagementPage";
import IuranPage from "./pages/IuranPage";
import RegionsPage from "./pages/RegionsPage";

import SigaAccountsPage from "./pages/SigaAccountsPage";
import SyncPage from "./pages/SyncPage";

import BendaharaDashboard from "./pages/BendaharaDashboard";
import LaporanPengeluaranPage from "./pages/LaporanPengeluaranPage";

import Landing from "./pages/Landing";
import ProfilePage from "./pages/ProfilePage";
import AiAssistantPage from "./pages/AiAssistantPage";

import {
  getCurrentUser,
  getToken,
  logout,
} from "./services/api";

import type { User } from "./types/auth";

import MiniSwal from "./components/MiniSwal";
import Toast from "./components/Toast";



export default function App() {


  const [user, setUser] = useState<User | null>(null);

  const [checking, setChecking] = useState(true);

  const [activePage, setActivePage] = useState("dashboard");

  const [showLogin, setShowLogin] = useState(false);

  const [authAlert, setAuthAlert] =
    useState<"login" | "logout" | null>(null);

  const [logoutConfirmOpen, setLogoutConfirmOpen] =
    useState(false);
  const [authError, setAuthError] = useState("");


  const hydrate = async () => {

    try {

      const me = await getCurrentUser();

      setUser(me);
      setAuthError("");
      return true;

    } catch (reason) {

      logout();

      setUser(null);
      setAuthError(
        reason instanceof Error
          ? reason.message
          : "Sesi login tidak valid atau akun Anda tidak aktif."
      );
      return false;

    }

  };



  useEffect(() => {

    void (async () => {

      if (getToken()) {
        await hydrate();
      }

      setChecking(false);

    })();

  }, []);




  const activeItem = useMemo(

    () =>

      navSections

        .flatMap((section) => section.items)

        .find((item) => item.id === activePage),

    [activePage]

  );



  const title = activeItem?.label || "Modul";



  const allowed =

    activePage === "profile" ||

    Boolean(

      user &&

      activeItem &&

      hasPermission(user, activeItem.permission)

    );




  useEffect(() => {

    document.title =
      `${title} | SIM IPEKB AI`;

  }, [title]);





  if (checking) {

    return <LoadingScreen />;

  }




  if (!user && !showLogin) {

    return (

      <>

        <Landing

          onLogin={() => setShowLogin(true)}

        />

        {authError && (

          <div className="fixed inset-x-4 top-4 z-50 mx-auto max-w-md rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800 shadow-lg">

            {authError}

          </div>

        )}

        <AuthAlert

          type={authAlert}

          onClose={() => setAuthAlert(null)}

        />

      </>

    );

  }





  if (!user) {

    return (

      <>

        <Login

          onLogin={async () => {

            setChecking(true);

            const authenticated = await hydrate();

            setShowLogin(!authenticated);

            if (authenticated) setAuthAlert("login");

            setChecking(false);

          }}

        />


        <AuthAlert

          type={authAlert}

          onClose={() => setAuthAlert(null)}

        />

      </>

    );

  }





  const signOut = () => {

    setLogoutConfirmOpen(false);

    logout();

    setUser(null);

    setActivePage("dashboard");

    setAuthAlert("logout");

  };





  let content;




  if (!allowed) {


    content = <AccessDenied />;



  } else if (activePage === "dashboard") {



    if (isRole(user, "ANGGOTA")) {


      content = (

        <MemberDashboard

          user={user}

          onNavigate={setActivePage}

        />

      );



    } else if (isRole(user, "BENDAHARA")) {


      content = (

        <BendaharaDashboard

          user={user}

          onNavigate={setActivePage}

        />

      );



    } else {


      content = (

        <AdminDashboard

          user={user}

          onNavigate={setActivePage}

        />

      );

    }




  } else if (activePage === "ai-assistant") {

    content = <AiAssistantPage user={user} />;


  } else if (activePage === "profile") {


    content = (

      <ProfilePage

        user={user}

        onUpdated={setUser}

      />

    );




  } else if (activePage === "family-recap") {


    content = <FamilyRecap user={user} />;




  } else if (activePage === "pkb") {


    content = <PkbPage user={user} />;




  } else if (activePage === "skp") {


    content =
      <PkbWorkModulePage kind="skp" />;




  } else if (activePage === "evisum") {


    content =
      <PkbWorkModulePage kind="evisum" />;




  } else if (activePage === "arsip") {


    content =
      <PkbWorkModulePage kind="arsip" />;




  } else if (activePage === "kader") {

  

    content =
      <KaderPage user={user} />;

   } else if (activePage === "anggota") {

    content =
      <AnggotaPage user={user} />;


  } else if (activePage === "users") {


    content =
      <UserManagementPage user={user} />;




  } else if (activePage === "iuran") {


    content =
      <IuranPage user={user} />;




  } else if (activePage === "laporan-pengeluaran") {


    content = (

      <LaporanPengeluaranPage

        user={user}

      />

    );




  } else if (activePage === "regions") {


    content =
      <RegionsPage />;





  } else if (

    activePage === "siga" ||

    activePage === "siga-account"

  ) {


    content = (

      <SigaAccountsPage

        user={user}

        onNavigate={setActivePage}

      />

    );




  } else if (activePage === "sync") {


    content =
      <SyncPage />;




  } else if (activePage === "sync-history") {


    content = (

      <ModulePlaceholder

        title="Riwayat Sinkronisasi SIGA"

      />

    );




  } else {


    content = (

      <ModulePlaceholder

        title={title}

      />

    );

  }







  return (

    <AdminLayout

      activePage={activePage}

      onNavigate={setActivePage}

      onLogout={() => setLogoutConfirmOpen(true)}

      user={user}

    >


      {content}



      <AuthAlert

        type={authAlert}

        onClose={() => setAuthAlert(null)}

      />



      <MiniSwal

        open={logoutConfirmOpen}

        title="Konfirmasi logout"

        text="Apakah Anda yakin akan logout?"

        tone="danger"

        confirmText="Ya, logout"

        cancelText="Batal"

        onConfirm={signOut}

        onCancel={() => setLogoutConfirmOpen(false)}

      />


    </AdminLayout>

  );

}




function AuthAlert({

  type,

  onClose,

}: {

  type: "login" | "logout" | null;

  onClose: () => void;

}) {


  if (!type) return null;



  return (

    <Toast

      open

      tone="success"

      title={
        type === "login"
          ? "Login berhasil"
          : "Logout berhasil"
      }

      message={
        type === "login"
          ? "Anda sudah berhasil login."
          : "Anda telah keluar dari aplikasi dengan aman."
      }

      onClose={onClose}

    />

  );

}




function AccessDenied() {

  return (

    <div className="mx-auto mt-16 max-w-lg rounded-[22px] border border-red-100 bg-white p-8 text-center shadow-sm">


      <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-red-50 text-2xl">

        🔒

      </div>



      <h2 className="mt-4 text-lg font-black text-[#142b4c]">

        Akses dibatasi

      </h2>



      <p className="mt-2 text-xs leading-5 text-slate-500">

        Role akun Anda tidak memiliki permission untuk membuka modul ini.

      </p>


    </div>

  );

}