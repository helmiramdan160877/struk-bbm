import type { LoginResponse, User } from "../types/auth";

import type {
  DashboardSummary,
  DashboardSigaRecap,
  DashboardSigaStats,
  DashboardSigaPoktanResponse,
  DashboardSigaPoktanAttendanceResponse,
  District,
  Family,
  FamilyListResponse,
  FamilyMember,
  Pkb,
  Province,
  Regency,
  SigaAccount,
  Village,
} from "../types/api";

const API_URL = (
  import.meta.env.VITE_API_URL ||
  "http://127.0.0.1:8000/api/v1"
).replace(/\/$/, "");

export function getToken() {
  return localStorage.getItem("access_token");
}

export function logout() {
  localStorage.removeItem("access_token");
  localStorage.removeItem("token_type");
}

interface ApiOptions extends RequestInit {
  auth?: boolean;
}

export async function apiRequest<T>(
  path: string,
  options: ApiOptions = {}
): Promise<T> {
  const { auth = true, headers, ...rest } = options;

  const token = getToken();

  const requestHeaders = new Headers(headers);

  requestHeaders.set("Accept", "application/json");

  if (auth && token) {
    requestHeaders.set(
      "Authorization",
      `Bearer ${token}`
    );
  }

  const response = await fetch(
    `${API_URL}${
      path.startsWith("/") ? path : `/${path}`
    }`,
    {
      ...rest,
      headers: requestHeaders,
    }
  );

  if (response.status === 401 && auth) {
    logout();
  }

  if (!response.ok) {
    let message = `Permintaan gagal (${response.status})`;

    try {
      const payload = (await response.json()) as {
        detail?: string;
        message?: string;
      };

      message =
        payload.detail ||
        payload.message ||
        message;
    } catch {
      // Response bukan JSON.
    }

    const error = new Error(message) as Error & { status?: number };
    error.status = response.status;
    throw error;
  }

  if (response.status === 204) {
    return undefined as T;
  }

  return response.json() as Promise<T>;
}

/* =========================================================
   AUTH
========================================================= */

export async function login(
  username: string,
  password: string
): Promise<LoginResponse> {
  const body = new URLSearchParams();

  body.append("username", username);
  body.append("password", password);

  const data =
    await apiRequest<LoginResponse>(
      "/auth/login",
      {
        method: "POST",
        auth: false,
        headers: {
          "Content-Type":
            "application/x-www-form-urlencoded",
        },
        body,
      }
    );

  localStorage.setItem(
    "access_token",
    data.access_token
  );

  localStorage.setItem(
    "token_type",
    data.token_type || "bearer"
  );

  return data;
}

export function getCurrentUser() {
  return apiRequest<User>("/auth/me");
}

export function updateMyProfile(payload: {
  full_name?: string;
  email?: string;
  phone?: string;
  photo?: string | null;
  password?: string;
}) {
  return apiRequest<User>("/auth/me", {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
}

/* =========================================================
   GEMINI AI ASSISTANT
========================================================= */

export function chatWithAi(
  message: string,
  context?: Record<string, unknown>,
  attachment?: { data: string; mimeType: string; name?: string },
  conversationId?: string
) {
  return apiRequest<{
    success: boolean;
    answer?: string;
    message?: string;
    conversation_id?: string;
  }>("/ai/chat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      message,
      context: context
        ? JSON.stringify(context)
        : null,
      image_data: attachment?.data || null,
      image_mime_type: attachment?.mimeType || null,
      file_name: attachment?.name || null,
      conversation_id: conversationId || null,
    }),
  });
}

export function getAiHistory(conversationId?: string) {
  const query = conversationId
    ? `?conversation_id=${encodeURIComponent(conversationId)}`
    : "";
  return apiRequest<{
    success: boolean;
    conversation_id?: string | null;
    messages: Array<{
      id: string;
      conversation_id: string;
      role: "user" | "assistant";
      content: string;
    }>;
  }>(`/ai/history${query}`);
}

export function clearAiHistory(conversationId?: string) {
  const query = conversationId
    ? `?conversation_id=${encodeURIComponent(conversationId)}`
    : "";
  return apiRequest<{ success: boolean }>(
    `/ai/history${query}`,
    { method: "DELETE" }
  );
}

/* =========================================================
   DASHBOARD
========================================================= */

export function getDashboardSummary() {
  return apiRequest<DashboardSummary>(
    "/dashboard/summary"
  );
}

export function getDashboardSigaRecap() {
  return apiRequest<DashboardSigaRecap>(
    "/dashboard/siga-recap"
  );
}

export function getDashboardSigaPoktanAttendance(
  bulan?: number,
  tahun?: number
) {
  const params = new URLSearchParams();

  if (bulan) {
    params.set("bulan", String(bulan));
  }

  if (tahun) {
    params.set("tahun", String(tahun));
  }

  return apiRequest<DashboardSigaPoktanAttendanceResponse>(
    `/dashboard/siga-poktan-attendance${
      params.toString()
        ? `?${params.toString()}`
        : ""
    }`
  );
}

export function getDashboardSigaPoktan(
  jenis:
    | "bkb"
    | "bkr"
    | "bkl"
    | "uppka"
    | "pikr",
  bulan?: number,
  tahun?: number
) {
  const params = new URLSearchParams({
    jenis,
  });

  if (bulan) {
    params.set("bulan", String(bulan));
  }

  if (tahun) {
    params.set("tahun", String(tahun));
  }

  return apiRequest<DashboardSigaPoktanResponse>(
    `/dashboard/siga-poktan?${params.toString()}`
  );
}

export function getDashboardSigaStats(
  bulan?: number,
  tahun?: number
) {
  const params = new URLSearchParams();

  if (bulan) {
    params.set("bulan", String(bulan));
  }

  if (tahun) {
    params.set("tahun", String(tahun));
  }

  return apiRequest<DashboardSigaStats>(
    `/dashboard/siga-stats${
      params.toString()
        ? `?${params.toString()}`
        : ""
    }`
  );
}

/* =========================================================
   FAMILY
========================================================= */

export function getFamilies(
  page = 1,
  limit = 25
) {
  return apiRequest<FamilyListResponse>(
    `/families/?page=${page}&limit=${limit}`
  );
}

export function createFamily(
  payload: Omit<Family, "id" | "is_active">
) {
  return apiRequest<Family>("/families/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
}

export function updateFamily(
  familyId: string,
  payload: Partial<Omit<Family, "id">>
) {
  return apiRequest<Family>(
    `/families/${familyId}`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

export function deleteFamily(
  familyId: string
) {
  return apiRequest<{
    success?: boolean;
    message?: string;
  }>(
    `/families/${familyId}`,
    {
      method: "DELETE",
    }
  );
}

/* =========================================================
   FAMILY MEMBERS
========================================================= */

export function getFamilyMembers() {
  return apiRequest<FamilyMember[]>(
    "/family-members/"
  );
}

export function updateFamilyMember(
  memberId: string,
  payload: Partial<FamilyMember>
) {
  return apiRequest<FamilyMember>(
    `/family-members/${memberId}`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

export function deleteFamilyMember(
  memberId: string
) {
  return apiRequest<{
    message?: string;
  }>(
    `/family-members/${memberId}`,
    {
      method: "DELETE",
    }
  );
}

/* =========================================================
   WILAYAH
========================================================= */

export function getProvinces() {
  return apiRequest<Province[]>(
    "/provinces/"
  );
}

export function getRegencies() {
  return apiRequest<Regency[]>(
    "/regencies/"
  );
}

export function getDistricts() {
  return apiRequest<District[]>(
    "/districts/"
  );
}

export function getVillages() {
  return apiRequest<Village[]>(
    "/villages/"
  );
}

/* =========================================================
   SIGA ACCOUNT
========================================================= */

export function getSigaAccounts() {
  return apiRequest<SigaAccount[]>(
    "/siga-accounts"
  );
}

export function createSigaAccount(payload: {
  district_id?: string | null;
  username: string;
  password: string;
  user_id?: string;
}) {
  return apiRequest<SigaAccount>(
    "/siga-accounts",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

export function updateSigaAccount(
  accountId: string,
  payload: {
    username?: string;
    password?: string;
    is_active?: boolean;
  }
) {
  return apiRequest<SigaAccount>(
    `/siga-accounts/${accountId}`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

export function deleteSigaAccount(
  accountId: string
) {
  return apiRequest<{
    message?: string;
  }>(
    `/siga-accounts/${accountId}`,
    {
      method: "DELETE",
    }
  );
}

/* =========================================================
   PKB
========================================================= */

export async function getPkbList() {
  try {
    return await apiRequest<Pkb[]>("/pkb");
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes("404")
    ) {
      return apiRequest<Pkb[]>("/pkb/pkb");
    }

    throw error;
  }
}

export function createPkb(
  payload: Omit<
    Pkb,
    "id" | "created_at" | "updated_at"
  >
) {
  return apiRequest<Pkb>("/pkb", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
}

export function updatePkb(
  pkbId: string,
  payload: Partial<Pkb>
) {
  return apiRequest<Pkb>(
    `/pkb/${pkbId}`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

export function deletePkb(
  pkbId: string
) {
  return apiRequest<{
    message?: string;
  }>(
    `/pkb/${pkbId}`,
    {
      method: "DELETE",
    }
  );
}

export function getPkbWilayahBinaan(
  pkbId: string
) {
  return apiRequest<
    { id: string; name: string; code: string; district_id: string }[]
  >(`/pkb/${pkbId}/wilayah-binaan`);
}

export function updatePkbWilayahBinaan(
  pkbId: string,
  villageIds: string[]
) {
  return apiRequest<{
    success: boolean;
    message: string;
    pkb_id: string;
    user_id: string;
    village_ids: string[];
    villages: {
      id: string;
      name: string;
      code: string;
      district_id: string;
    }[];
  }>(`/pkb/${pkbId}/wilayah-binaan`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      village_ids: villageIds,
    }),
  });
}

/* =========================================================
   SIGA SYNC
========================================================= */

export function runSigaSync(
  payload: {
    username_siga: string;
    password_siga: string;
    bulan: number;
    tahun: number;
  },
  mode: "full" | "members" = "full"
) {
  return apiRequest<Record<string, unknown>>(
    mode === "full"
      ? "/sync/run"
      : "/sync/members",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

/* =========================================================
   USERS
========================================================= */

export function getUsers() {
  return apiRequest<
    import("../types/api").AppUserRecord[]
  >("/users/");
}

export function getKaders() {
  return apiRequest<
    import("../types/api").AppUserRecord[]
  >("/users/kaders");
}

export function getRoles() {
  return apiRequest<
    import("../types/api").RoleRecord[]
  >("/roles/");
}

/* =========================================================
   CREATE USER
========================================================= */

export function createUser(payload: {
  username: string;
  email: string;
  full_name: string;
  password: string;
  role_id: string;
  nip?: string | null;
  phone?: string | null;
  district_id?: string | null;
  village_ids?: string[];
  master_source_id?: string | null;
  siga_account_id?: string | null;
  plan_type?: "FREE" | "PAID";
  plan_expires_at?: string | null;

}) {
  return apiRequest<
    import("../types/api").AppUserRecord
  >(
    "/users/",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

/* =========================================================
   UPDATE USER
========================================================= */

export function updateUser(
  userId: string,
  payload: {
    username?: string;
    email?: string;
    full_name?: string;
    password?: string;
    role_id?: string | null;
    is_active?: boolean;
    nip?: string | null;
    phone?: string | null;
    district_id?: string | null;
    village_ids?: string[];
    siga_account_id?: string | null;
    plan_type?: "FREE" | "PAID";
    plan_expires_at?: string | null;

  }
) {
  return apiRequest<
    import("../types/api").AppUserRecord
  >(
    `/users/${userId}`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

/* =========================================================
   USER SUBSCRIPTION
   KHUSUS SUPER ADMIN
========================================================= */

export function updateUserSubscription(
  userId: string,
  payload: {
    plan_type: "FREE" | "PAID";
    plan_expires_at?: string | null;
  }
) {
  return apiRequest<
    import("../types/api").AppUserRecord
  >(
    `/users/${userId}/subscription`,
    {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

/* =========================================================
   DELETE USER
========================================================= */

export function deleteUser(
  userId: string
) {
  return apiRequest<{
    success?: boolean;
    message?: string;
  }>(
    `/users/${userId}`,
    {
      method: "DELETE",
    }
  );
}

/* =========================================================
   USER ROLE / SCOPE
========================================================= */

export function getManageableRoles() {
  return apiRequest<
    import("../types/api").RoleRecord[]
  >(
    "/users/manageable-roles"
  );
}

export function getAvailableSigaAccounts() {
  return apiRequest<
    {
      id: string;
      username: string;
      nama?: string | null;
      district_id?: string | null;
      siga_district_id?: string | null;
      is_active: boolean;
    }[]
  >(
    "/users/available-siga-accounts"
  );
}

export function getManageableVillages() {
  return apiRequest<
    import("../types/api").ManageableVillage[]
  >(
    "/users/available-villages"
  );
}

export function getUserMasterSources(
  roleName: string
) {
  return apiRequest<
    import("../types/api").UserMasterSource[]
  >(
    `/users/master-sources?role_name=${encodeURIComponent(
      roleName
    )}`
  );
}

/* =========================================================
   USER PASSWORD
========================================================= */

export function resetUserPassword(
  userId: string,
  newPassword: string
) {
  return apiRequest<{
    success: boolean;
    message: string;
  }>(
    `/users/${userId}/password`,
    {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        new_password: newPassword,
      }),
    }
  );
}

/* =========================================================
   USER ACTIVE / INACTIVE
========================================================= */

export function setUserActive(
  userId: string,
  active: boolean
) {
  return apiRequest<{
    success: boolean;
    message: string;
  }>(
    `/users/${userId}/${
      active
        ? "activate"
        : "deactivate"
    }`,
    {
      method: "PATCH",
    }
  );
}

/* =========================================================
   USER VILLAGE
========================================================= */

export function assignUserVillage(
  userId: string,
  villageId: string
) {
  return apiRequest<Record<string, unknown>>(
    `/users/${userId}/villages`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        village_id: villageId,
      }),
    }
  );
}

/* =========================================================
   ANGGOTA DARI DATA PKB
========================================================= */

export function createAnggotaFromPkb(
  payload: {
    pkb_id: string;
    username: string;
    password: string;
    plan_type: "FREE" | "PAID";
    plan_expires_at?: string | null;
  }
) {
  return apiRequest<
    import("../types/api").AppUserRecord
  >(
    "/users/anggota-from-pkb",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

/* =========================================================
   IURAN
========================================================= */

export function getMyIuran(
  year: number
) {
  return apiRequest<
    import("../types/api").IuranSummary
  >(
    `/iuran/me?year=${year}`
  );
}

export function getIuranMembers(
  year: number,
  month?: number
) {
  return apiRequest<
    import("../types/api").IuranMemberSummary[]
  >(
    `/iuran/members?year=${year}${
      month
        ? `&month=${month}`
        : ""
    }`
  );
}

export function getMemberIuran(
  userId: string,
  year: number
) {
  return apiRequest<
    import("../types/api").IuranSummary
  >(
    `/iuran/member/${userId}?year=${year}`
  );
}

export function getIuranSetting(
  year: number
) {
  return apiRequest<
    import("../types/api").IuranSetting | null
  >(
    `/iuran/settings/${year}`
  );
}

export function saveIuranSetting(
  payload: {
    year: number;
    monthly_amount: number;
    due_day: number;
  }
) {
  return apiRequest<
    import("../types/api").IuranSetting
  >(
    `/iuran/settings/${payload.year}`,
    {
      method: "PUT",
      headers: {
        "Content-Type":
          "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

export function recordIuranPayment(
  payload: {
    user_id: string;
    year: number;
    month: number;
    amount?: number;
    paid_at?: string;
    payment_method?: string;
    reference_no?: string;
    notes?: string;
  }
) {
  return apiRequest<unknown>(
    "/iuran/payments",
    {
      method: "POST",
      headers: {
        "Content-Type":
          "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

/* =========================================================
   KADER
========================================================= */

export function getKaderMasters() {
  return apiRequest<
    import("../types/api").KaderMaster[]
  >("/kader");
}

export function createKaderMaster(
  payload: {
    nip: string;
    nama: string;
    email?: string | null;
    phone?: string | null;
    alamat?: string | null;
    jabatan?: string | null;
    village_id?: string | null;
    status?: string;
  }
) {
  return apiRequest<
    import("../types/api").KaderMaster
  >(
    "/kader",
    {
      method: "POST",
      headers: {
        "Content-Type":
          "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

export function updateKaderMaster(
  kaderId: string,
  payload: Partial<
    import("../types/api").KaderMaster
  >
) {
  return apiRequest<
    import("../types/api").KaderMaster
  >(
    `/kader/${kaderId}`,
    {
      method: "PUT",
      headers: {
        "Content-Type":
          "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}

export function deleteKaderMaster(
  kaderId: string
) {
  return apiRequest<{
    success: boolean;
    message: string;
  }>(
    `/kader/${kaderId}`,
    {
      method: "DELETE",
    }
  );
}
/* =========================================================
   ANGGOTA
========================================================= */

export interface AnggotaMaster {
  id: string;
  nama: string;
  nip?: string | null;
  phone?: string | null;
  status: string;
  created_at?: string;
  updated_at?: string;
}


export function getAnggotaMasters() {
  return apiRequest<AnggotaMaster[]>(
    "/anggota"
  );
}


export function createAnggotaMaster(
  payload: {
    nama: string;
    nip?: string | null;
    phone?: string | null;
    status?: string;
  }
) {
  return apiRequest<AnggotaMaster>(
    "/anggota",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}


export function updateAnggotaMaster(
  anggotaId: string,
  payload: Partial<AnggotaMaster>
) {
  return apiRequest<AnggotaMaster>(
    `/anggota/${anggotaId}`,
    {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    }
  );
}


export function deleteAnggotaMaster(
  anggotaId: string
) {
  return apiRequest<{
    success: boolean;
    message: string;
  }>(
    `/anggota/${anggotaId}`,
    {
      method: "DELETE",
    }
  );
}
/* =========================================================
   NOTIFICATIONS
========================================================= */

export function getNotifications(
  unreadOnly = false
) {
  return apiRequest<
    import("../types/api").NotificationResponse
  >(
    `/notifications?unread_only=${
      unreadOnly
        ? "true"
        : "false"
    }`
  );
}

export function markNotificationRead(
  notificationId: string
) {
  return apiRequest<{
    success: boolean;
  }>(
    `/notifications/${notificationId}/read`,
    {
      method: "PATCH",
    }
  );
}

export function runIuranReminder() {
  return apiRequest<{
    generated: number;
    members_unpaid: number;
    total_outstanding: number;
    sender: string;
  }>(
    "/notifications/run-iuran",
    {
      method: "POST",
    }
  );
}

/* =========================================================
   BENDAHARA
========================================================= */

export function getBendaharaSummary() {
  return apiRequest<{
    total_pemasukan: number;
    total_pengeluaran: number;
    saldo_kas: number;
    transaksi_bulan_ini: number;
  }>(
    "/iuran/bendahara-summary"
  );
}

/* =========================================================
   ADMIN DATABASE
   KHUSUS SUPER ADMIN
========================================================= */

export function resetOperationalDatabase(
  confirmation: string
) {
  return apiRequest<{
    success: boolean;
    message: string;
    deleted?: Record<string, number>;
  }>(
    "/admin/database/reset-data",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        confirmation,
      }),
    }
  );
}

/* =========================================================
   SIGA PKB / KADER DASHBOARD
========================================================= */

export interface SigaPkbKaderDashboard {
  peserta_kb_aktif: number;
  peserta_kb_dropout: number;
  kesertaan_kb: number;
  jumlah_dana: number;
  kader_aktif: number;
  kehadiran: number;
  bkb: number;
  bkl: number;
  bkr: number;
  uppka: number;
  pikr: number;
}

export async function getSigaPkbKaderDashboard(
  params?: Record<string, string>
) {
  const query = new URLSearchParams(
    params || {}
  ).toString();

  return apiRequest<SigaPkbKaderDashboard>(
    `/dashboard/siga-pkb-kader${
      query
        ? `?${query}`
        : ""
    }`
  );
}

/* =========================================================
   LINK AKUN SIGA KE USER
========================================================= */

export function linkSigaAccountToUser(
  accountId: string,
  userId: string
) {
  return apiRequest<SigaAccount>(
    `/siga-accounts/${accountId}/link-user?user_id=${encodeURIComponent(
      userId
    )}`,
    {
      method: "PUT",
    }
  );
}
export function getPkbSigaAccounts() {
  return apiRequest<{
    id: string;
    username: string;
    district_id: string | null;
    district_name?: string | null;
    siga_district_id?: string | null;
    is_active: boolean;
  }[]>("/pkb/siga-accounts");
}

export function getPkbSigaVillages(accountId: string) {
  return apiRequest<{
    id: string;
    siga_id?: string | null;
    code: string;
    name: string;
    district_id: string;
    district_name: string;
  }[]>(`/pkb/siga-villages/${accountId}`);
}

/* =========================================================
   SIGA KAMPUNG KB EKSTERNAL
========================================================= */

export interface SigaKampungKbResponse {
  data?: unknown[];
  total?: number;
  [key: string]: unknown;
}

export function getSigaKampungKb() {
  const filter = encodeURIComponent(JSON.stringify({
    provinsiId: "12",
    kabupatenId: "149",
    kecamatanId: "448",
    kelurahanId: "0",
    rwId: "0",
    rtId: "0",
  }));

  return fetch(
    `https://siga-api-gateway.bkkbn.go.id/poktan/siga/poktan/getListSetaraPoktan?filterPencarian=${filter}&jenisPoktan=kkb`,
    {
      headers: {
        Accept: "application/json, text/plain, */*",
        Authorization: `Bearer ${import.meta.env.VITE_SIGA_TOKEN || ""}`,
      },
    }
  ).then((res) => {
    if (!res.ok) throw new Error("Data Kampung KB SIGA gagal dimuat");
    return res.json() as Promise<SigaKampungKbResponse>;
  });
}
