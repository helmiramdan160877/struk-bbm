import { ROLE_PERMISSIONS } from "../config/permissions";
import type { Permission } from "../config/permissions";
import type { Role, User } from "../types/auth";

export function getUserRole(user: User | null): Role | null {
  if (!user?.role) return null;
  const value = typeof user.role === "string" ? user.role : user.role.name;
  const normalized = value.toUpperCase() as Role;
  return normalized in ROLE_PERMISSIONS ? normalized : null;
}

export function hasPermission(user: User | null, permission: Permission): boolean {
  const role = getUserRole(user);
  if (!role || !(role in ROLE_PERMISSIONS)) return false;
  return ROLE_PERMISSIONS[role as keyof typeof ROLE_PERMISSIONS].includes(permission);
}

export function isRole(user: User | null, roles: Role | Role[]): boolean {
  const role = getUserRole(user);
  if (!role) return false;
  return (Array.isArray(roles) ? roles : [roles]).includes(role);
}
