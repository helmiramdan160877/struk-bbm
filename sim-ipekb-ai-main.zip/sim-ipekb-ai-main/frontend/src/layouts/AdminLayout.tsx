import { useEffect, useMemo, useState, type ReactNode } from "react";
import Icon from "../components/Icon";
import { navSections } from "../config/navigation";
import { hasPermission } from "../auth/permissions";
import type { User } from "../types/auth";
import type { AppNotification } from "../types/api";
import { getNotifications, markNotificationRead } from "../services/api";

interface AdminLayoutProps {
  children: ReactNode;
  activePage: string;
  onNavigate: (page: string) => void;
  onLogout: () => void;
  user: User;
}

function roleLabel(user: User) {
  const raw = typeof user.role === "string" ? user.role : user.role?.name;
  return (raw || "USER").replaceAll("_", " ");
}

export default function AdminLayout({ children, activePage, onNavigate, onLogout, user }: AdminLayoutProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({ "Menu Utama": true });

  const loadNotifications = async () => {
    try {
      const data = await getNotifications(false);
      setNotifications(data.items);
      setUnreadCount(data.unread_count);
    } catch {
      // Notifikasi tidak boleh mengganggu navigasi utama bila backend belum di-upgrade.
    }
  };

  useEffect(() => {
    const initial = window.setTimeout(() => void loadNotifications(), 0);
    const timer = window.setInterval(() => void loadNotifications(), 60000);
    return () => { window.clearTimeout(initial); window.clearInterval(timer); };
  }, []);

  const visibleSections = useMemo(
    () => navSections
      .map((section) => ({ ...section, items: section.items.filter((item) => hasPermission(user, item.permission)) }))
      .filter((section) => section.items.length > 0),
    [user],
  );

  const activeItem = useMemo(
    () => visibleSections.flatMap((section) => section.items).find((item) => item.id === activePage),
    [activePage, visibleSections],
  );

  const activeSectionTitle = useMemo(
    () => visibleSections.find((section) => section.items.some((item) => item.id === activePage))?.title,
    [activePage, visibleSections],
  );

  const toggleSection = (title: string) => {
    setOpenSections((current) => ({ ...current, [title]: !current[title] }));
  };

  const go = (id: string) => {
    onNavigate(id);
    setMobileOpen(false);
    setProfileOpen(false);
    setNotificationOpen(false);
  };

  const sidebar = (
    <div className="flex h-full flex-col bg-white text-slate-700">
      <div className="flex h-[60px] items-center border-b border-slate-100 px-4">
        <button type="button" onClick={() => go("dashboard")} className="flex min-w-0 items-center gap-3 text-left">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-white">
            <img src="/logo-kemendukbangga.png" alt="Logo Kemendukbangga" className="h-full w-full object-contain" />
          </div>
          <div className="min-w-0"><div className="truncate text-[12px] font-black tracking-tight text-slate-900">SIM IPEKB AI</div><div className="mt-0.5 truncate text-[8px] font-semibold uppercase tracking-[0.13em] text-slate-400">Integrated Management</div></div>
        </button>
      </div>

      <nav className="sidebar-scroll flex-1 overflow-y-auto px-3 py-4">
        {visibleSections.map((section) => {
          const expanded = section.title === activeSectionTitle || (openSections[section.title] ?? section.title === "Menu Utama");
          const sectionActive = section.items.some((item) => item.id === activePage);

          return (
            <div key={section.title} className="mb-2 last:mb-1">
              <button
                type="button"
                onClick={() => toggleSection(section.title)}
                aria-expanded={expanded}
                className={`flex min-h-9 w-full items-center gap-2 rounded-xl px-3 text-left transition ${sectionActive ? "bg-slate-50 text-slate-700" : "text-slate-400 hover:bg-slate-50 hover:text-slate-600"}`}
              >
                <span className="truncate text-[9px] font-extrabold uppercase tracking-[0.13em]">{section.title}</span>
                <span className="ml-auto rounded-md bg-slate-100 px-1.5 py-0.5 text-[8px] font-black text-slate-400">{section.items.length}</span>
                <Icon name="chevronDown" size={13} className={`shrink-0 transition-transform ${expanded ? "rotate-180" : ""}`}/>
              </button>

              {expanded && (
                <div className="mt-1 space-y-1 pl-1">
                  {section.items.map((item) => {
                    const active = activePage === item.id;
                    return (
                      <button
                        type="button"
                        key={item.id}
                        onClick={() => go(item.id)}
                        className={`group flex min-h-10 w-full items-center gap-3 rounded-xl px-3 text-left transition ${active ? "bg-blue-50 text-blue-700" : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"}`}
                      >
                        <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg ${active ? "bg-white text-blue-600 shadow-sm ring-1 ring-blue-100" : "text-slate-400 group-hover:text-blue-600"}`}><Icon name={item.icon} size={16}/></span>
                        <span className={`truncate text-[11px] ${active ? "font-extrabold" : "font-semibold"}`}>{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      <div className="border-t border-slate-100 p-3">
        <div className="rounded-xl bg-slate-50 px-3 py-2.5"><div className="truncate text-[10px] font-extrabold text-slate-700">{roleLabel(user)}</div><div className="mt-0.5 truncate text-[9px] text-slate-400">Akses sesuai role</div></div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f6f8fc] text-slate-800">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[238px] border-r border-slate-200/80 bg-white lg:block">{sidebar}</aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button type="button" aria-label="Tutup menu" onClick={() => setMobileOpen(false)} className="absolute inset-0 bg-slate-950/40 backdrop-blur-[2px]"/>
          <aside className="relative h-full w-[286px] max-w-[86vw] border-r border-slate-200 bg-white shadow-2xl">{sidebar}</aside>
        </div>
      )}

      <div className="min-h-screen lg:pl-[238px]">
        <header className="sticky top-0 z-30 border-b border-slate-200/80 bg-white/95 backdrop-blur-xl">
          <div className="flex h-[60px] items-center justify-between gap-3 px-4 sm:px-5 xl:px-6">
            <div className="flex min-w-0 items-center gap-3">
              <button type="button" onClick={() => setMobileOpen(true)} className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 lg:hidden"><Icon name="menu" size={19}/></button>
              <div className="min-w-0">
                <div className="text-[9px] font-extrabold uppercase tracking-[0.16em] text-blue-500">SIM IPEKB AI</div>
                <h1 className="mt-0.5 truncate text-[14px] font-black tracking-tight text-slate-900">{activeItem?.label || "SIM IPEKB AI"}</h1>
              </div>
            </div>

            <div className="flex shrink-0 items-center gap-1.5">
              <div className="relative">
                <button type="button" aria-label="Notifikasi" onClick={() => { setNotificationOpen((value) => !value); setProfileOpen(false); if (!notificationOpen) void loadNotifications(); }} className="relative grid h-8 w-8 place-items-center rounded-lg border border-slate-200 bg-white text-slate-500 hover:bg-slate-50">
                  <Icon name="bell" size={14}/>
                  {unreadCount > 0 && <span className="absolute -right-1 -top-1 grid min-h-4 min-w-4 place-items-center rounded-full bg-red-500 px-1 text-[7px] font-black text-white">{unreadCount > 9 ? "9+" : unreadCount}</span>}
                </button>
                {notificationOpen && (
                  <div className="absolute right-0 mt-2 w-[330px] max-w-[82vw] overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl shadow-slate-200/70">
                    <div className="flex items-center justify-between border-b border-slate-100 px-3 py-2.5"><div><div className="text-[10px] font-black text-slate-800">Notifikasi</div><div className="text-[8px] text-slate-400">Tagihan kas dan informasi akun</div></div><span className="rounded-full bg-blue-50 px-2 py-1 text-[8px] font-black text-blue-600">{unreadCount} baru</span></div>
                    <div className="max-h-[360px] overflow-y-auto p-1.5">
                      {notifications.length === 0 ? <div className="px-3 py-8 text-center text-[9px] text-slate-400">Belum ada notifikasi.</div> : notifications.map((item) => <button key={item.id} type="button" onClick={async()=>{ if(!item.is_read){await markNotificationRead(item.id); await loadNotifications();} }} className={`w-full rounded-lg px-3 py-2.5 text-left hover:bg-slate-50 ${item.is_read ? "" : "bg-blue-50/50"}`}><div className="flex items-start gap-2"><span className={`mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full ${item.is_read?"bg-slate-200":"bg-blue-500"}`}/><div className="min-w-0"><div className="text-[9px] font-black text-slate-800">{item.title}</div><div className="mt-1 text-[8px] leading-4 text-slate-500">{item.message}</div><div className="mt-1 text-[7px] font-semibold uppercase tracking-wide text-slate-400">WA: {item.whatsapp_status}</div></div></div></button>)}
                    </div>
                  </div>
                )}
              </div>
              <div className="relative">
              <button type="button" title="Buka menu profil" aria-expanded={profileOpen} aria-label="Buka menu profil" onClick={() => { setProfileOpen((value) => !value); setNotificationOpen(false); }} className="flex h-10 items-center gap-2 rounded-xl border border-transparent px-1.5 transition hover:border-slate-200 hover:bg-slate-50">
                <div className="grid h-8 w-8 shrink-0 place-items-center overflow-hidden rounded-xl bg-blue-600 text-xs font-black text-white shadow-sm shadow-blue-200">{user.photo ? <img src={user.photo} alt="Foto profil" className="h-full w-full object-cover" /> : (user.full_name || user.username || "U").trim().charAt(0).toUpperCase()}</div>
                <span className="hidden max-w-28 truncate text-left sm:block"><span className="block truncate text-[10px] font-black text-slate-800">{user.full_name || user.username}</span><span className="block truncate text-[8px] text-slate-400">{roleLabel(user)}</span></span>
                <Icon name="chevronDown" size={14} className={`text-slate-400 transition ${profileOpen ? "rotate-180" : ""}`}/>
              </button>

              {profileOpen && (
                <div className="absolute right-0 mt-2 w-64 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl shadow-slate-200/70">
                  <button type="button" onClick={() => go("profile")} className="flex w-full items-center gap-3 border-b border-slate-100 bg-slate-50/70 p-4 text-left transition hover:bg-blue-50/60"><div className="grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-2xl bg-blue-600 text-sm font-black text-white">{user.photo ? <img src={user.photo} alt="Foto profil" className="h-full w-full object-cover" /> : (user.full_name || user.username || "U").trim().charAt(0).toUpperCase()}</div><div className="min-w-0"><div className="truncate text-xs font-black text-slate-900">{user.full_name || user.username}</div><div className="mt-1 truncate text-[10px] text-slate-400">@{user.username}</div><div className="mt-2 inline-flex rounded-lg bg-blue-100 px-2 py-1 text-[8px] font-black text-blue-700">{roleLabel(user)}</div></div></button>
                  <div className="p-2"><button type="button" title="Edit profil & akun" onClick={() => go("profile")} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-xs font-bold text-slate-700 hover:bg-slate-50"><Icon name="edit" size={16}/> Edit profil & akun</button><button type="button" title="Keluar" onClick={onLogout} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-xs font-bold text-red-600 hover:bg-red-50"><Icon name="logout" size={16}/> Keluar dari aplikasi</button></div>
                </div>
              )}
              </div>
            </div>
          </div>
        </header>

        <main className="p-4 sm:p-5 xl:p-6">{children}</main>
      </div>
    </div>
  );
}
