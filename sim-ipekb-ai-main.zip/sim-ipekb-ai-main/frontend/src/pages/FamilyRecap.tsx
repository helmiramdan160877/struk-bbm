import { useEffect, useMemo, useState, type FormEvent } from "react";
import Icon from "../components/Icon";
import MiniSwal from "../components/MiniSwal";
import {
  createFamily,
  deleteFamily,
  deleteFamilyMember,
  getFamilies,
  getFamilyMembers,
  getVillages,
  updateFamily,
  updateFamilyMember,
} from "../services/api";
import type { Family, FamilyListResponse, FamilyMember, Village } from "../types/api";
import type { User } from "../types/auth";
import { hasPermission, isRole } from "../auth/permissions";

const emptyResponse: FamilyListResponse = { items: [], total: 0, page: 1, limit: 10, total_pages: 0 };

type Tab = "families" | "members";

export default function FamilyRecap({ user }: { user: User }) {
  const canCreate = hasPermission(user, "families.manage");
  const superAdmin = isRole(user, ["SUPER_ADMIN", "SUPERADMIN"]);
  const [tab, setTab] = useState<Tab>("members");
  const [families, setFamilies] = useState<FamilyListResponse>(emptyResponse);
  const [members, setMembers] = useState<FamilyMember[]>([]);
  const [villages, setVillages] = useState<Village[]>([]);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [editFamily, setEditFamily] = useState<Family | null>(null);
  const [editMember, setEditMember] = useState<FamilyMember | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<{ type: "family" | "member"; item: Family | FamilyMember } | null>(null);
  const [deleting, setDeleting] = useState(false);

  const villageMap = useMemo(() => new Map(villages.map((v) => [v.id, v.name])), [villages]);

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const [familyData, memberData, villageData] = await Promise.all([
        getFamilies(page, limit),
        getFamilyMembers(),
        getVillages().catch(() => [] as Village[]),
      ]);
      setFamilies(familyData);
      setMembers(memberData);
      setVillages(villageData);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Data keluarga gagal dimuat.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let active = true;
    Promise.all([getFamilies(page, limit), getFamilyMembers(), getVillages().catch(() => [] as Village[])])
      .then(([familyData, memberData, villageData]) => { if (active) { setFamilies(familyData); setMembers(memberData); setVillages(villageData); setError(""); } })
      .catch((err: unknown) => { if (active) setError(err instanceof Error ? err.message : "Data keluarga gagal dimuat."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [page, limit]);

  const filteredFamilies = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return families.items;
    return families.items.filter((x) => [x.family_card_number, x.head_of_family, x.address, villageMap.get(x.village_id)]
      .some((value) => String(value || "").toLowerCase().includes(needle)));
  }, [families.items, query, villageMap]);

  const filteredMembers = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return members;
    return members.filter((x) => [x.full_name, x.nik, x.family_card_number, x.birth_date]
      .some((value) => String(value || "").toLowerCase().includes(needle)));
  }, [members, query]);

  const memberPageItems = useMemo(() => {
    const start = (page - 1) * limit;
    return filteredMembers.slice(start, start + limit);
  }, [filteredMembers, page, limit]);

  const total = tab === "families" ? families.total : filteredMembers.length;
  const totalPages = tab === "families" ? Math.max(families.total_pages, 1) : Math.max(Math.ceil(filteredMembers.length / limit), 1);

  const removeFamily = async (item: Family) => {
    if (!superAdmin) return;
    setDeleteTarget({ type: "family", item });
  };

  const removeMember = async (item: FamilyMember) => {
    if (!superAdmin) return;
    setDeleteTarget({ type: "member", item });
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      if (deleteTarget.type === "family") await deleteFamily(deleteTarget.item.id);
      else await deleteFamilyMember(deleteTarget.item.id);
      setDeleteTarget(null); setPage(1); await load();
    } catch (err) { setError(err instanceof Error ? err.message : "Data gagal dihapus."); }
    finally { setDeleting(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-xl font-black tracking-tight text-slate-900">Data Keluarga & Individu</h2>
          <p className="mt-1 text-xs text-slate-500">Data otomatis dibatasi sesuai wilayah binaan akun yang login.</p>
        </div>
        <div className="flex gap-2">
          <button type="button" onClick={() => void load()} className="inline-flex h-9 items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 text-[11px] font-bold text-slate-700"><Icon name="refresh" size={14} className={loading ? "animate-spin" : ""}/> Muat Ulang</button>
          {canCreate && <button type="button" onClick={() => setCreateOpen(true)} className="inline-flex h-9 items-center gap-2 rounded-lg bg-blue-600 px-3 text-[11px] font-bold text-white"><Icon name="plus" size={14}/> Tambah Keluarga</button>}
        </div>
      </div>

      {error && <div className="border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-800">{error}</div>}

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="inline-flex w-fit rounded-lg border border-slate-200 bg-white p-1">
          <button type="button" onClick={() => { setTab("members"); setPage(1); }} className={`rounded-md px-3 py-1.5 text-[11px] font-bold ${tab === "members" ? "bg-blue-600 text-white" : "text-slate-600"}`}>Individu</button>
          <button type="button" onClick={() => { setTab("families"); setPage(1); }} className={`rounded-md px-3 py-1.5 text-[11px] font-bold ${tab === "families" ? "bg-blue-600 text-white" : "text-slate-600"}`}>Keluarga</button>
        </div>
        <div className="relative w-full sm:w-80"><Icon name="search" size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/><input value={query} onChange={(e) => { setQuery(e.target.value); setPage(1); }} placeholder="Cari data..." className="h-9 w-full rounded-lg border border-slate-300 bg-white pl-9 pr-3 text-[11px] outline-none focus:border-blue-500"/></div>
      </div>

      <section className="bg-white">
        <div className="mb-4 flex items-center gap-2 text-[11px] font-bold text-slate-800"><Icon name="clipboard" size={15}/><span>Data Keluarga & Individu</span></div>
        <div className="overflow-x-auto border border-slate-300 bg-white">
          {tab === "members" ? (
            <table className="w-full min-w-225 border-collapse text-[11px]">
              <thead><tr className="bg-white text-center font-bold text-slate-900"><Th>No</Th><Th>Nama</Th><Th>NIK</Th><Th>Kode Keluarga</Th><Th>Tanggal Lahir</Th><Th>Usia</Th>{superAdmin && <Th>Aksi</Th>}</tr></thead>
              <tbody>
                {loading ? <LoadingRow cols={superAdmin ? 7 : 6}/> : memberPageItems.length === 0 ? <EmptyRow cols={superAdmin ? 7 : 6}/> : memberPageItems.map((item, index) => (
                  <tr key={item.id} className="hover:bg-slate-50"><Td center>{(page - 1) * limit + index + 1}</Td><Td>{item.full_name}</Td><Td center>{item.nik}</Td><Td center>{item.family_card_number || item.family_id.slice(0, 8)}</Td><Td center>{formatDate(item.birth_date)}</Td><Td center>{item.age ?? ageFromDate(item.birth_date)}</Td>{superAdmin && <Td center><div className="flex justify-center gap-1"><Action icon="edit" title="Edit" onClick={() => setEditMember(item)}/><Action icon="trash" title="Hapus" danger onClick={() => void removeMember(item)}/></div></Td>}</tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="w-full min-w-237.5 border-collapse text-[11px]">
              <thead><tr className="bg-white text-center font-bold text-slate-900"><Th>No</Th><Th>Kode Keluarga</Th><Th>Kepala Keluarga</Th><Th>Alamat</Th><Th>RT/RW</Th><Th>Desa/Kelurahan</Th><Th>Status</Th>{superAdmin && <Th>Aksi</Th>}</tr></thead>
              <tbody>
                {loading ? <LoadingRow cols={superAdmin ? 8 : 7}/> : filteredFamilies.length === 0 ? <EmptyRow cols={superAdmin ? 8 : 7}/> : filteredFamilies.map((item, index) => (
                  <tr key={item.id} className="hover:bg-slate-50"><Td center>{(page - 1) * limit + index + 1}</Td><Td center>{item.family_card_number}</Td><Td>{item.head_of_family}</Td><Td>{item.address}</Td><Td center>{item.rt || "-"}/{item.rw || "-"}</Td><Td>{villageMap.get(item.village_id) || "-"}</Td><Td center>{item.is_active ? "Aktif" : "Nonaktif"}</Td>{superAdmin && <Td center><div className="flex justify-center gap-1"><Action icon="edit" title="Edit" onClick={() => setEditFamily(item)}/><Action icon="trash" title="Hapus" danger onClick={() => void removeFamily(item)}/></div></Td>}</tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[10px] text-slate-700">
          <select value={limit} onChange={(e) => { setLimit(Number(e.target.value)); setPage(1); }} className="h-7 rounded border border-slate-300 bg-white px-2 outline-none"><option value={10}>10</option><option value={25}>25</option><option value={50}>50</option></select>
          <span>Total {total}</span>
          <div className="ml-auto flex items-center gap-1"><button type="button" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))} className="h-7 rounded border border-slate-300 px-2 disabled:opacity-40">‹</button><span className="px-2">{page} / {totalPages}</span><button type="button" disabled={page >= totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))} className="h-7 rounded border border-slate-300 px-2 disabled:opacity-40">›</button></div>
        </div>
      </section>

      {createOpen && canCreate && <FamilyModal title="Tambah Keluarga" villages={villages} onClose={() => setCreateOpen(false)} onSave={async (payload) => { await createFamily(payload as Omit<Family, "id" | "is_active">); setCreateOpen(false); await load(); }}/>} 
      {editFamily && superAdmin && <FamilyModal title="Edit Keluarga" family={editFamily} villages={villages} onClose={() => setEditFamily(null)} onSave={async (payload) => { await updateFamily(editFamily.id, payload); setEditFamily(null); await load(); }}/>} 
      {editMember && superAdmin && <MemberModal member={editMember} onClose={() => setEditMember(null)} onSave={async (payload) => { await updateFamilyMember(editMember.id, payload); setEditMember(null); await load(); }}/>} 
      <MiniSwal open={Boolean(deleteTarget)} title="Konfirmasi hapus" text={`Hapus ${deleteTarget?.type === "family" ? `keluarga ${(deleteTarget.item as Family).head_of_family}` : `data ${(deleteTarget?.item as FamilyMember | undefined)?.full_name || "ini"}`} secara permanen?`} tone="danger" confirmText="Hapus" busy={deleting} onCancel={() => setDeleteTarget(null)} onConfirm={() => void confirmDelete()}/>
    </div>
  );
}

function Th({ children }: { children: React.ReactNode }) { return <th className="border border-slate-300 px-3 py-2.5">{children}</th>; }
function Td({ children, center=false }: { children: React.ReactNode; center?: boolean }) { return <td className={`border border-slate-300 px-3 py-2 ${center ? "text-center" : ""}`}>{children}</td>; }
function EmptyRow({ cols }: { cols: number }) { return <tr><td colSpan={cols} className="border border-slate-300 px-4 py-3 text-center text-[10px] text-slate-600">Data tidak ditemukan</td></tr>; }
function LoadingRow({ cols }: { cols: number }) { return <tr>{Array.from({length: cols}).map((_, i) => <td key={i} className="border border-slate-300 px-3 py-3"><div className="h-2 animate-pulse bg-slate-100"/></td>)}</tr>; }
function Action({ icon, title, onClick, danger=false }: { icon: "edit" | "trash"; title: string; onClick: () => void; danger?: boolean }) { return <button type="button" title={title} onClick={onClick} className={`grid h-7 w-7 place-items-center rounded border ${danger ? "border-red-200 text-red-600 hover:bg-red-50" : "border-slate-300 text-slate-600 hover:bg-blue-50 hover:text-blue-700"}`}><Icon name={icon} size={13}/></button>; }
function formatDate(value?: string | null) { if (!value) return "-"; const d = new Date(`${value}T00:00:00`); return Number.isNaN(d.getTime()) ? value : new Intl.DateTimeFormat("id-ID").format(d); }
function ageFromDate(value?: string | null) { if (!value) return "-"; const birth = new Date(`${value}T00:00:00`); if (Number.isNaN(birth.getTime())) return "-"; const now = new Date(); let age = now.getFullYear() - birth.getFullYear(); const m = now.getMonth() - birth.getMonth(); if (m < 0 || (m === 0 && now.getDate() < birth.getDate())) age -= 1; return age; }

interface FamilyForm { village_id: string; family_card_number: string; head_of_family: string; address: string; rt: string; rw: string; postal_code: string; is_active?: boolean; }
function FamilyModal({ title, family, villages, onClose, onSave }: { title: string; family?: Family; villages: Village[]; onClose: () => void; onSave: (payload: FamilyForm) => Promise<void> }) {
  const [form, setForm] = useState<FamilyForm>({ village_id: family?.village_id || "", family_card_number: family?.family_card_number || "", head_of_family: family?.head_of_family || "", address: family?.address || "", rt: family?.rt || "", rw: family?.rw || "", postal_code: family?.postal_code || "", is_active: family?.is_active ?? true });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const submit = async (e: FormEvent) => { e.preventDefault(); setSaving(true); setError(""); try { await onSave(form); } catch (err) { setError(err instanceof Error ? err.message : "Gagal menyimpan data."); } finally { setSaving(false); } };
  return <Modal title={title} onClose={onClose}><form onSubmit={submit} className="space-y-4">{error && <div className="bg-red-50 p-3 text-xs text-red-700">{error}</div>}<div className="grid gap-3 sm:grid-cols-2"><Field label="Kode Keluarga / No. KK" value={form.family_card_number} onChange={(v) => setForm({...form,family_card_number:v})} required/><Field label="Kepala Keluarga" value={form.head_of_family} onChange={(v) => setForm({...form,head_of_family:v})} required/><label><Label>Desa/Kelurahan *</Label><select required value={form.village_id} onChange={(e) => setForm({...form,village_id:e.target.value})} className="h-10 w-full rounded-lg border border-slate-300 bg-white px-3 text-xs"><option value="">Pilih wilayah</option>{villages.map((v)=><option key={v.id} value={v.id}>{v.code} - {v.name}</option>)}</select></label><Field label="RT" value={form.rt} onChange={(v) => setForm({...form,rt:v})}/><Field label="RW" value={form.rw} onChange={(v) => setForm({...form,rw:v})}/><Field label="Kode Pos" value={form.postal_code} onChange={(v) => setForm({...form,postal_code:v})}/><label className="sm:col-span-2"><Label>Alamat *</Label><textarea required value={form.address} onChange={(e)=>setForm({...form,address:e.target.value})} rows={3} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs"/></label></div><Buttons onClose={onClose} saving={saving}/></form></Modal>;
}

function MemberModal({ member, onClose, onSave }: { member: FamilyMember; onClose: () => void; onSave: (payload: Partial<FamilyMember>) => Promise<void> }) {
  const [form, setForm] = useState({ full_name: member.full_name, nik: member.nik, gender: member.gender, birth_place: member.birth_place || "", birth_date: member.birth_date || "", relationship_to_head: member.relationship_to_head, is_alive: member.is_alive });
  const [saving, setSaving] = useState(false); const [error,setError]=useState("");
  const submit=async(e:FormEvent)=>{e.preventDefault();setSaving(true);setError("");try{await onSave(form);}catch(err){setError(err instanceof Error?err.message:"Gagal menyimpan data.");}finally{setSaving(false);}};
  return <Modal title="Edit Individu" onClose={onClose}><form onSubmit={submit} className="space-y-4">{error&&<div className="bg-red-50 p-3 text-xs text-red-700">{error}</div>}<div className="grid gap-3 sm:grid-cols-2"><Field label="Nama" value={form.full_name} onChange={(v)=>setForm({...form,full_name:v})} required/><Field label="NIK" value={form.nik} onChange={(v)=>setForm({...form,nik:v})} required/><Field label="Tempat Lahir" value={form.birth_place} onChange={(v)=>setForm({...form,birth_place:v})}/><Field label="Tanggal Lahir" type="date" value={form.birth_date} onChange={(v)=>setForm({...form,birth_date:v})}/><Field label="Jenis Kelamin" value={form.gender} onChange={(v)=>setForm({...form,gender:v})}/><Field label="Hubungan dengan KK" value={form.relationship_to_head} onChange={(v)=>setForm({...form,relationship_to_head:v})}/><label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={form.is_alive} onChange={(e)=>setForm({...form,is_alive:e.target.checked})}/> Masih aktif/hidup</label></div><Buttons onClose={onClose} saving={saving}/></form></Modal>;
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) { return <div className="fixed inset-0 z-90 grid place-items-center overflow-y-auto bg-slate-950/45 p-4"><div className="w-full max-w-2xl rounded-xl bg-white shadow-2xl"><div className="flex items-center justify-between border-b border-slate-200 px-5 py-4"><div className="text-sm font-black text-slate-900">{title}</div><button type="button" onClick={onClose} className="grid h-8 w-8 place-items-center rounded-lg bg-slate-100"><Icon name="close" size={15}/></button></div><div className="p-5">{children}</div></div></div>; }
function Label({ children }: { children: React.ReactNode }) { return <span className="mb-1 block text-[10px] font-bold text-slate-600">{children}</span>; }
function Field({ label, value, onChange, required=false, type="text" }: { label:string; value:string; onChange:(v:string)=>void; required?:boolean; type?:string }) { return <label><Label>{label}{required?" *":""}</Label><input required={required} type={type} value={value} onChange={(e)=>onChange(e.target.value)} className="h-10 w-full rounded-lg border border-slate-300 px-3 text-xs outline-none focus:border-blue-500"/></label>; }
function Buttons({ onClose, saving }: { onClose: () => void; saving: boolean }) { return <div className="flex justify-end gap-2 border-t border-slate-100 pt-4"><button type="button" onClick={onClose} className="h-9 rounded-lg border border-slate-300 px-4 text-xs font-bold">Batal</button><button disabled={saving} className="h-9 rounded-lg bg-blue-600 px-4 text-xs font-bold text-white disabled:opacity-50">{saving?"Menyimpan...":"Simpan"}</button></div>; }
