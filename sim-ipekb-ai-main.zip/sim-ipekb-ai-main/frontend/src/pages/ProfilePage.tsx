import { useRef, useState } from "react";
import Icon from "../components/Icon";
import { updateMyProfile } from "../services/api";
import type { User } from "../types/auth";

interface ProfilePageProps {
  user: User;
  onUpdated: (u: User) => void;
}

export default function ProfilePage({
  user,
  onUpdated,
}: ProfilePageProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [form, setForm] = useState({
    full_name: user.full_name || "",
    email: user.email || "",
    phone: user.phone || "",
    photo: user.photo || "",
    password: "",
  });

  const [loading, setLoading] = useState(false);

  const [notice, setNotice] = useState<{
    tone: "success" | "error";
    text: string;
  } | null>(null);

  const roleName =
    typeof user.role === "string"
      ? user.role
      : user.role?.name || "USER";

  const planType =
    (user as User & { plan_type?: string }).plan_type || "FREE";

  const villageNames =
    (user as User & {
      villages?: Array<{ name?: string }>;
    }).villages?.map((v) => v.name).filter(Boolean) || [];

  const handlePhoto = (file: File | undefined) => {
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setNotice({
        tone: "error",
        text: "File yang dipilih harus berupa gambar.",
      });
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      setNotice({
        tone: "error",
        text: "Ukuran foto maksimal 2 MB.",
      });
      return;
    }

    const reader = new FileReader();

    reader.onload = () => {
      const result = reader.result;

      if (typeof result === "string") {
        setForm((current) => ({
          ...current,
          photo: result,
        }));

        setNotice(null);
      }
    };

    reader.readAsDataURL(file);
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!form.full_name.trim()) {
      setNotice({
        tone: "error",
        text: "Nama tidak boleh kosong.",
      });
      return;
    }

    setLoading(true);
    setNotice(null);

    try {
      const payload = {
        full_name: form.full_name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        photo: form.photo || null,
        password: form.password.trim() || undefined,
      };

      const updated = await updateMyProfile(payload);

      onUpdated(updated);

      setForm((current) => ({
        ...current,
        password: "",
      }));

      setNotice({
        tone: "success",
        text: "Profil berhasil diperbarui.",
      });
    } catch (err) {
      setNotice({
        tone: "error",
        text:
          err instanceof Error
            ? err.message
            : "Profil gagal diperbarui.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      {/* HEADER */}
      <div>
        <div className="flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-blue-50 text-blue-600">
            <Icon name="user" size={18} />
          </div>

          <div>
            <h2 className="text-[17px] font-black text-slate-900">
              Profil & Akun
            </h2>

            <p className="mt-0.5 text-[10px] text-slate-500">
              Kelola informasi profil dan keamanan akun Anda.
            </p>
          </div>
        </div>
      </div>

      {/* NOTIFICATION */}
      {notice && (
        <div
          className={`flex items-center gap-2 rounded-xl border px-3 py-2.5 text-[10px] font-bold ${
            notice.tone === "success"
              ? "border-emerald-100 bg-emerald-50 text-emerald-700"
              : "border-red-100 bg-red-50 text-red-700"
          }`}
        >
          <Icon
            name={notice.tone === "success" ? "check" : "alert"}
            size={14}
          />

          <span>{notice.text}</span>
        </div>
      )}

      <form
        onSubmit={save}
        className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"
      >
        {/* PROFILE HEADER */}
        <div className="border-b border-slate-100 bg-slate-50/70 px-5 py-5">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              {/* FOTO */}
              <button
                type="button"
                title="Ganti foto profil"
                onClick={() => fileInputRef.current?.click()}
                className="group relative grid h-20 w-20 shrink-0 place-items-center overflow-hidden rounded-2xl bg-blue-50 text-xl font-black text-blue-600 ring-1 ring-slate-200"
              >
                {form.photo ? (
                  <img
                    src={form.photo}
                    alt="Foto profil"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <span>
                    {(form.full_name || user.username || "U")
                      .trim()
                      .charAt(0)
                      .toUpperCase()}
                  </span>
                )}

                <span className="absolute inset-0 flex items-center justify-center bg-slate-950/50 text-white opacity-0 transition group-hover:opacity-100">
                  <Icon name="edit" size={18} />
                </span>
              </button>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) =>
                  handlePhoto(e.target.files?.[0])
                }
              />

              <div className="min-w-0">
                <div className="truncate text-sm font-black text-slate-900">
                  {user.full_name || user.username}
                </div>

                <div className="mt-1 text-[10px] text-slate-400">
                  @{user.username}
                </div>

                <div className="mt-2 flex flex-wrap gap-1.5">
                  <span className="rounded-lg bg-blue-50 px-2 py-1 text-[8px] font-black uppercase text-blue-700">
                    {roleName.replaceAll("_", " ")}
                  </span>

                  <span
                    className={`rounded-lg px-2 py-1 text-[8px] font-black uppercase ${
                      planType === "PAID"
                        ? "bg-emerald-50 text-emerald-700"
                        : "bg-slate-100 text-slate-600"
                    }`}
                  >
                    Paket {planType}
                  </span>
                </div>
              </div>
            </div>

            <button
              type="button"
              title="Pilih foto profil"
              onClick={() => fileInputRef.current?.click()}
              className="flex h-9 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-[10px] font-bold text-slate-600 transition hover:bg-slate-50"
            >
              <Icon name="edit" size={14} />
              Ganti Foto
            </button>
          </div>

          <div className="mt-3 text-[8px] text-slate-400">
            Format gambar JPG, PNG, WEBP. Maksimal 2 MB.
          </div>
        </div>

        {/* INFORMASI YANG BOLEH DIUBAH */}
        <div className="p-5">
          <div className="mb-4">
            <div className="text-[11px] font-black uppercase tracking-wide text-slate-800">
              Informasi Profil
            </div>

            <div className="mt-1 text-[9px] text-slate-400">
              Informasi berikut dapat Anda ubah sendiri.
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field
              label="Nama Lengkap"
              value={form.full_name}
              onChange={(value) =>
                setForm((current) => ({
                  ...current,
                  full_name: value,
                }))
              }
            />

            <Field
              label="Email"
              type="email"
              value={form.email}
              onChange={(value) =>
                setForm((current) => ({
                  ...current,
                  email: value,
                }))
              }
            />

            <Field
              label="No. HP"
              value={form.phone}
              onChange={(value) =>
                setForm((current) => ({
                  ...current,
                  phone: value,
                }))
              }
            />

            <Field
              label="Username"
              value={user.username || ""}
              disabled
            />

            <Field
              label="NIP"
              value={(user as User & { nip?: string }).nip || ""}
              disabled
            />
          </div>

          {/* INFORMASI AKUN */}
          <div className="mt-7 border-t border-slate-100 pt-5">
            <div className="mb-4">
              <div className="text-[11px] font-black uppercase tracking-wide text-slate-800">
                Informasi Akun
              </div>

              <div className="mt-1 text-[9px] text-slate-400">
                Data kewenangan akun tidak dapat diubah dari halaman ini.
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <ReadOnlyField
                label="Role"
                value={roleName.replaceAll("_", " ")}
              />

              <ReadOnlyField
                label="Paket"
                value={planType}
              />

              <ReadOnlyField
                label="Desa Binaan"
                value={
                  villageNames.length > 0
                    ? villageNames.join(", ")
                    : "Sesuai penugasan"
                }
              />

              <ReadOnlyField
                label="Status Akun"
                value={
                  user.is_active === false
                    ? "Tidak Aktif"
                    : "Aktif"
                }
              />
            </div>
          </div>

          {/* PASSWORD */}
          <div className="mt-7 border-t border-slate-100 pt-5">
            <div className="mb-4">
              <div className="text-[11px] font-black uppercase tracking-wide text-slate-800">
                Keamanan Akun
              </div>

              <div className="mt-1 text-[9px] text-slate-400">
                Isi password hanya jika ingin mengganti password.
              </div>
            </div>

            <Field
              label="Password Baru"
              type="password"
              value={form.password}
              onChange={(value) =>
                setForm((current) => ({
                  ...current,
                  password: value,
                }))
              }
              placeholder="Kosongkan jika tidak ingin mengubah"
            />
          </div>

          {/* BUTTON */}
          <div className="mt-6 flex justify-end border-t border-slate-100 pt-5">
            <button
              type="submit"
              title="Simpan perubahan profil"
              disabled={loading}
              className="flex h-10 items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-[10px] font-black text-white shadow-sm shadow-blue-200 transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {loading ? (
                <>
                  <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white/40 border-t-white" />
                  Menyimpan...
                </>
              ) : (
                <>
                  <Icon name="check" size={15} />
                  Simpan Perubahan
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  disabled = false,
  placeholder,
}: {
  label: string;
  value: string;
  onChange?: (value: string) => void;
  type?: string;
  disabled?: boolean;
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[10px] font-bold text-slate-600">
        {label}
      </span>

      <input
        type={type}
        value={value}
        disabled={disabled}
        placeholder={placeholder}
        onChange={(e) => onChange?.(e.target.value)}
        className={`h-10 w-full rounded-xl border px-3 text-[11px] outline-none transition ${
          disabled
            ? "cursor-not-allowed border-slate-200 bg-slate-100 text-slate-400"
            : "border-slate-200 bg-slate-50 text-slate-800 focus:border-blue-400 focus:bg-white focus:ring-2 focus:ring-blue-50"
        }`}
      />
    </label>
  );
}

function ReadOnlyField({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div>
      <span className="mb-1.5 block text-[10px] font-bold text-slate-600">
        {label}
      </span>

      <div className="flex min-h-10 items-center rounded-xl border border-slate-200 bg-slate-100 px-3 text-[11px] font-semibold text-slate-500">
        {value || "-"}
      </div>
    </div>
  );
}