import { useEffect, useMemo, useState } from "react";
import type { User } from "../types/auth";
import type { IuranMemberSummary, Pkb } from "../types/api";
import Icon from "../components/Icon";
import { createAnggotaFromPkb, getBendaharaSummary, getIuranMembers, getPkbList } from "../services/api";

interface Props { user: User; onNavigate: (page: string) => void; }
const MONTHS = ["Semua bulan", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];

export default function BendaharaDashboard({ user, onNavigate }: Props) {
  const [summary, setSummary] = useState({ total_pemasukan: 0, total_pengeluaran: 0, saldo_kas: 0, transaksi_bulan_ini: 0 });
  const [unpaidMembers, setUnpaidMembers] = useState<IuranMemberSummary[]>([]);
  const [pkbs, setPkbs] = useState<Pkb[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ pkb_id: "", username: "", password: "", plan_type: "FREE" as "FREE" | "PAID", plan_expires_at: "" });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 5;

  const filteredMembers = useMemo(() => unpaidMembers.filter((item) => `${item.full_name} ${item.username} ${item.nip || ""}`.toLowerCase().includes(search.toLowerCase())), [search, unpaidMembers]);
  const pageCount = Math.max(1, Math.ceil(filteredMembers.length / pageSize));
  const visibleMembers = filteredMembers.slice((page - 1) * pageSize, page * pageSize);

  useEffect(() => {
    getPkbList().then(setPkbs).catch(() => setPkbs([]));
    getBendaharaSummary().then(setSummary).catch(() => undefined);
    getIuranMembers(year, month || undefined).then((members) => {
      setUnpaidMembers(members.filter((item) => Number(item.total_outstanding || 0) > 0));
    }).catch(() => setUnpaidMembers([]));
  }, [year, month]);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setSaving(true); setMessage("");
    try {
      await createAnggotaFromPkb({ ...form, plan_expires_at: form.plan_type === "PAID" && form.plan_expires_at ? new Date(form.plan_expires_at).toISOString() : null });
      setMessage("Akun anggota berhasil dibuat."); setOpen(false);
      setForm({ pkb_id: "", username: "", password: "", plan_type: "FREE", plan_expires_at: "" });
    } catch (err) { setMessage(err instanceof Error ? err.message : "Gagal membuat akun anggota."); }
    finally { setSaving(false); }
  }

  return <div className="space-y-5">
    <div className="flex items-center justify-between rounded-2xl border bg-white p-6 transition duration-200 hover:-translate-y-0.5 hover:border-blue-200 hover:shadow-lg hover:shadow-blue-100/60">
      <div><h1 className="text-xl font-black text-[#142b4c]">Dashboard Bendahara</h1><p className="mt-2 text-sm text-slate-500">Ringkasan pengelolaan keuangan IPKB</p><p className="mt-2 text-xs text-slate-400">Selamat datang, {user.full_name}</p></div>
      <button type="button" title="Tambah anggota dari data PKB" aria-label="Tambah anggota dari data PKB" onClick={() => setOpen(true)} className="grid h-10 w-10 place-items-center rounded-xl bg-blue-600 text-white"><Icon name="plus" size={18}/></button>
    </div>
    {message && <div className="rounded-xl border border-blue-100 bg-blue-50 px-3 py-2 text-[10px] font-bold text-blue-700">{message}</div>}
    <div className="grid gap-4 md:grid-cols-4">{[["Total Pemasukan",summary.total_pemasukan],["Total Pengeluaran",summary.total_pengeluaran],["Saldo Kas",summary.saldo_kas],["Transaksi Bulan Ini",summary.transaksi_bulan_ini]].map(([label,value])=><div key={String(label)} className="rounded-xl border bg-white p-5 transition duration-200 hover:-translate-y-1 hover:border-blue-200 hover:shadow-lg hover:shadow-blue-100/60"><p className="text-xs text-slate-500">{label}</p><h2 className="mt-2 text-2xl font-bold">{typeof value === "number" && String(label).includes("Transaksi") ? value : `Rp ${Number(value).toLocaleString("id-ID")}`}</h2></div>)}</div>
    <div className="grid gap-4 xl:grid-cols-2">
      <section className="overflow-hidden rounded-2xl border border-rose-100 bg-white shadow-sm transition duration-200 hover:-translate-y-1 hover:border-rose-200 hover:shadow-lg hover:shadow-rose-100/60">
        <div className="flex flex-wrap gap-2 border-b border-slate-100 p-3"><select value={year} onChange={(e) => { setYear(Number(e.target.value)); setPage(1); }} className="h-8 rounded-lg border border-slate-200 px-2 text-[10px] font-bold">{[year - 2, year - 1, year, year + 1].map((item) => <option key={item}>{item}</option>)}</select><select value={month || ""} onChange={(e) => { setMonth(e.target.value ? Number(e.target.value) : null); setPage(1); }} className="h-8 rounded-lg border border-slate-200 px-2 text-[10px] font-bold">{MONTHS.map((item, index) => <option key={item} value={index || ""}>{item}</option>)}</select><input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Cari nama / NIP" className="h-8 min-w-0 flex-1 rounded-lg border border-slate-200 px-2 text-[10px] outline-none focus:border-rose-300" /></div>
        <div className="max-h-72 overflow-y-auto"><table className="min-w-full text-left text-[10px]"><thead className="bg-slate-50 text-[8px] font-black uppercase tracking-wide text-slate-400"><tr><th className="px-5 py-2.5">Anggota dari Master PKB</th><th className="px-3 py-2.5">Belum bayar</th><th className="px-5 py-2.5 text-right">Tunggakan</th></tr></thead><tbody className="divide-y divide-slate-100">{visibleMembers.map((item) => <tr key={item.pkb_id || item.user_id}><td className="px-5 py-3"><div className="font-bold text-slate-800">{item.full_name}</div><div className="mt-0.5 text-[8px] text-slate-400">@{item.username}{item.nip ? ` • ${item.nip}` : ""}</div></td><td className="px-3 py-3 text-slate-500">{item.unpaid_months} bulan</td><td className="px-5 py-3 text-right font-black text-rose-700">Rp {Number(item.total_outstanding).toLocaleString("id-ID")}</td></tr>)}{visibleMembers.length === 0 && <tr><td colSpan={3} className="px-5 py-10 text-center text-[10px] text-slate-400">Tidak ada anggota yang menunggak pada filter ini.</td></tr>}</tbody></table></div>
        <div className="flex items-center justify-between border-t border-slate-100 px-5 py-3 text-[9px] text-slate-400"><span>{filteredMembers.length} anggota ditemukan</span><div className="flex items-center gap-2"><button type="button" title="Halaman sebelumnya" disabled={page === 1} onClick={() => setPage((value) => value - 1)} className="grid h-7 w-7 place-items-center rounded-lg border border-slate-200 disabled:opacity-40"><Icon name="chevronLeft" size={13}/></button><span>Halaman {page} / {pageCount}</span><button type="button" title="Halaman berikutnya" disabled={page === pageCount} onClick={() => setPage((value) => value + 1)} className="grid h-7 w-7 place-items-center rounded-lg border border-slate-200 disabled:opacity-40"><Icon name="chevronRight" size={13}/></button></div></div>
        <div className="border-t border-slate-100 p-3"><button type="button" onClick={() => onNavigate("iuran")} className="flex h-8 w-full items-center justify-center gap-2 rounded-lg bg-rose-50 text-[10px] font-black text-rose-700 hover:bg-rose-100">Buka detail iuran <Icon name="chevronRight" size={13}/></button></div>
      </section>
      <section className="overflow-hidden rounded-2xl border border-emerald-100 bg-white shadow-sm transition duration-200 hover:-translate-y-1 hover:border-emerald-200 hover:shadow-lg hover:shadow-emerald-100/60">
        <div className="flex items-center justify-between border-b border-emerald-100 bg-emerald-50/60 px-5 py-4"><div><h2 className="font-bold text-[#142b4c]">Pengeluaran</h2><p className="mt-1 text-[10px] text-slate-500">Ringkasan pengeluaran yang ditandatangani bendahara</p></div><Icon name="check" size={18} className="text-emerald-600"/></div>
        <div className="p-5"><div className="flex items-center justify-between rounded-xl bg-slate-50 p-4"><div><div className="text-[9px] font-black uppercase tracking-wide text-slate-400">Total pengeluaran</div><div className="mt-1 text-xl font-black text-slate-800">Rp {Number(summary.total_pengeluaran).toLocaleString("id-ID")}</div></div><span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-100 px-2.5 py-1 text-[9px] font-black text-emerald-700"><Icon name="check" size={12}/> Ditandatangani bendahara</span></div><div className="mt-4 flex items-start gap-3 text-[10px] leading-5 text-slate-500"><Icon name="info" size={15} className="mt-0.5 shrink-0 text-slate-400"/><span>Rincian transaksi pengeluaran ditampilkan dari modul Kas & Iuran. Gunakan tombol di bawah untuk melihat dan mengelola datanya.</span></div><button type="button" onClick={() => onNavigate("iuran")} className="mt-4 flex h-9 w-full items-center justify-center gap-2 rounded-lg border border-emerald-200 text-[10px] font-black text-emerald-700 hover:bg-emerald-50">Buka Kas & Iuran <Icon name="wallet" size={13}/></button></div>
      </section>
    </div>
    {open && <div className="fixed inset-0 z-[100] grid place-items-center bg-slate-950/35 p-4 backdrop-blur-sm"><form onSubmit={submit} className="w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl"><div className="flex items-center justify-between"><div><h3 className="text-sm font-black text-slate-900">Tambah Anggota</h3><p className="mt-1 text-[9px] text-slate-400">Ambil identitas dari Master PKB. Bendahara tidak membuat user PKB.</p></div><button type="button" title="Tutup" onClick={() => setOpen(false)} className="grid h-8 w-8 place-items-center rounded-lg bg-slate-100"><Icon name="close" size={14}/></button></div><div className="mt-4 space-y-3"><label className="block"><span className="text-[10px] font-bold text-slate-600">Pilih PKB</span><select required value={form.pkb_id} onChange={e=>{const pkb=pkbs.find(x=>x.id===e.target.value);setForm({...form,pkb_id:e.target.value,username:pkb?.nip||""})}} className="input-mini"><option value="">Pilih PKB</option>{pkbs.map(p=><option key={p.id} value={p.id}>{p.nama} — {p.nip}</option>)}</select></label><label className="block"><span className="text-[10px] font-bold text-slate-600">Username</span><input required value={form.username} onChange={e=>setForm({...form,username:e.target.value})} className="input-mini"/></label><label className="block"><span className="text-[10px] font-bold text-slate-600">Password</span><input required minLength={6} type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} className="input-mini"/></label><label className="block"><span className="text-[10px] font-bold text-slate-600">Paket</span><select value={form.plan_type} onChange={e=>setForm({...form,plan_type:e.target.value as "FREE"|"PAID"})} className="input-mini"><option value="FREE">FREE — Lihat saja</option><option value="PAID">PAID — Operasional</option></select></label>{form.plan_type === "PAID" && <label className="block"><span className="text-[10px] font-bold text-slate-600">Berlaku sampai</span><input required type="date" value={form.plan_expires_at} onChange={e=>setForm({...form,plan_expires_at:e.target.value})} className="input-mini"/></label>}</div><div className="mt-5 flex justify-end gap-2"><button type="button" title="Batal" onClick={()=>setOpen(false)} className="grid h-9 w-9 place-items-center rounded-lg border"><Icon name="close" size={14}/></button><button disabled={saving} title="Buat anggota" className="grid h-9 w-9 place-items-center rounded-lg bg-blue-600 text-white"><Icon name="check" size={15}/></button></div></form></div>}
  </div>;
}
