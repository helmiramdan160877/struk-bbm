import Icon, { type IconName } from "../components/Icon";

type ModuleKind = "skp" | "evisum" | "arsip";

const configs: Record<ModuleKind, { title: string; subtitle: string; icon: IconName; columns: string[] }> = {
  skp: {
    title: "SKP",
    subtitle: "Sasaran Kinerja Pegawai PKB",
    icon: "clipboard",
    columns: ["No", "Tahun", "Periode", "Sasaran Kinerja", "Target", "Realisasi", "Status", "Aksi"],
  },
  evisum: {
    title: "e-Visum",
    subtitle: "Dokumentasi dan verifikasi kegiatan lapangan PKB",
    icon: "fileCheck",
    columns: ["No", "Tanggal", "Nomor e-Visum", "Kegiatan", "Lokasi", "Status", "Aksi"],
  },
  arsip: {
    title: "Arsip Digital",
    subtitle: "Penyimpanan dokumen administrasi PKB",
    icon: "folder",
    columns: ["No", "Nama Dokumen", "Kategori", "Tanggal", "Keterangan", "Status", "Aksi"],
  },
};

export default function PkbWorkModulePage({ kind }: { kind: ModuleKind }) {
  const config = configs[kind];
  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-black tracking-tight text-slate-900">{config.title}</h2>
        <p className="mt-1 text-xs text-slate-500">{config.subtitle}</p>
      </div>

      <section className="bg-white">
        <div className="mb-4 flex items-center gap-2 text-[11px] font-bold text-slate-800">
          <Icon name={config.icon} size={15}/>
          <span>{config.title}</span>
        </div>
        <div className="overflow-x-auto border border-slate-300 bg-white">
          <table className="w-full min-w-[850px] border-collapse text-[11px]">
            <thead>
              <tr className="bg-white text-center font-bold text-slate-900">
                {config.columns.map((column) => <th key={column} className="border border-slate-300 px-3 py-2.5">{column}</th>)}
              </tr>
            </thead>
            <tbody>
              <tr>
                <td colSpan={config.columns.length} className="border border-slate-300 px-4 py-3 text-center text-[10px] text-slate-600">Data tidak ditemukan</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="mt-1.5 flex items-center gap-2 text-[10px] text-slate-700">
          <select defaultValue="10" className="h-7 rounded border border-slate-300 bg-white px-2 outline-none">
            <option>10</option><option>25</option><option>50</option>
          </select>
          <span>Total 0</span>
        </div>
      </section>
    </div>
  );
}
