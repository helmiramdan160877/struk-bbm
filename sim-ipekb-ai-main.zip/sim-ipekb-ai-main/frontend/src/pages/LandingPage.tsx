import { useEffect, useState } from "react";
import Icon from "../components/Icon";

interface Props { onLogin: () => void; }

const slides = [
  { eyebrow: "SIPEKB AI", title: "Satu platform untuk pengelolaan IPEKB yang lebih terarah.", text: "Kelola data keluarga, wilayah, PKB, Kader, laporan, keuangan, dan integrasi SIGA dari satu dashboard.", icon: "dashboard" as const },
  { eyebrow: "DATA KELUARGA", title: "Data keluarga lebih cepat ditemukan dan dipantau.", text: "Rekapitulasi dan data anggota tersaji dalam alur kerja yang ringkas untuk kebutuhan lapangan.", icon: "family" as const },
  { eyebrow: "INTEGRASI SIGA", title: "Sinkronisasi data lebih praktis dan terjadwal.", text: "Hubungkan akun SIGA dan siapkan sinkronisasi otomatis agar data tetap terbarui.", icon: "sync" as const },
];

export default function LandingPage({ onLogin }: Props) {
  const [index, setIndex] = useState(0);
  useEffect(() => {
    const timer = window.setInterval(() => setIndex(v => (v + 1) % slides.length), 5000);
    return () => window.clearInterval(timer);
  }, []);
  const slide = slides[index];
  return (
    <main className="min-h-screen overflow-hidden bg-[#f5f8fd] text-slate-800">
      <header className="relative z-20 flex h-[72px] items-center justify-between border-b border-white/70 bg-white/85 px-5 backdrop-blur-xl sm:px-10">
        <div className="flex items-center gap-3"><img src="/logo-kemendukbangga.png" className="h-10 w-10 object-contain" alt="Kemendukbangga"/><div><div className="text-sm font-black text-slate-900">SIPEKB AI</div><div className="text-[8px] font-bold uppercase tracking-[.18em] text-slate-400">Integrated Population Platform</div></div></div>
        <button onClick={onLogin} className="inline-flex h-9 items-center gap-2 rounded-xl bg-blue-600 px-4 text-[10px] font-black text-white shadow-lg shadow-blue-200 hover:bg-blue-700"><Icon name="user" size={14}/> Masuk</button>
      </header>
      <section className="relative mx-auto grid min-h-[calc(100vh-72px)] max-w-7xl items-center gap-10 px-5 py-12 sm:px-10 lg:grid-cols-[1.02fr_.98fr] lg:px-16">
        <div className="absolute -left-32 top-10 h-80 w-80 rounded-full bg-blue-300/25 blur-3xl"/><div className="absolute -right-20 bottom-0 h-96 w-96 rounded-full bg-cyan-200/30 blur-3xl"/>
        <div className="relative">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-blue-100 bg-white px-3 py-1.5 text-[9px] font-black uppercase tracking-[.15em] text-blue-600 shadow-sm"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500"/> Sistem terintegrasi & aman</div>
          <div key={index} className="animate-[siga-drop_.35s_ease-out]"><div className="text-[10px] font-black uppercase tracking-[.2em] text-blue-500">{slide.eyebrow}</div><h1 className="mt-3 max-w-2xl text-4xl font-black leading-[1.08] tracking-[-.04em] text-[#142b4c] sm:text-5xl xl:text-6xl">{slide.title}</h1><p className="mt-5 max-w-xl text-sm leading-7 text-slate-500">{slide.text}</p></div>
          <div className="mt-8 flex items-center gap-3"><button onClick={onLogin} title="Masuk ke aplikasi" className="inline-flex h-11 items-center gap-2 rounded-xl bg-[#142b4c] px-5 text-xs font-black text-white shadow-xl shadow-slate-300 hover:bg-blue-700">Masuk ke aplikasi <Icon name="chevronRight" size={15}/></button><div className="flex gap-1.5">{slides.map((_,i)=><button key={i} onClick={()=>setIndex(i)} aria-label={`Slide ${i+1}`} className={`h-1.5 rounded-full transition-all ${i===index?"w-7 bg-blue-600":"w-2 bg-slate-300"}`}/>)}</div></div>
          <div className="mt-10 grid max-w-xl grid-cols-3 border-y border-slate-200 py-4"><div><div className="text-lg font-black text-[#142b4c]">24/7</div><div className="mt-1 text-[9px] font-bold uppercase tracking-wide text-slate-400">Siap digunakan</div></div><div className="border-l border-slate-200 pl-4"><div className="text-lg font-black text-[#142b4c]">AI</div><div className="mt-1 text-[9px] font-bold uppercase tracking-wide text-slate-400">Insight terarah</div></div><div className="border-l border-slate-200 pl-4"><div className="text-lg font-black text-[#142b4c]">SIGA</div><div className="mt-1 text-[9px] font-bold uppercase tracking-wide text-slate-400">Terintegrasi</div></div></div>
        </div>
        <div className="relative">
          <div className="relative overflow-hidden rounded-[32px] border border-white bg-[#102a52] p-5 shadow-[0_30px_80px_rgba(24,62,115,.2)] sm:p-7">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_15%_15%,rgba(72,148,255,.42),transparent_35%),radial-gradient(circle_at_90%_85%,rgba(42,208,190,.2),transparent_38%)]"/>
            <div className="relative rounded-2xl border border-white/10 bg-white/10 p-5 backdrop-blur"><div className="flex items-center justify-between"><div className="flex items-center gap-2"><span className="grid h-9 w-9 place-items-center rounded-xl bg-white/15 text-white"><Icon name={slide.icon} size={17}/></span><div><div className="text-[10px] font-black text-white">SIPEKB AI</div><div className="text-[8px] text-blue-200">Operational dashboard</div></div></div><span className="rounded-full bg-emerald-400/15 px-2 py-1 text-[8px] font-black text-emerald-200">ONLINE</span></div>
              <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">{["Data Keluarga","Wilayah SIGA","PKB / Kader","Sinkronisasi","Laporan","Keuangan"].map((x,i)=><div key={x} className="rounded-2xl border border-white/10 bg-white/[.07] p-4"><div className="text-[17px] font-black text-white">{["33K+","33","120+","AUTO","24/7","AKTIF"][i]}</div><div className="mt-1 text-[8px] font-semibold text-blue-100/70">{x}</div></div>)}</div>
              <div className="mt-4 flex items-center gap-3 border-t border-white/10 pt-4"><span className="grid h-8 w-8 place-items-center rounded-lg bg-cyan-300/15 text-cyan-200"><Icon name="sparkles" size={15}/></span><div><div className="text-[10px] font-black text-white">AI siap membantu membaca pola data</div><div className="mt-0.5 text-[8px] text-blue-100/65">Ringkasan, prioritas wilayah, dan rekomendasi kerja.</div></div></div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
