interface DashboardProps {
  totalFamilies: number;
}

export default function Dashboard({
  totalFamilies,
}: DashboardProps) {
  return (
    <div className="space-y-6">

      {/* WELCOME */}
      <div>
        <h1 className="text-2xl font-bold text-slate-800">
          Dashboard
        </h1>

        <p className="mt-1 text-sm text-slate-500">
          Ringkasan data Sistem Informasi IPEKB AI
        </p>
      </div>

      {/* CARDS */}
      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">

        <div className="rounded-2xl bg-white p-6 shadow-sm">
          <p className="text-sm text-slate-500">
            Total Keluarga
          </p>

          <p className="mt-3 text-3xl font-bold text-blue-600">
            {totalFamilies.toLocaleString("id-ID")}
          </p>

          <p className="mt-2 text-xs text-slate-400">
            Data keluarga terdaftar
          </p>
        </div>

        <div className="rounded-2xl bg-white p-6 shadow-sm">
          <p className="text-sm text-slate-500">
            Anggota Keluarga
          </p>

          <p className="mt-3 text-3xl font-bold text-green-600">
            -
          </p>

          <p className="mt-2 text-xs text-slate-400">
            Akan terhubung ke Family Members
          </p>
        </div>

        <div className="rounded-2xl bg-white p-6 shadow-sm">
          <p className="text-sm text-slate-500">
            Desa Binaan
          </p>

          <p className="mt-3 text-3xl font-bold text-purple-600">
            -
          </p>

          <p className="mt-2 text-xs text-slate-400">
            Berdasarkan akun pengguna
          </p>
        </div>

        <div className="rounded-2xl bg-white p-6 shadow-sm">
          <p className="text-sm text-slate-500">
            Status Sistem
          </p>

          <p className="mt-3 text-2xl font-bold text-green-600">
            Online
          </p>

          <p className="mt-2 text-xs text-slate-400">
            FastAPI terhubung
          </p>
        </div>

      </div>

      {/* INFO */}
      <div className="rounded-2xl bg-white p-6 shadow-sm">

        <h2 className="text-lg font-bold text-slate-800">
          Informasi Sistem
        </h2>

        <p className="mt-2 text-sm leading-6 text-slate-500">
          SIM IPEKB AI digunakan untuk pengelolaan data
          keluarga, anggota keluarga, wilayah binaan,
          PKB, serta integrasi dan sinkronisasi data SIGA.
        </p>

      </div>

    </div>
  );
}