import { useEffect, useMemo, useState, type FormEvent } from "react";
import { getPkbList } from "../services/api";
import type { Pkb } from "../types/api";
import Icon from "../components/Icon";
import MiniSwal from "../components/MiniSwal";
import {
  getAnggotaMasters,
  createAnggotaMaster,
  updateAnggotaMaster,
  deleteAnggotaMaster,
  type AnggotaMaster,
} from "../services/api";
import { hasPermission, isRole } from "../auth/permissions";
import type { User } from "../types/auth";


interface Props {
  user: User;
}


const emptyForm = {
  nama:"",
  nip:"",
  phone:"",
  status:"AKTIF"
};


export default function AnggotaPage({user}:Props){

const canManage = hasPermission(user,"anggota.manage");
const superAdmin = isRole(user,["SUPER_ADMIN","SUPERADMIN"]);


const [items,setItems]=useState<AnggotaMaster[]>([]);
const [loading,setLoading]=useState(true);
const [saving,setSaving]=useState(false);

const [query,setQuery]=useState("");

const [pageSize,setPageSize]=useState(10);
const [page,setPage]=useState(1);

const [modalOpen,setModalOpen]=useState(false);
const [editTarget,setEditTarget]=useState<AnggotaMaster|null>(null);

const [deleteTarget,setDeleteTarget]=useState<AnggotaMaster|null>(null);

const [form,setForm]=useState(emptyForm);
const [pkbList,setPkbList]=useState<Pkb[]>([]);
const [pkbOpen,setPkbOpen]=useState(false);
const [pkbSearch,setPkbSearch]=useState("");


const [alert,setAlert]=useState({
 open:false,
 title:"",
 text:"",
 tone:"danger" as "danger"|"success"
});


const load=async()=>{

setLoading(true);

try{

const data=await getAnggotaMasters();

setItems(data);

}catch(err:any){

setAlert({
 open:true,
 title:"Gagal Memuat Data",
 text:err.message || "Data anggota gagal dimuat",
 tone:"danger"
});

}

finally{
setLoading(false);
}

};


useEffect(()=>{
load();
},[]);



const filtered=useMemo(()=>{

const q=query.toLowerCase().trim();

if(!q) return items;


return items.filter(x=>
[
x.nama,
x.nip,
x.phone,
x.status
]
.some(v=>
String(v||"")
.toLowerCase()
.includes(q)
)

);

},[items,query]);



const pagedItems=useMemo(()=>{

if(pageSize===0)return filtered;

const start=(page-1)*pageSize;

return filtered.slice(
start,
start+pageSize
);

},[filtered,page,pageSize]);
const totalPages =
pageSize===0
? 1
: Math.ceil(filtered.length / pageSize);


const openCreate=()=>{

setEditTarget(null);
setForm(emptyForm);
setModalOpen(true);

};



const openEdit=(item:AnggotaMaster)=>{

setEditTarget(item);

setForm({
nama:item.nama,
nip:item.nip||"",
phone:item.phone||"",
status:item.status
});

setModalOpen(true);

};



const submit=async(e:FormEvent)=>{

e.preventDefault();


if(
 !form.nama.trim() ||
 !form.nip.trim() ||
 !form.phone.trim()
){

setAlert({
open:true,
title:"Data Belum Lengkap",
text:"Nama, nip, dan No WhatsApp wajib diisi.",
tone:"danger"
});

return;

}

setSaving(true);


try{

const payload={
nama:form.nama.trim(),
nip:form.nip.trim(),
phone:form.phone.trim(),
status:form.status
};


if(editTarget){

await updateAnggotaMaster(
editTarget.id,
payload
);

}else{

await createAnggotaMaster(payload);

}


setModalOpen(false);

setAlert({
open:true,
title:"Berhasil",
text:`Data anggota berhasil ${
editTarget?"diperbarui":"ditambahkan"
}`,
tone:"success"
});


load();


}catch(err:any){

setAlert({
open:true,
title:"Gagal Menyimpan",
text:err.message,
tone:"danger"
});

}

finally{

setSaving(false);

}

};




const remove=async()=>{

if(!deleteTarget)return;


setSaving(true);


try{

await deleteAnggotaMaster(deleteTarget.id);

setDeleteTarget(null);

setAlert({
open:true,
title:"Berhasil",
text:"Data anggota berhasil dihapus",
tone:"success"
});


load();


}catch(err:any){

setAlert({
open:true,
title:"Gagal",
text:err.message,
tone:"danger"
});

}

finally{

setSaving(false);

}

};



return (

<div className="space-y-4">


<div className="flex justify-between items-end">

<div>

<h2 className="text-[17px] font-black text-slate-900">
Master Anggota
</h2>

<p className="text-[10px] text-slate-500">
Data anggota untuk iuran dan notifikasi WhatsApp
</p>

</div>


<div className="flex gap-2">

<button
onClick={load}
title="refresh"
className="h-8 px-3 rounded-lg border text-[10px]"
>
<Icon name="refresh" size={12}/>
</button>


{canManage&&

<button
onClick={async()=>{
  setPkbList(await getPkbList());
  setPkbOpen(true);
}}
title="Tambah Anggota"
className="h-8 px-3 rounded-lg bg-blue-600 text-white text-[10px] font-bold"
>
+ 
</button>

}

</div>

</div>



<div className="rounded-xl border bg-white shadow-sm">


<div className="p-3 border-b flex justify-between">

<div>

<div className="font-black text-[11px]">
Data Master
</div>

<div className="text-[9px] text-slate-400">
{filtered.length} anggota
</div>

</div>


<input
value={query}
onChange={e=>{
setQuery(e.target.value);
setPage(1);
}}
placeholder="Cari nama, nip, WhatsApp..."
className="h-8 w-[250px] rounded border px-2 text-[10px]"
/>


</div>




<div className="overflow-x-auto">

<table className="w-full border-collapse text-[10px]">


<thead className="bg-slate-100">

<tr>
<th className="border px-1 py-2 text-center w-10">
No
</th>
<th className="border px-2 py-2 text-center">
Nama
</th>

<th className="border px-2 py-2 text-center">
NIP
</th>

<th className="border px-2 py-2 text-center">
No WhatsApp
</th>

<th className="border px-2 py-2 text-center">
Status
</th>

<th className="border px-1 py-2 text-center w-16">
Aksi
</th>


</tr>

</thead>



<tbody>


{loading ?

<tr>

<td colSpan={5}
className="py-10 text-center text-slate-400">
Memuat data...
</td>

</tr>


:

pagedItems.map((item,index)=>(


<tr key={item.id}
className="hover:bg-slate-50">
<td className="border px-1 py-0.5 text-center w-10">
  {(page-1)*pageSize + index + 1}
</td>

<td className="border px-2 py-1 text-center font-bold">
{item.nama}
</td>


<td className="border px-2 py-1 text-center font-mono">
{item.nip||"-"}
</td>


<td className="border px-2 py-0.5 text-center">
{item.phone||"-"}
</td>


<td className="border px-2 py-0.5 text-center">

<span className="rounded-full bg-emerald-50 px-2 py-1 text-[8px] font-bold text-emerald-700">

{item.status}

</span>

</td>



<td className="border px-2 py-0.5 text-center align-middle">

  <div className="flex items-center justify-center gap-1">

    <button
      onClick={()=>openEdit(item)}
      title="Edit Anggota"
      className="h-6 w-6 flex items-center justify-center border rounded hover:bg-slate-100"
    >
      <Icon name="edit" size={10}/>
    </button>


    {superAdmin &&

    <button
      onClick={()=>setDeleteTarget(item)}
      title="Hapus Anggota"
      className="h-6 w-6 flex items-center justify-center border rounded text-red-500 hover:bg-red-50"
    >
      <Icon name="trash" size={10}/>
    </button>

    }

  </div>

</td>

</tr>


))


}


</tbody>


</table>
<div className="
flex items-center justify-between
border-t
px-3 py-3
text-[10px]
text-slate-500
">

<div>
Total Data : {" "}
<span className="font-black text-slate-700">
{filtered.length}
</span>{" "}
Anggota
</div>


<div className="flex items-center gap-2">

<select
value={pageSize}
onChange={e=>{
setPageSize(Number(e.target.value));
setPage(1);
}}
className="
h-7 rounded border px-2 text-[10px]
"
>
<option value={5}>5</option>
<option value={10}>10</option>
<option value={20}>20</option>
<option value={50}>50</option>
<option value={0}>ALL</option>
</select>


<button
disabled={page<=1}
onClick={()=>setPage(p=>p-1)}
className="
h-7 w-7 rounded border
disabled:opacity-40
"
>
‹
</button>


<span className="font-bold text-slate-700">
{page}/{totalPages}
</span>


<button
disabled={page>=totalPages}
onClick={()=>setPage(p=>p+1)}
className="
h-7 w-7 rounded border
disabled:opacity-40
"
>
›
</button>

</div>

</div>
</div>



</div>
{pkbOpen && (

<div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4">

<div className="w-full max-w-md rounded-2xl bg-white shadow-xl">

<div className="flex justify-between border-b px-4 py-3">

<h3 className="font-black text-sm">
Pilih Data PKB
</h3>

<button
onClick={()=>setPkbOpen(false)}
>
✕
</button>

</div>


<div className="p-4 space-y-3">

<input
value={pkbSearch}
onChange={e=>setPkbSearch(e.target.value)}
placeholder="Cari nama / NIP..."
className="h-9 w-full rounded border px-3 text-xs"
/>


<div className="max-h-72 overflow-auto">

{pkbList
.filter(x=>
x.nama.toLowerCase()
.includes(pkbSearch.toLowerCase())
||
(x.nip||"")
.includes(pkbSearch)
)
.map(pkb=>(


<button
key={pkb.id}
onClick={async()=>{

try{

await createAnggotaMaster({

  nama: pkb.nama,
  nip: pkb.nip || "",
  phone: pkb.phone || "",
  status:"AKTIF"

});


setAlert({
  open:true,
  title:"Berhasil",
  text:`Data anggota ${pkb.nama} berhasil disimpan`,
  tone:"success"
});


setPkbOpen(false);

load();


}catch(err:any){


setAlert({
  open:true,
  title:"Data Sudah Ada",
  text: err.message || "Data anggota sudah terdaftar",
  tone:"danger"
});


}


}}
className="
w-full
text-left
rounded-lg
border
p-3
hover:bg-blue-50
"
>

<div className="font-bold text-xs">
{pkb.nama}
</div>

<div className="text-[10px] text-slate-500">
NIP : {pkb.nip || "-"}
<br/>
WA : {pkb.phone || "-"}
</div>


</button>


))}

</div>

</div>

</div>

</div>

)}


<MiniSwal
open={!!deleteTarget}
title="Hapus Anggota?"
text={`Data ${deleteTarget?.nama} akan dihapus`}
tone="danger"
confirmText="Hapus"
busy={saving}
onCancel={()=>setDeleteTarget(null)}
onConfirm={()=>void remove()}
/>


<MiniSwal
open={alert.open}
title={alert.title}
text={alert.text}
tone={alert.tone}
confirmText="OK"
onCancel={()=>setAlert({...alert,open:false})}
onConfirm={()=>setAlert({...alert,open:false})}
/>

{modalOpen && (

<div className="
fixed inset-0 z-50 
flex items-center justify-center 
bg-black/30 
p-4
">

<div className="
w-full max-w-md
rounded-2xl
bg-white
shadow-2xl
overflow-hidden
">


{/* HEADER */}
<div className="
flex items-center justify-between
border-b
px-5
py-4
">


<div>

<h3 className="
text-sm
font-black
text-slate-900
">

{editTarget ? "Edit Anggota" : "Tambah Anggota"}

</h3>

<p className="
text-[10px]
text-slate-400
mt-1
">

Lengkapi data anggota untuk kebutuhan iuran

</p>

</div>


<button
type="button"
onClick={()=>setModalOpen(false)}
title="Batal"
className="
h-9
w-9
flex
items-center
justify-center
rounded-xl
border
text-slate-500
hover:bg-slate-100
"
>

<Icon name="close" size={15}/>

</button>


</div>





<form
onSubmit={submit}
className="
space-y-4
p-5
"
>



<div>

<label className="
text-[10px]
font-bold
text-slate-600
">

Nama Anggota

</label>


<input

value={form.nama}

onChange={
e=>setForm({
...form,
nama:e.target.value
})
}

placeholder="Masukkan nama anggota"

className="
mt-1
h-10
w-full
rounded-xl
border
px-3
text-xs
outline-none
focus:border-blue-500
focus:ring-2
focus:ring-blue-100
"

/>

</div>





<div>

<label className="
text-[10px]
font-bold
text-slate-600
">

NIP

</label>


<input

value={form.nip}

onChange={
e=>setForm({
...form,
nip:e.target.value
})
}

placeholder="Masukkan nip"

className="
mt-1
h-10
w-full
rounded-xl
border
px-3
text-xs
outline-none
focus:border-blue-500
focus:ring-2
focus:ring-blue-100
"

/>

</div>





<div>

<label className="
text-[10px]
font-bold
text-slate-600
">

No WhatsApp

</label>


<input

value={form.phone}

onChange={
e=>setForm({
...form,
phone:e.target.value
})
}

placeholder="08xxxxxxxxxx"

className="
mt-1
h-10
w-full
rounded-xl
border
px-3
text-xs
outline-none
focus:border-blue-500
focus:ring-2
focus:ring-blue-100
"

/>

</div>





<div>

<label className="
text-[10px]
font-bold
text-slate-600
">

Status

</label>


<select

value={form.status}

onChange={
e=>setForm({
...form,
status:e.target.value
})
}

className="
mt-1
h-10
w-full
rounded-xl
border
px-3
text-xs
outline-none
focus:border-blue-500
"

>

<option value="AKTIF">
AKTIF
</option>

<option value="NONAKTIF">
NONAKTIF
</option>

</select>


</div>





{/* BUTTON */}

<div className="
flex
justify-end
gap-2
pt-3
">


<button

type="button"

onClick={()=>setModalOpen(false)}

title="Batal"

className="
h-9
w-9
flex
items-center
justify-center
rounded-xl
border
text-slate-500
hover:bg-slate-100
"

>

<Icon name="close" size={15}/>

</button>




<button

disabled={saving}

title="Simpan Data"

className="
h-9
w-9
flex
items-center
justify-center
rounded-xl
bg-blue-600
text-white
hover:bg-blue-700
disabled:opacity-50
"

>

<Icon name="save" size={15}/>

</button>

</div>




</form>


</div>

</div>

)}

</div>

);

}