import { useEffect, useMemo, useState } from "react";
import Icon from "../components/Icon";
import MiniSwal from "../components/MiniSwal";
import { hasPermission, isRole } from "../auth/permissions";
import { createPkb, deletePkb, getManageableVillages, getPkbList, getPkbWilayahBinaan, getPkbSigaAccounts, getPkbSigaVillages, updatePkb, updatePkbWilayahBinaan } from "../services/api";
import type { ManageableVillage, Pkb } from "../types/api";
import type { User } from "../types/auth";

interface PkbPageProps { user: User }

type PkbForm = {
  siga_account_id: string;
  nip: string;
  nik: string;
  nama: string;
  tempat_lahir: string;
  tanggal_lahir: string;
  jenis_kelamin: string;
  agama: string;
  pendidikan: string;
  jabatan: string;
  status_asn: string;
  golongan: string;
  email: string;
  phone: string;
  alamat: string;
  kecamatan: string;
  desa: string;
  wilayah_binaan: string;
  village_id: string;
  status: string;
};

const emptyForm: PkbForm = {
  siga_account_id: "",
  nip: "", nik: "", nama: "", tempat_lahir: "", tanggal_lahir: "", jenis_kelamin: "",
  agama: "", pendidikan: "", jabatan: "", status_asn: "", golongan: "", email: "",
  phone: "", alamat: "", kecamatan: "", desa: "", wilayah_binaan: "", village_id: "", status: "AKTIF",
};

export default function PkbPage({ user }: PkbPageProps) {
  const canManage = hasPermission(user, "pkb.manage");
  const superAdmin = isRole(user, ["SUPER_ADMIN", "SUPERADMIN"]);
  const [items, setItems] = useState<Pkb[]>([]);
  const [villages, setVillages] = useState<ManageableVillage[]>([]);
  const [sigaAccounts, setSigaAccounts] = useState<{id:string; username:string; district_id:string|null; district_name?:string|null; siga_district_id?:string|null; is_active:boolean}[]>([]);
  const [sigaVillages, setSigaVillages] = useState<{id:string; siga_id?:string|null; code:string; name:string; district_id:string; district_name:string}[]>([]);
  const [sigaVillageLoading, setSigaVillageLoading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Pkb | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [alertOpen, setAlertOpen] = useState(false);
  const [alertMessage, setAlertMessage] = useState("");
  const [editing, setEditing] = useState<Pkb | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Pkb | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [binaanTarget, setBinaanTarget] = useState<Pkb | null>(null);
  const [binaanIds, setBinaanIds] = useState<string[]>([]);
  const [binaanSaving, setBinaanSaving] = useState(false);
  const [form, setForm] = useState<PkbForm>(emptyForm);
  const [selectedVillageIds, setSelectedVillageIds] = useState<string[]>([]);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const load = async () => {
  setLoading(true);
  setError("");

  try {
    const [pkbList, villageList, accountList] = await Promise.all([
      getPkbList(),
      canManage
        ? getManageableVillages()
        : Promise.resolve([] as ManageableVillage[]),
      canManage
        ? getPkbSigaAccounts()
        : Promise.resolve([] as typeof sigaAccounts),
    ]);

    setItems(pkbList);
    setVillages(villageList);
    setSigaAccounts(accountList);

  } catch (err) {
    setError(
      err instanceof Error
        ? err.message
        : "Master PKB gagal dimuat."
    );
  } finally {
    setLoading(false);
  }
};

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const [pkbList, villageList, accountList] = await Promise.all([
          getPkbList(),
          canManage ? getManageableVillages() : Promise.resolve([] as ManageableVillage[]),
          canManage ? getPkbSigaAccounts() : Promise.resolve([] as typeof sigaAccounts),
        ]);
        if (!active) return;
        setItems(pkbList);
        setVillages(villageList);
        setSigaAccounts(accountList);
        setError("");
      } catch (err) {
        if (active) setError(err instanceof Error ? err.message : "Master PKB gagal dimuat.");
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => { active = false; };
  }, [canManage]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return items.filter((item) => !needle || [item.nama, item.nip, item.nik, item.kecamatan, item.desa, item.wilayah_binaan]
      .some((value) => String(value || "").toLowerCase().includes(needle)));
  }, [items, query]);

  const activeCount = items.filter((item) => (item.status || "AKTIF").toUpperCase() === "AKTIF").length;
  const asnCount = items.filter((item) =>
  ["PNS", "PPPK", "PPPK PARUH WAKTU"]
    .includes(String(item.status_asn || "").toUpperCase())
).length;
  const selectedSigaAccount = sigaAccounts.find((account) => account.id === form.siga_account_id);
  const paginatedItems =
    pageSize === -1
      ? filtered
      : filtered.slice(
          (page - 1) * pageSize,
          page * pageSize
        );

  const totalPage =
    pageSize === -1
      ? 1
      : Math.ceil(filtered.length / pageSize);
  // Desa SIGA selalu diambil langsung dari SIGA berdasarkan akun yang dipilih.
  useEffect(() => {
    if (!modalOpen || !form.siga_account_id) {
      setSigaVillages([]);
      setSigaVillageLoading(false);
      return;
    }

    let active = true;
    setSigaVillageLoading(true);
    setError("");

    if (selectedSigaAccount?.district_name) {
      setForm((current) => ({
        ...current,
        kecamatan: selectedSigaAccount.district_name || current.kecamatan,
      }));
    }

    getPkbSigaVillages(form.siga_account_id)
      .then((data) => {
        if (!active) return;
        setSigaVillages(data);
        const districtName = data[0]?.district_name || selectedSigaAccount?.district_name || "";
        if (districtName) {
          setForm((current) => ({ ...current, kecamatan: districtName }));
        }
      })
      .catch((err) => {
        if (!active) return;
        setSigaVillages([]);
        setError(err instanceof Error ? err.message : "Desa SIGA gagal dimuat.");
      })
      .finally(() => {
        if (active) setSigaVillageLoading(false);
      });

    return () => {
      active = false;
    };
  }, [modalOpen, form.siga_account_id, selectedSigaAccount?.district_name]);

  // Jika hanya ada satu akun SIGA aktif, pilih otomatis.
  useEffect(() => {
    if (!modalOpen || form.siga_account_id || sigaAccounts.length !== 1) return;
    const account = sigaAccounts[0];
    setForm((current) => ({
      ...current,
      siga_account_id: account.id,
      kecamatan: account.district_name || current.kecamatan,
      village_id: "",
      desa: "",
      wilayah_binaan: "",
    }));
  }, [modalOpen, form.siga_account_id, sigaAccounts]);

  const toggleVillage = (villageId: string) => {
  setSelectedVillageIds((current) => {

    const updated = current.includes(villageId)
      ? current.filter((id) => id !== villageId)
      : [...current, villageId];


    const selected = sigaVillages.filter((village) =>
      updated.includes(village.id)
    );


    const names = selected.map((village) => village.name);


    setForm((currentForm) => ({
      ...currentForm,
      village_id: updated[0] || "",
      desa: names.join(", "),
      wilayah_binaan: names.join(", "),
    }));


    return updated;
  });
};

  const openCreate = () => {
  setEditing(null);
  setForm(emptyForm);
  setSelectedVillageIds([]);
  setModalOpen(true);
};

  const openBinaan = async (item: Pkb) => {
    if (!superAdmin) return;
    setError("");
    try {
      const links = await getPkbWilayahBinaan(item.id);
      setBinaanIds(links.map((v) => v.id));
      setBinaanTarget(item);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Data desa binaan gagal dimuat.");
    }
  };

  const saveBinaan = async () => {
    if (!binaanTarget || !binaanIds.length) return;
    setBinaanSaving(true);
    setError("");
    try {
      await updatePkbWilayahBinaan(binaanTarget.id, binaanIds);
      setBinaanTarget(null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Desa binaan gagal disimpan.");
    } finally {
      setBinaanSaving(false);
    }
  };

  const openEdit = (item: Pkb) => {
    if (!superAdmin) return;
    setEditing(item);
    setForm({
      nip: item.nip || "", nik: item.nik || "", nama: item.nama || "", tempat_lahir: item.tempat_lahir || "",
      tanggal_lahir: item.tanggal_lahir || "", jenis_kelamin: item.jenis_kelamin || "", agama: item.agama || "",
      pendidikan: item.pendidikan || "", jabatan: item.jabatan || "", status_asn: item.status_asn || "",
      golongan: item.golongan || "", email: item.email || "", phone: item.phone || "", alamat: item.alamat || "",
      kecamatan: item.kecamatan || "", desa: item.desa || "", wilayah_binaan: item.wilayah_binaan || "",
      village_id: "", siga_account_id: item.siga_account_id || "", status: item.status || "AKTIF",
    });
    setSelectedVillageIds([]);
    setModalOpen(true);
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!canManage) return;
    setSaving(true);
    setError("");
    try {
     const payload = {

  nip: form.nip.trim(), 
  nik: form.nik.trim(), 
  nama: form.nama.trim(),

  tempat_lahir: form.tempat_lahir || null, 
  tanggal_lahir: form.tanggal_lahir || null,

  jenis_kelamin: form.jenis_kelamin || null, 
  agama: form.agama || null, 
  pendidikan: form.pendidikan || null,

  jabatan: form.jabatan || null, 
  status_asn: form.status_asn || null, 
  golongan: form.golongan || null,

  email: form.email || null, 
  phone: form.phone || null, 
  alamat: form.alamat || null,

  kecamatan: form.kecamatan || null,
  desa: form.desa || null,
  wilayah_binaan: form.wilayah_binaan || null,

  village_id: selectedVillageIds[0] || null,
  village_ids: selectedVillageIds,

  siga_account_id: form.siga_account_id || null,
  status: form.status || "AKTIF",

};
      if (editing) {
        await updatePkb(editing.id, payload);
        setAlertMessage("Perubahan data PKB berhasil disimpan.");
      } else {
        await createPkb(payload);
        setAlertMessage("Data PKB baru berhasil ditambahkan.");
      }

      setAlertOpen(true);

      setForm(emptyForm);
      setEditing(null);
      setModalOpen(false);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Master PKB gagal disimpan.");
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    if (!superAdmin || !deleteTarget) return;
    setDeleting(true);
    try {
      await deletePkb(deleteTarget.id);
      setDeleteTarget(null);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Master PKB gagal dihapus.");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-lg font-black tracking-tight text-[#142b4c]">Master PKB</h2>
          <p className="mt-0.5 text-[10px] text-slate-500">Sumber identitas akun PKB dan ANGGOTA.</p>
        </div>
        <div className="flex gap-2">

        {/* Muat Ulang */}
        <button
          type="button"
          onClick={() => void load()}
          className="group relative inline-grid h-9 w-9 place-items-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
        >
          <Icon
            name="refresh"
            size={16}
            className={loading ? "animate-spin" : ""}
          />

          <span className="pointer-events-none absolute -top-10 left-1/2 hidden -translate-x-1/2 whitespace-nowrap rounded-md bg-slate-900 px-2 py-1 text-[10px] font-semibold text-white shadow-lg group-hover:block">
            Muat Ulang
          </span>
        </button>


        {/* Tambah PKB */}
        {canManage && (
          <button
            type="button"
            onClick={openCreate}
            className="group relative inline-grid h-9 w-9 place-items-center rounded-lg bg-blue-600 text-white hover:bg-blue-700"
          >
            <Icon name="plus" size={18}/>

            <span className="pointer-events-none absolute -top-10 left-1/2 hidden -translate-x-1/2 whitespace-nowrap rounded-md bg-slate-900 px-2 py-1 text-[10px] font-semibold text-white shadow-lg group-hover:block">
              Tambah PKB
            </span>
          </button>
        )}

      </div>
      </div>

      {!canManage && <div className="flex gap-2 rounded-lg border border-blue-100 bg-blue-50 p-3 text-[10px] text-blue-800"><Icon name="shield" size={15}/><div><b>Akses baca saja.</b> Pengelolaan Master PKB dikunci untuk SUPER ADMIN.</div></div>}

      <div className="grid gap-2 sm:grid-cols-3">
        {[["Total PKB", items.length, "users"], ["PKB Aktif", activeCount, "check"], ["Status ASN", asnCount, "shield"]].map(([label, value, icon]) => (
          <div key={String(label)} className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
            <div className="flex items-center justify-between">
              <div><div className="text-[9px] font-extrabold uppercase tracking-wide text-slate-400">{label}</div><div className="mt-1 text-xl font-black text-[#142b4c]">{loading ? "—" : value}</div></div>
              <div className="grid h-6 w-6 place-items-center rounded-lg bg-blue-50 text-blue-700"><Icon name={icon as "users" | "check" | "shield"} size={15}/></div>
            </div>
          </div>
        ))}
      </div>

      {error && <div className="flex gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-[10px] leading-4 text-amber-800"><Icon name="alert" size={15}/><div>{error}</div></div>}

      <div className="bg-white">
        <div className="mb-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-800"><Icon name="user" size={14}/> Master PKB</div>
          <div className="relative w-full sm:w-72">
          <div className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
            <Icon name="search" size={14}/>
          </div>

          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Cari nama, NIP, NIK, wilayah..."
            className="h-9 w-full rounded-xl border border-slate-200 bg-white pl-10 pr-3 text-[11px] outline-none"
          />
        </div>
        </div>
        <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
          <table className="w-full min-w-[900px] border-collapse text-[10px]">
            <thead className="bg-slate-100 font-bold text-slate-700">
            <tr>
            <th className="border px-1 py-1 text-center text-center">No</th>
            <th className="border px-1 py-1 text-center text-center">Nama</th>
            <th className="border px-1 py-1 text-center text-center">NIP</th>
            <th className="border px-1 py-1 text-center text-center">Email</th>
            <th className="border px-1 py-1 text-center text-center">Jabatan</th>
            <th className="border px-1 py-1 text-center text-center">Status ASN</th>
            <th className="border px-1 py-1 text-center text-center">Golongan</th>
            <th className="border px-1 py-1 text-center text-center">Kecamatan</th>
            <th className="border px-1 py-1 text-center text-center">Wilayah Binaan</th>
            <th className="border px-1 py-1 text-center text-center">Status</th>
            <th className="border px-1 py-1 text-center text-center">Aksi</th>
            </tr>
            </thead>
            <tbody>
              {loading ? (

              <tr>
                <td 
                  colSpan={11} 
                  className="px-3 py-10 text-center text-[10px] text-slate-400"
                >
                  Memuat data...
                </td>
              </tr>

              ) : filtered.length === 0 ? (

            <tr>
              <td colSpan={11} className="px-1 py-1 text-center text-slate-500">
                Belum ada Master PKB.
              </td>
            </tr>

          ) : paginatedItems.map((item, index) => (

          <tr key={item.id} className="text-slate-600 hover:bg-slate-50">

            <td className="border px-1 py-1 text-center text-center">
              {((page - 1) * pageSize) + index + 1}
            </td>


            <td className="border px-1 py-1 text-center text-center">
              <div className="font-bold text-[#142b4c]">
                {item.nama}
              </div>
            </td>


            <td className="border px-1 py-1 text-center text-center font-mono">
              {item.nip || "—"}
            </td>


            <td className="border px-1 py-1 text-center text-center">
              {item.email || "—"}
            </td>


            <td className="border px-1 py-1 text-center text-center">
              {item.jabatan || "—"}
            </td>


            <td className="border px-1 py-1 text-center text-center">
              {item.status_asn || "—"}
            </td>


            <td className="border px-1 py-1 text-center text-center">
              {item.golongan || "—"}
            </td>


            <td className="border px-1 py-1 text-center text-center">
              {item.kecamatan || "—"}
            </td>


            <td className="border px-1 py-1 text-center text-center">
              {item.wilayah_binaan || 
                [item.kecamatan, item.desa].filter(Boolean).join(" / ") || 
                "—"}
            </td>


            <td className="border px-2 py-1 text-center">
              <span className={`rounded-full px-2 py-0.5 text-[8px] font-extrabold ${
                (item.status || "AKTIF").toUpperCase() === "AKTIF"
                ? "bg-emerald-50 text-emerald-700"
                : "bg-slate-100 text-slate-500"
              }`}>
                {item.status || "AKTIF"}
              </span>
            </td>


            <td className="border px-1 py-1 text-center">
              <div className="inline-flex gap-1">

                <Action 
                  icon="eye" 
                  onClick={() => setSelected(item)}
                />

                {superAdmin && (
                  <>
                    <Action 
                      icon="edit" 
                      onClick={() => openEdit(item)}
                    />

                   

                    <Action 
                      icon="trash" 
                      danger 
                      onClick={() => setDeleteTarget(item)}
                    />
                  </>
                )}

              </div>
            </td>

          </tr>

          ))}

          </tbody>
          </table>
        </div>
        <div className="mt-1.5 text-[9px] text-slate-500">Total {filtered.length}</div>
      </div>
        <div className="-mt-9 ml-10 flex items-center justify-between border-t border-slate-200 px-2 py-1 text-[10px]">

      <div className="flex items-center gap-2">
      <span>Tampil:</span>

      <select
        value={pageSize}
        onChange={(e)=>{
          setPage(1);
          setPageSize(Number(e.target.value));
        }}
  className="h-4 w-8 rounded border border-slate-300 px-0 text-[8px] leading-none"
>
      <option value={5}>5</option>
      <option value={10}>10</option>
      <option value={25}>25</option>
      <option value={50}>50</option>
      <option value={-1}>All</option>
      </select>

      </div>


      <div className="flex items-center gap-2">

      <button
      disabled={page===1}
      onClick={()=>setPage(page-1)}
      className="h-4 w-4 rounded border text-[8px] leading-none"
      >
      ‹
      </button>


      <span className="text-[8px]">
      {page} / {totalPage}
      </span>


      <button
      disabled={page===totalPage}
      onClick={()=>setPage(page+1)}
      className="h-4 w-4 rounded border text-[8px] leading-none"
      >
      ›
      </button>

      </div>

      </div>
      {selected && <div className="fixed inset-0 z-80 grid place-items-center bg-slate-950/40 p-4 backdrop-blur-[2px]"><div className="w-full max-w-xl overflow-hidden rounded-2xl bg-white shadow-2xl"><div className="flex items-center justify-between border-b border-slate-100 p-4"><div><div className="text-xs font-extrabold text-[#142b4c]">{selected.nama}</div><div className="mt-0.5 text-[9px] text-slate-400">Detail Master PKB</div></div><button type="button" onClick={() => setSelected(null)} className="grid h-6 w-6 place-items-center rounded-lg bg-slate-50 text-slate-500"><Icon name="close" size={15}/></button></div><div className="grid gap-2 p-4 sm:grid-cols-2">{[["NIP", selected.nip], ["NIK", selected.nik], ["Jabatan", selected.jabatan], ["Status ASN", selected.status_asn], ["Golongan", selected.golongan], ["Pendidikan", selected.pendidikan], ["Kecamatan", selected.kecamatan], ["Desa", selected.desa], ["Telepon", selected.phone], ["Email", selected.email]].map(([label, value]) => <div key={String(label)} className="rounded-lg bg-slate-50 p-2.5"><div className="text-[8px] font-bold uppercase text-slate-400">{label}</div><div className="mt-1 wrap-break-word text-[10px] font-bold text-[#142b4c]">{value || "—"}</div></div>)}</div></div></div>}

      {modalOpen && canManage && <div className="fixed inset-0 z-90 overflow-y-auto bg-slate-950/45 p-4 backdrop-blur-[2px]"><form onSubmit={submit} className="mx-auto my-5 w-full max-w-4xl overflow-hidden rounded-2xl bg-white shadow-2xl"><div className="flex items-center justify-between border-b border-slate-100 p-4"><div><div className="text-xs font-extrabold text-[#142b4c]">{editing ? "Edit Master PKB" : "Tambah Master PKB"}</div><div className="mt-0.5 text-[9px] text-slate-400">Identitas ini akan menjadi sumber akun PKB dan ANGGOTA.</div></div><button type="button" onClick={() => { setModalOpen(false); setEditing(null); }} className="grid h-6 w-6 place-items-center rounded-lg bg-slate-50 text-slate-500"><Icon name="close" size={15}/></button></div><div className="grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-3">
        <Field label="NIP" required value={form.nip} onChange={(value) => setForm({ ...form, nip: value })}/><Field label="NIK" required value={form.nik} onChange={(value) => setForm({ ...form, nik: value })}/><Field label="Nama Lengkap" required value={form.nama} onChange={(value) => setForm({ ...form, nama: value })}/><Field label="Tempat Lahir" value={form.tempat_lahir} onChange={(value) => setForm({ ...form, tempat_lahir: value })}/><Field label="Tanggal Lahir" type="date" value={form.tanggal_lahir} onChange={(value) => setForm({ ...form, tanggal_lahir: value })}/><Select label="Jenis Kelamin" value={form.jenis_kelamin} onChange={(value) => setForm({ ...form, jenis_kelamin: value })} options={["LAKI-LAKI", "PEREMPUAN"]}/><Field label="Agama" value={form.agama} onChange={(value) => setForm({ ...form, agama: value })}/><Field label="Pendidikan" value={form.pendidikan} onChange={(value) => setForm({ ...form, pendidikan: value })}/><Field label="Jabatan" value={form.jabatan} onChange={(value) => setForm({ ...form, jabatan: value })}/>
        <Select
            label="Status ASN"
            value={form.status_asn}
            onChange={(value) => setForm({ ...form, status_asn: value })}
            options={[
              "PNS",
              "PPPK",
              "PPPK Paruh Waktu"
            ]}
            />
        <Field label="Golongan" value={form.golongan} onChange={(value) => setForm({ ...form, golongan: value })}/><Field label="Nomor HP" value={form.phone} onChange={(value) => setForm({ ...form, phone: value })}/><Field label="Email" type="email" value={form.email} onChange={(value) => setForm({ ...form, email: value })}/>
        <label><Label>Akun SIGA</Label><select value={form.siga_account_id} onChange={(e)=>{const account=sigaAccounts.find((a)=>a.id===e.target.value);setForm({...form,siga_account_id:e.target.value,village_id:"",desa:"",kecamatan:account?.district_name||"",wilayah_binaan:""});}} className="input-mini"><option value="">Pilih akun SIGA...</option>{sigaAccounts.map((a)=><option key={a.id} value={a.id}>{a.username}{a.district_name ? ` — ${a.district_name}` : ""}</option>)}</select></label>
        <div>
  <Label>Desa SIGA</Label>

  <div className="max-h-36 overflow-y-auto rounded-lg border border-slate-200 p-2">

    {!form.siga_account_id && (
      <div className="text-[10px] text-slate-400">
        Pilih akun SIGA dulu...
      </div>
    )}

    {sigaVillageLoading && (
      <div className="text-[10px] text-slate-400">
        Memuat desa SIGA...
      </div>
    )}

    {!sigaVillageLoading && sigaVillages.map((village) => (
      <label
        key={village.id}
        className="flex items-center gap-2 rounded-md p-1.5 text-[10px] hover:bg-slate-50"
      >

        <input
          type="checkbox"
          checked={selectedVillageIds.includes(village.id)}
          onChange={() => toggleVillage(village.id)}
        />

        <span>
          {village.name}
          <span className="text-slate-400">
            {" "}• {village.district_name}
          </span>
        </span>

      </label>
    ))}

  </div>

  <div className="mt-1 text-[9px] text-slate-400">
    {selectedVillageIds.length} desa dipilih
  </div>

</div>
      </div><div className="flex justify-end gap-2 border-t border-slate-100 bg-slate-50/60 p-3"><button type="button" onClick={() => { setModalOpen(false); setEditing(null); }} className="h-8 rounded-lg border border-slate-200 bg-white px-3 text-[10px] font-bold text-slate-600">Batal</button><button disabled={saving} className="h-8 rounded-lg bg-blue-600 px-4 text-[10px] font-extrabold text-white disabled:opacity-60">{saving ? "Menyimpan..." : editing ? "Simpan Perubahan" : "Simpan PKB"}</button></div></form></div>}

      {binaanTarget && (
        <div className="fixed inset-0 z-[95] grid place-items-center bg-slate-950/45 p-4 backdrop-blur-[2px]">
          <div className="w-full max-w-xl overflow-hidden rounded-2xl bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 p-4">
              <div><div className="text-xs font-extrabold text-[#142b4c]">Desa Binaan — {binaanTarget.nama}</div><div className="mt-0.5 text-[9px] text-slate-400">Pilih desa yang menjadi cakupan sinkronisasi SIGA PKB.</div></div>
              <button type="button" onClick={() => setBinaanTarget(null)} className="grid h-3 w-3 place-items-center rounded-lg bg-slate-50 text-slate-500"><Icon name="close" size={15}/></button>
            </div>
            <div className="max-h-[55vh] overflow-y-auto p-4">
              <div className="mb-2 text-[9px] font-black uppercase tracking-wide text-slate-500">{binaanIds.length} desa dipilih</div>
              <div className="grid gap-2 sm:grid-cols-2">
                {villages.map((v) => {
                  const checked = binaanIds.includes(v.id);
                  return <button key={v.id} type="button" onClick={() => setBinaanIds((current) => checked ? current.filter((id) => id !== v.id) : [...current, v.id])} className={`flex items-center gap-2 rounded-lg border p-2.5 text-left ${checked ? "border-blue-300 bg-blue-50" : "border-slate-200 bg-white"}`}>
                    <span className={`grid h-4 w-4 place-items-center rounded border ${checked ? "border-blue-600 bg-blue-600 text-white" : "border-slate-300 bg-white"}`}>{checked && <Icon name="check" size={10}/>}</span>
                    <span className="min-w-0"><span className="block truncate text-[10px] font-extrabold text-slate-700">{v.name}</span><span className="block truncate text-[8px] text-slate-400">{v.district_name} • {v.code}</span></span>
                  </button>;
                })}
              </div>
            </div>
            <div className="flex justify-end gap-2 border-t border-slate-100 bg-slate-50/60 p-3"><button type="button" onClick={() => setBinaanTarget(null)} className="h-8 rounded-lg border border-slate-200 bg-white px-3 text-[10px] font-bold text-slate-600">Batal</button><button type="button" disabled={binaanSaving || !binaanIds.length} onClick={() => void saveBinaan()} className="h-8 rounded-lg bg-blue-600 px-4 text-[10px] font-extrabold text-white disabled:opacity-50">{binaanSaving ? "Menyimpan..." : "Simpan Desa Binaan"}</button></div>
          </div>
        </div>
      )}

      <MiniSwal open={Boolean(deleteTarget)} title="Hapus Master PKB" text={`Data ${deleteTarget?.nama || "PKB"} akan dihapus dari master. Akun yang sudah tertaut harus dilepas terlebih dahulu.`} tone="danger" confirmText="Hapus" busy={deleting} onCancel={() => setDeleteTarget(null)} onConfirm={() => void remove()}/>
        <MiniSwal
        open={alertOpen}
        title="Berhasil"
        text={alertMessage}
        tone="success"
        confirmText="OK"
        onCancel={() => setAlertOpen(false)}
        onConfirm={() => setAlertOpen(false)}
      />
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) { return <span className="mb-1 block text-[9px] font-extrabold uppercase tracking-wide text-slate-500">{children}</span>; }
function Field({ label, value, onChange, required = false, type = "text" }: { label: string; value: string; onChange: (value: string) => void; required?: boolean; type?: string }) { return <label><Label>{label}{required ? " *" : ""}</Label><input required={required} type={type} value={value} onChange={(event) => onChange(event.target.value)} className="input-mini"/></label>; }
function Select({ label, value, onChange, options }: { label: string; value: string; onChange: (value: string) => void; options: string[] }) { return <label><Label>{label}</Label><select value={value} onChange={(event) => onChange(event.target.value)} className="input-mini"><option value="">Pilih...</option>{options.map((option) => <option key={option} value={option}>{option}</option>)}</select></label>; }
function Action({
  icon,
  onClick,
  danger = false,
}: {
  icon: "eye" | "edit" | "map" | "trash";
  onClick: () => void;
  danger?: boolean;
}) {

  const tooltip = {
    eye: "Lihat Detail",
    edit: "Edit PKB",
    map: "Desa Binaan",
    trash: "Hapus PKB",
  }[icon];

  return (
    <button
      type="button"
      onClick={onClick}
      className={`group relative inline-grid h-3 w-3 place-items-center rounded-md border ${
        danger
          ? "border-red-200 text-red-600 hover:bg-red-50"
          : "border-slate-200 text-slate-500 hover:text-blue-700"
      }`}
    >

      <Icon name={icon} size={13}/>

      {/* Tooltip */}
      <span className="
        pointer-events-none
        absolute
        -top-9
        left-1/2
        hidden
        -translate-x-1/2
        whitespace-nowrap
        rounded-md
        bg-slate-900
        px-2
        py-1
        text-[9px]
        font-semibold
        text-white
        shadow-lg
        group-hover:block
        z-50
      ">
        {tooltip}
      </span>

    </button>
  );
}
