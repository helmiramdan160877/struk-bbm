import { useEffect, useMemo, useState, type ReactNode } from "react";
import Icon from "../components/Icon";
import MiniSwal from "../components/MiniSwal";
import Toast from "../components/Toast";
import { isRole } from "../auth/permissions";
import {
  createUser,
  deleteUser,
  getDistricts,
  getManageableRoles,
  getManageableVillages,
  getAvailableSigaAccounts,
  getUserMasterSources,
  getUsers,
  resetUserPassword,
  setUserActive,
  updateUser,
} from "../services/api";

import type {
  AppUserRecord,
  District,
  ManageableVillage,
  RoleRecord,
  UserMasterSource,
} from "../types/api";

import type { User } from "../types/auth";

const emptyForm = {
  master_source_id: "",
  full_name: "",
  username: "",
  email: "",
  phone: "",
  nip: "",
  password: "",
  role_id: "",
  district_id: "",
  village_ids: [] as string[],
  plan_type: "FREE" as "FREE" | "PAID",
  plan_expires_at: "",
  siga_account_id: "",
};

type EditForm = {
  full_name: string;
  username: string;
  email: string;
  phone: string;
  nip: string;
  role_id: string;
  district_id: string;
  village_ids: string[];
  plan_type: "FREE" | "PAID";
  plan_expires_at: string;
  siga_account_id: string;
};

export default function UserManagementPage({
  user,
}: {
  user: User;
}) {
  const superAdmin = isRole(user, ["SUPER_ADMIN", "SUPERADMIN"]);

  const [items, setItems] = useState<AppUserRecord[]>([]);
  const [roles, setRoles] = useState<RoleRecord[]>([]);
  const [villages, setVillages] = useState<ManageableVillage[]>([]);
  const [districts, setDistricts] = useState<District[]>([]);
  const [masterSources, setMasterSources] = useState<UserMasterSource[]>(
    []
  );
  const [sigaAccounts, setSigaAccounts] = useState<{
    id: string;
    username: string;
    nama?: string | null;
    district_name?: string | null;
    is_active: boolean;
  }[]>([]);

  const [query, setQuery] = useState("");
  const [villageQuery, setVillageQuery] = useState("");
  const [pageSize, setPageSize] = useState(10);
  const [page, setPage] = useState(1);

  const [loading, setLoading] = useState(true);
  const [sourceLoading, setSourceLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const [notice, setNotice] = useState<{
    tone: "error" | "success";
    text: string;
  } | null>(null);

  const [formOpen, setFormOpen] = useState(false);

  const [editTarget, setEditTarget] =
    useState<AppUserRecord | null>(null);

  const [viewTarget, setViewTarget] =
    useState<AppUserRecord | null>(null);

  const [deleteTarget, setDeleteTarget] =
    useState<AppUserRecord | null>(null);

  const [resetTarget, setResetTarget] =
    useState<AppUserRecord | null>(null);

  const [statusTarget, setStatusTarget] =
    useState<AppUserRecord | null>(null);

  const [newPassword, setNewPassword] = useState("");

  const [form, setForm] = useState(emptyForm);

  const [editForm, setEditForm] = useState<EditForm>({
    full_name: "",
    username: "",
    email: "",
    phone: "",
    nip: "",
    role_id: "",
    district_id: "",
    village_ids: [],
    plan_type: "FREE",
    plan_expires_at: "",
    siga_account_id: "",
    });

  /* =========================================================
     LOAD DATA
  ========================================================= */

  const load = async () => {
    setLoading(true);

    try {
      const [
        users,
        roleList,
        villageList,
        sigaAccountList,
        districtList,
      ] = await Promise.all([
        getUsers(),
        getManageableRoles(),
        getManageableVillages(),
        getAvailableSigaAccounts(),
        superAdmin
          ? getDistricts()
          : Promise.resolve([] as District[]),
      ]);

      setItems(users);
      setRoles(roleList);
      setVillages(villageList);
      setSigaAccounts(sigaAccountList);
      setDistricts(districtList);
      setNotice(null);
    } catch (err) {
      setNotice({
        tone: "error",
        text:
          err instanceof Error
            ? err.message
            : "Manajemen user gagal dimuat.",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void load();
    }, 0);

    return () => window.clearTimeout(timer);
  }, [superAdmin]);

  /* =========================================================
     CREATE USER
  ========================================================= */

  const selectedRole = roles.find(
    (role) => role.id === form.role_id
  );

  const selectedRoleName = (
    selectedRole?.name || ""
  ).toUpperCase();

  const usesMaster = [
  "PKB",
  "KADER",
  "PPKBD",
  "ANGGOTA",
  "UPPKA",
].includes(selectedRoleName);

  const needsVillages = usesMaster;

  const needsDistrict =
    superAdmin && selectedRoleName === "ADMIN";

  const needsSigaAccount = [
    "PKB",
    "PPKBD",
    "ADMIN",
    "ADMIN_KABUPATEN",
  ].includes(selectedRoleName);

  const selectedSource = masterSources.find(
    (source) => source.id === form.master_source_id
  );

  useEffect(() => {
    let active = true;

    const timer = window.setTimeout(() => {
      if (!formOpen || !usesMaster || !selectedRoleName) {
        if (active) {
          setMasterSources([]);
        }
        return;
      }

      if (active) {
        setSourceLoading(true);
      }

      getUserMasterSources(selectedRoleName)
        .then((data) => {
          if (active) {
            setMasterSources(data);
          }
        })
        .catch((err: unknown) => {
          if (active) {
            setNotice({
              tone: "error",
              text:
                err instanceof Error
                  ? err.message
                  : "Master sumber gagal dimuat.",
            });
          }
        })
        .finally(() => {
          if (active) {
            setSourceLoading(false);
          }
        });
    }, 0);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [formOpen, selectedRoleName, usesMaster]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();

    if (!needle) {
      return items;
    }

    return items.filter((item) =>
      [
        item.full_name,
        item.username,
        item.email,
        item.role?.name,
        item.phone,
      ].some((value) =>
        String(value || "")
          .toLowerCase()
          .includes(needle)
      )
    );
  }, [items, query]);

  const pageCount = pageSize === 0
    ? 1
    : Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, pageCount);

  const pagedItems = useMemo(() => {
    if (pageSize === 0) {
      return filtered;
    }

    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [currentPage, filtered, pageSize]);

  const filteredVillages = useMemo(() => {
    const needle = villageQuery.trim().toLowerCase();

    if (!needle) {
      return villages;
    }

    return villages.filter((v) =>
      `${v.name} ${v.code} ${v.district_name}`
        .toLowerCase()
        .includes(needle)
    );
  }, [villageQuery, villages]);

  const openCreate = () => {
    const first = roles[0]?.id || "";

    setForm({
      ...emptyForm,
      role_id: first,
    });

    setVillageQuery("");
    setMasterSources([]);
    setNotice(null);
    setFormOpen(true);
  };

  const roleChanged = (roleId: string) => {
    setForm({
      ...emptyForm,
      role_id: roleId,
      username: form.username,
      password: form.password,
    });

    setVillageQuery("");
  };

  const sourceChanged = (sourceId: string) => {
    const source = masterSources.find(
      (item) => item.id === sourceId
    );

    setForm((current) => ({
      ...current,
      master_source_id: sourceId,
      full_name: source?.name || "",
      email: source?.email || "",
      phone: source?.phone || "",
      nip: source?.code || "",
      village_ids: source?.village_id
        ? [source.village_id]
        : [],
      siga_account_id: source?.siga_account_id || "",
    }));
  };

  const toggleVillage = (id: string) => {
    setForm((current) => ({
      ...current,
      village_ids: current.village_ids.includes(id)
        ? current.village_ids.filter(
            (value) => value !== id
          )
        : [...current.village_ids, id],
    }));
  };

  const submit = async (
    event: React.FormEvent
  ) => {
    event.preventDefault();
    setNotice(null);

    if (
      usesMaster &&
      !form.master_source_id
    ) {
      setNotice({
        tone: "error",
        text: `Pilih data dari ${
        ["KADER", "UPPKA", "PPKBD"].includes(selectedRoleName)
          ? "Master Kader"
          : "Master PKB"
      }.`,
      });

      return;
    }

    if (
      needsVillages &&
      form.village_ids.length === 0
    ) {
      setNotice({
        tone: "error",
        text: "Pilih minimal satu wilayah binaan.",
      });

      return;
    }

    if (
      form.plan_type === "FREE" &&
      form.village_ids.length > 1
    ) {
      setNotice({
        tone: "error",
        text: "Paket FREE maksimal 1 desa.",
      });

      return;
    }

    if (
      needsDistrict &&
      !form.district_id
    ) {
      setNotice({
        tone: "error",
        text:
          "Role ADMIN wajib memiliki kecamatan binaan.",
      });

      return;
    }

    if (needsSigaAccount && !form.siga_account_id) {
      setNotice({
        tone: "error",
        text: "Pilih akun SIGA yang akan digunakan user.",
      });
      return;
    }

    setSaving(true);

    try {
      await createUser({
        master_source_id:
          form.master_source_id || null,

        full_name:
          form.full_name.trim(),

        username:
          form.username.trim(),

        email:
          form.email.trim(),

        phone:
          form.phone.trim() || null,

        nip:
          form.nip.trim() || null,

        password:
          form.password,

        role_id:
          form.role_id,

        district_id:
          form.district_id || null,

        village_ids:
          needsVillages
            ? form.village_ids
            : [],

        plan_type:
          form.plan_type,

        plan_expires_at:
          form.plan_type === "PAID" &&
          form.plan_expires_at
            ? new Date(
                form.plan_expires_at
              ).toISOString()
            : null,

        siga_account_id:
          form.siga_account_id || null,
      });

      setFormOpen(false);

      setNotice({
        tone: "success",
        text:
          "User berhasil dibuat dan wilayah akses sudah diterapkan.",
      });

      await load();
    } catch (err) {
      setNotice({
        tone: "error",
        text:
          err instanceof Error
            ? err.message
            : "User gagal dibuat.",
      });
    } finally {
      setSaving(false);
    }
  };

  /* =========================================================
     VIEW
  ========================================================= */

  const openView = (
    item: AppUserRecord
  ) => {
    setViewTarget(item);
  };

  /* =========================================================
     EDIT
  ========================================================= */

  const openEdit = (
    item: AppUserRecord
  ) => {
    setEditTarget(item);

    setEditForm({
      full_name: item.full_name || "",
      username: item.username || "",
      email: item.email || "",
      phone: item.phone || "",
      nip: item.nip || "",
      role_id: item.role?.id || "",
      district_id:
        (item as AppUserRecord & {
          district_id?: string | null;
        }).district_id || "",
      village_ids:
        item.user_villages?.map(
          (v) => v.village_id
        ) || [],
      plan_type:
        ((item as AppUserRecord & {
          plan_type?: "FREE" | "PAID";
        }).plan_type || "FREE") as
          | "FREE"
          | "PAID",
      plan_expires_at:
        formatDateForInput(
          (item as AppUserRecord & {
            plan_expires_at?: string | null;
          }).plan_expires_at
        ),
      siga_account_id: item.siga_account_id || "",
    });
  };

  const saveEdit = async (
    event: React.FormEvent
  ) => {
    event.preventDefault();

    if (!editTarget) {
      return;
    }

    setSaving(true);
    setNotice(null);

    try {
      await updateUser(editTarget.id, {
        full_name:
          editForm.full_name.trim(),

        username:
          editForm.username.trim(),

        email:
          editForm.email.trim(),

        phone:
          editForm.phone.trim() || null,

        nip:
          editForm.nip.trim() || null,

        role_id:
          editForm.role_id || null,

        district_id:
          editForm.district_id || null,

        village_ids:
          editForm.village_ids,

        plan_type:
          editForm.plan_type,

        plan_expires_at:
          editForm.plan_type === "PAID" &&
          editForm.plan_expires_at
            ? new Date(
                editForm.plan_expires_at
              ).toISOString()
            : null,

          siga_account_id:
            editForm.siga_account_id || null,
      });

      setEditTarget(null);

      setNotice({
        tone: "success",
        text:
          "Data user berhasil diperbarui.",
      });

      await load();
    } catch (err) {
      setNotice({
        tone: "error",
        text:
          err instanceof Error
            ? err.message
            : "Data user gagal diperbarui.",
      });
    } finally {
      setSaving(false);
    }
  };

  /* =========================================================
     STATUS
  ========================================================= */

  const doStatusChange = async () => {
    if (!statusTarget) {
      return;
    }

    setSaving(true);

    try {
      await setUserActive(
        statusTarget.id,
        !statusTarget.is_active
      );

      setNotice({
        tone: "success",
        text: `Akun ${
          statusTarget.username
        } berhasil ${
          statusTarget.is_active
            ? "dinonaktifkan"
            : "diaktifkan"
        }.`,
      });

      setStatusTarget(null);

      await load();
    } catch (err) {
      setNotice({
        tone: "error",
        text:
          err instanceof Error
            ? err.message
            : "Status user gagal diubah.",
      });
    } finally {
      setSaving(false);
    }
  };

  /* =========================================================
     DELETE
  ========================================================= */

  const doDelete = async () => {
    if (!deleteTarget) {
      return;
    }

    setSaving(true);

    try {
      await deleteUser(deleteTarget.id);

      setNotice({
        tone: "success",
        text: `User ${deleteTarget.username} berhasil dihapus.`,
      });

      setDeleteTarget(null);

      await load();
    } catch (err) {
      setNotice({
        tone: "error",
        text:
          err instanceof Error
            ? err.message
            : "User gagal dihapus.",
      });
    } finally {
      setSaving(false);
    }
  };

  /* =========================================================
     RESET PASSWORD
  ========================================================= */

  const resetPassword = async (
    event: React.FormEvent
  ) => {
    event.preventDefault();

    if (!resetTarget) {
      return;
    }

    setSaving(true);

    try {
      await resetUserPassword(
        resetTarget.id,
        newPassword
      );

      setNotice({
        tone: "success",
        text: `Password ${resetTarget.username} berhasil direset.`,
      });

      setResetTarget(null);
      setNewPassword("");
    } catch (err) {
      setNotice({
        tone: "error",
        text:
          err instanceof Error
            ? err.message
            : "Password gagal direset.",
      });
    } finally {
      setSaving(false);
    }
  };

  /* =========================================================
     RENDER
  ========================================================= */

  return (
    <div className="space-y-4">

      {/* HEADER */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-[17px] font-black tracking-tight text-slate-900">
            Manajemen User
          </h2>

          <p className="mt-1 text-[10px] leading-4 text-slate-500">
            PKB dan Anggota mengambil identitas dari
            Master PKB. Kader mengambil identitas dari
            Master Kader.
          </p>
        </div>

        <div className="flex gap-2">

          {/* REFRESH */}
          <button
            type="button"
            title="Muat ulang data"
            aria-label="Muat ulang data"
            onClick={() => void load()}
            className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
          >
            <Icon
              name="refresh"
              size={13}
              className={
                loading
                  ? "animate-spin"
                  : ""
              }
            />
          </button>

          {/* ADD */}
          <button
            type="button"
            title="Tambah user"
            aria-label="Tambah user"
            onClick={openCreate}
            className="grid h-8 w-8 place-items-center rounded-lg bg-blue-600 text-white hover:bg-blue-700"
          >
            <Icon
              name="plus"
              size={13}
            />
          </button>

        </div>
      </div>

      {/* STAT */}
      <div className="grid gap-2 sm:grid-cols-3">
        <Stat
          label="Total User"
          value={items.length}
          icon="users"
        />

        <Stat
          label="User Aktif"
          value={
            items.filter(
              (i) => i.is_active
            ).length
          }
          icon="check"
        />

        <Stat
          label="Wilayah SIGA"
          value={villages.length}
          icon="map"
        />
      </div>

      <Toast
        open={Boolean(notice)}
        title={notice?.tone === "error" ? "Gagal" : "Berhasil"}
        message={notice?.text || ""}
        tone={notice?.tone === "error" ? "error" : "success"}
        onClose={() => setNotice(null)}
      />

      {/* TABLE */}
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">

        <div className="flex flex-col gap-2 border-b border-slate-100 p-3 sm:flex-row sm:items-center sm:justify-between">

          <div>
            <div className="text-[11px] font-black text-slate-800">
              Daftar Akun
            </div>

            <div className="mt-0.5 text-[9px] text-slate-400">
              Master terhubung ditandai pada kolom role.
            </div>
          </div>

          <div className="relative w-full sm:w-72">

            <Icon
              name="search"
              size={13}
              className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400"
            />

            <input
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(1);
              }}
              placeholder="Cari user..."
              className="h-8 w-full rounded-lg border border-slate-200 bg-slate-50 pl-8 pr-2 text-[10px] outline-none focus:border-blue-400 focus:bg-white"
            />

          </div>
        </div>

        <div className="overflow-x-auto">

          <table className="w-full min-w-[1050px] text-left text-[10px]">

            <thead className="bg-slate-50 text-[9px] font-black uppercase tracking-wide text-slate-400">

              <tr>
                <th className="px-3 py-2.5">
                  User
                </th>

                <th className="px-3 py-2.5">
                  Role / Master
                </th>

                <th className="px-3 py-2.5">
                  Wilayah Binaan
                </th>

                <th className="px-3 py-2.5">
                  Kontak
                </th>

                <th className="px-3 py-2.5">
                  Paket
                </th>

                <th className="px-3 py-2.5">
                  Status
                </th>

                <th className="px-3 py-2.5 text-right">
                  Aksi
                </th>
              </tr>

            </thead>

            <tbody className="divide-y divide-slate-100">

              {loading ? (
                <tr>
                  <td
                    colSpan={7}
                    className="px-3 py-10 text-center text-slate-400"
                  >
                    Memuat data...
                  </td>
                </tr>
              ) : filtered.length === 0 ? (
                <tr>
                  <td
                    colSpan={7}
                    className="px-3 py-10 text-center text-slate-400"
                  >
                    Belum ada user.
                  </td>
                </tr>
              ) : (
                pagedItems.map((item) => {

                  const planType =
                    (item as AppUserRecord & {
                      plan_type?: string;
                    }).plan_type ||
                    "FREE";

                  return (
                    <tr
                      key={item.id}
                      className="hover:bg-slate-50/70"
                    >

                      {/* USER */}
                      <td className="px-3 py-3">

                        <div className="font-extrabold text-slate-800">
                          {item.full_name}
                        </div>

                        <div className="mt-0.5 font-mono text-[9px] text-slate-400">
                          @{item.username}
                        </div>

                      </td>

                      {/* ROLE */}
                      <td className="px-3 py-3">

                        <span className="rounded-md bg-blue-50 px-2 py-1 text-[8px] font-black text-blue-700">
                          {item.role?.name || "-"}
                        </span>

                        <div className="mt-1 text-[8px] text-slate-400">
                          {item.kader_id
                            ? "Master Kader"
                            : item.pkb_id
                            ? "Master PKB"
                            : "Manual"}
                        </div>

                      </td>

                      {/* VILLAGE */}
                      <td className="px-3 py-3">
                        <VillageBadges
                          item={item}
                        />
                      </td>

                      {/* CONTACT */}
                      <td className="px-3 py-3">

                        <div>
                          {item.phone || "—"}
                        </div>

                        <div className="mt-0.5 text-[9px] text-slate-400">
                          {item.email}
                        </div>

                      </td>

                      {/* PLAN */}
                      <td className="px-3 py-3">

                        <span
                          className={`rounded-full px-2 py-1 text-[8px] font-black ${
                            planType === "PAID"
                              ? "bg-amber-50 text-amber-700"
                              : "bg-slate-100 text-slate-600"
                          }`}
                        >
                          {planType}
                        </span>

                      </td>

                      {/* STATUS */}
                      <td className="px-3 py-3">

                        <span
                          className={`rounded-full px-2 py-1 text-[8px] font-black ${
                            item.is_active
                              ? "bg-emerald-50 text-emerald-700"
                              : "bg-slate-100 text-slate-500"
                          }`}
                        >
                          {item.is_active
                            ? "AKTIF"
                            : "NONAKTIF"}
                        </span>

                      </td>

                      {/* ACTION */}
                      <td className="px-3 py-3">

                        <div className="flex justify-end gap-1">

                          {/* VIEW */}
                          <ActionButton
                            title="Lihat detail user"
                            icon="eye"
                            onClick={() =>
                              openView(item)
                            }
                          />

                          {/* EDIT */}
                          {superAdmin && (
                            <ActionButton
                              title="Edit user"
                              icon="edit"
                              onClick={() =>
                                openEdit(item)
                              }
                            />
                          )}

                          {/* STATUS */}
                          {superAdmin && (
                            <ActionButton
                              title={
                                item.is_active
                                  ? "Nonaktifkan user"
                                  : "Aktifkan user"
                              }
                              icon={
                                item.is_active
                                  ? "clock"
                                  : "check"
                              }
                              onClick={() =>
                                setStatusTarget(
                                  item
                                )
                              }
                            />
                          )}

                          {/* RESET PASSWORD */}
                          {superAdmin && (
                            <ActionButton
                              title="Reset password"
                              icon="shield"
                              onClick={() => {
                                setResetTarget(
                                  item
                                );
                                setNewPassword(
                                  ""
                                );
                              }}
                            />
                          )}

                          {/* DELETE */}
                          {superAdmin && (
                            <ActionButton
                              title="Hapus user"
                              icon="trash"
                              danger
                              onClick={() =>
                                setDeleteTarget(
                                  item
                                )
                              }
                            />
                          )}

                        </div>

                      </td>

                    </tr>
                  );
                })
              )}

            </tbody>

          </table>

        </div>

        <div className="flex flex-col gap-2 border-t border-slate-100 px-3 py-2 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-[10px] text-slate-500">
            Menampilkan{" "}
            <span className="font-bold text-slate-700">
              {filtered.length === 0 ? 0 : (currentPage - 1) * pageSize + 1}
            </span>
            {" - "}
            <span className="font-bold text-slate-700">
              {pageSize === 0
                ? filtered.length
                : Math.min(currentPage * pageSize, filtered.length)}
            </span>
            {" dari "}
            <span className="font-bold text-slate-700">{filtered.length}</span>
            {" user"}
          </div>

          <div className="flex items-center gap-2">
            <select
              aria-label="Jumlah user per halaman"
              value={pageSize}
              onChange={(event) => {
                setPageSize(Number(event.target.value));
                setPage(1);
              }}
              className="h-7 rounded-lg border border-slate-200 bg-white px-2 text-[10px]"
            >
              <option value={5}>5</option>
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={0}>ALL</option>
            </select>

            <button
              type="button"
              disabled={currentPage === 1}
              onClick={() => setPage(currentPage - 1)}
              className="h-7 rounded-lg border border-slate-200 px-3 text-[10px] disabled:opacity-40"
            >
              Prev
            </button>

            <span className="min-w-5 text-center text-[10px] font-bold">
              {currentPage}
            </span>

            <button
              type="button"
              disabled={pageSize === 0 || currentPage >= pageCount}
              onClick={() => setPage(currentPage + 1)}
              className="h-7 rounded-lg border border-slate-200 px-3 text-[10px] disabled:opacity-40"
            >
              Next
            </button>
          </div>
        </div>

      </section>

      {/* =====================================================
          CREATE MODAL
      ===================================================== */}

      {formOpen && (
        <div className="fixed inset-0 z-[100] overflow-y-auto bg-slate-950/35 p-4 backdrop-blur-[2px]">

          <form
            onSubmit={submit}
            className="mx-auto my-4 w-full max-w-3xl rounded-2xl border border-slate-200 bg-white shadow-2xl"
          >

            <div className="flex items-start justify-between border-b border-slate-100 px-4 py-3">

              <div>
                <div className="text-[12px] font-black text-slate-900">
                  Buat User
                </div>

                <div className="mt-0.5 text-[9px] text-slate-400">
                  Pilih role, lalu sumber master akan muncul otomatis.
                </div>
              </div>

              <button
                type="button"
                title="Tutup"
                aria-label="Tutup"
                onClick={() =>
                  setFormOpen(false)
                }
                className="grid h-7 w-7 place-items-center rounded-lg bg-slate-100 text-slate-500"
              >
                <Icon
                  name="close"
                  size={13}
                />
              </button>

            </div>

            <div className="grid gap-4 p-4 lg:grid-cols-2">

              <div className="space-y-3">

                <label>
                  <Label>Role *</Label>

                  <select
                    required
                    value={form.role_id}
                    onChange={(e) =>
                      roleChanged(
                        e.target.value
                      )
                    }
                    className="input-mini"
                  >
                    <option value="">
                      Pilih role
                    </option>

                    {roles.map((r) => (
                      <option
                        key={r.id}
                        value={r.id}
                      >
                        {r.name}
                      </option>
                    ))}
                  </select>
                </label>

                {usesMaster && (
                  <label>
                    <Label>
                      Sumber Data *
                    </Label>

                    <select
                      required
                      value={
                        form.master_source_id
                      }
                      onChange={(e) =>
                        sourceChanged(
                          e.target.value
                        )
                      }
                      className="input-mini"
                    >
                      <option value="">
                        {sourceLoading
                          ? "Memuat master..."
                          : `Pilih ${
                              ["KADER", "UPPKA", "PPKBD"].includes(selectedRoleName)
                                ? "Master Kader"
                                : "Master PKB"
                            }`}
                      </option>

                      {masterSources.map(
                        (source) => (
                          <option
                            key={source.id}
                            value={source.id}
                          >
                            {source.name} —{" "}
                            {source.code}
                            {source.village_name
                              ? ` — ${source.village_name}`
                              : ""}
                          </option>
                        )
                      )}
                    </select>
                  </label>
                )}

                {usesMaster &&
                  selectedSource && (
                    <div className="rounded-xl border border-blue-100 bg-blue-50/60 p-3">

                      <div className="text-[9px] font-black uppercase tracking-wide text-blue-600">
                        Identitas dari master
                      </div>

                      <div className="mt-2 text-[11px] font-black text-slate-800">
                        {selectedSource.name}
                      </div>

                      <div className="mt-1 text-[9px] leading-4 text-slate-500">
                        {selectedSource.code} •{" "}
                        {selectedSource.phone ||
                          "tanpa WA"} •{" "}
                        {selectedSource.village_name ||
                          "wilayah belum ditentukan"}
                      </div>

                    </div>
                  )}

                {needsSigaAccount && (
                  <label>
                    <Label>Akun SIGA *</Label>
                    <select
                      required
                      value={form.siga_account_id}
                      onChange={(e) =>
                        setForm({
                          ...form,
                          siga_account_id: e.target.value,
                        })
                      }
                      className="input-mini"
                    >
                      <option value="">Pilih akun SIGA</option>
                      {sigaAccounts.map((account) => (
                        <option key={account.id} value={account.id}>
                          {account.username}{account.nama ? ` — ${account.nama}` : ""}
                          {account.district_name ? ` — ${account.district_name}` : ""}
                        </option>
                      ))}
                    </select>
                  </label>
                )}

                <div className="grid gap-3 sm:grid-cols-2">

                  <Field
                    label="Username"
                    value={form.username}
                    onChange={(v) =>
                      setForm({
                        ...form,
                        username: v,
                      })
                    }
                    required
                  />

                  <Field
                    label="Password Awal"
                    type="password"
                    value={form.password}
                    onChange={(v) =>
                      setForm({
                        ...form,
                        password: v,
                      })
                    }
                    required
                    minLength={6}
                  />

                  {usesMaster ? (
                    <>
                      <Field
                        label="Nama"
                        value={
                          form.full_name
                        }
                        onChange={(v) =>
                          setForm({
                            ...form,
                            full_name: v,
                          })
                        }
                        disabled
                      />

                      <Field
                        label="NIP / ID"
                        value={form.nip}
                        onChange={(v) =>
                          setForm({
                            ...form,
                            nip: v,
                          })
                        }
                        disabled
                      />

                      <Field
                        label="Email"
                        type="email"
                        value={form.email}
                        onChange={(v) =>
                          setForm({
                            ...form,
                            email: v,
                          })
                        }
                      />

                      <Field
                        label="Nomor WhatsApp"
                        value={form.phone}
                        onChange={(v) =>
                          setForm({
                            ...form,
                            phone: v,
                          })
                        }
                        disabled
                      />
                    </>
                  ) : (
                    <>
                      <Field
                        label="Nama Lengkap"
                        value={
                          form.full_name
                        }
                        onChange={(v) =>
                          setForm({
                            ...form,
                            full_name: v,
                          })
                        }
                        required
                      />

                      <Field
                        label="Email"
                        type="email"
                        value={form.email}
                        onChange={(v) =>
                          setForm({
                            ...form,
                            email: v,
                          })
                        }
                      />

                      <Field
                        label="Nomor HP"
                        value={form.phone}
                        onChange={(v) =>
                          setForm({
                            ...form,
                            phone: v,
                          })
                        }
                      />

                      <Field
                        label="NIP / ID"
                        value={form.nip}
                        onChange={(v) =>
                          setForm({
                            ...form,
                            nip: v,
                          })
                        }
                      />
                    </>
                  )}

                </div>

                {needsDistrict && (
                  <label>
                    <Label>
                      Kecamatan Admin *
                    </Label>

                    <select
                      required
                      value={
                        form.district_id
                      }
                      onChange={(e) =>
                        setForm({
                          ...form,
                          district_id:
                            e.target.value,
                        })
                      }
                      className="input-mini"
                    >
                      <option value="">
                        Pilih kecamatan
                      </option>

                      {districts.map(
                        (d) => (
                          <option
                            key={d.id}
                            value={d.id}
                          >
                            {d.name} ({d.code})
                          </option>
                        )
                      )}
                    </select>
                  </label>
                )}

              </div>

              <div>

                {needsVillages ? (
                  <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3">

                    <div className="flex items-center justify-between">

                      <div>
                        <Label>
                          Wilayah Binaan *
                        </Label>

                        <div className="text-[9px] text-slate-400">
                          Otomatis mengikuti master,
                          masih dapat ditambah.
                        </div>
                      </div>

                      <span className="rounded-full bg-blue-600 px-2 py-1 text-[8px] font-black text-white">
                        {form.village_ids.length} dipilih
                      </span>

                    </div>

                    <div className="relative mt-2">

                      <Icon
                        name="search"
                        size={12}
                        className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400"
                      />

                      <input
                        value={
                          villageQuery
                        }
                        onChange={(e) =>
                          setVillageQuery(
                            e.target.value
                          )
                        }
                        placeholder="Cari desa..."
                        className="h-8 w-full rounded-lg border border-slate-200 bg-white pl-8 pr-2 text-[10px] outline-none focus:border-blue-400"
                      />

                    </div>

                    <div className="mt-2 max-h-[290px] space-y-1.5 overflow-y-auto">

                      {filteredVillages.map(
                        (v) => {
                          const checked =
                            form.village_ids.includes(
                              v.id
                            );

                          return (
                            <button
                              type="button"
                              key={v.id}
                              onClick={() =>
                                toggleVillage(
                                  v.id
                                )
                              }
                              className={`flex w-full items-center gap-2 rounded-lg border p-2 text-left ${
                                checked
                                  ? "border-blue-300 bg-blue-50"
                                  : "border-slate-200 bg-white"
                              }`}
                            >

                              <span
                                className={`grid h-4 w-4 place-items-center rounded border ${
                                  checked
                                    ? "border-blue-600 bg-blue-600 text-white"
                                    : "border-slate-300"
                                }`}
                              >
                                {checked && (
                                  <Icon
                                    name="check"
                                    size={10}
                                  />
                                )}
                              </span>

                              <div className="min-w-0">

                                <div className="truncate text-[10px] font-extrabold text-slate-700">
                                  {v.name}
                                </div>

                                <div className="truncate text-[8px] text-slate-400">
                                  {v.district_name} •{" "}
                                  {v.code}
                                </div>

                              </div>

                            </button>
                          );
                        }
                      )}

                    </div>

                  </div>
                ) : (
                  <div className="grid min-h-40 place-items-center rounded-xl border border-dashed border-slate-200 bg-slate-50 p-5 text-center">

                    <div>
                      <Icon
                        name="shield"
                        size={20}
                        className="mx-auto text-blue-600"
                      />

                      <div className="mt-2 text-[10px] font-black text-slate-700">
                        Role administratif
                      </div>

                      <div className="mt-1 text-[9px] text-slate-400">
                        Tidak memakai desa binaan.
                      </div>
                    </div>

                  </div>
                )}

                <div className="mt-3 grid gap-3 sm:grid-cols-2">

                  <label>
                    <Label>
                      Paket Akses
                    </Label>

                    <select
                      value={
                        form.plan_type
                      }
                      onChange={(e) =>
                        setForm({
                          ...form,
                          plan_type:
                            e.target
                              .value as
                              | "FREE"
                              | "PAID",
                        })
                      }
                      className="input-mini"
                    >
                      <option value="FREE">
                        FREE — Lihat saja
                      </option>

                      <option value="PAID">
                        PAID — Operasional
                      </option>
                    </select>
                  </label>

                  {form.plan_type ===
                    "PAID" && (
                    <label>
                      <Label>
                        Berlaku Sampai
                      </Label>

                      <input
                        type="date"
                        value={
                          form.plan_expires_at
                        }
                        onChange={(e) =>
                          setForm({
                            ...form,
                            plan_expires_at:
                              e.target.value,
                          })
                        }
                        className="input-mini"
                      />
                    </label>
                  )}

                </div>

              </div>

            </div>

            <div className="flex justify-end gap-2 border-t border-slate-100 bg-slate-50 px-4 py-3">

              <button
                type="button"
                onClick={() =>
                  setFormOpen(false)
                }
                className="h-8 rounded-lg border border-slate-200 bg-white px-3 text-[10px] font-extrabold text-slate-600"
              >
                Batal
              </button>

              <button
                disabled={saving}
                className="h-8 rounded-lg bg-blue-600 px-4 text-[10px] font-extrabold text-white disabled:opacity-50"
              >
                {saving
                  ? "Menyimpan..."
                  : "Buat User"}
              </button>

            </div>

          </form>

        </div>
      )}

      {/* =====================================================
          VIEW MODAL
      ===================================================== */}

      {viewTarget && (
        <div className="fixed inset-0 z-[110] grid place-items-center bg-slate-950/35 p-4 backdrop-blur-[2px]">

          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white shadow-2xl">

            <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">

              <div>
                <div className="text-[12px] font-black text-slate-900">
                  Detail User
                </div>

                <div className="text-[9px] text-slate-400">
                  Informasi akun
                </div>
              </div>

              <button
                type="button"
                title="Tutup"
                aria-label="Tutup"
                onClick={() =>
                  setViewTarget(null)
                }
                className="grid h-7 w-7 place-items-center rounded-lg bg-slate-100 text-slate-500"
              >
                <Icon
                  name="close"
                  size={13}
                />
              </button>

            </div>

            <div className="space-y-3 p-4">

              <InfoRow
                label="Nama"
                value={
                  viewTarget.full_name
                }
              />

              <InfoRow
                label="Username"
                value={`@${viewTarget.username}`}
              />

              <InfoRow
                label="Email"
                value={
                  viewTarget.email ||
                  "—"
                }
              />

              <InfoRow
                label="No. HP"
                value={
                  viewTarget.phone ||
                  "—"
                }
              />

              <InfoRow
                label="Role"
                value={
                  viewTarget.role?.name ||
                  "—"
                }
              />

              <InfoRow
                label="Status"
                value={
                  viewTarget.is_active
                    ? "AKTIF"
                    : "NONAKTIF"
                }
              />

              <InfoRow
                label="Wilayah"
                value={
                  viewTarget.user_villages
                    ?.map(
                      (v) =>
                        v.village.name
                    )
                    .join(", ") ||
                  "Tidak ada"
                }
              />

            </div>

          </div>

        </div>
      )}

      {/* =====================================================
          EDIT MODAL
      ===================================================== */}

      {editTarget && (
        <div className="fixed inset-0 z-[115] overflow-y-auto bg-slate-950/35 p-4 backdrop-blur-[2px]">

          <form
            onSubmit={saveEdit}
            className="mx-auto my-4 w-full max-w-2xl rounded-2xl border border-slate-200 bg-white shadow-2xl"
          >

            <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">

              <div>
                <div className="text-[12px] font-black text-slate-900">
                  Edit User
                </div>

                <div className="text-[9px] text-slate-400">
                  @{editTarget.username}
                </div>
              </div>

              <button
                type="button"
                title="Tutup"
                aria-label="Tutup"
                onClick={() =>
                  setEditTarget(null)
                }
                className="grid h-7 w-7 place-items-center rounded-lg bg-slate-100 text-slate-500"
              >
                <Icon
                  name="close"
                  size={13}
                />
              </button>

            </div>

            <div className="grid gap-3 p-4 sm:grid-cols-2">

              <Field
                label="Nama Lengkap"
                value={
                  editForm.full_name
                }
                onChange={(v) =>
                  setEditForm({
                    ...editForm,
                    full_name: v,
                  })
                }
                required
              />

              <Field
                label="Username"
                value={
                  editForm.username
                }
                onChange={(v) =>
                  setEditForm({
                    ...editForm,
                    username: v,
                  })
                }
                required
              />

              <Field
                label="Email"
                type="email"
                value={editForm.email}
                onChange={(v) =>
                  setEditForm({
                    ...editForm,
                    email: v,
                  })
                }
                required
              />

              <Field
                label="Nomor HP"
                value={editForm.phone}
                onChange={(v) =>
                  setEditForm({
                    ...editForm,
                    phone: v,
                  })
                }
              />

              <Field
                label="NIP / ID"
                value={editForm.nip}
                onChange={(v) =>
                  setEditForm({
                    ...editForm,
                    nip: v,
                  })
                }
              />

              <label>
                <Label>
                  Role
                </Label>

                <select
                  value={
                    editForm.role_id
                  }
                  onChange={(e) =>
                    setEditForm({
                      ...editForm,
                      role_id:
                        e.target.value,
                    })
                  }
                  className="input-mini"
                >
                  <option value="">
                    Pilih role
                  </option>

                  {roles.map((r) => (
                    <option
                      key={r.id}
                      value={r.id}
                    >
                      {r.name}
                    </option>
                  ))}
                </select>
              </label>

              <label>
                <Label>
                  Paket Akses
                </Label>

                <select
                  value={
                    editForm.plan_type
                  }
                  onChange={(e) =>
                    setEditForm({
                      ...editForm,
                      plan_type:
                        e.target
                          .value as
                          | "FREE"
                          | "PAID",
                    })
                  }
                  className="input-mini"
                >
                  <option value="FREE">
                    FREE — Lihat saja
                  </option>

                  <option value="PAID">
                    PAID — Operasional
                  </option>
                </select>
              </label>

              {["PKB", "PPKBD", "ADMIN", "ADMIN_KABUPATEN"].includes(
                (roles.find((role) => role.id === editForm.role_id)?.name || "").toUpperCase()
              ) && (
                <label>
                  <Label>Akun SIGA *</Label>
                  <select
                    required
                    value={editForm.siga_account_id}
                    onChange={(e) =>
                      setEditForm({
                        ...editForm,
                        siga_account_id: e.target.value,
                      })
                    }
                    className="input-mini"
                  >
                    <option value="">Pilih akun SIGA</option>
                    {sigaAccounts.map((account) => (
                      <option key={account.id} value={account.id}>
                        {account.username}{account.nama ? ` — ${account.nama}` : ""}
                        {account.district_name ? ` — ${account.district_name}` : ""}
                      </option>
                    ))}
                  </select>
                </label>
              )}

              {editForm.plan_type ===
                "PAID" && (
                <label>
                  <Label>
                    Berlaku Sampai
                  </Label>

                  <input
                    type="date"
                    value={
                      editForm.plan_expires_at
                    }
                    onChange={(e) =>
                      setEditForm({
                        ...editForm,
                        plan_expires_at:
                          e.target.value,
                      })
                    }
                    className="input-mini"
                  />
                </label>
              )}

            </div>

            <div className="flex justify-end gap-2 border-t border-slate-100 bg-slate-50 px-4 py-3">

              <button
                type="button"
                onClick={() =>
                  setEditTarget(null)
                }
                className="h-8 rounded-lg border border-slate-200 bg-white px-3 text-[10px] font-extrabold text-slate-600"
              >
                Batal
              </button>

              <button
                disabled={saving}
                className="h-8 rounded-lg bg-blue-600 px-4 text-[10px] font-extrabold text-white disabled:opacity-50"
              >
                {saving
                  ? "Menyimpan..."
                  : "Simpan Perubahan"}
              </button>

            </div>

          </form>

        </div>
      )}

      {/* =====================================================
          RESET PASSWORD
      ===================================================== */}

      {resetTarget && (
        <div className="fixed inset-0 z-[120] grid place-items-center bg-slate-950/35 p-4 backdrop-blur-[2px]">

          <form
            onSubmit={resetPassword}
            className="w-full max-w-[340px] rounded-2xl border border-slate-200 bg-white p-4 shadow-2xl"
          >

            <div className="text-[12px] font-black text-slate-900">
              Reset Password
            </div>

            <div className="mt-1 text-[9px] text-slate-400">
              @{resetTarget.username}
            </div>

            <div className="mt-3">

              <Field
                label="Password Baru"
                type="password"
                value={newPassword}
                onChange={setNewPassword}
                minLength={6}
                required
              />

            </div>

            <div className="mt-4 flex justify-end gap-2">

              <button
                type="button"
                onClick={() =>
                  setResetTarget(null)
                }
                className="h-8 rounded-lg border border-slate-200 px-3 text-[10px] font-bold"
              >
                Batal
              </button>

              <button
                disabled={saving}
                className="h-8 rounded-lg bg-blue-600 px-3 text-[10px] font-extrabold text-white"
              >
                {saving
                  ? "Menyimpan..."
                  : "Simpan"}
              </button>

            </div>

          </form>

        </div>
      )}

      {/* =====================================================
          STATUS CONFIRM
      ===================================================== */}

      <MiniSwal
        open={!!statusTarget}
        title={
          statusTarget?.is_active
            ? "Nonaktifkan akun"
            : "Aktifkan akun"
        }
        text={`Akun ${
          statusTarget?.username || ""
        } akan ${
          statusTarget?.is_active
            ? "dinonaktifkan"
            : "diaktifkan"
        }.`}
        tone={
          statusTarget?.is_active
            ? "danger"
            : "info"
        }
        confirmText={
          statusTarget?.is_active
            ? "Nonaktifkan"
            : "Aktifkan"
        }
        busy={saving}
        onCancel={() =>
          setStatusTarget(null)
        }
        onConfirm={() =>
          void doStatusChange()
        }
      />

      {/* =====================================================
          DELETE CONFIRM
      ===================================================== */}

      <MiniSwal
        open={!!deleteTarget}
        title="Hapus user"
        text={`User ${
          deleteTarget?.username || ""
        } akan dihapus secara permanen. Data akun tidak dapat dikembalikan.`}
        tone="danger"
        confirmText="Hapus"
        cancelText="Batal"
        busy={saving}
        onCancel={() =>
          setDeleteTarget(null)
        }
        onConfirm={() =>
          void doDelete()
        }
      />

    </div>
  );
}

/* =========================================================
   ACTION BUTTON
========================================================= */

function ActionButton({
  title,
  icon,
  onClick,
  danger = false,
}: {
  title: string;
  icon:
    | "eye"
    | "edit"
    | "clock"
    | "check"
    | "shield"
    | "trash";
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      onClick={onClick}
      className={`grid h-7 w-7 place-items-center rounded-lg border transition ${
        danger
          ? "border-red-100 text-red-500 hover:border-red-200 hover:bg-red-50 hover:text-red-700"
          : "border-slate-200 text-slate-500 hover:border-blue-200 hover:bg-blue-50 hover:text-blue-700"
      }`}
    >
      <Icon
        name={icon}
        size={12}
      />
    </button>
  );
}

/* =========================================================
   HELPERS
========================================================= */

function formatDateForInput(
  value?: string | null
) {
  if (!value) {
    return "";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "";
  }

  return date.toISOString().slice(0, 10);
}

function VillageBadges({
  item,
}: {
  item: AppUserRecord;
}) {
  const list =
    item.user_villages || [];

  if (!list.length) {
    return (
      <span className="text-[9px] text-slate-400">
        Tidak ada
      </span>
    );
  }

  return (
    <div className="flex max-w-xs flex-wrap gap-1">

      {list
        .slice(0, 3)
        .map((link) => (
          <span
            key={link.village_id}
            className="rounded bg-slate-100 px-1.5 py-1 text-[8px] font-bold text-slate-600"
          >
            {link.village.name}
          </span>
        ))}

      {list.length > 3 && (
        <span className="rounded bg-blue-50 px-1.5 py-1 text-[8px] font-bold text-blue-600">
          +{list.length - 3}
        </span>
      )}

    </div>
  );
}

function Stat({
  label,
  value,
  icon,
}: {
  label: string;
  value: number;
  icon: "users" | "check" | "map";
}) {
  return (
    <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white p-3 shadow-sm">

      <div className="grid h-8 w-8 place-items-center rounded-lg bg-blue-50 text-blue-600">
        <Icon
          name={icon}
          size={14}
        />
      </div>

      <div>
        <div className="text-[15px] font-black text-slate-900">
          {value}
        </div>

        <div className="text-[9px] font-semibold text-slate-400">
          {label}
        </div>
      </div>

    </div>
  );
}

function Label({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <span className="mb-1 block text-[9px] font-black uppercase tracking-wide text-slate-500">
      {children}
    </span>
  );
}

function Field({
  label,
  value,
  onChange,
  required = false,
  type = "text",
  minLength,
  disabled = false,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
  type?: string;
  minLength?: number;
  disabled?: boolean;
}) {
  return (
    <label>
      <Label>
        {label}
        {required ? " *" : ""}
      </Label>

      <input
        disabled={disabled}
        required={required}
        minLength={minLength}
        type={type}
        value={value}
        onChange={(e) =>
          onChange(e.target.value)
        }
        className="h-8 w-full rounded-lg border border-slate-200 bg-white px-2 text-[10px] outline-none focus:border-blue-400 disabled:bg-slate-50 disabled:text-slate-500"
      />
    </label>
  );
}

function InfoRow({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-lg border border-slate-100 bg-slate-50 px-3 py-2">

      <div className="text-[8px] font-black uppercase tracking-wide text-slate-400">
        {label}
      </div>

      <div className="mt-1 text-[10px] font-bold text-slate-700">
        {value}
      </div>

    </div>
  );
}