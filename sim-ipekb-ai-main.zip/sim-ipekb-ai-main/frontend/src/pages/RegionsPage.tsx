import { useEffect, useMemo, useState } from "react";
import Icon from "../components/Icon";
import { getDistricts, getProvinces, getRegencies, getVillages } from "../services/api";
import type { District, Province, Regency, Village } from "../types/api";

type Tab = "province" | "regency" | "district" | "village";

export default function RegionsPage() {
  const [provinces, setProvinces] = useState<Province[]>([]);
  const [regencies, setRegencies] = useState<Regency[]>([]);
  const [districts, setDistricts] = useState<District[]>([]);
  const [villages, setVillages] = useState<Village[]>([]);
  const [tab, setTab] = useState<Tab>("village");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = async () => {
    setLoading(true); setError("");
    try {
      const [p, r, d, v] = await Promise.all([getProvinces(), getRegencies(), getDistricts(), getVillages()]);
      setProvinces(p); setRegencies(r); setDistricts(d); setVillages(v);
    } catch (err) { setError(err instanceof Error ? err.message : "Master wilayah gagal dimuat."); }
    finally { setLoading(false); }
  };
  useEffect(() => {
    let active = true;
    Promise.all([getProvinces(), getRegencies(), getDistricts(), getVillages()])
      .then(([p, r, d, v]) => { if (active) { setProvinces(p); setRegencies(r); setDistricts(d); setVillages(v); setError(""); } })
      .catch((err: unknown) => { if (active) setError(err instanceof Error ? err.message : "Master wilayah gagal dimuat."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const provinceMap = useMemo(() => new Map(provinces.map((x) => [x.id, x.name])), [provinces]);
  const regencyMap = useMemo(() => new Map(regencies.map((x) => [x.id, x.name])), [regencies]);
  const districtMap = useMemo(() => new Map(districts.map((x) => [x.id, x.name])), [districts]);

  const rows = useMemo(() => {
    const needle = query.toLowerCase().trim();
    const filter = <T extends { code: string; name: string }>(items: T[]) => items.filter((x) => !needle || `${x.code} ${x.name}`.toLowerCase().includes(needle));
    if (tab === "province") return filter(provinces).map((x) => ({ id:x.id, code:x.code, name:x.name, parent:"Indonesia", active:x.is_active }));
    if (tab === "regency") return filter(regencies).map((x) => ({ id:x.id, code:x.code, name:x.name, parent:provinceMap.get(x.province_id) || "—", active:x.is_active }));
    if (tab === "district") return filter(districts).map((x) => ({ id:x.id, code:x.code, name:x.name, parent:regencyMap.get(x.regency_id) || "—", active:x.is_active }));
    return filter(villages).map((x) => ({ id:x.id, code:x.code, name:x.name, parent:districtMap.get(x.district_id) || "—", active:x.is_active }));
  }, [tab, query, provinces, regencies, districts, villages, provinceMap, regencyMap, districtMap]);

  const tabs: Array<{ id: Tab; label: string; count: number }> = [
    { id:"province", label:"Provinsi", count:provinces.length }, { id:"regency", label:"Kab/Kota", count:regencies.length }, { id:"district", label:"Kecamatan", count:districts.length }, { id:"village", label:"Desa/Kelurahan", count:villages.length },
  ];

  return <div className="space-y-5">
    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><h2 className="text-xl font-black tracking-tight text-[#142b4c]">Master Wilayah</h2><p className="mt-1 text-xs text-slate-500">Struktur wilayah yang tersimpan pada database lokal SIM IPEKB AI.</p></div><button type="button" onClick={() => void load()} className="inline-flex h-10 items-center gap-2 self-start rounded-xl border border-slate-200 bg-white px-4 text-xs font-bold text-slate-600 shadow-sm"><Icon name="refresh" size={16} className={loading?"animate-spin":""}/> Muat Ulang</button></div>
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{tabs.map((item)=><button key={item.id} type="button" onClick={()=>setTab(item.id)} className={`rounded-[18px] border p-4 text-left transition ${tab===item.id?'border-blue-200 bg-blue-50 shadow-sm':'border-slate-200 bg-white hover:border-blue-100'}`}><div className="flex items-center justify-between"><span className={`text-[10px] font-extrabold uppercase tracking-wide ${tab===item.id?'text-blue-700':'text-slate-400'}`}>{item.label}</span><Icon name="map" size={16} className={tab===item.id?'text-blue-600':'text-slate-300'}/></div><div className="mt-2 text-2xl font-black text-[#142b4c]">{loading?'—':new Intl.NumberFormat('id-ID').format(item.count)}</div></button>)}</div>
    {error && <div className="rounded-xl border border-red-100 bg-red-50 p-4 text-xs font-semibold text-red-700">{error}</div>}
    <div className="overflow-hidden rounded-[20px] border border-slate-200 bg-white shadow-sm">
      <div className="flex flex-col gap-3 border-b border-slate-100 p-4 sm:flex-row sm:items-center sm:justify-between"><div><div className="text-xs font-extrabold text-[#142b4c]">Daftar {tabs.find((x)=>x.id===tab)?.label}</div><div className="mt-1 text-[10px] text-slate-400">{rows.length} data ditampilkan</div></div><div className="relative w-full sm:w-72"><Icon name="search" size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/><input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Cari kode atau nama..." className="h-10 w-full rounded-xl border border-slate-200 bg-slate-50 pl-9 pr-3 text-xs outline-none focus:border-blue-400 focus:bg-white"/></div></div>
      <div className="overflow-x-auto"><table className="w-full min-w-[680px] text-left"><thead className="bg-slate-50 text-[10px] font-extrabold uppercase tracking-wide text-slate-400"><tr><th className="px-5 py-3 w-16">No</th><th className="px-4 py-3">Kode</th><th className="px-4 py-3">Nama Wilayah</th><th className="px-4 py-3">Induk Wilayah</th><th className="px-5 py-3">Status</th></tr></thead><tbody className="divide-y divide-slate-100">{loading?Array.from({length:6}).map((_,i)=><tr key={i}>{Array.from({length:5}).map((__,j)=><td key={j} className="px-4 py-4"><div className="h-3 animate-pulse rounded bg-slate-100"/></td>)}</tr>):rows.map((row,i)=><tr key={row.id} className="text-xs text-slate-600 hover:bg-blue-50/30"><td className="px-5 py-3.5 text-slate-400">{i+1}</td><td className="px-4 py-3.5 font-mono font-bold text-blue-700">{row.code}</td><td className="px-4 py-3.5 font-bold text-[#142b4c]">{row.name}</td><td className="px-4 py-3.5">{row.parent}</td><td className="px-5 py-3.5"><span className={`rounded-full px-2.5 py-1 text-[9px] font-extrabold ${row.active?'bg-emerald-50 text-emerald-700':'bg-slate-100 text-slate-500'}`}>{row.active?'AKTIF':'NONAKTIF'}</span></td></tr>)}</tbody></table></div>
    </div>
  </div>;
}
