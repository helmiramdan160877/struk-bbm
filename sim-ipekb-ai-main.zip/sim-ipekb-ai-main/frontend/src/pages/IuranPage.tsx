import { useEffect, useMemo, useState } from "react";
import Icon from "../components/Icon";
import MiniSwal from "../components/MiniSwal";
import { isRole } from "../auth/permissions";
import {
  getIuranMembers,
  getPkbList,
  getIuranSetting,
  getMemberIuran,
  getMyIuran,
  recordIuranPayment,
  runIuranReminder,
  saveIuranSetting,
} from "../services/api";
import type { IuranMemberSummary, IuranSetting, IuranSummary, Pkb } from "../types/api";
import type { User } from "../types/auth";

interface Props { user: User }
const now = new Date();

function rupiah(value: number | string | undefined) {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(Number(value || 0));
}
function statusTone(status: string) {
  if (status === "LUNAS") return "bg-emerald-50 text-emerald-700 ring-emerald-100";
  if (status === "KURANG") return "bg-amber-50 text-amber-700 ring-amber-100";
  if (status === "BELUM DITAGIH") return "bg-slate-100 text-slate-500 ring-slate-200";
  return "bg-rose-50 text-rose-700 ring-rose-100";
}

export default function IuranPage({ user }: Props) {
  const manager = isRole(user, ["SUPER_ADMIN", "ADMIN", "BENDAHARA"]);
  const canViewMembers = manager || isRole(user, "PENGURUS");
  const [year, setYear] = useState(now.getFullYear());
  const [summary, setSummary] = useState<IuranSummary | null>(null);
  const [members, setMembers] = useState<IuranMemberSummary[]>([]);
  const [pkbs, setPkbs] = useState<Pkb[]>([]);
  const [selectedPkbId, setSelectedPkbId] = useState("");
  const [selectedUserId, setSelectedUserId] = useState("");
  const [setting, setSetting] = useState<IuranSetting | null>(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{tone:"error"|"success";text:string}|null>(null);
  const [showPayment, setShowPayment] = useState(false);
  const [showSetting, setShowSetting] = useState(false);
  const [confirmReminder, setConfirmReminder] = useState(false);
  const [saving, setSaving] = useState(false);

  const selectedMember = useMemo(() => members.find((item) => item.user_id === selectedUserId) || null, [members, selectedUserId]);

  useEffect(() => {
    getPkbList().then(setPkbs).catch(() => setPkbs([]));
  }, []);

  const load = async () => {
    setLoading(true);
    try {
      if (canViewMembers) {
        const [memberRows, currentSetting] = await Promise.all([getIuranMembers(year), getIuranSetting(year)]);
        setMembers(memberRows); setSetting(currentSetting);
        const nextUserId = selectedUserId || memberRows[0]?.user_id || "";
        setSelectedUserId(nextUserId);
        setSelectedPkbId(memberRows.find((item) => item.user_id === nextUserId)?.pkb_id || pkbs[0]?.id || "");
        setSummary(nextUserId ? await getMemberIuran(nextUserId, year) : null);
      } else { setSummary(await getMyIuran(year)); setMembers([]); }
    } catch (err) { setMessage({tone:"error",text:err instanceof Error ? err.message : "Data iuran belum dapat dimuat."}); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    const timer = window.setTimeout(() => void load(), 0);
    return () => window.clearTimeout(timer);
  }, [year]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (canViewMembers && selectedUserId) void getMemberIuran(selectedUserId, year).then(setSummary).catch(()=>{}); }, [selectedUserId]); // eslint-disable-line react-hooks/exhaustive-deps

  const aggregate = useMemo(() => ({
    paid: members.reduce((sum, item) => sum + Number(item.total_paid || 0), 0),
    outstanding: members.reduce((sum, item) => sum + Number(item.total_outstanding || 0), 0),
    unpaid: members.filter((item) => Number(item.total_outstanding || 0) > 0).length,
  }), [members]);

  const periodLabel = summary?.charged_through_month_name ? `Januari–${summary.charged_through_month_name}` : "Belum ada tagihan";

  const runReminder = async () => {
    setSaving(true); setMessage(null);
    try {
      const result = await runIuranReminder();
      setConfirmReminder(false);
      setMessage({tone:"success",text:`Reminder diproses untuk ${result.members_unpaid} anggota. Total tunggakan ${rupiah(result.total_outstanding)}. Pengirim WA ${result.sender}.`});
    } catch(err){setMessage({tone:"error",text:err instanceof Error?err.message:"Reminder gagal dijalankan."});}
    finally{setSaving(false);}
  };

  return <div className="space-y-4">
    <section className="rounded-2xl border border-emerald-900/10 bg-gradient-to-r from-[#145c3a] to-[#1f7b4d] p-4 text-white shadow-sm">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between"><div><div className="text-[8px] font-black uppercase tracking-[.14em] text-emerald-100">Keuangan Organisasi</div><h2 className="mt-1 text-[17px] font-black">Kas & Iuran IPKB</h2><p className="mt-1 text-[10px] text-emerald-50/80">Kewajiban dihitung dari Januari sampai bulan berjalan. Reminder otomatis setiap tanggal 25.</p></div><div className="flex flex-wrap gap-2"><select value={year} onChange={(e)=>setYear(Number(e.target.value))} className="h-8 rounded-lg border border-white/15 bg-white/10 px-2 text-[10px] font-bold text-white outline-none [&>option]:text-slate-800">{[year-2,year-1,year,year+1].map(item=><option key={item}>{item}</option>)}</select><button onClick={()=>void load()} className="inline-flex h-8 items-center gap-2 rounded-lg bg-white/10 px-3 text-[10px] font-bold ring-1 ring-white/15"><Icon name="refresh" size={13} className={loading?"animate-spin":""}/> Perbarui</button>{manager&&<button onClick={()=>setConfirmReminder(true)} className="inline-flex h-8 items-center gap-2 rounded-lg bg-white px-3 text-[10px] font-black text-emerald-800"><Icon name="bell" size={13}/> Kirim Reminder</button>}</div></div>
    </section>

    {message&&<div className={`rounded-xl border px-3 py-2.5 text-[10px] font-semibold ${message.tone==="error"?"border-rose-200 bg-rose-50 text-rose-800":"border-emerald-200 bg-emerald-50 text-emerald-700"}`}>{message.text}</div>}

    {canViewMembers?<section className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4"><Stat label="Anggota Aktif" value={String(members.length)} note={`${aggregate.unpaid} belum lunas`} icon="users"/><Stat label="Kas Masuk" value={rupiah(aggregate.paid)} note={`Periode berjalan ${year}`} icon="wallet"/><Stat label="Tunggakan" value={rupiah(aggregate.outstanding)} note="Januari sampai bulan berjalan" icon="alert"/><Stat label="Iuran / Bulan" value={rupiah(setting?.monthly_amount||0)} note={setting?"Reminder otomatis tanggal 25":"Nominal belum diatur"} icon="calendar"/></section>:summary&&<section className="grid gap-2 sm:grid-cols-2 xl:grid-cols-4"><Stat label="Iuran / Bulan" value={rupiah(summary.monthly_amount)} note={`Tahun ${summary.year}`} icon="calendar"/><Stat label="Sudah Dibayar" value={rupiah(summary.total_paid)} note={`${summary.paid_months} bulan lunas`} icon="check"/><Stat label="Tunggakan" value={rupiah(summary.total_outstanding)} note={`${summary.unpaid_months} bulan belum lunas`} icon="alert"/><Stat label="Tagihan Berjalan" value={rupiah(summary.total_expected)} note={periodLabel} icon="wallet"/></section>}

    {canViewMembers&&<section className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm"><div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between"><div className="min-w-0 flex-1"><label className="mb-1 block text-[9px] font-black uppercase tracking-wide text-slate-500">Pilih Anggota dari Master PKB</label><select value={selectedPkbId} onChange={(e)=>{const pkbId=e.target.value;const linked=members.find((item)=>item.pkb_id===pkbId);setSelectedPkbId(pkbId);setSelectedUserId(linked?.user_id||"");setSummary(null);}} className="h-8 w-full max-w-xl rounded-lg border border-slate-200 px-2 text-[10px] font-semibold"><option value="">{pkbs.length?"Pilih data Master PKB":"Master PKB belum tersedia"}</option>{pkbs.map((pkb)=><option key={pkb.id} value={pkb.id}>{pkb.nama} — {pkb.nip}{members.some((item)=>item.pkb_id===pkb.id)?"":" — belum terhubung"}</option>)}</select>{selectedMember?<p className="mt-1 text-[8px] text-slate-400">Akun: @{selectedMember.username}{selectedMember.phone?` • ${selectedMember.phone}`:""}</p>:selectedPkbId&&<p className="mt-1 text-[8px] font-semibold text-amber-600">Data PKB belum memiliki akun anggota untuk pencatatan pembayaran.</p>}</div>{manager&&<div className="flex gap-2"><button onClick={()=>setShowSetting(true)} className="inline-flex h-8 items-center gap-2 rounded-lg border border-slate-200 px-3 text-[10px] font-extrabold text-slate-600"><Icon name="settings" size={13}/> Atur Iuran</button><button disabled={!selectedUserId} onClick={()=>setShowPayment(true)} className="inline-flex h-8 items-center gap-2 rounded-lg bg-blue-700 px-3 text-[10px] font-extrabold text-white disabled:opacity-40"><Icon name="plus" size={13}/> Catat Bayar</button></div>}</div></section>}

    <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm"><div className="flex items-center justify-between border-b border-slate-100 px-3 py-2.5"><div><h3 className="text-[11px] font-black text-slate-800">Status Iuran {year}</h3><p className="mt-0.5 text-[9px] text-slate-400">{canViewMembers&&selectedMember?selectedMember.full_name:`Periode tagihan ${periodLabel}`}</p></div>{loading&&<Icon name="refresh" size={13} className="animate-spin text-blue-600"/>}</div><div className="overflow-x-auto"><table className="min-w-full text-left text-[10px]"><thead className="bg-slate-50 text-[8px] font-black uppercase tracking-wide text-slate-400"><tr><th className="px-3 py-2.5">Bulan</th><th className="px-3 py-2.5">Tagihan</th><th className="px-3 py-2.5">Dibayar</th><th className="px-3 py-2.5">Tanggal</th><th className="px-3 py-2.5">Metode</th><th className="px-3 py-2.5">Status</th></tr></thead><tbody className="divide-y divide-slate-100">{(summary?.months||[]).map(item=><tr key={item.month} className="text-slate-600"><td className="px-3 py-2.5 font-extrabold text-slate-800">{item.month_name}</td><td className="px-3 py-2.5">{item.status==="BELUM DITAGIH"?"—":rupiah(item.expected_amount)}</td><td className="px-3 py-2.5 font-bold">{rupiah(item.paid_amount)}</td><td className="px-3 py-2.5">{item.paid_at?new Date(`${item.paid_at}T00:00:00`).toLocaleDateString("id-ID"):"—"}</td><td className="px-3 py-2.5">{item.payment_method||"—"}</td><td className="px-3 py-2.5"><span className={`inline-flex rounded-full px-2 py-1 text-[8px] font-black ring-1 ${statusTone(item.status)}`}>{item.status}</span></td></tr>)}{!loading&&!summary&&<tr><td colSpan={6} className="px-3 py-10 text-center text-[9px] text-slate-400">Belum ada data iuran.</td></tr>}</tbody></table></div></section>

    {showSetting&&<SettingModal year={year} current={setting} saving={saving} onClose={()=>setShowSetting(false)} onSave={async(amount)=>{setSaving(true);try{const result=await saveIuranSetting({year,monthly_amount:amount,due_day:25});setSetting(result);setShowSetting(false);setMessage({tone:"success",text:"Nominal iuran disimpan. Penagihan otomatis tetap tanggal 25."});await load();}catch(err){setMessage({tone:"error",text:err instanceof Error?err.message:"Gagal menyimpan iuran."});}finally{setSaving(false);}}}/>} 
    {showPayment&&selectedUserId&&<PaymentModal year={year} summary={summary} saving={saving} onClose={()=>setShowPayment(false)} onSave={async(payload)=>{setSaving(true);try{await recordIuranPayment({user_id:selectedUserId,year,...payload});setShowPayment(false);setMessage({tone:"success",text:"Pembayaran berhasil dicatat."});await load();}catch(err){setMessage({tone:"error",text:err instanceof Error?err.message:"Pembayaran gagal dicatat."});}finally{setSaving(false);}}}/>} 
    <MiniSwal open={confirmReminder} title="Kirim reminder tagihan" text="Sistem akan membuat notifikasi untuk anggota yang belum lunas dan rekap untuk bendahara. WhatsApp dikirim melalui gateway yang dikonfigurasi dengan nomor pengirim +62 822-9505-6743." confirmText="Kirim sekarang" busy={saving} onCancel={()=>setConfirmReminder(false)} onConfirm={()=>void runReminder()}/>
  </div>;
}

function Stat({label,value,note,icon}:{label:string;value:string;note:string;icon:"users"|"wallet"|"alert"|"calendar"|"check"}){return <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm"><div className="flex items-start justify-between gap-2"><div className="min-w-0"><p className="text-[8px] font-black uppercase tracking-wide text-slate-400">{label}</p><p className="mt-1 truncate text-[16px] font-black text-slate-800">{value}</p></div><div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-emerald-50 text-emerald-700"><Icon name={icon} size={14}/></div></div><p className="mt-2 text-[8px] font-semibold text-slate-400">{note}</p></div>}
function SettingModal({year,current,saving,onClose,onSave}:{year:number;current:IuranSetting|null;saving:boolean;onClose:()=>void;onSave:(amount:number)=>Promise<void>}){const[amount,setAmount]=useState(String(current?.monthly_amount||""));return <Modal title={`Atur Iuran ${year}`} onClose={onClose}><Field label="Nominal per bulan (Rp)"><input type="number" min="0" value={amount} onChange={(e)=>setAmount(e.target.value)} className="input-mini" placeholder="50000"/></Field><div className="mt-3 rounded-lg bg-slate-50 p-2 text-[9px] leading-4 text-slate-500">Tanggal tagihan dan reminder otomatis dikunci pada <b>tanggal 25</b>.</div><button type="button" disabled={saving||Number(amount)<=0} onClick={()=>void onSave(Number(amount))} className="mt-3 h-8 w-full rounded-lg bg-blue-700 text-[10px] font-extrabold text-white disabled:opacity-40">{saving?"Menyimpan...":"Simpan"}</button></Modal>}
function PaymentModal({year,summary,saving,onClose,onSave}:{year:number;summary:IuranSummary|null;saving:boolean;onClose:()=>void;onSave:(payload:{month:number;amount?:number;paid_at?:string;payment_method?:string;reference_no?:string;notes?:string})=>Promise<void>}){const chargeable=(summary?.months||[]).filter(item=>item.status!=="BELUM DITAGIH");const firstUnpaid=chargeable.find(item=>item.status!=="LUNAS")?.month||chargeable.at(-1)?.month||1;const[month,setMonth]=useState(String(firstUnpaid));const[amount,setAmount]=useState(String(summary?.monthly_amount||""));const[paidAt,setPaidAt]=useState(now.toISOString().slice(0,10));const[method,setMethod]=useState("TUNAI");const[reference,setReference]=useState("");const[notes,setNotes]=useState("");return <Modal title={`Catat Pembayaran ${year}`} onClose={onClose}><div className="grid gap-3 sm:grid-cols-2"><Field label="Bulan"><select value={month} onChange={(e)=>setMonth(e.target.value)} className="input-mini">{chargeable.map(item=><option key={item.month} value={item.month} disabled={item.status==="LUNAS"}>{item.month_name}{item.status==="LUNAS"?" — lunas":""}</option>)}</select></Field><Field label="Nominal (Rp)"><input type="number" min="0" value={amount} onChange={(e)=>setAmount(e.target.value)} className="input-mini"/></Field><Field label="Tanggal Bayar"><input type="date" value={paidAt} onChange={(e)=>setPaidAt(e.target.value)} className="input-mini"/></Field><Field label="Metode"><select value={method} onChange={(e)=>setMethod(e.target.value)} className="input-mini"><option>TUNAI</option><option>TRANSFER</option><option>QRIS</option></select></Field><div className="sm:col-span-2"><Field label="No. Referensi"><input value={reference} onChange={(e)=>setReference(e.target.value)} className="input-mini"/></Field></div><div className="sm:col-span-2"><Field label="Catatan"><textarea value={notes} onChange={(e)=>setNotes(e.target.value)} className="min-h-14 w-full rounded-lg border border-slate-200 p-2 text-[10px] outline-none"/></Field></div></div><button type="button" disabled={saving||Number(amount)<=0} onClick={()=>void onSave({month:Number(month),amount:Number(amount),paid_at:paidAt,payment_method:method,reference_no:reference||undefined,notes:notes||undefined})} className="mt-3 h-8 w-full rounded-lg bg-blue-700 text-[10px] font-extrabold text-white disabled:opacity-40">{saving?"Menyimpan...":"Simpan Pembayaran"}</button></Modal>}
function Field({label,children}:{label:string;children:React.ReactNode}){return <label className="block"><span className="mb-1 block text-[9px] font-black uppercase tracking-wide text-slate-500">{label}</span>{children}</label>}
function Modal({title,onClose,children}:{title:string;onClose:()=>void;children:React.ReactNode}){return <div className="fixed inset-0 z-[110] grid place-items-center bg-slate-950/35 p-4 backdrop-blur-[2px]"><div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-slate-200 bg-white shadow-2xl"><div className="flex items-center justify-between border-b border-slate-100 px-4 py-3"><h3 className="text-[12px] font-black text-slate-800">{title}</h3><button onClick={onClose} className="grid h-7 w-7 place-items-center rounded-lg bg-slate-100 text-slate-500"><Icon name="close" size={13}/></button></div><div className="p-4">{children}</div></div></div>}
