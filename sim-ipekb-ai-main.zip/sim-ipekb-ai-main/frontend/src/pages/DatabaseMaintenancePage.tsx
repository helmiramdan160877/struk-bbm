import { useState } from "react";
import Icon from "../components/Icon";
import { isRole } from "../auth/permissions";
import { resetOperationalDatabase } from "../services/api";
import type { User } from "../types/auth";

interface Props {
  user: User;
}

const confirmationText = "HAPUS SEMUA DATA";

export default function DatabaseMaintenancePage({
  user,
}: Props) {
  const [confirmation, setConfirmation] =
    useState("");

  const [saving, setSaving] =
    useState(false);

  const [notice, setNotice] = useState<{
    tone: "success" | "error";
    text: string;
  } | null>(null);

  const isSuperAdmin = isRole(user, [
    "SUPER_ADMIN",
    "SUPERADMIN",
  ]);

  const canSubmit =
    isSuperAdmin &&
    confirmation === confirmationText &&
    !saving;

  const clearData = async () => {
    if (!canSubmit) return;

    setSaving(true);
    setNotice(null);

    try {
      const result =
        await resetOperationalDatabase(
          confirmation
        );

      setConfirmation("");

      const deletedCount = result.deleted
        ? Object.values(result.deleted).reduce(
            (total, count) =>
              total + Number(count || 0),
            0
          )
        : 0;

      setNotice({
        tone: "success",
        text: `${result.message} ${deletedCount} data operasional berhasil dibersihkan.`,
      });
    } catch (error) {
      setNotice({
        tone: "error",
        text:
          error instanceof Error
            ? error.message
            : "Gagal menghapus data operasional.",
      });
    } finally {
      setSaving(false);
    }
  };

  if (!isSuperAdmin) {
    return (
      <section className="page-row mx-auto max-w-3xl">
        <div className="siga-panel p-6 text-center">
          <Icon
            name="shield"
            size={28}
            className="mx-auto text-amber-600"
          />

          <h2 className="mt-3 text-lg font-black text-slate-900">
            Akses khusus superadmin
          </h2>

          <p className="mt-2 text-xs text-slate-500">
            Pusat data hanya dapat digunakan oleh
            akun SUPER_ADMIN.
          </p>
        </div>
      </section>
    );
  }

  return (
    <div className="space-y-5">

      {/* HEADER */}
      <section className="page-row page-row-dark">
        <div>
          <div className="section-kicker text-cyan-200">
            ADMINISTRASI SISTEM
          </div>

          <h2 className="mt-1 text-2xl font-black text-white">
            Pusat Data
          </h2>

          <p className="mt-2 max-w-2xl text-xs leading-6 text-blue-100/75">
            Kelola pembersihan data operasional
            tanpa menghapus akun, role, wilayah,
            dan konfigurasi integrasi.
          </p>
        </div>

        <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-white/10 text-cyan-200">
          <Icon
            name="database"
            size={23}
          />
        </div>
      </section>

      {/* DELETE DATA */}
      <section className="siga-panel overflow-hidden">

        {/* TITLE */}
        <div className="flex items-start gap-3 border-b border-slate-200 px-5 py-4">

          <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-amber-50 text-amber-700">
            <Icon
              name="trash"
              size={17}
            />
          </div>

          <div>
            <h3 className="text-sm font-black text-slate-900">
              Hapus data operasional
            </h3>

            <p className="mt-1 text-[11px] leading-5 text-slate-500">
              Tindakan ini mengosongkan data
              keluarga, anggota, PKB, kader,
              iuran, dan relasi operasional.
              Data akun superadmin tetap
              dipertahankan.
            </p>
          </div>
        </div>

        {/* CONTENT */}
        <div className="space-y-4 p-5">

          {/* WARNING */}
          <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-[11px] leading-5 text-amber-800">
            <strong>Peringatan:</strong>{" "}
            proses ini tidak dapat dibatalkan.
            Pastikan backup database sudah tersedia.
          </div>

          {/* CONFIRMATION */}
          <label className="block text-[11px] font-extrabold text-slate-700">
            Ketik{" "}
            <span className="font-mono text-amber-700">
              {confirmationText}
            </span>{" "}
            untuk melanjutkan

            <input
              value={confirmation}
              onChange={(event) =>
                setConfirmation(
                  event.target.value
                )
              }
              className="input-mini mt-2 h-10 font-mono text-xs"
              placeholder={confirmationText}
              autoComplete="off"
            />
          </label>

          {/* NOTIFICATION */}
          {notice && (
            <div
              className={`rounded-xl px-4 py-3 text-[11px] font-semibold ${
                notice.tone === "success"
                  ? "bg-emerald-50 text-emerald-700"
                  : "bg-rose-50 text-rose-700"
              }`}
            >
              {notice.text}
            </div>
          )}

          {/* BUTTON */}
          <button
            type="button"
            title="Hapus semua data operasional"
            aria-label="Hapus semua data operasional"
            disabled={!canSubmit}
            onClick={() =>
              void clearData()
            }
            className="inline-flex h-10 items-center gap-2 rounded-xl bg-rose-700 px-4 text-xs font-black text-white transition hover:bg-rose-800 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Icon
              name="trash"
              size={15}
            />

            {saving
              ? "Memproses..."
              : "Hapus data operasional"}
          </button>

        </div>
      </section>
    </div>
  );
}