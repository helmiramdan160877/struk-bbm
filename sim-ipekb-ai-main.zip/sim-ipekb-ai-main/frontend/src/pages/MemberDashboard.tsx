import { useEffect, useState } from "react";
import Icon from "../components/Icon";
import { getMyIuran } from "../services/api";
import type { IuranSummary } from "../types/api";
import type { User } from "../types/auth";

interface Props { user: User; onNavigate: (page: string) => void }

function rupiah(value: number | undefined) {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(Number(value || 0));
}

export default function MemberDashboard({ user, onNavigate }: Props) {
  const year = new Date().getFullYear();
  const [data, setData] = useState<IuranSummary | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    getMyIuran(year).then(setData).catch((err: unknown) => setError(err instanceof Error ? err.message : "Iuran belum dapat dimuat."));
  }, [year]);

  const firstName = (user.full_name || user.username).trim().split(/\s+/)[0] || "Anggota";
  const progress = data?.total_expected ? Math.min(100, Math.round((Number(data.total_paid) / Number(data.total_expected)) * 100)) : 0;

  return <div className="space-y-4">
    <section className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#173d78] via-[#245baf] to-[#2f73de] p-4 text-white shadow-sm">
      <div className="absolute -right-16 -top-24 h-64 w-64 rounded-full border-[36px] border-white/5" />
      <div className="relative"><div className="mb-3 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.14em] text-blue-100 ring-1 ring-white/10"><Icon name="user" size={14}/> Portal Anggota IPKB</div><h2 className="text-[18px] font-black tracking-tight">Halo, {firstName}.</h2><p className="mt-1 max-w-2xl text-[10px] leading-5 text-blue-100/80">Cek status iuran IPKB dan riwayat pembayaran akun Anda dari satu halaman.</p></div>
    </section>

    {error && <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs text-amber-800">{error}</div>}

    <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      <Card label="Iuran per Bulan" value={rupiah(data?.monthly_amount)} note={`Periode ${year}`} icon="calendar" />
      <Card label="Sudah Dibayar" value={rupiah(data?.total_paid)} note={`${data?.paid_months || 0} bulan lunas`} icon="check" />
      <Card label="Sisa Iuran" value={rupiah(data?.total_outstanding)} note={`${data?.unpaid_months ?? 12} bulan belum lunas`} icon="alert" />
      <Card label="Tagihan Berjalan" value={rupiah(data?.total_expected)} note={data?.charged_through_month_name ? `Januari–${data.charged_through_month_name}` : "Belum ada tagihan"} icon="wallet" />
    </section>

    <section className="grid gap-5 lg:grid-cols-[1fr_.8fr]">
      <div className="rounded-[22px] border border-slate-200 bg-white p-5 shadow-sm sm:p-6"><div className="flex items-center justify-between"><div><h3 className="text-sm font-extrabold text-[#142b4c]">Progres Iuran {year}</h3><p className="mt-1 text-[9px] text-slate-400">Persentase kewajiban Januari sampai bulan berjalan</p></div><div className="text-xl font-black text-emerald-700">{progress}%</div></div><div className="mt-5 h-3 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-emerald-500 transition-all" style={{ width: `${progress}%` }}/></div><div className="mt-4 flex justify-between text-[10px] font-semibold text-slate-400"><span>{data?.paid_months || 0} bulan lunas</span><span>{data?.unpaid_months ?? 12} bulan tersisa</span></div></div>
      <div className="rounded-[22px] border border-slate-200 bg-white p-5 shadow-sm sm:p-6"><div className="grid h-11 w-11 place-items-center rounded-2xl bg-emerald-50 text-emerald-700"><Icon name="wallet" size={20}/></div><h3 className="mt-4 text-sm font-extrabold text-[#142b4c]">Kas & Iuran IPKB</h3><p className="mt-2 text-xs leading-5 text-slate-500">Lihat status setiap bulan, tanggal pembayaran, dan metode pembayaran yang sudah diverifikasi bendahara.</p><button type="button" onClick={() => onNavigate("iuran")} className="mt-5 inline-flex h-10 w-full items-center justify-center gap-2 rounded-xl bg-[#173d78] text-xs font-extrabold text-white hover:bg-[#245baf]"><Icon name="eye" size={15}/> Lihat Detail Iuran</button></div>
    </section>
  </div>;
}

function Card({ label, value, note, icon }: { label: string; value: string; note: string; icon: "calendar" | "check" | "alert" | "wallet" }) {
  return <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm"><div className="flex items-start justify-between gap-2"><div><p className="text-[8px] font-extrabold uppercase tracking-wide text-slate-400">{label}</p><p className="mt-1 text-[16px] font-black tracking-tight text-[#142b4c]">{value}</p></div><div className="grid h-8 w-8 place-items-center rounded-lg bg-blue-50 text-blue-700"><Icon name={icon} size={14}/></div></div><p className="mt-2 text-[8px] font-semibold text-slate-400">{note}</p></div>;
}
