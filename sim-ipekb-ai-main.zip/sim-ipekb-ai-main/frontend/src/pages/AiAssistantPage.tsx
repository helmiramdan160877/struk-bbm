import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import Icon from "../components/Icon";
import { chatWithAi, clearAiHistory, getAiHistory } from "../services/api";
import type { User } from "../types/auth";

type Message = { role: "user" | "assistant"; content: string };

export default function AiAssistantPage({ user }: { user: User }) {
  const [messages, setMessages] = useState<Message[]>([{ role: "assistant", content: "Halo! Saya Asisten AI SIM IPEKB. Saya dapat membantu menyusun uraian kegiatan, laporan, tindak lanjut, dan menjawab pertanyaan tentang penggunaan aplikasi." }]);
  const [input, setInput] = useState("");
  const [image, setImage] = useState<{ data: string; mimeType: string; name: string; preview?: string } | null>(null);
  const [imageError, setImageError] = useState("");
  const [loading, setLoading] = useState(false);
  const [conversationId, setConversationId] = useState<string | undefined>();
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let active = true;
    void getAiHistory().then((history) => {
      if (!active || history.messages.length === 0) return;
      setConversationId(history.conversation_id || history.messages[0].conversation_id);
      setMessages(history.messages.map(({ role, content }) => ({ role, content })));
    }).catch(() => undefined);
    return () => { active = false; };
  }, []);
  const suggestions = [
    "Buatkan uraian kegiatan pembinaan peserta KB suntik.",
    "Buatkan hasil kegiatan dan tindak lanjut pembinaan BKB.",
    "Buatkan format laporan kegiatan PKB yang formal.",
    "Apa saja yang perlu disiapkan untuk kegiatan pembinaan keluarga?",
  ];

  async function send(message?: string) {
    const text = (message ?? input).trim() || (image ? "Analisis foto ini." : "");
    if (!text || loading) return;
    setInput("");
    const attachedImage = image;
    setImage(null);
    setMessages((current) => [...current, { role: "user", content: text }]);
    setLoading(true);
    try {
      const result = await chatWithAi(text, {
        role: typeof user.role === "string" ? user.role : user.role?.name,
        username: user.username,
        full_name: user.full_name,
        district_id: user.district_id,
        plan_type: user.plan_type,
      }, attachedImage ? { data: attachedImage.data, mimeType: attachedImage.mimeType, name: attachedImage.name } : undefined, conversationId);
      if (result.conversation_id) setConversationId(result.conversation_id);
      setMessages((current) => [...current, { role: "assistant", content: result.answer || result.message || "AI tidak memberikan jawaban." }]);
    } catch (error) {
      setMessages((current) => [...current, { role: "assistant", content: error instanceof Error ? `Maaf, AI belum dapat digunakan: ${error.message}` : "Maaf, terjadi kesalahan saat menghubungi AI." }]);
    } finally { setLoading(false); }
  }

  function onSubmit(event: FormEvent) { event.preventDefault(); void send(); }

  function onInputKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void send();
    }
  }

  function onImageChange(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    setImageError("");
    if (!file) return;
    const supportedExtensions = /\.(jpe?g|png|webp|gif|pdf|docx?|xlsx?|csv|txt)$/i;
    if (!supportedExtensions.test(file.name)) {
      setImageError("Format yang didukung: gambar, PDF, Word, Excel, CSV, dan TXT.");
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      setImageError("Ukuran file maksimal 15 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = typeof reader.result === "string" ? reader.result : "";
      const [, data] = result.split(",", 2);
      if (!data) {
        setImageError("Foto tidak dapat dibaca.");
        return;
      }
      setImage({
        data,
        mimeType: file.type || "application/octet-stream",
        name: file.name,
        preview: file.type.startsWith("image/") ? result : undefined,
      });
    };
    reader.onerror = () => setImageError("Foto tidak dapat dibaca.");
    reader.readAsDataURL(file);
  }

  async function onClearHistory() {
    await clearAiHistory(conversationId);
    setConversationId(undefined);
    setMessages([{ role: "assistant", content: "Riwayat percakapan sudah dihapus. Silakan mulai pertanyaan baru." }]);
  }

  return (
    <div className="mx-auto max-w-5xl space-y-4">
      <div className="flex items-center gap-2">
        <div className="grid h-9 w-9 place-items-center rounded-xl bg-blue-50 text-blue-600"><Icon name="sparkles" size={18} /></div>
        <div><h2 className="text-[17px] font-black text-slate-900">Asisten AI</h2><p className="mt-0.5 text-[10px] text-slate-500">Bantuan AI untuk pekerjaan administrasi dan kegiatan IPEKB.</p></div>
      </div>
      <div className="grid gap-4 lg:grid-cols-[1fr_270px]">
        <section className="flex min-h-[620px] flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3"><div><div className="text-[11px] font-black text-slate-800">Chat AI SIM IPEKB</div><div className="mt-0.5 text-[8px] text-slate-400">Konteks akun dan history tersimpan aman per user.</div></div><div className="flex items-center gap-2"><button type="button" onClick={() => void onClearHistory()} disabled={loading} title="Hapus history percakapan" className="text-[8px] font-bold text-slate-400 hover:text-red-600">Hapus history</button><span className="rounded-lg bg-emerald-50 px-2 py-1 text-[8px] font-black text-emerald-700">ONLINE</span></div></div>
          <div className="flex-1 space-y-3 overflow-y-auto p-4">
            {messages.map((message, index) => <div key={`${message.role}-${index}`} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}><div className={`max-w-[88%] rounded-2xl px-3.5 py-3 text-[10px] leading-5 ${message.role === "user" ? "rounded-br-md bg-blue-600 text-white" : "rounded-bl-md bg-slate-50 text-slate-700 ring-1 ring-slate-100"}`}><div className="mb-1 text-[8px] font-black uppercase tracking-wide opacity-60">{message.role === "user" ? "Anda" : "Asisten AI"}</div><div className="whitespace-pre-wrap">{message.content}</div></div></div>)}
            {loading && <div className="flex justify-start"><div className="rounded-2xl rounded-bl-md bg-slate-50 px-4 py-3 text-[10px] text-slate-500 ring-1 ring-slate-100">AI sedang menyusun jawaban...</div></div>}
          </div>
          <form onSubmit={onSubmit} className="border-t border-slate-100 p-3">
            {image && <div className="mb-2 flex items-center gap-2 rounded-lg bg-blue-50 px-2.5 py-2 text-[9px] text-blue-700">{image.preview ? <img src={image.preview} alt={`Preview ${image.name}`} className="h-12 w-12 rounded-md object-cover" /> : <div className="grid h-12 w-12 shrink-0 place-items-center rounded-md bg-white text-[8px] font-black uppercase text-blue-600">{image.name.split(".").pop() || "file"}</div>}<span className="min-w-0 flex-1 truncate">{image.name}</span><button type="button" onClick={() => setImage(null)} className="ml-2 font-black" title="Hapus lampiran">x</button></div>}
            {imageError && <div className="mb-2 text-[9px] font-semibold text-red-600">{imageError}</div>}
            <div className="flex items-end gap-2 rounded-xl border border-slate-200 bg-slate-50 p-2 focus-within:border-blue-300 focus-within:bg-white"><input ref={fileInputRef} type="file" accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt" onChange={onImageChange} className="hidden" /><button type="button" onClick={() => fileInputRef.current?.click()} disabled={loading} title="Tambah file untuk dianalisis" className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-slate-200 bg-white text-slate-600 transition hover:border-blue-200 hover:text-blue-600 disabled:opacity-40"><Icon name="file" size={15} /></button><textarea value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={onInputKeyDown} placeholder="Tulis pertanyaan atau perintah..." rows={2} disabled={loading} className="min-h-[42px] flex-1 resize-none bg-transparent px-2 py-1 text-[10px] text-slate-800 outline-none placeholder:text-slate-400" /><button type="submit" disabled={loading || (!input.trim() && !image)} title="Kirim ke AI" className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-blue-600 text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-40"><Icon name="sparkles" size={15} /></button></div>
          </form>
        </section>
        <aside className="h-fit rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"><div className="text-[11px] font-black text-slate-800">Contoh pertanyaan</div><div className="mt-1 text-[9px] leading-4 text-slate-400">Klik contoh untuk langsung bertanya.</div><div className="mt-3 space-y-2">{suggestions.map((suggestion) => <button key={suggestion} type="button" onClick={() => void send(suggestion)} disabled={loading} className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5 text-left text-[9px] font-semibold leading-4 text-slate-600 transition hover:border-blue-200 hover:bg-blue-50 hover:text-blue-700 disabled:opacity-50">{suggestion}</button>)}</div><div className="mt-5 rounded-xl bg-blue-50 p-3"><div className="flex items-center gap-2 text-[9px] font-black text-blue-700"><Icon name="info" size={13} />Tips</div><p className="mt-1 text-[8px] leading-4 text-blue-700/70">Untuk hasil yang lebih baik, tuliskan nama kegiatan, sasaran, lokasi, dan tujuan kegiatan.</p></div></aside>
      </div>
    </div>
  );
}
