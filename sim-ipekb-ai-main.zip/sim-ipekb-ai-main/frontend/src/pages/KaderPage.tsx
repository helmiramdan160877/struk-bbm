import { useEffect, useMemo, useState, type FormEvent } from "react";
import Icon from "../components/Icon";
import MiniSwal from "../components/MiniSwal";
import { hasPermission, isRole } from "../auth/permissions";
import {
  createKaderMaster,
  deleteKaderMaster,
  getKaderMasters,
  getManageableVillages,
  updateKaderMaster,
  getPkbSigaAccounts,
  getPkbSigaVillages
} from "../services/api";
import type { KaderMaster, ManageableVillage } from "../types/api";
import type { User } from "../types/auth";

interface Props { user: User }
  const emptyForm = { 
    nik:"",
    nama:"",
    email:"",
    phone:"",
    jabatan:"",
    alamat:"",
    siga_account_id:"",
    kecamatan:"",
    village_id:"",
    status:"AKTIF"
  };

export default function KaderPage({ user }: Props) {
  const canManage = hasPermission(user, "kader.manage");
  const superAdmin = isRole(user, ["SUPER_ADMIN", "SUPERADMIN"]);
  const [items,setItems]=useState<KaderMaster[]>([]);
  const [districts,setDistricts]=useState<any[]>([]);
  const [selectedDistrict,setSelectedDistrict]=useState("");
  const [villages,setVillages]=useState<ManageableVillage[]>([]);
  const [sigaAccounts,setSigaAccounts]=useState<any[]>([]);
  const [sigaVillages,setSigaVillages]=useState<any[]>([]);
  const [loading,setLoading]=useState(true);
  const [saving,setSaving]=useState(false);
  const [query,setQuery]=useState("");
  const [pageSize,setPageSize]=useState(10);
  const [page,setPage]=useState(1);
  const [message,setMessage]=useState<{tone:"success"|"error";text:string}|null>(null);
  const [alert,setAlert]=useState<{
        open:boolean;
        title:string;
        text:string;
        tone:"success"|"danger";
      }>({
        open:false,
        title:"",
        text:"",
        tone:"danger"
      });
  const [modalOpen,setModalOpen]=useState(false);
  const [editTarget,setEditTarget]=useState<KaderMaster|null>(null);
  const [deleteTarget,setDeleteTarget]=useState<KaderMaster|null>(null);
  const [form,setForm]=useState(emptyForm);

  const load=async()=>{
    setLoading(true);
    try {
  const [masters, villageList, accountList] = await Promise.all([
    getKaderMasters(),
    canManage ? getManageableVillages() : Promise.resolve([]),
    canManage ? getPkbSigaAccounts() : Promise.resolve([])
  ]);

  setItems(masters);
  setVillages(villageList);
  setSigaAccounts(accountList);
  setMessage(null);
      setItems(masters); setVillages(villageList); setMessage(null);
    } catch(err:any){

  const msg =
    err?.response?.data?.detail ||
    err?.detail ||
    err?.message ||
    "Master Kader gagal disimpan.";

  setAlert({
    open:true,
    title:"Gagal Menyimpan",
    text:typeof msg === "string" ? msg : JSON.stringify(msg),
    tone:"danger"
  });

}
    finally { setLoading(false); }
  };

  useEffect(()=>{
    const timer = window.setTimeout(() => void load(), 0);
    return () => window.clearTimeout(timer);
  },[]); // eslint-disable-line react-hooks/exhaustive-deps

  const filtered=useMemo(()=>{
    const n=query.trim().toLowerCase(); if(!n)return items;
    return items.filter((x)=>[x.nama,x.nik,x.phone,x.email,x.village_name,x.district_name].some((v)=>String(v||"").toLowerCase().includes(n)));
  },[items,query]);
  const pagedItems = useMemo(()=>{

    if(pageSize === 0) return filtered;

    const start = (page - 1) * pageSize;

    return filtered.slice(
      start,
      start + pageSize
    );

},[filtered,page,pageSize]);
  const openCreate=()=>{setEditTarget(null);setForm(emptyForm);setModalOpen(true);};
  const openEdit=(item:KaderMaster)=>{
  setEditTarget(item);

  setForm({
    nik:item.nik,
    nama:item.nama,
    email:item.email||"",
    phone:item.phone||"",
    jabatan:item.jabatan||"",
    alamat:item.alamat||"",
    siga_account_id:"",
    kecamatan:item.district_name||"",
    village_id:item.village_id||"",
    status:item.status||"AKTIF"
  });

  setModalOpen(true);
};

  const submit=async(e:FormEvent)=>{
    e.preventDefault(); setSaving(true); setMessage(null);
    const payload={nik:form.nik.trim(),nama:form.nama.trim(),email:form.email.trim()||null,phone:form.phone.trim()||null,jabatan:form.jabatan.trim()||null,alamat:form.alamat.trim()||null,village_id:form.village_id||null,status:form.status};
    try {
      if(editTarget) await updateKaderMaster(editTarget.id,payload); else await createKaderMaster(payload);
      setModalOpen(false); setMessage({tone:"success",text:`Master Kader berhasil ${editTarget?"diperbarui":"ditambahkan"}.`}); await load();
    } 
    catch(err:any){

  console.log("ERROR SIMPAN KADER:", err);

  const msg =
    err?.response?.data?.detail ||
    err?.detail ||
    err?.message ||
    "Master Kader gagal disimpan.";

  setAlert({
    open:true,
    title:"Gagal Menyimpan",
    text:typeof msg==="string" ? msg : JSON.stringify(msg),
    tone:"danger"
  });

}
    finally{setSaving(false);}
  };

  const remove=async()=>{
    if(!deleteTarget)return; setSaving(true);
    try{await deleteKaderMaster(deleteTarget.id);setDeleteTarget(null);setMessage({tone:"success",text:"Master Kader berhasil dihapus."});await load();}
    catch(err:any){

  const msg =
    err?.response?.data?.detail ||
    err?.detail ||
    err?.message ||
    "Master Kader gagal disimpan.";

  setAlert({
    open:true,
    title:"Gagal Menyimpan",
    text:typeof msg==="string" ? msg : JSON.stringify(msg),
    tone:"danger"
  });

}
    finally{setSaving(false);}
  };

  return <div className="space-y-4">
    <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div><h2 className="text-[17px] font-black tracking-tight text-slate-900">Master Kader</h2><p className="mt-1 text-[10px] leading-4 text-slate-500">Sumber identitas akun role KADER. Data user tidak perlu diketik ulang.</p></div>
      <div className="flex gap-2"><button onClick={()=>void load()} className="inline-flex h-8 items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 text-[10px] font-extrabold text-slate-600"><Icon name="refresh" size={13} className={loading?"animate-spin":""}/> Muat Ulang</button>{canManage&&<button onClick={openCreate} className="inline-flex h-8 items-center gap-2 rounded-lg bg-blue-600 px-3 text-[10px] font-extrabold text-white"><Icon name="plus" size={13}/> Tambah Kader</button>}</div>
    </div>

    
    <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
      <div className="flex items-center justify-between gap-3 border-b border-slate-100 p-3"><div><div className="text-[11px] font-black text-slate-800">Data Master</div><div className="text-[9px] text-slate-400">{filtered.length} kader</div></div><div className="relative w-full max-w-[300px]"><Icon name="search" size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400"/><input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Cari nama, NIK, desa..." className="h-8 w-full rounded-lg border border-slate-200 bg-slate-50 pl-8 pr-2 text-[10px] outline-none focus:border-blue-400 focus:bg-white"/></div></div>
      <div className="overflow-x-auto"><table className="w-full min-w-[860px] text-[10px] border-collapse">
        <thead className="bg-slate-50 text-[9px] font-black uppercase tracking-wide text-slate-400 text-center">
          <tr>
            <th className="px-2 py-2 border text-center">
              Nama Kader
              </th>

              <th className="px-2 py-2 border text-center">
              Email
              </th>

              <th className="px-2 py-2 border text-center">
              NIK
              </th>

              <th className="px-2 py-2 border text-center">
              Kecamatan
              </th>

              <th className="px-2 py-2 border text-center">
              Desa
              </th>

              <th className="px-2 py-2 border text-center">
              Kontak
              </th>

              <th className="px-2 py-2 border text-center">
              Jabatan
              </th>

              <th className="px-2 py-2 border text-center">
              Status
              </th>
            {canManage&&<th className="px-2 py-2 border text-center">Aksi</th>}
            </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">{loading?<tr><td colSpan={7} className="px-3 py-10 text-center text-slate-400">Memuat data...</td></tr>:filtered.length===0?<tr><td colSpan={7} className="px-3 py-10 text-center text-slate-400">Belum ada master Kader.</td></tr>:pagedItems.map((item)=><tr key={item.id} className="hover:bg-slate-50/70">
            <td className="px-1 py-1 border text-center align-middle">
              <div className="font-extrabold text-slate-800">{item.nama}</div>
              </td>
              <td className="px-1 py-1 border text-center align-middle">
                {item.email || "—"}
                </td>
              <td className="px-2 py-2 border font-mono text-center align-middle">{item.nik}</td>
              <td className="px-1 py-1 border text-center align-middle">
                {item.district_name || "—"}
                </td>
              <td className="px-1 py-1 border text-center align-middle">
                <div className="font-bold text-slate-700">{item.village_name||"—"}</div>
                </td>
                <td className="px-1 py-1 border text-center align-middle">{item.phone||"—"}</td>
                <td className="px-1 py-1 border text-center align-middle">{item.jabatan||"—"}</td>
                <td className="px-1 py-1 border text-center align-middle"><span className={`rounded-full px-2 py-1 text-[8px] font-black ${item.status==="AKTIF"?"bg-emerald-50 text-emerald-700":"bg-slate-100 text-slate-500"}`}>{item.status}</span></td>{canManage&&<td className="px-1 py-1 border text-center align-middle">
                  <div className="flex items-center justify-center gap-1"><button
      title="Edit Kader"
      onClick={()=>openEdit(item)} className="grid h-5 w-5 place-items-center rounded border border-slate-200 text-slate-500 hover:text-blue-600"><Icon name="edit" size={12}/></button>{superAdmin&&<button
      title="Hapus Kader"
      onClick={()=>setDeleteTarget(item)} className="grid h-7 w-7 place-items-center rounded-lg border border-slate-200 text-slate-500 hover:text-red-600"><Icon name="trash" size={12}/></button>}</div></td>}</tr>)}</tbody></table><div className="flex items-center justify-between border-t border-slate-100 px-3 py-2">

      <div className="text-[10px] text-slate-500">

Menampilkan{" "}

<span className="font-bold text-slate-700">
{filtered.length === 0 ? 0 : ((page-1)*pageSize)+1}
</span>

{" - "}

<span className="font-bold text-slate-700">
{
pageSize===0 
? filtered.length 
: Math.min(page*pageSize, filtered.length)
}
</span>

{" dari "}

<span className="font-bold text-slate-700">
{filtered.length}
</span>

{" kader"}

</div>


<div className="flex items-center gap-2">


<select
value={pageSize}
onChange={(e)=>{
setPageSize(Number(e.target.value));
setPage(1);
}}
className="h-7 rounded-lg border border-slate-200 px-2 text-[10px]"
>

<option value={5}>5</option>
<option value={10}>10</option>
<option value={20}>20</option>
<option value={50}>50</option>
<option value={0}>ALL</option>

</select>


<button
disabled={page===1}
onClick={()=>setPage(page-1)}
className="h-7 rounded-lg border px-3 text-[10px] disabled:opacity-40"
>
Prev
</button>


<span className="text-[10px] font-bold">
{page}
</span>


<button
disabled={
pageSize===0 ||
page*pageSize>=filtered.length
}
onClick={()=>setPage(page+1)}
className="h-7 rounded-lg border px-3 text-[10px] disabled:opacity-40"
>
Next
</button>


</div>

</div></div>
    </div>

    {modalOpen&&canManage&&(
<div className="fixed inset-0 z-[100] grid place-items-center overflow-y-auto bg-slate-950/35 p-4 backdrop-blur-[2px]">

<form onSubmit={submit} className="w-full max-w-xl rounded-2xl border border-slate-200 bg-white shadow-2xl">

<div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
<div>
<div className="text-[12px] font-black text-slate-900">
{editTarget?"Edit":"Tambah"} Master Kader
</div>
<div className="mt-0.5 text-[9px] text-slate-400">
Data ini menjadi sumber akun KADER.
</div>
</div>

<button type="button" onClick={()=>setModalOpen(false)}
className="grid h-7 w-7 place-items-center rounded-lg bg-slate-100 text-slate-500">
<Icon name="close" size={13}/>
</button>
</div>


<div className="grid gap-3 p-4 sm:grid-cols-2">

<Field label="Nama Kader" value={form.nama} onChange={(v)=>setForm({...form,nama:v})} required/>

<Field label="NIK / ID Kader" value={form.nik} onChange={(v)=>setForm({...form,nik:v})} required/>

<Field label="Email" type="email" value={form.email} onChange={(v)=>setForm({...form,email:v})} required/>

<Field label="Nomor WhatsApp" value={form.phone} onChange={(v)=>setForm({...form,phone:v})} required/>

<Field label="Jabatan" value={form.jabatan} onChange={(v)=>setForm({...form,jabatan:v})} required/>


<label>
<Label>Status</Label>
<select
value={form.status}
onChange={(e)=>setForm({...form,status:e.target.value})}
className="h-8 w-full rounded-lg border border-slate-200 px-2 text-[10px]"
>
<option>AKTIF</option>
<option>NONAKTIF</option>
</select>
</label>



<label>
<Label>Akun SIGA</Label>

<select 
value={form.siga_account_id} 
onChange={async(e)=>{

  const id = e.target.value;

  const akun = sigaAccounts.find(
    (a)=>a.id === id
  );

  if(!akun){
    setForm({
      ...form,
      siga_account_id:"",
      kecamatan:"",
      village_id:""
    });
    setSigaVillages([]);
    return;
  }

  const villages = await getPkbSigaVillages(id);

  setSigaVillages(villages);

  setForm({
    ...form,
    siga_account_id:id,
    kecamatan:akun.district_name || "",
    village_id:""
  });

}}
className="h-8 w-full rounded-lg border border-slate-200 px-2 text-[10px]" 
>
<option value="">Pilih Akun SIGA</option>

{sigaAccounts.map((a)=>(
<option key={a.id} value={a.id}>
{a.name || a.username}
</option>
))}

</select>
</label>


<label>
<Label>Kecamatan</Label>

<input
value={form.kecamatan}
readOnly
className="h-8 w-full rounded-lg border border-slate-200 px-2 text-[10px] bg-slate-50"
/>

</label>

<label>
<Label>Desa Binaan (SIGA)</Label>
<select
required
value={form.village_id}
onChange={(e)=>setForm({...form,village_id:e.target.value})}
className="h-8 w-full rounded-lg border border-slate-200 px-2 text-[10px]"
>

<option value="">Pilih Desa</option>

{sigaVillages.map(v=>( 
<option key={v.id} value={v.id}> 
{v.name}
</option> 
))}

</select>
</label>


<label className="sm:col-span-2">
<Label>Alamat</Label>
<textarea
value={form.alamat}
onChange={(e)=>setForm({...form,alamat:e.target.value})}
className="min-h-16 w-full rounded-lg border border-slate-200 p-2 text-[10px] outline-none focus:border-blue-400"
/>
</label>

</div>


<div className="flex justify-end gap-2 border-t border-slate-100 bg-slate-50 px-4 py-3">

<button type="button"
onClick={()=>setModalOpen(false)}
className="h-8 rounded-lg border border-slate-200 bg-white px-3 text-[10px] font-extrabold text-slate-600">
Batal
</button>

<button disabled={saving}
className="h-8 rounded-lg bg-blue-600 px-4 text-[10px] font-extrabold text-white disabled:opacity-50">
{saving?"Menyimpan...":"Simpan"}
</button>

</div>


</form>

</div>
)}
    <MiniSwal open={!!deleteTarget} title="Hapus master Kader" text={`Data ${deleteTarget?.nama||"Kader"} akan dihapus permanen. Master yang sudah terhubung ke user tidak dapat dihapus.`} tone="danger" confirmText="Hapus" busy={saving} onCancel={()=>setDeleteTarget(null)} onConfirm={()=>void remove()}/>
  </div>;
    <MiniSwal
    open={alert.open}
    title={alert.title}
    text={alert.text}
    tone={alert.tone}
    confirmText="OK"
    onCancel={()=>setAlert({
      ...alert,
      open:false
    })}
    onConfirm={()=>setAlert({
      ...alert,
      open:false
    })}
/>
}

function Label({children}:{children:React.ReactNode}){return <span className="mb-1 block text-[9px] font-black uppercase tracking-wide text-slate-500">{children}</span>}
function Field({label,value,onChange,required=false,type="text"}:{label:string;value:string;onChange:(v:string)=>void;required?:boolean;type?:string}){return <label><Label>{label}{required?" *":""}</Label><input required={required} type={type} value={value} onChange={(e)=>onChange(e.target.value)} className="h-8 w-full rounded-lg border border-slate-200 px-2 text-[10px] outline-none focus:border-blue-400"/></label>}
