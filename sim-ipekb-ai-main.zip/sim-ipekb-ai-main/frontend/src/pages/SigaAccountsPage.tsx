import { useEffect, useMemo, useState, type FormEvent } from "react";
import Icon from "../components/Icon";
import MiniSwal from "../components/MiniSwal";
import { getSigaAccounts, getDistricts, createSigaAccount, updateSigaAccount, deleteSigaAccount } from "../services/api";
import type { SigaAccount, District } from "../types/api";
import type { User } from "../types/auth";
import { hasPermission, isRole } from "../auth/permissions";

function dateTime(value: string | null) { if(!value) return 'Belum pernah'; const date=new Date(value); return Number.isNaN(date.getTime())?value:new Intl.DateTimeFormat('id-ID',{dateStyle:'medium',timeStyle:'short'}).format(date); }

type FormMode = "create" | "edit" | null;

export default function SigaAccountsPage({ user, onNavigate }: { user: User; onNavigate: (page:string)=>void }) {
  const canSync = hasPermission(user, "siga.sync");
  const canManage = hasPermission(user, "siga.manage");
  const pkbScoped = isRole(user, "PKB");
  const [items,setItems]=useState<SigaAccount[]>([]); 
  const [loading,setLoading]=useState(true); 
  const [error,setError]=useState('');
  const [districts, setDistricts] = useState<District[]>([]);
  const [formMode, setFormMode] = useState<FormMode>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ districtId: '', username: '', password: '', userId: '' });
  const [formError, setFormError] = useState('');
  const [formLoading, setFormLoading] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<SigaAccount | null>(null);
  const [deleting, setDeleting] = useState(false);

  const districtMap = useMemo(() => new Map(districts.map((district) => [district.id, district.name])), [districts]);

  const loadData = async () => {
    try {
      const [accounts, dists] = await Promise.all([
        getSigaAccounts(),
        getDistricts(),
      ]);
      setItems(accounts);
      setDistricts(dists);
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Akun SIGA gagal dimuat.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let active = true;
    (async () => {
      if (active) await loadData();
    })();
    return () => { active = false; };
  }, []);

  const handleOpenCreate = () => {
    setFormMode("create");
    setEditingId(null);
    setFormData({ districtId: '', username: '', password: '', userId: '' });
    setFormError('');
  };

  const handleOpenEdit = (item: SigaAccount) => {
    setFormMode("edit");
    setEditingId(item.id);
    setFormData({ districtId: item.district_id || '', username: item.username, password: '', userId: item.linked_user_id || '' });
    setFormError('');
  };

  const handleCloseForm = () => {
    setFormMode(null);
    setEditingId(null);
    setFormData({ districtId: '', username: '', password: '', userId: '' });
    setFormError('');
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError('');

    setFormLoading(true);

    try {
      if (formMode === "create") {
        await createSigaAccount({
          username: formData.username,
          password: formData.password,
        });
      } else if (formMode === "edit" && editingId) {
        await updateSigaAccount(editingId, {
          username: formData.username || undefined,
          password: formData.password || undefined,
        });
      }
      handleCloseForm();
      await loadData();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Gagal menyimpan akun SIGA.');
    } finally {
      setFormLoading(false);
    }
  };

  const handleDelete = (id: string) => {
    const target = items.find((item) => item.id === id);
    if (!target) return;
    setDeleteTarget(target);
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await deleteSigaAccount(deleteTarget.id);
      setDeleteTarget(null);
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gagal menghapus akun SIGA.');
    } finally {
      setDeleting(false);
    }
  };

  return <div className="space-y-5">
    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h2 className="text-xl font-black tracking-tight text-[#142b4c]">Akun SIGA</h2>
        <p className="mt-1 text-xs text-slate-500">Akun integrasi yang digunakan untuk mengambil dan menyinkronkan data SIGA.</p>
      </div>
      <div className="flex gap-2">
        {canManage && <button type="button" onClick={handleOpenCreate} className="inline-flex h-10 items-center gap-2 self-start rounded-xl bg-emerald-600 px-4 text-xs font-extrabold text-white"><Icon name="plus" size={16}/> Tambah Akun</button>}
        {canSync && <button type="button" onClick={()=>onNavigate('sync')} className="inline-flex h-10 items-center gap-2 self-start rounded-xl bg-blue-600 px-4 text-xs font-extrabold text-white"><Icon name="sync" size={16}/> Sinkronisasi</button>}
      </div>
    </div>

    {pkbScoped && <div className="flex items-start gap-3 rounded-2xl border border-blue-100 bg-blue-50/70 p-4 text-[11px] leading-5 text-blue-800"><Icon name="map" size={17} className="mt-0.5 shrink-0"/><div><div className="font-extrabold">Akun SIGA mengikuti wilayah binaan PKB</div><div className="mt-0.5 text-blue-700/80">Daftar ini hanya menampilkan akun SIGA pada kecamatan yang berasal dari desa atau kelurahan binaan akun PKB yang sedang login.</div></div></div>}

    <div className="grid gap-3 sm:grid-cols-3">
      <div className="rounded-[18px] border border-slate-200 bg-white p-4"><div className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">Total Akun</div><div className="mt-2 text-2xl font-black text-[#142b4c]">{loading?'—':items.length}</div></div>
      <div className="rounded-[18px] border border-slate-200 bg-white p-4"><div className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">Akun Aktif</div><div className="mt-2 text-2xl font-black text-emerald-700">{loading?'—':items.filter(x=>x.is_active).length}</div></div>
      <div className="rounded-[18px] border border-slate-200 bg-white p-4"><div className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400">Pernah Sinkron</div><div className="mt-2 text-2xl font-black text-blue-700">{loading?'—':items.filter(x=>x.last_sync_at).length}</div></div>
    </div>

    {error && <div className="rounded-xl border border-red-100 bg-red-50 p-4 text-xs font-semibold text-red-700">{error}</div>}

    <div className="grid gap-4 lg:grid-cols-2">
      {loading?Array.from({length:2}).map((_,i)=>
        <div key={i} className="h-44 animate-pulse rounded-[20px] border border-slate-200 bg-white"/>):items.length===0?<div className="rounded-[20px] border border-dashed border-slate-300 bg-white p-10 text-center lg:col-span-2"><div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-slate-50 text-slate-300"><Icon name="database"/></div><div className="mt-3 text-xs font-bold text-slate-500">Belum ada akun SIGA</div></div>:items.map(item=><div key={item.id} className="rounded-[20px] border border-slate-200 bg-white p-5 shadow-sm"><div className="flex items-start justify-between gap-4"><div className="flex min-w-0 items-center gap-3"><div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-blue-50 text-blue-700"><Icon name="database" size={19}/></div><div className="min-w-0"><div className="truncate text-sm font-extrabold text-[#142b4c]">{item.username}</div><div className="mt-1 truncate font-mono text-[9px] text-slate-400">{item.id}</div></div></div><span className={`rounded-full px-2.5 py-1 text-[9px] font-extrabold ${item.is_active?'bg-emerald-50 text-emerald-700':'bg-slate-100 text-slate-500'}`}>{item.is_active?'AKTIF':'NONAKTIF'}</span></div><div className="mt-5 grid grid-cols-2 gap-3"><div className="rounded-xl bg-slate-50 p-3"><div className="text-[9px] font-bold uppercase tracking-wide text-slate-400">Kecamatan</div>
        <div className="mt-1 truncate text-[10px] font-semibold text-slate-600">
          {item.district_name 
            || (item.district_id ? districtMap.get(item.district_id) : null) 
            || 'Belum dipetakan'}
        </div></div><div className="rounded-xl bg-slate-50 p-3"><div className="text-[9px] font-bold uppercase tracking-wide text-slate-400">Sinkron Terakhir</div><div className="mt-1 text-[10px] font-semibold text-slate-600">{dateTime(item.last_sync_at)}</div></div></div>{canManage && <div className="mt-4 flex gap-2"><button type="button" onClick={() => handleOpenEdit(item)} className="flex-1 rounded-xl border border-blue-200 bg-blue-50 py-2 text-xs font-extrabold text-blue-700 hover:bg-blue-100"><Icon name="edit" size={12} className="inline mr-1"/>Edit</button><button type="button" onClick={() => handleDelete(item.id)} className="flex-1 rounded-xl border border-red-200 bg-red-50 py-2 text-xs font-extrabold text-red-700 hover:bg-red-100"><Icon name="trash" size={12} className="inline mr-1"/>Hapus</button></div>}</div>)}
            </div>

    {/* MODAL FORM */}
    {formMode && canManage && (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-[22px] max-w-md w-full p-6 shadow-lg">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-extrabold text-[#142b4c]">
              {formMode === "create" ? "Tambah Akun SIGA" : "Edit Akun SIGA"}
            </h3>
            <button type="button" onClick={handleCloseForm} className="text-slate-400 hover:text-slate-600">
              <Icon name="x" size={20}/>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <label className="block">
              <span className="mb-1.5 block text-[10px] font-extrabold uppercase tracking-wide text-slate-500">Username SIGA</span>
              <input 
                type="text"
                value={formData.username}
                onChange={e => setFormData({...formData, username: e.target.value})}
                required
                placeholder="Masukkan username SIGA"
                className="h-11 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none focus:border-blue-400"
              />
            </label>

            <label className="block">
              <span className="mb-1.5 block text-[10px] font-extrabold uppercase tracking-wide text-slate-500">Password SIGA {formMode === 'edit' && <span className="text-slate-400">(kosongkan jika tidak diubah)</span>}</span>
              <input 
                type="password"
                value={formData.password}
                onChange={e => setFormData({...formData, password: e.target.value})}
                required={formMode === "create"}
                placeholder="Masukkan password SIGA"
                autoComplete="new-password"
                className="h-11 w-full rounded-xl border border-slate-200 px-3 text-xs outline-none focus:border-blue-400 focus:ring-4 focus:ring-blue-50"
              />
            </label>


            {formError && <div className="flex gap-2 rounded-xl border border-red-100 bg-red-50 p-3 text-[11px] font-semibold leading-5 text-red-700"><Icon name="alert" size={16} className="mt-0.5 shrink-0"/>{formError}</div>}

            <div className="flex gap-2 pt-4">
              <button 
                type="button" 
                onClick={handleCloseForm}
                className="flex-1 h-11 rounded-xl border border-slate-200 text-xs font-extrabold text-slate-600 hover:bg-slate-50"
              >
                Batal
              </button>
              <button 
                type="submit"
                disabled={formLoading}
                className="flex-1 flex items-center justify-center gap-2 h-11 rounded-xl bg-blue-600 text-xs font-extrabold text-white disabled:opacity-60"
              >
                {formLoading ? <>
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white"/>
                  Menyimpan...
                </> : <>
                  <Icon name="check" size={16}/>
                  {formMode === "create" ? "Buat Akun" : "Simpan"}
                </>}
              </button>
            </div>
          </form>
        </div>
      </div>
    )}
    <MiniSwal open={Boolean(deleteTarget)} title="Konfirmasi hapus" text={`Hapus akun SIGA ${deleteTarget?.username || "ini"} secara permanen?`} tone="danger" confirmText="Hapus" busy={deleting} onCancel={() => setDeleteTarget(null)} onConfirm={() => void confirmDelete()}/>
  </div>;
}
