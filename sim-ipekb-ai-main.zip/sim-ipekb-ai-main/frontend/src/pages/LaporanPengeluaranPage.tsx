import { useState } from "react";
import type { User } from "../types/auth";
import Icon from "../components/Icon";
import MiniSwal from "../components/MiniSwal";


interface Props {
  user: User;
}

interface Expense {
  id: number;
  date: string;
  description: string;
  evidence: string;
  amount: number;
}

export default function LaporanPengeluaranPage({user}: Props) {

  const tanggal = new Date().toLocaleDateString("id-ID");
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [inputOpen, setInputOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Expense | null>(null);
  const [editTarget, setEditTarget] = useState<Expense | null>(null);
  const [emptyAction, setEmptyAction] = useState<"edit" | "delete" | null>(null);
  const [form, setForm] = useState({ date: new Date().toISOString().slice(0, 10), description: "", evidence: "", amount: "" });


  const printPDF = () => {
    window.print();
  };


  const exportExcel = () => {

    const csv = `
LAPORAN PENGELUARAN IPKB

Tanggal, Keterangan, Bukti Pengeluaran, Jumlah
${expenses.length ? expenses.map((item) => `${item.date}, ${item.description}, ${item.evidence || "-"}, ${item.amount}`).join("\n") : `${tanggal}, Belum ada data, -, 0`}

Bendahara,
${user.full_name}
NIP,
${user.nip || "-"}
`;

    const blob = new Blob(
      [csv],
      {
        type:"application/vnd.ms-excel"
      }
    );


    const url = URL.createObjectURL(blob);

    const a=document.createElement("a");

    a.href=url;

    a.download="laporan-pengeluaran.xls";

    a.click();
    URL.revokeObjectURL(url);

  };

  const addExpense = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const expense = { id: editingId || Date.now(), date: form.date, description: form.description.trim(), evidence: form.evidence.trim(), amount: Number(form.amount) };
    setExpenses((current) => editingId ? current.map((item) => item.id === editingId ? expense : item) : [...current, expense]);
    setForm({ date: new Date().toISOString().slice(0, 10), description: "", evidence: "", amount: "" });
    setEditingId(null);
    setInputOpen(false);
  };

  const editExpense = (expense: Expense) => {
    setEditTarget(expense);
  };

  const confirmEdit = () => {
    if (!editTarget) return;
    const expense = editTarget;
    setEditingId(expense.id);
    setForm({ date: expense.date, description: expense.description, evidence: expense.evidence, amount: String(expense.amount) });
    setInputOpen(true);
    setEditTarget(null);
  };

  const removeExpense = () => {
    if (!deleteTarget) return;
    setExpenses((current) => current.filter((item) => item.id !== deleteTarget.id));
    setDeleteTarget(null);
  };



return (

<div className="space-y-5">


<section className="rounded-2xl bg-white p-6 shadow">

<div className="flex items-start justify-between gap-4">

<div className="flex items-start gap-3">
<button type="button" title="Input data pengeluaran" aria-label="Input data pengeluaran" onClick={() => setInputOpen(true)} className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-blue-600 text-white transition hover:bg-blue-700 hover:shadow-md hover:shadow-blue-200">
<Icon name="plus" size={16}/>
</button>
<div>

<h1 className="text-xl font-black">
Laporan Pengeluaran
</h1>

<p className="text-xs text-slate-500">
Rincian penggunaan dana IPKB
</p>

</div>
</div>


<div className="flex gap-2">


<button
type="button"
title="Cetak laporan PDF"
aria-label="Cetak laporan PDF"
onClick={printPDF}
className="grid h-9 w-9 place-items-center rounded-xl bg-blue-600 text-white transition hover:bg-blue-700"
>

<Icon name="file" size={15}/>

</button>



<button
type="button"
title="Ekspor laporan Excel"
aria-label="Ekspor laporan Excel"
onClick={exportExcel}
className="grid h-9 w-9 place-items-center rounded-xl bg-emerald-600 text-white transition hover:bg-emerald-700"
>

<Icon name="download" size={15}/>

</button>


</div>

</div>


</section>



<section
id="print-area"
className="relative min-h-175 rounded-2xl bg-white p-8 shadow"
>


<h2 className="text-center text-lg font-black">
LAPORAN RINCIAN PENGELUARAN IPKB
</h2>


<p className="mt-2 text-center text-xs">
Periode {tanggal}
</p>



<table className="mt-8 w-full border-collapse text-sm">


<thead>

<tr className="bg-slate-100">

<th className="w-10 border px-1.5 py-1.5 text-center">
No
</th>

<th className="border px-2 py-1.5">
Tanggal
</th>

<th className="border px-2 py-1.5">
Uraian
</th>
<th className="border px-2 py-1.5">
Bukti Pengeluaran
</th>

<th className="border px-2 py-1.5 text-center">
Jumlah
</th>

<th className="print:hidden border px-2 py-1.5 text-center">
Aksi
</th>


</tr>

</thead>


<tbody>
{expenses.length === 0 ? <tr>

<td className="w-10 border px-1.5 py-1.5 text-center">
1
</td>

<td className="border px-2 py-1.5">
-
</td>

<td className="border px-2 py-1.5">
Belum ada data
</td>
<td className="border px-2 py-1.5">
Belum ada data
</td>

<td className="border px-2 py-1.5 text-right">
Rp 0
</td>

<td className="print:hidden border px-2 py-1.5"><div className="flex justify-center gap-1"><button type="button" title="Edit pengeluaran" aria-label="Edit pengeluaran" onClick={() => setEmptyAction("edit")} className="grid h-7 w-7 place-items-center rounded-lg border border-blue-200 text-blue-400 transition hover:bg-blue-50 hover:text-blue-600"><Icon name="edit" size={13}/></button><button type="button" title="Hapus pengeluaran" aria-label="Hapus pengeluaran" onClick={() => setEmptyAction("delete")} className="grid h-7 w-7 place-items-center rounded-lg border border-red-200 text-red-400 transition hover:bg-red-50 hover:text-red-600"><Icon name="trash" size={13}/></button></div></td>


</tr> : expenses.map((item, index) => <tr key={item.id}>
<td className="w-10 border px-1.5 py-1.5 text-center">{index + 1}</td>
<td className="border px-2 py-1.5">{item.date}</td>
<td className="border px-2 py-1.5">{item.description}</td>
<td className="border px-2 py-1.5">{item.evidence || "-"}</td>
<td className="border px-2 py-1.5 text-right">Rp {item.amount.toLocaleString("id-ID")}</td>
<td className="print:hidden border px-2 py-1.5"><div className="flex justify-center gap-1"><button type="button" title="Edit pengeluaran" aria-label={`Edit pengeluaran ${item.description}`} onClick={() => editExpense(item)} className="grid h-7 w-7 place-items-center rounded-lg border border-blue-200 text-blue-600 transition hover:bg-blue-50"><Icon name="edit" size={13}/></button><button type="button" title="Hapus pengeluaran" aria-label={`Hapus pengeluaran ${item.description}`} onClick={() => setDeleteTarget(item)} className="grid h-7 w-7 place-items-center rounded-lg border border-red-200 text-red-600 transition hover:bg-red-50"><Icon name="trash" size={13}/></button></div></td>
</tr>)}


</tbody>


</table>



<div className="absolute bottom-8 right-8 text-right text-xs">


<p>
Mengetahui,
</p>

<div className="mt-12">
<p className="font-bold">
Bendahara IPKB
</p>



<p>
{user.full_name}
</p>


<p>
NIP. {user.nip || "-"}
</p>


<p className="mt-5">
{new Date().toLocaleDateString("id-ID")}
</p>
</div>


</div>



</section>

{inputOpen && <div className="fixed inset-0 z-120 grid place-items-center bg-slate-950/35 p-4 backdrop-blur-sm"><form onSubmit={addExpense} className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-5 shadow-2xl"><div className="flex items-center justify-between"><div><h2 className="text-sm font-black text-slate-900">{editingId ? "Edit Pengeluaran" : "Input Pengeluaran"}</h2><p className="mt-1 text-[10px] text-slate-500">Tambahkan transaksi ke laporan ini.</p></div><button type="button" title="Tutup" aria-label="Tutup" onClick={() => { setInputOpen(false); setEditingId(null); }} className="grid h-8 w-8 place-items-center rounded-lg bg-slate-100 text-slate-500"><Icon name="close" size={14}/></button></div><div className="mt-4 space-y-3"><label className="block"><span className="mb-1 block text-[10px] font-bold text-slate-600">Tanggal</span><input required type="date" value={form.date} onChange={(event) => setForm({...form, date: event.target.value})} className="input-mini" /></label><label className="block"><span className="mb-1 block text-[10px] font-bold text-slate-600">Uraian</span><input required value={form.description} onChange={(event) => setForm({...form, description: event.target.value})} placeholder="Contoh: Konsumsi rapat" className="input-mini" /></label><label className="block"><span className="mb-1 block text-[10px] font-bold text-slate-600">Bukti Pengeluaran PDF/JPG</span><input required type="file" accept="application/pdf,image/jpeg,image/jpg" onChange={(event) => setForm({...form, evidence: event.target.files?.[0]?.name || ""})} className="block w-full rounded-lg border border-slate-200 px-2 py-2 text-[10px] text-slate-600 file:mr-2 file:rounded-md file:border-0 file:bg-blue-50 file:px-2 file:py-1 file:text-[10px] file:font-bold file:text-blue-700" /><span className="mt-1 block text-[9px] text-slate-400">Format: PDF atau JPG/JPEG.</span></label><label className="block"><span className="mb-1 block text-[10px] font-bold text-slate-600">Jumlah</span><input required min="1" type="number" value={form.amount} onChange={(event) => setForm({...form, amount: event.target.value})} placeholder="0" className="input-mini" /></label></div><div className="mt-5 flex justify-end gap-2"><button type="button" onClick={() => { setInputOpen(false); setEditingId(null); }} className="h-9 rounded-lg border border-slate-200 px-3 text-[10px] font-bold text-slate-600">Batal</button><button type="submit" className="grid h-9 w-9 place-items-center rounded-lg bg-blue-600 text-white" title="Simpan pengeluaran" aria-label="Simpan pengeluaran"><Icon name="check" size={15}/></button></div></form></div>}


<MiniSwal open={Boolean(deleteTarget)} title="Hapus pengeluaran" text={`Data ${deleteTarget?.description || "ini"} akan dihapus. Lanjutkan?`} tone="danger" confirmText="Hapus" onCancel={() => setDeleteTarget(null)} onConfirm={removeExpense}/>
<MiniSwal open={Boolean(editTarget)} title="Edit pengeluaran" text={`Apakah Anda yakin ingin mengedit data ${editTarget?.description || "ini"}?`} confirmText="Ya, edit" onCancel={() => setEditTarget(null)} onConfirm={confirmEdit}/>
<MiniSwal open={Boolean(emptyAction)} title="Belum ada data" text={`Belum ada data pengeluaran untuk ${emptyAction === "edit" ? "diedit" : "dihapus"}. Silakan input data terlebih dahulu.`} confirmText="Mengerti" onCancel={() => setEmptyAction(null)} onConfirm={() => setEmptyAction(null)}/>
</div>

);

}