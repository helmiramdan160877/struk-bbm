import { useState, type FormEvent } from "react";
import Icon from "../components/Icon";
import Toast from "../components/Toast";
import { login } from "../services/api";

interface LoginProps {
  onLogin: () => void | Promise<void>;
}

export default function Login({ onLogin }: LoginProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(username.trim(), password);
      await onLogin();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login gagal. Silakan coba kembali.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
    <Toast
      open={Boolean(error)}
      title="Login gagal"
      message={error}
      tone="error"
      onClose={() => setError("")}
    />
    <div className="relative min-h-screen overflow-hidden bg-[#edf4ff] px-4 py-8 sm:px-6">
      <div className="pointer-events-none absolute -left-24 -top-24 h-80 w-80 rounded-full bg-blue-300/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-28 right-0 h-96 w-96 rounded-full bg-cyan-300/25 blur-3xl" />
      <div className="relative mx-auto grid min-h-[calc(100vh-4rem)] max-w-6xl overflow-hidden rounded-[28px] border border-white/60 bg-white shadow-[0_30px_80px_rgba(35,73,135,.15)] lg:grid-cols-[1.08fr_.92fr]">
        <section className="relative hidden overflow-hidden bg-[#102a52] lg:flex lg:flex-col lg:justify-between">
          <img
            src="/gedung-kemendukbangga.png"
            alt="Gedung Kemendukbangga/BKKBN"
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-[#0b2d59]/90 via-[#0b3d78]/65 to-[#0d6acb]/45" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_15%,rgba(255,255,255,.18),transparent_30%),linear-gradient(180deg,transparent_35%,rgba(4,20,45,.78))]" />

          <div className="relative z-10 p-10 xl:p-12">
            <div className="flex items-center gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white/95 shadow-lg ring-1 ring-white/60">
                <img src="/logo-kemendukbangga.png" alt="Kemendukbangga/BKKBN" className="h-8 w-8 object-contain" />
              </div>
              <div className="rounded-xl bg-white/10 px-3 py-2 backdrop-blur-md ring-1 ring-white/20">
                <div className="text-lg font-black tracking-wide text-white">SIPEKB</div>
                <div className="text-[9px] font-semibold uppercase tracking-[.16em] text-blue-100">Sistem Informasi Penyuluh KB</div>
              </div>
            </div>

            <div className="mt-24 max-w-lg">
              <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/12 px-3 py-1.5 text-[11px] font-bold text-white backdrop-blur-md">
                <Icon name="shield" size={15} /> Data SIGA terintegrasi
              </div>
              <h1 className="text-4xl font-black leading-tight tracking-[-.035em] text-white xl:text-5xl">
                Selamat datang di SIPEKB
              </h1>
              <p className="mt-5 max-w-md text-sm leading-7 text-blue-50/90">
                Sistem Informasi Penyuluh KB untuk mengelola data keluarga, wilayah, kegiatan, pelaporan, dan integrasi SIGA.
              </p>
            </div>
          </div>

          <div className="relative z-10 grid grid-cols-3 gap-3 p-10 pt-0 xl:p-12 xl:pt-0">
            {[
              ["family", "Data Keluarga"],
              ["dashboard", "Dashboard SIGA"],
              ["sync", "Sinkronisasi"],
            ].map(([icon, label]) => (
              <div key={label} className="rounded-2xl border border-white/15 bg-white/12 p-4 text-white shadow-lg backdrop-blur-md">
                <Icon name={icon as "family" | "dashboard" | "sync"} size={19} className="text-blue-100" />
                <div className="mt-3 text-xs font-bold">{label}</div>
              </div>
            ))}
          </div>
        </section>

        <section className="flex items-center justify-center p-6 sm:p-10 lg:p-14">
          <div className="w-full max-w-md">
            <div className="mb-9 lg:hidden">
              <div className="mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-200"><Icon name="sparkles" /></div>
              <div className="text-xl font-black text-[#142b4c]">SIPEKB AI</div>
            </div>
            <div>
              <p className="text-xs font-bold uppercase tracking-[.16em] text-blue-600">Selamat datang</p>
              <h2 className="mt-2 text-3xl font-black tracking-[-.03em] text-[#142b4c]">Masuk ke akun Anda</h2>
              <p className="mt-2 text-sm leading-6 text-slate-500">Gunakan akun SIM IPEKB AI yang telah terdaftar.</p>
            </div>

            <form onSubmit={handleSubmit} className="mt-8 space-y-5">
              <div>
                <label className="mb-2 block text-xs font-bold text-slate-700">Username</label>
                <div className="relative">
                  <Icon name="user" size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input value={username} onChange={(e) => setUsername(e.target.value)} required autoComplete="username" placeholder="Masukkan username" className="h-12 w-full rounded-xl border border-slate-200 bg-slate-50/70 pl-11 pr-4 text-sm outline-none transition focus:border-blue-400 focus:bg-white focus:ring-4 focus:ring-blue-100/70" />
                </div>
              </div>
              <div>
                <label className="mb-2 block text-xs font-bold text-slate-700">Password</label>
                <div className="relative">
                  <Icon name="shield" size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} required autoComplete="current-password" placeholder="Masukkan password" className="h-12 w-full rounded-xl border border-slate-200 bg-slate-50/70 pl-11 pr-12 text-sm outline-none transition focus:border-blue-400 focus:bg-white focus:ring-4 focus:ring-blue-100/70" />
                  <button type="button" onClick={() => setShowPassword((value) => !value)} className="absolute right-3 top-1/2 grid h-8 w-8 -translate-y-1/2 place-items-center text-slate-400 hover:text-blue-600" aria-label="Tampilkan password"><Icon name="eye" size={17} /></button>
                </div>
              </div>
              {error && <div className="flex items-start gap-2 rounded-xl border border-red-100 bg-red-50 px-3.5 py-3 text-xs font-medium leading-5 text-red-700"><Icon name="alert" size={17} className="mt-0.5 shrink-0" />{error}</div>}
              <button type="submit" disabled={loading} className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#2f6feb] px-4 text-sm font-extrabold text-white shadow-lg shadow-blue-200 transition hover:bg-[#245ed0] disabled:cursor-wait disabled:opacity-70">
                {loading ? <><span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />Memproses...</> : <>Masuk <Icon name="chevronRight" size={17} /></>}
              </button>
            </form>
            <p className="mt-8 text-center text-[11px] text-slate-400">SIPEKB AI • Sistem Informasi IPEKB</p>
          </div>
        </section>
      </div>
    </div>
    </>
  );
}
