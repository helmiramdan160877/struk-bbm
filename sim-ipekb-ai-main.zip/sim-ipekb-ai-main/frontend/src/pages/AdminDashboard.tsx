import { useEffect, useMemo, useState, type ReactElement } from "react";
import Icon, { type IconName } from "../components/Icon";
import { getDashboardSigaPoktan, getDashboardSigaPoktanAttendance, getDashboardSigaRecap, getDashboardSigaStats, getDashboardSummary, getSigaKampungKb } from "../services/api";
import type { DashboardSigaPoktanAttendanceResponse, DashboardSigaPoktanResponse, DashboardSigaRecap, DashboardSigaStats, DashboardSummary } from "../types/api";
import type { User } from "../types/auth";
import { hasPermission, isRole } from "../auth/permissions";
import type { Permission } from "../config/permissions";

interface DashboardProps {
  user: User;
  onNavigate: (page: string) => void;
}

function formatNumber(value: number | undefined) {
  return new Intl.NumberFormat("id-ID").format(value ?? 0);
}

function formatDateTime(value: string | null | undefined) {
  if (!value) return "Belum pernah sinkron";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("id-ID", { dateStyle: "medium", timeStyle: "short" }).format(date);
}

export default function AdminDashboard({ user, onNavigate }: DashboardProps): ReactElement {
  const [data, setData] = useState<DashboardSummary | null>(null);
  const [recap, setRecap] = useState<DashboardSigaRecap | null>(null);
  const [loading, setLoading] = useState(true);
  const [recapLoading, setRecapLoading] = useState(true);
  const [error, setError] = useState("");
  const [recapError, setRecapError] = useState("");
  const [sigaStats, setSigaStats] = useState<DashboardSigaStats | null>(null);
  const [sigaLoading, setSigaLoading] = useState(false);
  const [sigaError, setSigaError] = useState("");
  const [sigaDetail, setSigaDetail] = useState<"pus" | "kb" | "poktan" | "kehadiran" | null>(null);
  const [poktanType, setPoktanType] = useState<"bkb" | "bkr" | "bkl" | "uppka" | "pikr">("bkb");
  const [poktanData, setPoktanData] = useState<DashboardSigaPoktanResponse | null>(null);
  const [poktanLoading, setPoktanLoading] = useState(false);
  const [poktanError, setPoktanError] = useState("");
  const [poktanAttendance, setPoktanAttendance] = useState<DashboardSigaPoktanAttendanceResponse | null>(null);
  const [poktanAttendanceLoading, setPoktanAttendanceLoading] = useState(false);
  const [poktanAttendanceError, setPoktanAttendanceError] = useState("");
  const [kampungKb, setKampungKb] = useState<any>(null);
  const sigaDashboardEnabled = isRole(user, "PKB") || isRole(user, "ADMIN");

  useEffect(() => {
    getSigaKampungKb().then(setKampungKb).catch(() => setKampungKb(null));
  }, []);

  const load = async () => {
    setLoading(true);
    setRecapLoading(true);
    setError("");
    setRecapError("");

    const [summaryResult, recapResult] = await Promise.allSettled([
      getDashboardSummary(),
      getDashboardSigaRecap(),
    ]);

    if (summaryResult.status === "fulfilled") {
      setData(summaryResult.value);
    } else {
      setError(summaryResult.reason instanceof Error ? summaryResult.reason.message : "Dashboard belum dapat dimuat.");
    }

    if (recapResult.status === "fulfilled") {
      setRecap(recapResult.value);
    } else {
      setRecapError(recapResult.reason instanceof Error ? recapResult.reason.message : "Rekap SIGA belum dapat dimuat.");
    }

    if (sigaDashboardEnabled) {
      setSigaLoading(true);
      try {
        setSigaStats(await getDashboardSigaStats());
      } catch (reason) {
        setSigaError(reason instanceof Error ? reason.message : "Data SIGA belum dapat dimuat.");
      } finally {
        setSigaLoading(false);
      }
    } else {
      setSigaStats(null);
    }

    setLoading(false);
    setRecapLoading(false);
  };

  useEffect(() => {
    let active = true;

    Promise.allSettled([getDashboardSummary(), getDashboardSigaRecap()]).then(([summaryResult, recapResult]) => {
      if (!active) return;

      if (summaryResult.status === "fulfilled") {
        setData(summaryResult.value);
        setError("");
      } else {
        setError(summaryResult.reason instanceof Error ? summaryResult.reason.message : "Dashboard belum dapat dimuat.");
      }

      if (recapResult.status === "fulfilled") {
        setRecap(recapResult.value);
        setRecapError("");
      } else {
        setRecapError(recapResult.reason instanceof Error ? recapResult.reason.message : "Rekap SIGA belum dapat dimuat.");
      }

      setLoading(false);
      setRecapLoading(false);
    });

    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!sigaDashboardEnabled) return;

    let active = true;
    setSigaLoading(true);
    setSigaError("");

    getDashboardSigaStats()
      .then((value) => {
        if (active) setSigaStats(value);
      })
      .catch((reason) => {
        if (active) setSigaError(reason instanceof Error ? reason.message : "Data SIGA belum dapat dimuat.");
      })
      .finally(() => {
        if (active) setSigaLoading(false);
      });

    return () => { active = false; };
  }, [sigaDashboardEnabled]);


  useEffect(() => {
    if (!sigaDashboardEnabled || sigaDetail !== "poktan") return;

    let active = true;
    setPoktanLoading(true);
    setPoktanError("");

    getDashboardSigaPoktan(poktanType)
      .then((value) => {
        if (active) setPoktanData(value);
      })
      .catch((reason) => {
        if (active) {
          setPoktanData(null);
          setPoktanError(
            reason instanceof Error
              ? reason.message
              : "Data kehadiran Poktan belum dapat dimuat."
          );
        }
      })
      .finally(() => {
        if (active) setPoktanLoading(false);
      });

    return () => { active = false; };
  }, [sigaDashboardEnabled, sigaDetail, poktanType]);


  useEffect(() => {
    if (!sigaDashboardEnabled || sigaDetail !== "kehadiran") return;

    let active = true;
    setPoktanAttendanceLoading(true);
    setPoktanAttendanceError("");

    getDashboardSigaPoktanAttendance()
      .then((value) => {
        if (active) setPoktanAttendance(value);
      })
      .catch((reason) => {
        if (active) {
          setPoktanAttendance(null);
          setPoktanAttendanceError(
            reason instanceof Error
              ? reason.message
              : "Rekap kehadiran Poktan belum dapat dimuat."
          );
        }
      })
      .finally(() => {
        if (active) setPoktanAttendanceLoading(false);
      });

    return () => { active = false; };
  }, [sigaDashboardEnabled, sigaDetail]);


  const firstName = useMemo(() => (user.full_name || user.username).trim().split(/\s+/)[0] || "Admin", [user]);
  const matchedPercent = data && data.total_member > 0 ? Math.round((data.matched / data.total_member) * 100) : 0;
  const scopedPpm = sigaStats?.totals.poktan_target ?? 0;
  const scopedPpmAchievement = scopedPpm > 0
    ? Math.min(100, Math.round(((sigaStats?.totals.poktan_participation ?? 0) / scopedPpm) * 100))
    : 0;
  const canSync = hasPermission(user, "siga.sync");

  const summary: Array<{ label: string; value: number; sub: string; icon: IconName; tone: string }> = [
    { label: "Kepala Keluarga", value: data?.total_family ?? 0, sub: "Data keluarga dalam wilayah", icon: "family", tone: "bg-blue-50 text-blue-700" },
    { label: "Anggota Keluarga", value: data?.total_member ?? 0, sub: "Total individu terdata", icon: "users", tone: "bg-violet-50 text-violet-700" },
    { label: "Anggota Aktif", value: data?.alive ?? 0, sub: "Status individu aktif", icon: "heart", tone: "bg-emerald-50 text-emerald-700" },
    { label: "Desa / Kelurahan", value: data?.village ?? 0, sub: "Wilayah sesuai hak akses", icon: "map", tone: "bg-amber-50 text-amber-700" },
  ];

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden rounded-3xl bg-linear-to-r from-[#173d78] via-[#245baf] to-[#2f73de] p-6 text-white shadow-lg shadow-blue-950/10 sm:p-7">
        <div className="absolute -right-16 -top-24 h-64 w-64 rounded-full border-36 border-white/5" />
        <div className="absolute -bottom-24 right-20 h-52 w-52 rounded-full bg-cyan-300/10 blur-2xl" />
        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.14em] text-blue-100 ring-1 ring-white/10">
              <Icon name="sparkles" size={14} /> Dashboard Administrasi
            </div>
            <h2 className="text-2xl font-black tracking-tight sm:text-3xl">Halo, {firstName}.</h2>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-blue-100/80">Pantau ringkasan data keluarga, cakupan wilayah binaan, akun SIGA, dan hasil sinkronisasi dari satu halaman.</p>
          </div>
          <button type="button" onClick={() => void load()} className="inline-flex h-10 items-center justify-center gap-2 self-start rounded-xl bg-white/10 px-4 text-xs font-bold ring-1 ring-white/15 hover:bg-white/15 lg:self-auto">
            <Icon name="refresh" size={16} className={loading || recapLoading ? "animate-spin" : ""} /> Perbarui Data
          </button>
        </div>
      </section>

      {error && (
        <div className="flex items-start justify-between gap-4 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          <div className="flex items-start gap-3"><Icon name="alert" size={19} className="mt-0.5 shrink-0" /><div><div className="font-bold">Data backend belum tersedia</div><p className="mt-1 text-xs leading-5 text-amber-800">{error}</p></div></div>
          <button type="button" onClick={() => void load()} className="shrink-0 text-xs font-bold underline">Coba lagi</button>
        </div>
      )}

      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {summary.map((item) => (
          <div
            key={item.label}
            className="group relative overflow-hidden rounded-[22px] border border-slate-200/80 bg-white p-5 shadow-[0_4px_18px_rgba(15,23,42,0.05)] transition-all duration-200 hover:-translate-y-0.5 hover:border-blue-200 hover:shadow-[0_10px_28px_rgba(15,23,42,0.09)]"
          >
            <div className="absolute inset-x-0 top-0 h-1 bg-linear-to-r from-blue-500 via-blue-400 to-cyan-400 opacity-0 transition-opacity duration-200 group-hover:opacity-100" />

            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0">
                <p className="truncate text-[10px] font-extrabold uppercase tracking-[.12em] text-slate-400">
                  {item.label}
                </p>
                <p className="mt-3 text-[30px] font-black leading-none tracking-tight text-[#142b4c]">
                  {loading ? "—" : formatNumber(item.value)}
                </p>
              </div>

              <div className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl ring-1 ring-black/5 ${item.tone}`}>
                <Icon name={item.icon} size={21} />
              </div>
            </div>

            <div className="mt-5 flex items-center justify-between gap-3 border-t border-slate-100 pt-3">
              <p className="min-w-0 truncate text-[10px] font-semibold text-slate-400">
                {item.sub}
              </p>
              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-slate-50 text-[11px] font-black text-slate-400 transition-colors group-hover:bg-blue-50 group-hover:text-blue-600">
                ↗
              </span>
            </div>
          </div>
        ))}
      </section>

      {sigaDashboardEnabled && sigaStats && (
        <section className="rounded-[22px] border border-blue-100 bg-white p-5 shadow-sm sm:p-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="inline-flex items-center gap-2 rounded-lg bg-blue-50 px-2.5 py-1.5 text-[10px] font-extrabold uppercase tracking-[.08em] text-blue-700">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> SIGA SESUAI AKUN
              </div>
              <h3 className="mt-3 text-sm font-extrabold text-[#142b4c]">Dashboard SIGA sesuai Akun</h3>
              <p className="mt-1 text-[11px] text-slate-400">
                Data langsung dari akun SIGA <span className="font-bold text-slate-600">{sigaStats.username_siga}</span> dan dibatasi sesuai scope wilayah akun/user.
              </p>
            </div>
            <div className="rounded-lg bg-slate-50 px-3 py-1.5 text-[10px] font-extrabold text-slate-600">
              {sigaStats.period.bulan.toString().padStart(2, "0")}/{sigaStats.period.tahun}
            </div>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {[
              ["Data Keluarga", sigaStats.totals.total_family, "KK sesuai scope SIGA", "family" as IconName],
              ["Anggota Keluarga", sigaStats.totals.total_member, "Individu sesuai scope", "users" as IconName],
              ["Total PUS", sigaStats.totals.total_pus, "Pasangan Usia Subur", "heart" as IconName],
              ["Unmet Need", sigaStats.totals.total_unmet_need, "PUS unmet need", "alert" as IconName],
              ["PUS Belum KB", sigaStats.totals.pus_not_kb, "PUS bukan peserta KB", "users" as IconName],
              ["Desa SIGA", sigaStats.scope.village_count, "Desa dalam scope", "map" as IconName],
              ["Anggota BKB", sigaStats.totals.bkb_participation, "Kesertaan BKB", "users" as IconName],
              ["Anggota BKL", sigaStats.totals.bkl_participation, "Kesertaan BKL", "users" as IconName],
              ["Anggota BKR", sigaStats.totals.bkr_participation, "Kesertaan BKR", "users" as IconName],
              ["Anggota UPPKA", sigaStats.totals.uppka_participation, "Kesertaan UPPKA", "users" as IconName],
              ["PPM", scopedPpm, "Sasaran Poktan dari SIGA", "target" as IconName],
              ["Capaian terhadap PPM", scopedPpmAchievement, "Kesertaan Poktan / sasaran", "chart" as IconName],
              ["Kampung KB", Array.isArray(kampungKb?.data) ? kampungKb.data.length : 0, "Data Kampung KB SIGA", "map" as IconName],
            ].map(([label, value, sub, icon]) => (
              <div key={String(label)} className="group rounded-2xl border border-slate-200 bg-white p-4 transition hover:-translate-y-0.5 hover:border-blue-300 hover:shadow-md">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-[10px] font-extrabold uppercase tracking-[.08em] text-slate-400">{label}</div>
                    <div className="mt-3 text-3xl font-black text-[#142b4c]">{label === "Capaian terhadap PPM" ? `${Number(value).toFixed(0)}%` : formatNumber(Number(value))}</div>
                  </div>
                  <div className="grid h-10 w-10 place-items-center rounded-xl bg-blue-50 text-blue-700"><Icon name={icon as IconName} size={18} /></div>
                </div>
                <div className="mt-4 border-t border-slate-100 pt-3 text-[10px] font-semibold text-slate-400">{sub}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {sigaDashboardEnabled && (
        <>
          <section className="rounded-[22px] border border-blue-100 bg-white p-5 shadow-sm sm:p-6">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h3 className="text-sm font-extrabold text-[#142b4c]">Dashboard SIGA</h3>
                <p className="mt-1 text-[11px] text-slate-400">
                  Data langsung dari akun SIGA yang terhubung dengan user dan dibatasi sesuai wilayah akses.
                </p>
              </div>
              <div className="rounded-lg bg-blue-50 px-3 py-1.5 text-[10px] font-extrabold text-blue-700">
                {sigaLoading ? "Memuat SIGA..." : sigaStats ? `${sigaStats.period.bulan.toString().padStart(2, "0")}/${sigaStats.period.tahun}` : "SIGA"}
              </div>
            </div>

            {sigaError && (
              <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-[11px] font-semibold text-amber-800">
                {sigaError}
              </div>
            )}

            <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {[
                {
                  id: "pus" as const,
                  label: "Total PUS",
                  value: sigaStats?.totals.total_pus ?? 0,
                  sub: "Pasangan Usia Subur",
                  icon: "users" as IconName,
                },
                {
                  id: "kb" as const,
                  label: "Kesertaan KB Aktif",
                  value: sigaStats?.kb_aktif.reduce((sum, row) => sum + row.jumlah, 0) ?? 0,
                  sub: "Klik untuk lihat IUD, Implan, Suntikan, dll.",
                  icon: "heart" as IconName,
                },
                {
                  id: "poktan" as const,
                  label: "Kesertaan Poktan",
                  value: sigaStats?.totals.poktan_participation ?? 0,
                  sub: `Sasaran ${formatNumber(sigaStats?.totals.poktan_target ?? 0)}`,
                  icon: "users" as IconName,
                },
                {
                  id: "kehadiran" as const,
                  label: "Kehadiran Poktan",
                  value: sigaStats?.bkr.attendance_percent ?? 0,
                  sub: "BKB · BKR · BKL · UPPKA · PIK Remaja",
                  icon: "calendar" as IconName,
                },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setSigaDetail(item.id)}
                  className={`group rounded-2xl border p-4 text-left transition hover:-translate-y-0.5 hover:border-blue-300 hover:shadow-md ${
                    sigaDetail === item.id ? "border-blue-400 bg-blue-50/50" : "border-slate-200 bg-white"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-[10px] font-extrabold uppercase tracking-[.1em] text-slate-400">{item.label}</div>
                      <div className="mt-3 text-3xl font-black text-[#142b4c]">
                        {sigaLoading ? "—" : item.id === "kehadiran" ? `${Number(item.value).toFixed(1)}%` : formatNumber(item.value)}
                      </div>
                    </div>
                    <div className="grid h-10 w-10 place-items-center rounded-xl bg-blue-50 text-blue-700">
                      <Icon name={item.icon} size={18} />
                    </div>
                  </div>
                  <div className="mt-4 border-t border-slate-100 pt-3 text-[10px] font-semibold text-slate-400">{item.sub}</div>
                </button>
              ))}
            </div>

            {sigaStats && sigaDetail === "pus" && (
              <div className="mt-5 rounded-2xl border border-slate-100 bg-slate-50/70 p-5">
                <h4 className="text-sm font-extrabold text-[#142b4c]">Detail PUS</h4>
                <div className="mt-4 grid gap-3 sm:grid-cols-4">
                  {[
                    ["PUS", sigaStats.totals.total_pus],
                    ["Wanita Hamil", sigaStats.totals.total_pregnant],
                    ["PUS Bukan Peserta KB", sigaStats.totals.pus_not_kb],
                    ["Unmet Need", sigaStats.totals.total_unmet_need],
                  ].map(([label, value]) => (
                    <div key={String(label)} className="rounded-xl bg-white p-4 ring-1 ring-slate-100">
                      <div className="text-2xl font-black text-[#142b4c]">{formatNumber(Number(value))}</div>
                      <div className="mt-1 text-[10px] font-bold text-slate-500">{label}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {sigaStats && sigaDetail === "kb" && (
              <div className="mt-5 overflow-x-auto rounded-2xl border border-slate-100">
                <table className="min-w-170 w-full text-left text-[11px]">
                  <thead className="bg-slate-50 text-[9px] font-extrabold uppercase tracking-wider text-slate-400">
                    <tr>
                      <th className="px-4 py-3">Metode Kontrasepsi</th>
                      <th className="px-4 py-3 text-right">Pemerintah</th>
                      <th className="px-4 py-3 text-right">Swasta</th>
                      <th className="px-4 py-3 text-right">Lainnya</th>
                      <th className="px-4 py-3 text-right">Jumlah</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {sigaStats.kb_aktif.map((row) => (
                      <tr key={row.metode_kontrasepsi}>
                        <td className="px-4 py-3 font-extrabold text-slate-800">{row.metode_kontrasepsi}</td>
                        <td className="px-4 py-3 text-right">{formatNumber(row.pemerintah)}</td>
                        <td className="px-4 py-3 text-right">{formatNumber(row.swasta)}</td>
                        <td className="px-4 py-3 text-right">{formatNumber(row.lainnya)}</td>
                        <td className="px-4 py-3 text-right font-black text-blue-700">{formatNumber(row.jumlah)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {sigaStats && sigaDetail === "poktan" && (
              <div className="mt-5 space-y-4">
                <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
                  {[
                    ["bkb", "BKB", sigaStats.totals.bkb_participation, sigaStats.totals.bkb_target],
                    ["bkr", "BKR", sigaStats.totals.bkr_participation, sigaStats.totals.bkr_target],
                    ["bkl", "BKL", sigaStats.totals.bkl_participation, sigaStats.totals.bkl_target],
                    ["uppka", "UPPKA", sigaStats.totals.uppka_participation, 0],
                    ["pikr", "PIK Remaja", 0, 0],
                  ].map(([id, label, participation, target]) => (
                    <button
                      key={String(id)}
                      type="button"
                      onClick={() => setPoktanType(id as "bkb" | "bkr" | "bkl" | "uppka" | "pikr")}
                      className={`rounded-2xl border p-4 text-left transition hover:border-blue-300 hover:shadow-sm ${
                        poktanType === id
                          ? "border-blue-400 bg-blue-50/60"
                          : "border-slate-100 bg-slate-50/70"
                      }`}
                    >
                      <div className="text-xs font-black text-[#142b4c]">{label}</div>
                      <div className="mt-2 text-xl font-black text-blue-700">
                        {formatNumber(Number(participation))}
                      </div>
                      <div className="mt-1 text-[10px] font-semibold text-slate-400">
                        Kesertaan · Sasaran {formatNumber(Number(target))}
                      </div>
                    </button>
                  ))}
                </div>

                {poktanError && (
                  <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-[11px] font-semibold text-amber-800">
                    {poktanError}
                  </div>
                )}

                {poktanLoading ? (
                  <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-6 text-center text-[11px] font-semibold text-slate-400">
                    Mengambil data {poktanType.toUpperCase()} dari SIGA...
                  </div>
                ) : poktanData ? (
                  <>
                    <div className="grid gap-3 sm:grid-cols-4">
                      {[
                        ["Pertemuan", poktanData.attendance.meetings],
                        ["Anggota", poktanData.attendance.members],
                        ["Hadir", poktanData.attendance.attended],
                        ["Kehadiran", poktanData.attendance.percentage_available ? `${Number(poktanData.attendance.attendance_percent).toFixed(1)}%` : "—"],
                      ].map(([label, value]) => (
                        <div key={String(label)} className="rounded-xl bg-slate-50 p-4">
                          <div className="text-xl font-black text-[#142b4c]">
                            {typeof value === "string" ? value : formatNumber(Number(value))}
                          </div>
                          <div className="mt-1 text-[10px] font-bold text-slate-500">{label}</div>
                        </div>
                      ))}
                    </div>

                    <div className="overflow-x-auto rounded-2xl border border-slate-100">
                      <table className="min-w-170 w-full text-left text-[11px]">
                        <thead className="bg-slate-50 text-[9px] font-extrabold uppercase tracking-wider text-slate-400">
                          <tr>
                            <th className="px-4 py-3">Nama Poktan</th>
                            <th className="px-4 py-3">Desa / Kelurahan</th>
                            <th className="px-4 py-3">Tanggal Kegiatan</th>
                            <th className="px-4 py-3 text-right">Anggota</th>
                            <th className="px-4 py-3 text-right">Hadir</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {poktanData.poktan.length ? (
                            poktanData.poktan.map((row, index) => (
                              <tr key={`${row.village_code}-${row.nama_poktan}-${row.tanggal_kegiatan}-${index}`}>
                                <td className="px-4 py-3 font-extrabold text-slate-800">{row.nama_poktan}</td>
                                <td className="px-4 py-3 text-slate-600">{row.village_name}</td>
                                <td className="px-4 py-3 text-slate-500">{row.tanggal_kegiatan}</td>
                                <td className="px-4 py-3 text-right">{formatNumber(row.anggota)}</td>
                                <td className="px-4 py-3 text-right font-black text-emerald-700">{formatNumber(row.hadir)}</td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan={5} className="px-6 py-8 text-center text-[11px] font-semibold text-slate-400">
                                Belum ada detail nama Poktan yang tercatat pada kegiatan periode ini.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>

                    <p className="text-[10px] leading-5 text-slate-400">
                      Rekap kehadiran menggunakan laporan bulanan SIGA. Daftar nama Poktan diambil dari detail kegiatan SIGA yang tercatat pada periode yang dipilih.
                    </p>
                  </>
                ) : null}
              </div>
            )}

            {sigaStats && sigaDetail === "kehadiran" && (
              <div className="mt-5 space-y-4">
                <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
                  {(
                    poktanAttendance?.items ?? [
                      { jenis: "bkb", label: "BKB", meetings: 0, members: 0, attended: 0, attendance_percent: 0, percentage_available: false, villages: [] },
                      { jenis: "bkr", label: "BKR", meetings: sigaStats.bkr.meetings, members: sigaStats.bkr.bkr_families, attended: sigaStats.bkr.bkr_attended, attendance_percent: sigaStats.bkr.attendance_percent, percentage_available: true, villages: [] },
                      { jenis: "bkl", label: "BKL", meetings: 0, members: 0, attended: 0, attendance_percent: 0, percentage_available: false, villages: [] },
                      { jenis: "uppka", label: "UPPKA", meetings: 0, members: 0, attended: 0, attendance_percent: 0, percentage_available: false, villages: [] },
                      { jenis: "pikr", label: "PIK Remaja", meetings: 0, members: 0, attended: 0, attendance_percent: 0, percentage_available: false, villages: [] },
                    ]
                  ).map((item) => (
                    <button
                      key={item.jenis}
                      type="button"
                      onClick={() => {
                        setSigaDetail("poktan");
                        setPoktanType(item.jenis);
                      }}
                      className="rounded-2xl border border-slate-100 bg-slate-50/70 p-4 text-left transition hover:border-blue-300 hover:shadow-sm"
                    >
                      <div className="text-xs font-black text-[#142b4c]">{item.label}</div>
                      <div className="mt-2 text-xl font-black text-blue-700">
                        {formatNumber(item.attended)}
                      </div>
                      <div className="mt-1 text-[10px] font-semibold text-slate-400">
                        Hadir · {Number(item.attendance_percent).toFixed(1)}%
                      </div>
                    </button>
                  ))}
                </div>

                {poktanAttendanceError && (
                  <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-[11px] font-semibold text-amber-800">
                    {poktanAttendanceError}
                  </div>
                )}

                {poktanAttendanceLoading ? (
                  <div className="rounded-2xl border border-slate-100 bg-slate-50/70 p-6 text-center text-[11px] font-semibold text-slate-400">
                    Mengambil seluruh rekap kehadiran Poktan dari SIGA...
                  </div>
                ) : poktanAttendance ? (
                  <div className="overflow-x-auto rounded-2xl border border-slate-100">
                    <table className="min-w-220 w-full text-left text-[11px]">
                      <thead className="bg-slate-50 text-[9px] font-extrabold uppercase tracking-wider text-slate-400">
                        <tr>
                          <th className="px-4 py-3">Poktan</th>
                          <th className="px-4 py-3 text-right">Pertemuan</th>
                          <th className="px-4 py-3 text-right">Anggota</th>
                          <th className="px-4 py-3 text-right">Hadir</th>
                          <th className="px-4 py-3 text-right">Kehadiran</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {poktanAttendance.items.map((item) => (
                          <tr key={item.jenis}>
                            <td className="px-4 py-3 font-extrabold text-slate-800">{item.label}</td>
                            <td className="px-4 py-3 text-right">{formatNumber(item.meetings)}</td>
                            <td className="px-4 py-3 text-right">{formatNumber(item.members)}</td>
                            <td className="px-4 py-3 text-right font-black text-emerald-700">{formatNumber(item.attended)}</td>
                            <td className="px-4 py-3 text-right font-black text-blue-700">{item.percentage_available ? `${Number(item.attendance_percent).toFixed(1)}%` : "—"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : null}

                <p className="text-[10px] leading-5 text-slate-400">
                  Rekap diambil dari laporan bulanan SIGA: Tabel 3B (BKB), 4A (BKR), 5A (BKL), 6B (UPPKA), dan 7A (PIK Remaja).
                </p>
              </div>
            )}
          </section>
        </>
      )}

      <section className="grid gap-5 xl:grid-cols-[1.15fr_.85fr]">
        <div className="rounded-[22px] border border-slate-200/80 bg-white shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4 sm:px-6">
            <div><h3 className="text-sm font-extrabold text-[#142b4c]">Kualitas Data Individu</h3><p className="mt-1 text-[11px] text-slate-400">Ringkasan kecocokan data anggota keluarga dalam wilayah akses</p></div>
            <div className="rounded-lg bg-emerald-50 px-2.5 py-1 text-[10px] font-extrabold text-emerald-700">{matchedPercent}% matched</div>
          </div>
          <div className="grid gap-4 p-5 sm:grid-cols-3 sm:p-6">
            {[{label:"Matched",value:data?.matched ?? 0,icon:"link" as IconName,tone:"text-emerald-700 bg-emerald-50"},{label:"Belum Matched",value:data?.unmatched ?? 0,icon:"alert" as IconName,tone:"text-amber-700 bg-amber-50"},{label:"Tidak Aktif",value:data?.dead ?? 0,icon:"users" as IconName,tone:"text-slate-600 bg-slate-100"}].map((item) => (
              <div key={item.label} className="rounded-2xl bg-slate-50/70 p-4 ring-1 ring-slate-100">
                <div className={`grid h-9 w-9 place-items-center rounded-xl ${item.tone}`}><Icon name={item.icon} size={17}/></div>
                <div className="mt-4 text-2xl font-black text-[#142b4c]">{loading ? "—" : formatNumber(item.value)}</div><div className="mt-1 text-[11px] font-semibold text-slate-500">{item.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-[22px] border border-slate-200/80 bg-white p-5 shadow-sm sm:p-6">
          <div className="flex items-center justify-between"><div><h3 className="text-sm font-extrabold text-[#142b4c]">Integrasi SIGA</h3><p className="mt-1 text-[11px] text-slate-400">Akun otomatis mengikuti wilayah akses</p></div><div className={`h-2.5 w-2.5 rounded-full ${data?.siga_account_count ? "bg-emerald-500" : "bg-slate-300"}`} /></div>
          <div className="mt-5 space-y-3">
            <div className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3"><span className="text-[11px] font-semibold text-slate-500">Username SIGA</span><span className="max-w-44 truncate text-xs font-extrabold text-[#142b4c]">{data?.username_siga || "Belum terhubung"}</span></div>
            <div className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3"><span className="text-[11px] font-semibold text-slate-500">Akun sesuai wilayah</span><span className="text-xs font-extrabold text-[#142b4c]">{loading ? "—" : formatNumber(data?.siga_account_count)}</span></div>
            <div className="flex items-center justify-between rounded-xl bg-slate-50 px-4 py-3"><span className="text-[11px] font-semibold text-slate-500">Sinkron terakhir</span><span className="max-w-52 text-right text-[10px] font-bold text-slate-600">{loading ? "—" : formatDateTime(data?.last_sync_at)}</span></div>
            <div className="grid grid-cols-3 gap-2">
              {[["Provinsi",data?.province],["Kab/Kota",data?.regency],["Kecamatan",data?.district]].map(([label,value]) => <div key={String(label)} className="rounded-xl border border-slate-100 p-3 text-center"><div className="text-lg font-black text-[#142b4c]">{loading ? "—" : value}</div><div className="mt-1 text-[9px] font-bold uppercase tracking-wide text-slate-400">{label}</div></div>)}
            </div>
          </div>
          {canSync && <button type="button" onClick={() => onNavigate("sync")} className="mt-4 flex h-10 w-full items-center justify-center gap-2 rounded-xl bg-[#142b4c] text-xs font-extrabold text-white hover:bg-[#1d3c68]"><Icon name="sync" size={16}/> Buka Sinkronisasi</button>}
        </div>
      </section>

      <section className="overflow-hidden rounded-[22px] border border-slate-200/80 bg-white shadow-sm">
        <div className="flex flex-col gap-3 border-b border-slate-100 px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <div>
            <h3 className="text-sm font-extrabold text-[#142b4c]">Rekap Hasil SIGA</h3>
            <p className="mt-1 text-[11px] text-slate-400">Jumlah KK, anggota, dan status padan per desa atau kelurahan sesuai wilayah akun.</p>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-[10px] font-bold">
            <span className="rounded-lg bg-blue-50 px-2.5 py-1.5 text-blue-700">{recapLoading ? "—" : `${formatNumber(recap?.totals.village)} wilayah`}</span>
            <span className="rounded-lg bg-slate-100 px-2.5 py-1.5 text-slate-600">{formatDateTime(recap?.last_sync_at)}</span>
          </div>
        </div>

        {recapError && <div className="m-5 rounded-xl border border-amber-200 bg-amber-50 p-3 text-[11px] font-semibold text-amber-800">{recapError}</div>}

        <div className="overflow-x-auto">
          <table className="min-w-205 w-full text-left">
            <thead className="bg-slate-50/80 text-[9px] font-extrabold uppercase tracking-[.08em] text-slate-400">
              <tr>
                <th className="px-5 py-3.5 sm:px-6">Desa / Kelurahan</th>
                <th className="px-4 py-3.5">ID SIGA</th>
                <th className="px-4 py-3.5 text-right">KK</th>
                <th className="px-4 py-3.5 text-right">Anggota</th>
                <th className="px-4 py-3.5 text-right">Padan</th>
                <th className="px-5 py-3.5 text-right sm:px-6">Belum Padan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recapLoading ? (
                Array.from({ length: 3 }).map((_, index) => <tr key={index}><td colSpan={6} className="px-6 py-4"><div className="h-4 animate-pulse rounded bg-slate-100" /></td></tr>)
              ) : recap?.villages.length ? (
                recap.villages.map((row) => (
                  <tr key={row.village_id} className="text-[11px] text-slate-600 hover:bg-slate-50/60">
                    <td className="px-5 py-3.5 font-extrabold text-slate-800 sm:px-6"><div>{row.village_name}</div><div className="mt-0.5 text-[9px] font-medium text-slate-400">Kode {row.village_code}</div></td>
                    <td className="px-4 py-3.5 font-mono text-[9px] text-slate-400">{row.siga_id || "—"}</td>
                    <td className="px-4 py-3.5 text-right font-bold">{formatNumber(row.total_family)}</td>
                    <td className="px-4 py-3.5 text-right font-bold">{formatNumber(row.total_member)}</td>
                    <td className="px-4 py-3.5 text-right font-bold text-emerald-700">{formatNumber(row.matched)}</td>
                    <td className="px-5 py-3.5 text-right font-bold text-amber-700 sm:px-6">{formatNumber(row.unmatched)}</td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan={6} className="px-6 py-10 text-center text-[11px] font-semibold text-slate-400">Belum ada hasil SIGA pada wilayah akun ini.</td></tr>
              )}
            </tbody>
            {!recapLoading && recap && recap.villages.length > 0 && (
              <tfoot className="border-t border-slate-200 bg-slate-50/70 text-[11px] font-black text-[#142b4c]">
                <tr>
                  <td className="px-5 py-4 sm:px-6" colSpan={2}>TOTAL WILAYAH AKSES</td>
                  <td className="px-4 py-4 text-right">{formatNumber(recap.totals.total_family)}</td>
                  <td className="px-4 py-4 text-right">{formatNumber(recap.totals.total_member)}</td>
                  <td className="px-4 py-4 text-right text-emerald-700">{formatNumber(recap.totals.matched)}</td>
                  <td className="px-5 py-4 text-right text-amber-700 sm:px-6">{formatNumber(recap.totals.unmatched)}</td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </section>

      {isRole(user, "PKB") && (
        <section className="rounded-[22px] border border-blue-100 bg-white p-5 shadow-sm sm:p-6">
          <div className="mb-4"><h3 className="text-sm font-extrabold text-[#142b4c]">Menu Kerja PKB</h3><p className="mt-1 text-[11px] text-slate-400">Akses cepat administrasi dan kinerja PKB</p></div>
          <div className="grid gap-3 sm:grid-cols-3">
            {[
              {id:"skp",label:"SKP",desc:"Sasaran kinerja pegawai",icon:"clipboard" as IconName},
              {id:"evisum",label:"e-Visum",desc:"Dokumentasi kegiatan lapangan",icon:"fileCheck" as IconName},
              {id:"arsip",label:"Arsip Digital",desc:"Dokumen administrasi PKB",icon:"folder" as IconName},
            ].map((item)=><button type="button" key={item.id} onClick={()=>onNavigate(item.id)} className="flex items-center gap-3 rounded-2xl border border-slate-200 p-4 text-left transition hover:border-blue-300 hover:bg-blue-50/40"><div className="grid h-10 w-10 place-items-center rounded-xl bg-blue-50 text-blue-700"><Icon name={item.icon} size={18}/></div><div><div className="text-xs font-extrabold text-slate-800">{item.label}</div><div className="mt-1 text-[10px] text-slate-400">{item.desc}</div></div></button>)}
          </div>
        </section>
      )}

      <section className="rounded-[22px] border border-slate-200/80 bg-white p-5 shadow-sm sm:p-6">
        <div className="mb-4"><h3 className="text-sm font-extrabold text-[#142b4c]">Akses Cepat</h3><p className="mt-1 text-[11px] text-slate-400">Menu yang paling sering digunakan</p></div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {([{id:"family-recap",label:"Data Keluarga",desc:"Lihat rekap keluarga",icon:"family" as IconName,permission:"families.view" as Permission},{id:"regions",label:"Wilayah",desc:"Master data wilayah",icon:"map" as IconName,permission:"wilayah.view" as Permission},{id:"pkb",label:"Master PKB",desc:"Sumber akun PKB dan anggota",icon:"user" as IconName,permission:"pkb.view" as Permission},{id:"kader",label:"Master Kader",desc:"Sumber akun kader lapangan",icon:"users" as IconName,permission:"kader.view" as Permission},{id:"iuran",label:"Kas & Iuran",desc:"Status iuran IPKB",icon:"wallet" as IconName,permission:"kas.view" as Permission},{id:"siga",label:"Akun SIGA",desc:"Status akun integrasi",icon:"database" as IconName,permission:"siga.view" as Permission}].filter((item)=>hasPermission(user,item.permission))).map((item) => (
            <button type="button" key={item.id} onClick={() => onNavigate(item.id)} className="group flex items-center gap-3 rounded-2xl border border-slate-200 p-4 text-left transition hover:-translate-y-0.5 hover:border-blue-200 hover:shadow-md hover:shadow-blue-100/40"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-50 text-blue-700 group-hover:bg-blue-600 group-hover:text-white"><Icon name={item.icon} size={18}/></div><div className="min-w-0"><div className="text-xs font-extrabold text-[#142b4c]">{item.label}</div><div className="mt-1 truncate text-[10px] text-slate-400">{item.desc}</div></div><Icon name="chevronRight" size={15} className="ml-auto text-slate-300 group-hover:text-blue-500"/></button>
          ))}
        </div>
      </section>
    </div>
  );
}
