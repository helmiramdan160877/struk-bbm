import { useState } from "react";

export default function AdminSiga() {
  const [activeMenu, setActiveMenu] = useState("Rekapitulasi Data Keluarga");

  const menuSections = [
    {
      title: "YAN KB / PELKON",
      items: ["Kartu Pendaftaran", "Register"],
    },
    {
      title: "DALLAP",
      items: ["Kartu Pendaftaran", "Register"],
    },
    {
      title: "LAPORAN",
      items: [
        "YAN KB",
        "DALLAP",
        "KELUARGA BERISIKO STUNTING",
        "ELSIMIL",
      ],
    },
    {
      title: "REKAPITULASI",
      items: ["Rekapitulasi Data Keluarga"],
    },
    {
      title: "PENGATURAN",
      items: ["Lokus", "User Catin Mandiri"],
    },
    {
      title: "ADMINISTRASI",
      items: [
        "Master PKB",
        "Master Kader",
        "Wilayah",
        "Akun SIGA",
        "Sinkronisasi",
      ],
    },
  ];

  const families = [
    {
      no: 1,
      nama: "HAJI SUTARDI",
      nik: "3203171203540005",
      kk: "32031720030001001002002",
      lahir: "12-03-1954",
      usia: 72,
    },
    {
      no: 2,
      nama: "DEDEN GINANJAR",
      nik: "3203171508840010",
      kk: "32031720030001001003003",
      lahir: "15-08-1984",
      usia: 41,
    },
    {
      no: 3,
      nama: "HERAWATI",
      nik: "3203175111270005",
      kk: "32031720030001001004004",
      lahir: "11-12-1970",
      usia: 55,
    },
    {
      no: 4,
      nama: "SUHANDI",
      nik: "3203172767990003",
      kk: "32031720030001001004005",
      lahir: "27-07-1999",
      usia: 27,
    },
    {
      no: 5,
      nama: "YONI SADELI",
      nik: "3203171306900010",
      kk: "32031720030001001005006",
      lahir: "13-06-1990",
      usia: 36,
    },
  ];

  return (
    <div className="min-h-screen bg-white text-[12px] text-slate-700">

      {/* HEADER */}
      <header className="h-11.5 bg-linear-to-r from-[#4f91d2] to-[#70a9df] flex items-center px-5 text-white">

        <div className="flex items-center gap-3 w-51.25">
          <div className="text-[25px] font-bold tracking-tight">
            ◔
          </div>

          <div>
            <div className="text-[22px] font-semibold leading-none">
              SIM IPEKB AI
            </div>

            <div className="text-[7px] opacity-90">
              Sistem Informasi Keluarga
            </div>
          </div>
        </div>

        <button className="text-[22px] opacity-80 hover:opacity-100">
          ☰
        </button>

        <div className="ml-auto w-7 h-7 rounded-full bg-white/80 border border-white flex items-center justify-center text-slate-500">
          👤
        </div>
      </header>

      <div className="flex">

        {/* SIDEBAR */}
        <aside className="w-51.25 min-h-[calc(100vh-46px)] border-r border-[#b8d4ed] bg-white">

          {/* BERANDA */}
          <div
            onClick={() => setActiveMenu("Beranda")}
            className={`h-10.5 px-4 flex items-center gap-3 cursor-pointer ${
              activeMenu === "Beranda"
                ? "bg-[#00c875] text-white"
                : "hover:bg-slate-100"
            }`}
          >
            <span>⌂</span>
            <span>Beranda</span>
          </div>

          {menuSections.map((section) => (
            <div key={section.title}>

              <div className="px-4 pt-4 pb-2 text-[10px] font-bold text-slate-700 uppercase">
                {section.title}
              </div>

              {section.items.map((item) => {
                const active = activeMenu === item;

                return (
                  <div
                    key={item}
                    onClick={() => setActiveMenu(item)}
                    className={`min-h-8.5 px-4 flex items-center justify-between cursor-pointer ${
                      active
                        ? "bg-[#00c875] text-white"
                        : "text-slate-700 hover:bg-slate-100"
                    }`}
                  >
                    <div className="flex items-center gap-2">

                      <span className="text-[13px]">
                        ▦
                      </span>

                      <span>{item}</span>

                    </div>

                    {(item === "Kartu Pendaftaran" ||
                      item === "Register" ||
                      item === "ELSIMIL" ||
                      item === "Rekapitulasi Data Keluarga") && (
                      <span className="text-[13px]">
                        ‹
                      </span>
                    )}

                  </div>
                );
              })}
            </div>
          ))}

        </aside>

        {/* CONTENT */}
        <main className="flex-1 min-w-0 bg-[#f7f9fb]">

          {/* TITLE */}
          <div className="px-4 py-5">

            <h1 className="text-[13px] font-bold text-slate-800">
              {activeMenu}
            </h1>

            <div className="mt-1 text-[11px] text-slate-500">
              Rekapitulasi Data Keluarga
            </div>

          </div>

          {/* SEARCH PANEL */}
          <section className="mx-4 border border-slate-200 bg-white">

            <div className="bg-[#3f609b] text-white h-6.75 px-3 flex items-center justify-between font-semibold">

              <span>Pencarian</span>

              <span>⌃</span>

            </div>

            <div className="p-4">

              {/* PERIODE */}
              <div className="grid grid-cols-[180px_1fr] gap-2 mb-2">

                <label className="pt-2">
                  Periode
                </label>

                <div className="grid grid-cols-2 gap-5">

                  <select className="h-[30px] border border-slate-300 rounded px-2 bg-white">
                    <option>Agustus</option>
                  </select>

                  <select className="h-[30px] border border-slate-300 rounded px-2 bg-white">
                    <option>2026</option>
                  </select>

                </div>

              </div>

              {/* NAMA */}
              <div className="grid grid-cols-[180px_1fr] gap-2 mb-2">

                <label className="pt-2">
                  Nama
                </label>

                <input
                  className="h-[30px] border border-slate-300 rounded px-2"
                  placeholder=""
                />

              </div>

              {/* NIK */}
              <div className="grid grid-cols-[180px_1fr] gap-2 mb-2">

                <label className="pt-2">
                  NIK
                </label>

                <input
                  className="h-[30px] border border-slate-300 rounded px-2"
                />

              </div>

              {/* PROVINSI / KABUPATEN */}
              <div className="grid grid-cols-2 gap-5 mb-2">

                <div className="grid grid-cols-[180px_1fr] gap-2">

                  <label className="pt-2">
                    Provinsi
                  </label>

                  <select className="h-[30px] border border-slate-300 rounded px-2">
                    <option>32 - JAWA BARAT</option>
                  </select>

                </div>

                <div className="grid grid-cols-[180px_1fr] gap-2">

                  <label className="pt-2">
                    Kab/Kota
                  </label>

                  <select className="h-[30px] border border-slate-300 rounded px-2">
                    <option>03 - CIANJUR</option>
                  </select>

                </div>

              </div>

              {/* KECAMATAN / DESA */}
              <div className="grid grid-cols-2 gap-5 mb-2">

                <div className="grid grid-cols-[180px_1fr] gap-2">

                  <label className="pt-2">
                    Kecamatan
                  </label>

                  <select className="h-[30px] border border-slate-300 rounded px-2">
                    <option>17 - KADUPANDAK</option>
                  </select>

                </div>

                <div className="grid grid-cols-[180px_1fr] gap-2">

                  <label className="pt-2">
                    Desa/Kel
                  </label>

                  <select className="h-[30px] border border-slate-300 rounded px-2">
                    <option>2003 - SUKASARI</option>
                  </select>

                </div>

              </div>

              {/* DUSUN / RT */}
              <div className="grid grid-cols-2 gap-5 mb-3">

                <div className="grid grid-cols-[180px_1fr] gap-2">

                  <label className="pt-2">
                    Dusun/RW
                  </label>

                  <input
                    className="h-[30px] border border-slate-300 rounded px-2"
                    placeholder="Cari..."
                  />

                </div>

                <div className="grid grid-cols-[180px_1fr] gap-2">

                  <label className="pt-2">
                    RT
                  </label>

                  <input
                    className="h-[30px] border border-slate-300 rounded px-2"
                    placeholder="Cari..."
                  />

                </div>

              </div>

              {/* ADVANCED */}
              <div className="mb-4 text-[#3176b8] cursor-pointer">

                <span className="inline-flex items-center justify-center w-5 h-5 bg-[#3176b8] text-white mr-1">
                  +
                </span>

                Pencarian Lanjutan

              </div>

              {/* BUTTON */}
              <div className="grid grid-cols-3 gap-5">

                <button className="h-7 bg-[#4388c9] text-white font-semibold hover:bg-[#3477b5]">
                  🔍 &nbsp; Cari
                </button>

                <button className="h-7 bg-[#dd493b] text-white font-semibold hover:bg-[#c63c30]">
                  📄 &nbsp; Cetak
                </button>

                <button className="h-7 bg-[#00bd8b] text-white font-semibold hover:bg-[#00a87b]">
                  📊 &nbsp; Cetak
                </button>

              </div>

            </div>

          </section>

          {/* DATA */}
          <section className="mx-4 mt-7">

            <div className="flex items-center gap-2 mb-3 font-semibold text-slate-700">
              ▣ Data Keluarga & Individu
            </div>

            <div className="overflow-hidden border border-slate-300">

              <table className="w-full border-collapse text-[10px]">

                <thead>

                  <tr className="bg-white">

                    <th className="border border-slate-300 px-2 py-2 w-[7%]">
                      No
                    </th>

                    <th className="border border-slate-300 w-[6%]">
                    </th>

                    <th className="border border-slate-300 px-2 py-2">
                      Nama
                    </th>

                    <th className="border border-slate-300 px-2 py-2">
                      NIK
                    </th>

                    <th className="border border-slate-300 px-2 py-2">
                      Kode Keluarga
                    </th>

                    <th className="border border-slate-300 px-2 py-2">
                      Tanggal Lahir
                    </th>

                    <th className="border border-slate-300 px-2 py-2">
                      Usia
                    </th>

                  </tr>

                </thead>

                <tbody>

                  {families.map((family) => (

                    <tr
                      key={family.no}
                      className="odd:bg-[#f3f3f3] even:bg-white hover:bg-blue-50"
                    >

                      <td className="border border-slate-300 px-2 py-2 text-center">
                        {family.no}
                      </td>

                      <td className="border border-slate-300 text-center">

                        <button
                          className="w-5.75 h-5 bg-[#3f619b] text-white rounded-xs hover:bg-[#2e4d82]"
                          title="Detail"
                        >
                          🔍
                        </button>

                      </td>

                      <td className="border border-slate-300 px-2 py-2">
                        {family.nama}
                      </td>

                      <td className="border border-slate-300 px-2 py-2 text-center">
                        {family.nik}
                      </td>

                      <td className="border border-slate-300 px-2 py-2 text-center">
                        {family.kk}
                      </td>

                      <td className="border border-slate-300 px-2 py-2 text-center">
                        {family.lahir}
                      </td>

                      <td className="border border-slate-300 px-2 py-2 text-center">
                        {family.usia}
                      </td>

                    </tr>

                  ))}

                </tbody>

              </table>

            </div>

          </section>

        </main>

      </div>

    </div>
  );
}