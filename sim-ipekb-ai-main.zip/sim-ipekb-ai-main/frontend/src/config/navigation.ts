import type { IconName } from "../components/Icon";
import type { Permission } from "./permissions";


export interface NavigationItem {

  id: string;

  label: string;

  icon: IconName;

  permission: Permission;

}


export interface NavigationSection {

  title: string;

  items: NavigationItem[];

}



export const navSections: NavigationSection[] = [

  {
    title: "Menu Utama",
    items: [
      {
        id: "dashboard",
        label: "Dashboard",
        icon: "dashboard",
        permission: "dashboard.view",
      },
      {
        id: "ai-assistant",
        label: "Asisten AI",
        icon: "sparkles",
        permission: "ai.view",
      },
    ],
  },


  {
    title: "Data Keluarga",
    items: [

      {
        id: "family-recap",
        label: "Data Keluarga",
        icon: "family",
        permission: "families.view",
      },

      {
        id: "regions",
        label: "Wilayah",
        icon: "map",
        permission: "wilayah.view",
      },

    ],
  },



  {
    title: "Administrasi",
    items: [

      {
        id: "pkb",
        label: "Master PKB",
        icon: "user",
        permission: "pkb.view",
      },

      {
        id: "kader",
        label: "Master Kader",
        icon: "users",
        permission: "kader.view",
      },
      {
        id: "anggota",
        label: "Master Anggota",
        icon: "family",
        permission: "anggota.view",
      },

      {
        id: "poktan",
        label: "Master Poktan",
        icon: "users",
        permission: "poktan.view",
      },

      {
        id: "uppka",
        label: "Master UPPKA",
        icon: "users",
        permission: "uppka.view",
      },

      {
        id: "redaktur",
        label: "Master Redaktur",
        icon: "edit",
        permission: "redaktur.view",
      },


        {
          id: "users",
          label: "Manajemen User",
          icon: "users",
          permission: "users.view",
        },

      ],
    },



    {
      title: "Keuangan",
      items: [

      {
        id: "iuran",
        label: "Kas & Iuran",
        icon: "wallet",
        permission: "kas.view",
      },

    ],
  },



  {
    title: "Operasional PKB",
    items: [

      {
        id: "skp",
        label: "SKP",
        icon: "clipboard",
        permission: "skp.view",
      },


      {
        id: "evisum",
        label: "e-Visum",
        icon: "fileCheck",
        permission: "evisum.view",
      },


      {
        id: "arsip",
        label: "Arsip Digital",
        icon: "folder",
        permission: "arsip.view",
      },

    ],
  },



  {
    title: "Integrasi SIGA",
    items: [

      {
        id: "siga-account",
        label: "Akun SIGA",
        icon: "database",
        permission: "siga.view",
      },


      {
        id: "sync",
        label: "Sinkronisasi",
        icon: "sync",
        permission: "siga.sync",
      },


      {
        id: "sync-history",
        label: "Riwayat Sinkronisasi",
        icon: "clock",
        permission: "siga.sync",
      },

    ],
  },
  {
  title: "Laporan",
  items: [
    {
      id: "laporan-pengeluaran",
      label: "Laporan Pengeluaran",
      icon: "report",
      permission: "kas.view",
    },
  ],
},


];