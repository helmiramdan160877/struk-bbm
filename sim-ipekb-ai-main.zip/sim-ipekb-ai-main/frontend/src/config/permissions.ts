import type { Role } from "../types/auth";

export type Permission =
  | "dashboard.view"
  | "users.view" | "users.manage"
  | "roles.view" | "roles.manage"
  | "wilayah.view" | "wilayah.manage"
  | "families.view" | "families.manage"
  | "family_members.view" | "family_members.manage"
  | "pkb.view" | "pkb.manage"
  | "kader.view" | "kader.manage"
  | "anggota.view" | "anggota.manage"
  | "poktan.view" | "poktan.manage"
  | "uppka.view" | "uppka.manage"
  | "redaktur.view" | "redaktur.manage"
  | "rencana_kerja.view" | "rencana_kerja.manage"
  | "skp.view" | "skp.manage"
  | "capaian.view" | "capaian.manage"
  | "evisum.view" | "evisum.manage"
  | "kas.view" | "kas.manage"
  | "arsip.view" | "arsip.manage"
  | "siga.view" | "siga.manage" | "siga.sync"
  | "laporan.view"
  | "ai.view";

const all: Permission[] = [
  "dashboard.view",
  "users.view", "users.manage",
  "roles.view", "roles.manage",
  "wilayah.view", "wilayah.manage",
  "families.view", "families.manage",
  "family_members.view", "family_members.manage",
  "pkb.view", "pkb.manage",
  "kader.view", "kader.manage",
  "rencana_kerja.view", "rencana_kerja.manage",
  "skp.view", "skp.manage",
  "capaian.view", "capaian.manage",
  "evisum.view", "evisum.manage",
  "kas.view", "kas.manage",
  "arsip.view", "arsip.manage",
  "siga.view", "siga.manage", "siga.sync",
  "laporan.view",
  "ai.view",
  "anggota.view", "anggota.manage",
  "poktan.view", "poktan.manage",
  "uppka.view", "uppka.manage",
  "redaktur.view", "redaktur.manage",
];

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  SUPERADMIN: all,
  SUPER_ADMIN: all,

  // Admin operasional. Pengelolaan role dan data PKB tetap dikunci ke SUPER_ADMIN.
  ADMIN: all.filter((permission) => !["roles.manage", "pkb.manage"].includes(permission)),

  PENGURUS: [
    "dashboard.view", "wilayah.view", "pkb.view", "kader.view",
    "capaian.view", "kas.view", "arsip.view", "laporan.view", "ai.view"
  ],

  PKB: [
    "dashboard.view", "wilayah.view",
    "families.view", "families.manage",
    "family_members.view", "family_members.manage",
    "pkb.view", "kader.view",
    "rencana_kerja.view", "rencana_kerja.manage",
    "skp.view", "skp.manage",
    "capaian.view", "capaian.manage",
    "evisum.view", "evisum.manage",
    "kas.view",
    "arsip.view", "arsip.manage",
    "siga.view", "laporan.view",
      "ai.view",
],

  KADER: [
    "dashboard.view", "wilayah.view",
    "families.view", "family_members.view",
    "kader.view", "capaian.view", "arsip.view", "laporan.view",
      "ai.view",
],

  OPERATOR: [
    "dashboard.view", "wilayah.view", "pkb.view", "kader.view",
    "siga.view", "siga.sync", "laporan.view",
      "ai.view",
],

  BENDAHARA: ["dashboard.view", "kas.view", "kas.manage", "ai.view",
],
  PIMPINAN: ["dashboard.view", "pkb.view", "kader.view", "capaian.view", "laporan.view", "ai.view",
],
  VIEWER: ["dashboard.view", "wilayah.view", "capaian.view", "laporan.view", "ai.view",
],
  ANGGOTA: ["dashboard.view", "kas.view", "laporan.view", "ai.view",
],
};
