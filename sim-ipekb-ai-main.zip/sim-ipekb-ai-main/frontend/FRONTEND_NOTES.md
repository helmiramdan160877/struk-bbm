# SIM IPEKB AI — Frontend V2

Frontend ini merupakan pengembangan dari project SIM IPEKB AI yang sudah ada.

## Stack
- React 19
- TypeScript
- Vite
- Tailwind CSS 4
- Backend API: FastAPI (`VITE_API_URL`)

## Yang sudah dikembangkan
- Login terhubung JWT backend (`/auth/login` dan `/auth/me`)
- Layout admin responsif (desktop, tablet, mobile)
- Sidebar collapse/drawer mobile
- Dashboard terhubung `/dashboard/summary`
- Rekap data keluarga + pagination + pencarian + detail + tambah keluarga + export CSV
- Master wilayah (provinsi, kab/kota, kecamatan, desa/kelurahan)
- Data PKB
- Daftar akun SIGA
- Form sinkronisasi SIGA (full / anggota)
- Placeholder konsisten untuk modul backend yang belum tersedia
- Handling loading, error, dan session expired

## Menjalankan di Windows
Node_modules dari arsip lama sebaiknya JANGAN dipakai ulang karena dependency native dapat berbeda antar OS/mesin.

PowerShell:

```powershell
cd frontend
Remove-Item -Recurse -Force node_modules -ErrorAction SilentlyContinue
npm install
npm run dev
```

Kemudian buka alamat yang ditampilkan Vite (biasanya `http://localhost:5173`).

Pastikan backend FastAPI aktif di `http://127.0.0.1:8000` atau ubah `frontend/.env`:

```env
VITE_API_URL=http://127.0.0.1:8000/api/v1
```

## Build produksi

```powershell
npm run build
```

Output build akan berada di folder `dist`.

## Catatan endpoint PKB
Pada backend project saat ini, router PKB mempunyai prefix di `main.py` dan di file router sehingga endpoint aktual dapat menjadi `/api/v1/pkb/pkb`. Frontend V2 sudah memberi kompatibilitas untuk struktur tersebut. Untuk jangka panjang, sebaiknya prefix backend dirapikan menjadi satu kali saja.

## Validasi source
- TypeScript type-check: PASS
- ESLint: PASS
