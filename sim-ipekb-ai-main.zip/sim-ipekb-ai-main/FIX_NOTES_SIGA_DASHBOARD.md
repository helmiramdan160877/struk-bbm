# Fix SIGA, Dashboard, Wilayah PKB, dan Dropdown Menu

## Perubahan utama

- Dashboard kini menampilkan **Rekap Hasil SIGA per desa/kelurahan** sesuai wilayah akses user.
- Rekap mencakup jumlah KK, anggota, data padan, data belum padan, total per wilayah, dan waktu sinkron terakhir.
- Akun SIGA untuk **PKB/Kader** dibatasi otomatis berdasarkan kecamatan dari desa/kelurahan binaan yang aktif.
- Relasi `UserSigaAccount` direkonsiliasi otomatis saat wilayah binaan user ditambah, dihapus, atau role user berubah.
- Fallback username SIGA hard-coded di dashboard dihapus.
- `last_sync_at` sekarang diperbarui setelah sinkronisasi penuh maupun sinkronisasi anggota berhasil.
- Endpoint sinkronisasi dan test anggota SIGA memvalidasi akun terhadap scope wilayah user.
- Admin hanya dapat mengelola akun SIGA pada kecamatannya sendiri. Super Admin tetap global.
- PKB hanya melihat akun SIGA wilayah binaannya dan tidak lagi mendapat tombol kelola yang akan berujung 403.
- Sidebar diubah menjadi **dropdown/collapsible menu per kelompok**, dengan kelompok halaman aktif otomatis terbuka.
- Response akun SIGA lama yang belum mempunyai `district_id` dibuat kompatibel agar tidak memicu error validasi.

## Validasi yang sudah dijalankan

- `python -m compileall` backend: PASS
- TypeScript `tsc -b`: PASS
- ESLint frontend: PASS
- Pemeriksaan hard-coded akun SIGA lama: PASS, sudah tidak ada

## Menjalankan project

Dependensi `node_modules` dan virtual environment tidak disertakan dalam paket hasil perbaikan. Gunakan dependency file project:

```bash
cd frontend
npm install
npm run build
```

Untuk backend, aktifkan environment Python project kemudian install dependency dari file requirements yang tersedia sebelum menjalankan FastAPI.
