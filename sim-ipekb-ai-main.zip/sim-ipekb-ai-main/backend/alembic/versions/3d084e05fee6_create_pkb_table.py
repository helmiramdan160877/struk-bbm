"""create pkb table

Revision ID: 3d084e05fee6
Revises: 4ee8bdcd6489
Create Date: 2026-08-07 20:01:34.205703
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.

revision: str = "3d084e05fee6"
down_revision: Union[str, Sequence[str], None] = "4ee8bdcd6489"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Create pkbs table."""

    op.create_table(
        "pkbs",

        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),

        sa.Column(
            "nip",
            sa.String(length=30),
            nullable=False,
        ),

        sa.Column(
            "nik",
            sa.String(length=20),
            nullable=False,
        ),

        sa.Column(
            "nama",
            sa.String(length=150),
            nullable=False,
        ),

        sa.Column(
            "tempat_lahir",
            sa.String(length=100),
            nullable=True,
        ),

        sa.Column(
            "tanggal_lahir",
            sa.Date(),
            nullable=True,
        ),

        sa.Column(
            "jenis_kelamin",
            sa.String(length=20),
            nullable=True,
        ),

        sa.Column(
            "agama",
            sa.String(length=30),
            nullable=True,
        ),

        sa.Column(
            "pendidikan",
            sa.String(length=100),
            nullable=True,
        ),

        sa.Column(
            "jabatan",
            sa.String(length=100),
            nullable=True,
        ),

        sa.Column(
            "status_asn",
            sa.String(length=50),
            nullable=True,
        ),

        sa.Column(
            "golongan",
            sa.String(length=20),
            nullable=True,
        ),

        sa.Column(
            "email",
            sa.String(length=150),
            nullable=True,
        ),

        sa.Column(
            "phone",
            sa.String(length=30),
            nullable=True,
        ),

        sa.Column(
            "alamat",
            sa.Text(),
            nullable=True,
        ),

        sa.Column(
            "photo",
            sa.String(),
            nullable=True,
        ),

        sa.Column(
            "kecamatan",
            sa.String(length=100),
            nullable=True,
        ),

        sa.Column(
            "desa",
            sa.String(length=100),
            nullable=True,
        ),

        sa.Column(
            "wilayah_binaan",
            sa.Text(),
            nullable=True,
        ),

        sa.Column(
            "status",
            sa.String(length=20),
            nullable=False,
            server_default="AKTIF",
        ),

        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),

        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),

        sa.PrimaryKeyConstraint("id"),

        sa.UniqueConstraint(
            "nip",
            name="uq_pkbs_nip",
        ),

        sa.UniqueConstraint(
            "nik",
            name="uq_pkbs_nik",
        ),
    )


def downgrade() -> None:
    """Drop pkbs table."""

    op.drop_table("pkbs")