"""add user village scope

Revision ID: 82bf62223ac1
Revises: 3d084e05fee6
Create Date: 2026-08-08 11:37:57.601019
"""

from typing import Sequence, Union

from alembic import op


revision: str = "82bf62223ac1"
down_revision: Union[str, Sequence[str], None] = "3d084e05fee6"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """
    user_villages sudah dibuat sebelumnya.
    Migration ini tidak membuat ulang tabel tersebut.
    """
    pass


def downgrade() -> None:
    """
    Jangan menghapus user_villages karena tabel sudah dikelola
    oleh migration sebelumnya.
    """
    pass