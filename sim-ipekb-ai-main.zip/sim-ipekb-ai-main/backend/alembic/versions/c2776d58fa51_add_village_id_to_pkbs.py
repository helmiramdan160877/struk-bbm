"""add village_id to pkbs

Revision ID: c2776d58fa51
Revises: 4ee8bdcd6489
Create Date: 2026-08-08
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision: str = "c2776d58fa51"
down_revision: Union[str, Sequence[str], None] = "82bf62223ac1"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Add village_id to pkbs table."""

    op.add_column(
        "pkbs",
        sa.Column(
            "village_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
        ),
    )

    op.create_foreign_key(
        "fk_pkbs_village_id_villages",
        "pkbs",
        "villages",
        ["village_id"],
        ["id"],
        ondelete="SET NULL",
    )

    op.create_index(
        "ix_pkbs_village_id",
        "pkbs",
        ["village_id"],
    )


def downgrade() -> None:
    """Remove village_id from pkbs table."""

    op.drop_index(
        "ix_pkbs_village_id",
        table_name="pkbs",
    )

    op.drop_constraint(
        "fk_pkbs_village_id_villages",
        "pkbs",
        type_="foreignkey",
    )

    op.drop_column(
        "pkbs",
        "village_id",
    )