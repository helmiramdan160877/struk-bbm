"""fix pkb timestamp nullable

Revision ID: 7df528ef3202
Revises: 87e827ee4480
Create Date: 2026-08-09 14:10:20.750640

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '7df528ef3202'
down_revision: Union[str, Sequence[str], None] = '87e827ee4480'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    pass


def downgrade() -> None:
    """Downgrade schema."""
    pass
