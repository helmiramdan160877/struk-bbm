"""link master PKB to SIGA account

Revision ID: 20260914_pkb_siga
Revises: v7_master_iuran_notifications
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "20260914_pkb_siga"
down_revision: Union[str, Sequence[str], None] = "v7_master_iuran"
branch_labels = None
depends_on = None

def upgrade() -> None:
    op.add_column("pkbs", sa.Column("siga_account_id", postgresql.UUID(as_uuid=True), nullable=True))
    op.create_foreign_key(
        "fk_pkbs_siga_account_id_siga_accounts",
        "pkbs", "siga_accounts", ["siga_account_id"], ["id"], ondelete="SET NULL"
    )
    op.create_index("ix_pkbs_siga_account_id", "pkbs", ["siga_account_id"])

def downgrade() -> None:
    op.drop_index("ix_pkbs_siga_account_id", table_name="pkbs")
    op.drop_constraint("fk_pkbs_siga_account_id_siga_accounts", "pkbs", type_="foreignkey")
    op.drop_column("pkbs", "siga_account_id")
