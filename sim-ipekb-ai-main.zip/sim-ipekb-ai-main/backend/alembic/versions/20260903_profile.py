"""add profile editing support

Revision ID: 20260903_profile
Revises: 20260903_user_subscription
"""
from alembic import op
import sqlalchemy as sa

revision = "20260903_profile"
down_revision = "20260903_user_subscription"
branch_labels = None
depends_on = None

def upgrade():
    op.alter_column("users", "photo", type_=sa.Text(), existing_type=sa.String(length=255), existing_nullable=True)

def downgrade():
    op.alter_column("users", "photo", type_=sa.String(length=255), existing_type=sa.Text(), existing_nullable=True)
