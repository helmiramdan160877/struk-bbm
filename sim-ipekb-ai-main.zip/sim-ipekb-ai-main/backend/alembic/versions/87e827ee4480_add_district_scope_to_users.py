"""add district scope to users

Revision ID: 87e827ee4480
Revises: c2776d58fa51
Create Date: 2026-08-09 13:55:50.795620

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "87e827ee4480"
down_revision: Union[str, Sequence[str], None] = "c2776d58fa51"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Add district scope to users."""

    op.add_column(
        "users",
        sa.Column(
            "district_id",
            sa.UUID(),
            nullable=True,
        ),
    )

    op.create_foreign_key(
        "fk_users_district_id",
        "users",
        "districts",
        ["district_id"],
        ["id"],
    )


def downgrade() -> None:
    """Remove district scope from users."""

    op.drop_constraint(
        "fk_users_district_id",
        "users",
        type_="foreignkey",
    )

    op.drop_column(
        "users",
        "district_id",
    )