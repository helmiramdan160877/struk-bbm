"""create user_siga_accounts junction table

Revision ID: user_siga_accounts_001
Revises: a14c2026iuran
Create Date: 2026-08-18 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = "user_siga_accounts_001"
down_revision = "a14c2026iuran"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create user_siga_accounts table
    op.create_table(
        "user_siga_accounts",
        sa.Column(
            "user_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "siga_account_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(),
            nullable=False,
            server_default=sa.func.now(),
            onupdate=sa.func.now(),
        ),
        sa.ForeignKeyConstraint(
            ["user_id"],
            ["users.id"],
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["siga_account_id"],
            ["siga_accounts.id"],
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint(
            "user_id",
            "siga_account_id",
            name="pk_user_siga_accounts",
        ),
    )


def downgrade() -> None:
    op.drop_table("user_siga_accounts")
