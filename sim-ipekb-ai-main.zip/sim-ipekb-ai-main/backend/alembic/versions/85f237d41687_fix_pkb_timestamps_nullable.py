"""fix pkb timestamps nullable

Revision ID: 85f237d41687
Revises: 7df528ef3202
Create Date: 2026-08-09 14:17:27.454616

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.

revision: str = "85f237d41687"

down_revision: Union[str, Sequence[str], None] = "7df528ef3202"

branch_labels: Union[str, Sequence[str], None] = None

depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""

    op.alter_column(
        "pkbs",
        "created_at",
        existing_type=sa.DateTime(timezone=True),
        nullable=False,
    )

    op.alter_column(
        "pkbs",
        "updated_at",
        existing_type=sa.DateTime(timezone=True),
        nullable=False,
    )


def downgrade() -> None:
    """Downgrade schema."""

    op.alter_column(
        "pkbs",
        "created_at",
        existing_type=sa.DateTime(timezone=True),
        nullable=True,
    )

    op.alter_column(
        "pkbs",
        "updated_at",
        existing_type=sa.DateTime(timezone=True),
        nullable=True,
    )