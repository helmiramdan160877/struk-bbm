"""master kader, user master links, and iuran notifications

Revision ID: v7_master_iuran
Revises: user_siga_accounts_001
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "v7_master_iuran"
down_revision: Union[str, Sequence[str], None] = "user_siga_accounts_001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "kaders",
        sa.Column("nik", sa.String(length=20), nullable=False),
        sa.Column("nama", sa.String(length=150), nullable=False),
        sa.Column("email", sa.String(length=150), nullable=True),
        sa.Column("phone", sa.String(length=30), nullable=True),
        sa.Column("alamat", sa.Text(), nullable=True),
        sa.Column("jabatan", sa.String(length=100), nullable=True),
        sa.Column("village_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("status", sa.String(length=20), server_default="AKTIF", nullable=False),
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["village_id"], ["villages.id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("nik", name="uq_kaders_nik"),
    )
    op.create_index("ix_kaders_nik", "kaders", ["nik"], unique=False)
    op.create_index("ix_kaders_nama", "kaders", ["nama"], unique=False)
    op.create_index("ix_kaders_village_id", "kaders", ["village_id"], unique=False)

    op.add_column("users", sa.Column("pkb_id", postgresql.UUID(as_uuid=True), nullable=True))
    op.add_column("users", sa.Column("kader_id", postgresql.UUID(as_uuid=True), nullable=True))
    op.create_foreign_key("fk_users_pkb_id", "users", "pkbs", ["pkb_id"], ["id"], ondelete="SET NULL")
    op.create_foreign_key("fk_users_kader_id", "users", "kaders", ["kader_id"], ["id"], ondelete="SET NULL")
    op.create_index("ix_users_pkb_id", "users", ["pkb_id"], unique=False)
    op.create_index("ix_users_kader_id", "users", ["kader_id"], unique=False)

    # Migrasikan identitas KADER lama ke master Kader tanpa menghapus akun lama.
    op.execute("""
        WITH kader_users AS (
            SELECT
                u.id,
                u.full_name,
                u.email,
                u.phone,
                u.nip,
                u.created_at,
                u.updated_at,
                (
                    SELECT uv.village_id
                    FROM user_villages uv
                    WHERE uv.user_id = u.id
                    ORDER BY uv.created_at NULLS LAST
                    LIMIT 1
                ) AS village_id,
                COUNT(*) OVER (PARTITION BY NULLIF(BTRIM(u.nip), '')) AS nip_count
            FROM users u
            JOIN roles r ON r.id = u.role_id
            WHERE UPPER(r.name) = 'KADER'
        )
        INSERT INTO kaders (id, nik, nama, email, phone, village_id, status, created_at, updated_at)
        SELECT
            id,
            CASE
                WHEN nip IS NULL OR BTRIM(nip) = '' THEN 'KADER-' || LEFT(id::text, 12)
                WHEN nip_count > 1 THEN LEFT(nip, 10) || '-' || LEFT(id::text, 8)
                ELSE nip
            END,
            full_name,
            email,
            phone,
            village_id,
            'AKTIF',
            created_at,
            updated_at
        FROM kader_users
        ON CONFLICT (id) DO NOTHING
    """)
    op.execute("""
        UPDATE users u
        SET kader_id = u.id
        FROM roles r
        WHERE r.id = u.role_id AND UPPER(r.name) = 'KADER' AND EXISTS (SELECT 1 FROM kaders k WHERE k.id = u.id)
    """)
    op.execute("""
        UPDATE users u
        SET pkb_id = p.id
        FROM roles r, pkbs p
        WHERE r.id = u.role_id
          AND UPPER(r.name) IN ('PKB', 'ANGGOTA')
          AND u.nip IS NOT NULL
          AND BTRIM(u.nip) <> ''
          AND p.nip = u.nip
    """)

    op.create_table(
        "iuran_notifications",
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("year", sa.Integer(), nullable=False),
        sa.Column("month", sa.Integer(), nullable=False),
        sa.Column("kind", sa.String(length=40), nullable=False),
        sa.Column("title", sa.String(length=160), nullable=False),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("outstanding_amount", sa.Numeric(14, 2), server_default="0", nullable=False),
        sa.Column("is_read", sa.Boolean(), server_default=sa.text("false"), nullable=False),
        sa.Column("whatsapp_status", sa.String(length=20), server_default="PENDING", nullable=False),
        sa.Column("whatsapp_error", sa.Text(), nullable=True),
        sa.Column("whatsapp_sent_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("user_id", "year", "month", "kind", name="uq_iuran_notification_user_period_kind"),
    )
    op.create_index("ix_iuran_notifications_user_id", "iuran_notifications", ["user_id"], unique=False)
    op.create_index("ix_iuran_notifications_year", "iuran_notifications", ["year"], unique=False)
    op.create_index("ix_iuran_notifications_month", "iuran_notifications", ["month"], unique=False)
    op.create_index("ix_iuran_notifications_kind", "iuran_notifications", ["kind"], unique=False)

    op.execute("UPDATE iuran_settings SET due_day = 25")


def downgrade() -> None:
    op.drop_index("ix_iuran_notifications_kind", table_name="iuran_notifications")
    op.drop_index("ix_iuran_notifications_month", table_name="iuran_notifications")
    op.drop_index("ix_iuran_notifications_year", table_name="iuran_notifications")
    op.drop_index("ix_iuran_notifications_user_id", table_name="iuran_notifications")
    op.drop_table("iuran_notifications")

    op.drop_index("ix_users_kader_id", table_name="users")
    op.drop_index("ix_users_pkb_id", table_name="users")
    op.drop_constraint("fk_users_kader_id", "users", type_="foreignkey")
    op.drop_constraint("fk_users_pkb_id", "users", type_="foreignkey")
    op.drop_column("users", "kader_id")
    op.drop_column("users", "pkb_id")

    op.drop_index("ix_kaders_village_id", table_name="kaders")
    op.drop_index("ix_kaders_nama", table_name="kaders")
    op.drop_index("ix_kaders_nik", table_name="kaders")
    op.drop_table("kaders")
