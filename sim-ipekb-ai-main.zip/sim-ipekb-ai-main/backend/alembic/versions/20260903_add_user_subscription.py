"""add free/paid subscription fields to users

Revision ID: 20260903_user_subscription
Revises: v7_master_iuran
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "20260903_user_subscription"
down_revision: Union[str, Sequence[str], None] = "v7_master_iuran"
branch_labels = None
depends_on = None

def upgrade() -> None:
    op.add_column("users", sa.Column("plan_type", sa.String(length=20), nullable=False, server_default="FREE"))
    op.add_column("users", sa.Column("plan_expires_at", sa.DateTime(timezone=True), nullable=True))
    op.create_index("ix_users_plan_type", "users", ["plan_type"], unique=False)

def downgrade() -> None:
    op.drop_index("ix_users_plan_type", table_name="users")
    op.drop_column("users", "plan_expires_at")
    op.drop_column("users", "plan_type")
