"""create iuran settings and payments tables

Revision ID: a14c2026iuran
Revises: 8d78d486cb10
Create Date: 2026-08-14
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "a14c2026iuran"
down_revision: Union[str, Sequence[str], None] = "8d78d486cb10"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "iuran_settings",
        sa.Column("year", sa.Integer(), nullable=False),
        sa.Column("monthly_amount", sa.Numeric(14, 2), nullable=False),
        sa.Column("due_day", sa.Integer(), nullable=False, server_default="10"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("year", name="uq_iuran_settings_year"),
    )
    op.create_index(op.f("ix_iuran_settings_year"), "iuran_settings", ["year"], unique=False)

    op.create_table(
        "iuran_payments",
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("year", sa.Integer(), nullable=False),
        sa.Column("month", sa.Integer(), nullable=False),
        sa.Column("amount", sa.Numeric(14, 2), nullable=False),
        sa.Column("paid_at", sa.Date(), nullable=False),
        sa.Column("payment_method", sa.String(length=30), nullable=True),
        sa.Column("reference_no", sa.String(length=100), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="VERIFIED"),
        sa.Column("verified_by_user_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("verified_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["verified_by_user_id"], ["users.id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("user_id", "year", "month", name="uq_iuran_payment_user_period"),
    )
    op.create_index(op.f("ix_iuran_payments_user_id"), "iuran_payments", ["user_id"], unique=False)
    op.create_index(op.f("ix_iuran_payments_year"), "iuran_payments", ["year"], unique=False)
    op.create_index(op.f("ix_iuran_payments_month"), "iuran_payments", ["month"], unique=False)


def downgrade() -> None:
    op.drop_index(op.f("ix_iuran_payments_month"), table_name="iuran_payments")
    op.drop_index(op.f("ix_iuran_payments_year"), table_name="iuran_payments")
    op.drop_index(op.f("ix_iuran_payments_user_id"), table_name="iuran_payments")
    op.drop_table("iuran_payments")
    op.drop_index(op.f("ix_iuran_settings_year"), table_name="iuran_settings")
    op.drop_table("iuran_settings")
