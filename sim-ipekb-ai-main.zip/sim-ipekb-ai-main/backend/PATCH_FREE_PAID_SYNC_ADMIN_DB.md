# Patch SIM-IPEKB-AI — FREE/PAID + Auto Sync SIGA + Reset Data

## Fitur
1. User memiliki `FREE` atau `PAID`.
2. Hanya `SUPER_ADMIN` yang boleh mengubah paket.
3. FREE maksimal 1 desa binaan.
4. PAID dapat memiliki banyak desa binaan; masa berlaku opsional melalui `plan_expires_at`.
5. Sinkronisasi SIGA otomatis setiap hari pukul **00:00 WIB (Asia/Jakarta)**.
6. Auto-sync memakai seluruh akun SIGA aktif yang tersimpan terenkripsi.
7. Auto-sync menjalankan RegionSync + ParentSync + MemberSync.
8. SUPER_ADMIN mempunyai endpoint penghapusan data operasional dengan konfirmasi `HAPUS SEMUA DATA`.
9. Reset tidak menghapus akun user, role, permission, master wilayah, atau akun SIGA, sehingga login dan auto-sync tetap dapat digunakan.

## Migrasi
Dari folder `backend`:

```powershell
python -m alembic upgrade head
```

## Menjalankan backend

```powershell
python -m uvicorn app.main:app --reload
```

## Endpoint paket

```text
PATCH /api/v1/users/{user_id}/subscription
Authorization: Bearer <TOKEN_SUPER_ADMIN>
Content-Type: application/json

{
  "plan_type": "PAID",
  "plan_expires_at": "2027-01-01T00:00:00+07:00"
}
```

Untuk FREE:

```json
{
  "plan_type": "FREE",
  "plan_expires_at": null
}
```

## Endpoint reset data

```text
POST /api/v1/admin/database/reset-data?confirmation=HAPUS%20SEMUA%20DATA
Authorization: Bearer <TOKEN_SUPER_ADMIN>
```

Endpoint ini sengaja memakai konfirmasi teks untuk mencegah klik tidak sengaja.

## Jadwal SIGA
Default:

```text
SYNC_SCHEDULE_HOUR=0
SYNC_SCHEDULE_MINUTE=0
AUTO_SYNC_ENABLED=true
```

Bisa ditaruh di `.env` bila ingin eksplisit.
