from app.core.encryption import encryption_service

password = "AdminSIGA123"

encrypted = encryption_service.encrypt(password)

print("Encrypted :", encrypted)

decrypted = encryption_service.decrypt(encrypted)

print("Decrypted :", decrypted)