from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # =========================
    # APP
    # =========================
    APP_NAME: str
    APP_VERSION: str
    ENVIRONMENT: str = "development"

    # =========================
    # DATABASE
    # =========================
    DB_HOST: str
    DB_PORT: int
    DB_NAME: str
    DB_USER: str
    DB_PASSWORD: str

    # =========================
    # JWT
    # =========================
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440

    # =========================
    # ENCRYPTION
    # =========================
    FERNET_KEY: str

    # =========================
    # SIGA
    # =========================
    SIGA_BASE_URL: str
    GEMINI_API_KEY: str | None = None
    GEMINI_MODEL: str = "gemini-3.5-flash-lite"

    # =========================
    # SCHEDULER
    # =========================
    SYNC_SCHEDULE_HOUR: int = 0
    SYNC_SCHEDULE_MINUTE: int = 0

    AUTO_SYNC_ENABLED: bool = True

    # Tagihan kas otomatis setiap tanggal 25 (Asia/Jakarta).
    IURAN_BILLING_DAY: int = 25
    IURAN_BILLING_HOUR: int = 8
    IURAN_BILLING_MINUTE: int = 0

    # WhatsApp gateway. Nomor pengirim mengikuti nomor resmi yang diberikan.
    WA_SENDER_NUMBER: str = "+62 822-9505-6743"
    WA_GATEWAY_URL: str | None = None
    WA_GATEWAY_API_KEY: str | None = None
    WA_GATEWAY_TIMEOUT_SECONDS: int = 20

    model_config = SettingsConfigDict(
        env_file=".env",
        case_sensitive=True,
        extra="ignore",
    )

    @property
    def database_url(self) -> str:
        return (
            f"postgresql+psycopg://{self.DB_USER}:{self.DB_PASSWORD}"
            f"@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"
        )


@lru_cache
def get_settings():
    return Settings()


settings = get_settings()