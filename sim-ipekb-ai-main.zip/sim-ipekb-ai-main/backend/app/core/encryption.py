from cryptography.fernet import Fernet

from app.core.config import settings


class EncryptionService:
    def __init__(self):
        self._fernet = Fernet(settings.FERNET_KEY.encode())

    def encrypt(self, value: str) -> str:
        return self._fernet.encrypt(value.encode()).decode()

    def decrypt(self, value: str) -> str:
        return self._fernet.decrypt(value.encode()).decode()


encryption_service = EncryptionService()