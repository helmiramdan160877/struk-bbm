from __future__ import annotations

import logging
from datetime import datetime

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from app.core.config import settings
from app.core.encryption import encryption_service
from app.db.database import SessionLocal
from app.models.siga_account import SigaAccount
from app.services.iuran_notification_service import generate_monthly_iuran_notifications
from app.sync.sync_manager import SyncManager

logger = logging.getLogger(__name__)
_scheduler: BackgroundScheduler | None = None


def _run_iuran_job():
    db = SessionLocal()
    try:
        generate_monthly_iuran_notifications(db, send_wa=True)
    except Exception:
        logger.exception("Job iuran otomatis gagal")
    finally:
        db.close()


def _run_siga_auto_sync():
    db = SessionLocal()
    started = datetime.now()
    try:
        if not settings.AUTO_SYNC_ENABLED:
            logger.info("Auto-sync SIGA dinonaktifkan oleh konfigurasi.")
            return

        accounts = (
            db.query(SigaAccount)
            .filter(SigaAccount.is_active.is_(True))
            .order_by(SigaAccount.username.asc())
            .all()
        )
        if not accounts:
            logger.warning("Auto-sync SIGA: tidak ada akun SIGA aktif.")
            return

        now = datetime.now()
        for account in accounts:
            try:
                password = encryption_service.decrypt(account.password_encrypted)
                result = SyncManager(db).run(
                    username_siga=account.username,
                    password_siga=password,
                    bulan=now.month,
                    tahun=now.year,
                )
                account.last_sync_at = datetime.now()
                db.add(account)
                db.commit()
                logger.info("Auto-sync SIGA %s berhasil: %s", account.username, result)
            except Exception:
                db.rollback()
                logger.exception("Auto-sync SIGA %s gagal", account.username)

        logger.info("Auto-sync SIGA selesai dalam %s", datetime.now() - started)
    except Exception:
        db.rollback()
        logger.exception("Auto-sync SIGA job gagal")
    finally:
        db.close()


def start_scheduler():
    global _scheduler
    if _scheduler and _scheduler.running:
        return

    _scheduler = BackgroundScheduler(timezone="Asia/Jakarta")

    # SIGA otomatis setiap hari pukul 00:00 WIB.
    _scheduler.add_job(
        _run_siga_auto_sync,
        CronTrigger(hour=settings.SYNC_SCHEDULE_HOUR, minute=settings.SYNC_SCHEDULE_MINUTE, timezone="Asia/Jakarta"),
        id="daily_siga_auto_sync",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )

    _scheduler.add_job(
        _run_iuran_job,
        CronTrigger(
            day=settings.IURAN_BILLING_DAY,
            hour=settings.IURAN_BILLING_HOUR,
            minute=settings.IURAN_BILLING_MINUTE,
            timezone="Asia/Jakarta",
        ),
        id="monthly_iuran_reminder",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )
    _scheduler.start()
    logger.info("Scheduler aktif. Auto-sync SIGA: %02d:%02d WIB", settings.SYNC_SCHEDULE_HOUR, settings.SYNC_SCHEDULE_MINUTE)


def stop_scheduler():
    global _scheduler
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
    _scheduler = None
