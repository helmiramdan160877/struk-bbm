from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class UserCreate(BaseModel):
    username: str
    email: str | None = None
    full_name: str
    password: str = Field(min_length=6)
    role_id: UUID
    nip: str | None = None
    phone: str | None = None
    district_id: UUID | None = None
    village_ids: list[UUID] = Field(default_factory=list)
    master_source_id: UUID | None = None
    siga_account_id: UUID | None = None
    plan_type: str = "FREE"
    plan_expires_at: datetime | None = None


class UserUpdate(BaseModel):
    email: str | None = None
    full_name: str | None = None
    password: str | None = Field(default=None, min_length=6)
    role_id: UUID | None = None
    is_active: bool | None = None
    nip: str | None = None
    phone: str | None = None
    district_id: UUID | None = None
    village_ids: list[UUID] | None = None
    master_source_id: UUID | None = None
    plan_type: str | None = None
    plan_expires_at: datetime | None = None
    siga_account_id: UUID | None = None


class AnggotaFromPkbCreate(BaseModel):
    pkb_id: UUID
    username: str
    email: str | None = None
    password: str = Field(min_length=6)
    plan_type: str = "FREE"
    plan_expires_at: datetime | None = None


class SubscriptionUpdate(BaseModel):
    plan_type: str
    plan_expires_at: datetime | None = None


class PasswordReset(BaseModel):
    new_password: str = Field(min_length=6)


class UserRoleResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    name: str
    description: str | None = None
    is_active: bool


class UserVillageMini(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    code: str
    name: str
    district_id: UUID
    siga_id: str | None = None


class UserVillageLinkResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    village_id: UUID
    village: UserVillageMini


class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    username: str
    email: str | None = None
    full_name: str
    is_active: bool
    nip: str | None = None
    phone: str | None = None
    district_id: UUID | None = None
    pkb_id: UUID | None = None
    kader_id: UUID | None = None
    siga_account_id: UUID | None = None
    plan_type: str
    plan_expires_at: datetime | None = None
    plan_active: bool = True
    role: UserRoleResponse | None = None
    user_villages: list[UserVillageLinkResponse] = Field(default_factory=list)


class ManageableVillageResponse(BaseModel):
    id: UUID
    code: str
    name: str
    district_id: UUID
    district_name: str
    siga_id: str | None = None
    source: str = "SIGA"


class UserMasterSourceResponse(BaseModel):
    id: UUID
    source_type: str
    code: str
    name: str
    email: str | None = None
    phone: str | None = None
    village_id: UUID | None = None
    village_name: str | None = None
    district_id: UUID | None = None
    siga_account_id: UUID | None = None
    status: str = "AKTIF"
