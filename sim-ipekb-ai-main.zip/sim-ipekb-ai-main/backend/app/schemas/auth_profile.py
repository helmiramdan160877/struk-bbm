from datetime import datetime
from pydantic import BaseModel, EmailStr, Field

class ProfileUpdate(BaseModel):
    full_name: str = Field(min_length=2, max_length=150)
    email: EmailStr
    phone: str | None = Field(default=None, max_length=20)
    photo: str | None = None
    password: str | None = Field(default=None, min_length=6)
