from datetime import date
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class FamilyMemberCreate(BaseModel):
    family_id: UUID
    nik: str
    full_name: str
    gender: str
    birth_place: str | None = None
    birth_date: date | None = None
    religion: str | None = None
    education: str | None = None
    occupation: str | None = None
    marital_status: str | None = None
    relationship_to_head: str


class FamilyMemberUpdate(BaseModel):
    family_id: UUID | None = None
    nik: str | None = None
    full_name: str | None = None
    gender: str | None = None
    birth_place: str | None = None
    birth_date: date | None = None
    religion: str | None = None
    education: str | None = None
    occupation: str | None = None
    marital_status: str | None = None
    relationship_to_head: str | None = None
    is_alive: bool | None = None


class FamilyMemberResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    family_id: UUID
    nik: str
    full_name: str
    gender: str
    birth_place: str | None
    birth_date: date | None
    age: int | None = None
    family_card_number: str | None = None
    religion: str | None
    education: str | None
    occupation: str | None
    marital_status: str | None
    relationship_to_head: str
    is_alive: bool