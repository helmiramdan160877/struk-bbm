from uuid import UUID

from pydantic import BaseModel, ConfigDict


class RegencyCreate(BaseModel):
    province_id: UUID
    code: str
    name: str


class RegencyUpdate(BaseModel):
    province_id: UUID | None = None
    code: str | None = None
    name: str | None = None
    is_active: bool | None = None


class RegencyResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    province_id: UUID
    code: str
    name: str
    is_active: bool