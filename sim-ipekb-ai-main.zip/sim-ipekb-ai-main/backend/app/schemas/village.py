from uuid import UUID

from pydantic import BaseModel, ConfigDict


class VillageCreate(BaseModel):
    district_id: UUID
    code: str
    name: str


class VillageUpdate(BaseModel):
    district_id: UUID | None = None
    code: str | None = None
    name: str | None = None
    is_active: bool | None = None


class VillageResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    district_id: UUID
    code: str
    name: str
    is_active: bool