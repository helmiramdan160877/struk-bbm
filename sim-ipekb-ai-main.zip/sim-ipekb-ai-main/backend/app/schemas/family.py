from uuid import UUID

from pydantic import BaseModel, ConfigDict


# =========================================================
# CREATE
# =========================================================

class FamilyCreate(BaseModel):
    village_id: UUID
    family_card_number: str
    head_of_family: str
    address: str
    rt: str | None = None
    rw: str | None = None
    postal_code: str | None = None


# =========================================================
# UPDATE
# =========================================================

class FamilyUpdate(BaseModel):
    village_id: UUID | None = None
    family_card_number: str | None = None
    head_of_family: str | None = None
    address: str | None = None
    rt: str | None = None
    rw: str | None = None
    postal_code: str | None = None
    is_active: bool | None = None


# =========================================================
# RESPONSE
# =========================================================

class FamilyResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    village_id: UUID
    family_card_number: str
    head_of_family: str
    address: str
    rt: str | None
    rw: str | None
    postal_code: str | None
    is_active: bool


# =========================================================
# LIST RESPONSE
# =========================================================

class FamilyListResponse(BaseModel):
    items: list[FamilyResponse]
    total: int
    page: int
    limit: int
    total_pages: int