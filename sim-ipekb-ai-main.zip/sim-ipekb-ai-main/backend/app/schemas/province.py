from uuid import UUID

from pydantic import BaseModel, ConfigDict


class ProvinceCreate(BaseModel):
    code: str
    name: str


class ProvinceUpdate(BaseModel):
    code: str | None = None
    name: str | None = None
    is_active: bool | None = None


class ProvinceResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    code: str
    name: str
    is_active: bool