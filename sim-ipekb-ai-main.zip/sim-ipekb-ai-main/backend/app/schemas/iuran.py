from datetime import date, datetime
from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class IuranSettingUpsert(BaseModel):
    year: int = Field(ge=2020, le=2100)
    monthly_amount: Decimal = Field(ge=0)
    due_day: int = Field(default=25, ge=1, le=28)


class IuranSettingResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    year: int
    monthly_amount: Decimal
    due_day: int
    is_active: bool


class IuranPaymentCreate(BaseModel):
    user_id: UUID | None = None
    year: int = Field(ge=2020, le=2100)
    month: int = Field(ge=1, le=12)
    amount: Decimal | None = Field(default=None, ge=0)
    paid_at: date | None = None
    payment_method: str | None = None
    reference_no: str | None = None
    notes: str | None = None


class IuranPaymentResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    user_id: UUID
    year: int
    month: int
    amount: Decimal
    paid_at: date
    payment_method: str | None = None
    reference_no: str | None = None
    notes: str | None = None
    status: str
    verified_by_user_id: UUID | None = None
    verified_at: datetime | None = None


class IuranMonthStatus(BaseModel):
    month: int
    month_name: str
    expected_amount: Decimal
    paid_amount: Decimal
    status: str
    paid_at: date | None = None
    payment_method: str | None = None
    reference_no: str | None = None


class IuranMySummary(BaseModel):
    year: int
    monthly_amount: Decimal
    total_expected: Decimal
    total_paid: Decimal
    total_outstanding: Decimal
    paid_months: int
    unpaid_months: int
    charged_through_month: int = 0
    charged_through_month_name: str | None = None
    months: list[IuranMonthStatus]


class IuranMemberSummary(BaseModel):
    user_id: UUID
    pkb_id: UUID | None = None
    full_name: str
    username: str
    nip: str | None = None
    phone: str | None = None
    year: int
    total_expected: Decimal
    total_paid: Decimal
    total_outstanding: Decimal
    paid_months: int
    unpaid_months: int
