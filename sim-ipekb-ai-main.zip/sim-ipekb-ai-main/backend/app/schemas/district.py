from uuid import UUID

from pydantic import BaseModel, ConfigDict


class DistrictCreate(BaseModel):
    regency_id: UUID
    code: str
    name: str


class DistrictUpdate(BaseModel):
    regency_id: UUID | None = None
    code: str | None = None
    name: str | None = None
    is_active: bool | None = None


class DistrictResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    regency_id: UUID
    code: str
    name: str
    is_active: bool