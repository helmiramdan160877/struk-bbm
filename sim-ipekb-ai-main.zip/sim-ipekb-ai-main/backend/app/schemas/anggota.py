from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class AnggotaCreate(BaseModel):
    nama: str
    nip: str | None = None
    phone: str | None = None
    status: str = "AKTIF"



class AnggotaUpdate(BaseModel):
    nama: str | None = None
    nip: str | None = None
    phone: str | None = None
    status: str | None = None



class AnggotaResponse(AnggotaCreate):
    id: UUID
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(
        from_attributes=True
    )