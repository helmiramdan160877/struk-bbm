from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class KaderBase(BaseModel):
    nik: str = Field(min_length=8, max_length=20)
    nama: str = Field(min_length=2, max_length=150)
    email: EmailStr | None = None
    phone: str | None = Field(default=None, max_length=30)
    alamat: str | None = None
    jabatan: str | None = Field(default=None, max_length=100)
    village_id: UUID | None = None
    status: str = "AKTIF"


class KaderCreate(KaderBase):
    pass


class KaderUpdate(BaseModel):
    nik: str | None = Field(default=None, min_length=8, max_length=20)
    nama: str | None = Field(default=None, min_length=2, max_length=150)
    email: EmailStr | None = None
    phone: str | None = Field(default=None, max_length=30)
    alamat: str | None = None
    jabatan: str | None = Field(default=None, max_length=100)
    village_id: UUID | None = None
    status: str | None = None


class KaderResponse(KaderBase):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    created_at: datetime
    updated_at: datetime
    village_name: str | None = None
    district_name: str | None = None
