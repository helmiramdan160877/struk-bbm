from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class SigaAccountCreate(BaseModel):
    district_id: UUID | None = None
    username: str
    password: str


class SigaAccountUpdate(BaseModel):
    username: str | None = None
    password: str | None = None
    is_active: bool | None = None


class SigaAccountResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    district_id: UUID | None = None
    username: str
    is_active: bool
    last_sync_at: datetime | None = None
    district_name: str | None = None
    siga_district_id: str | None = None