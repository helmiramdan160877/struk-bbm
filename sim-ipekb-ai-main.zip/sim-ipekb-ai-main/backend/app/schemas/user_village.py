from uuid import UUID

from pydantic import BaseModel, ConfigDict


class UserVillageCreate(BaseModel):
    village_id: UUID


class UserVillageResponse(BaseModel):
    id: UUID
    user_id: UUID
    village_id: UUID

    model_config = ConfigDict(
        from_attributes=True,
    )