from datetime import date, datetime
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict


# =========================================================
# BASE
# =========================================================

class PKBBase(BaseModel):
    nip: str
    nik: str
    nama: str

    tempat_lahir: Optional[str] = None
    tanggal_lahir: Optional[date] = None

    jenis_kelamin: Optional[str] = None
    agama: Optional[str] = None
    pendidikan: Optional[str] = None

    jabatan: Optional[str] = None
    status_asn: Optional[str] = None
    golongan: Optional[str] = None

    email: Optional[str] = None
    phone: Optional[str] = None

    alamat: Optional[str] = None
    photo: Optional[str] = None

    kecamatan: Optional[str] = None
    desa: Optional[str] = None
    wilayah_binaan: Optional[str] = None

    village_id: Optional[UUID] = None
    siga_account_id: Optional[UUID] = None

    status: Optional[str] = "AKTIF"


# =========================================================
# CREATE
# =========================================================

class PKBCreate(PKBBase):
    pass


# =========================================================
# UPDATE
# =========================================================

class PKBUpdate(BaseModel):
    nip: Optional[str] = None
    nik: Optional[str] = None
    nama: Optional[str] = None

    tempat_lahir: Optional[str] = None
    tanggal_lahir: Optional[date] = None

    jenis_kelamin: Optional[str] = None
    agama: Optional[str] = None
    pendidikan: Optional[str] = None

    jabatan: Optional[str] = None
    status_asn: Optional[str] = None
    golongan: Optional[str] = None

    email: Optional[str] = None
    phone: Optional[str] = None

    alamat: Optional[str] = None
    photo: Optional[str] = None

    kecamatan: Optional[str] = None
    desa: Optional[str] = None
    wilayah_binaan: Optional[str] = None

    village_id: Optional[UUID] = None
    siga_account_id: Optional[UUID] = None

    status: Optional[str] = None


# =========================================================
# RESPONSE
# =========================================================

class PKBResponse(PKBBase):
    id: UUID

    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(
        from_attributes=True,
    )