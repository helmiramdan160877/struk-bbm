from __future__ import annotations

import logging
import time

import httpx
from sqlalchemy.orm import Session

from .session import SigaSession

logger = logging.getLogger(__name__)


class BaseApiSync:

    def __init__(
        self,
        db: Session,
        session: SigaSession,
    ):
        self.db = db
        self.session = session

    def get_json(
        self,
        endpoint: str,
        params: dict | None = None,
        retry: int = 5,
        timeout: float | None = None,
    ) -> dict:

        for attempt in range(1, retry + 1):

            try:
                response = self.session.get(
                    endpoint,
                    params=params,
                    **({"timeout": timeout} if timeout is not None else {}),
                )

                print("\n" + "=" * 100)
                print(f"GET ATTEMPT : {attempt}/{retry}")
                print("URL         :", response.request.url)
                print("STATUS      :", response.status_code)
                print("PARAMS      :", params)
                print("RESPONSE    :", response.text[:2000])
                print("=" * 100)

                if response.status_code >= 500:

                    if attempt < retry:
                        delay = min(2 ** attempt, 15)

                        print(
                            f"[SIGA 5xx] Retry dalam {delay} detik..."
                        )

                        time.sleep(delay)
                        continue

                    raise httpx.HTTPStatusError(
                        f"Server Error {response.status_code}",
                        request=response.request,
                        response=response,
                    )

                response.raise_for_status()

                return response.json()

            except (
                httpx.ReadTimeout,
                httpx.ConnectTimeout,
                httpx.WriteTimeout,
                httpx.PoolTimeout,
                httpx.ConnectError,
                httpx.RemoteProtocolError,
            ) as exc:

                print(
                    f"[NETWORK ERROR] "
                    f"attempt={attempt}/{retry}: {exc}"
                )

                if attempt >= retry:
                    raise

                delay = min(2 ** attempt, 15)
                time.sleep(delay)

            except httpx.HTTPStatusError as exc:

                print(
                    f"[HTTP ERROR] "
                    f"attempt={attempt}/{retry}: {exc}"
                )

                if exc.response is not None:
                    print(
                        "STATUS   :",
                        exc.response.status_code,
                    )
                    print(
                        "URL      :",
                        exc.request.url,
                    )
                    print(
                        "RESPONSE :",
                        exc.response.text[:2000],
                    )

                if attempt >= retry:
                    raise

                delay = min(2 ** attempt, 15)
                time.sleep(delay)

        raise RuntimeError(
            "Request SIGA gagal setelah seluruh percobaan."
        )

    def post_json(
        self,
        endpoint: str,
        json: dict | None = None,
        data: dict | None = None,
        retry: int = 5,
    ) -> dict:

        for attempt in range(1, retry + 1):

            try:
                response = self.session.post(
                    endpoint,
                    json=json,
                    data=data,
                )

                print("\n" + "=" * 100)
                print(f"POST ATTEMPT : {attempt}/{retry}")
                print("URL          :", response.request.url)
                print("STATUS       :", response.status_code)
                print("RESPONSE     :", response.text[:2000])
                print("=" * 100)

                if response.status_code >= 500:

                    if attempt < retry:
                        delay = min(2 ** attempt, 15)
                        time.sleep(delay)
                        continue

                    raise httpx.HTTPStatusError(
                        f"Server Error {response.status_code}",
                        request=response.request,
                        response=response,
                    )

                response.raise_for_status()

                return response.json()

            except (
                httpx.ReadTimeout,
                httpx.ConnectTimeout,
                httpx.WriteTimeout,
                httpx.PoolTimeout,
                httpx.ConnectError,
                httpx.RemoteProtocolError,
            ) as exc:

                print(
                    f"[NETWORK ERROR] "
                    f"attempt={attempt}/{retry}: {exc}"
                )

                if attempt >= retry:
                    raise

                delay = min(2 ** attempt, 15)
                time.sleep(delay)

            except httpx.HTTPStatusError as exc:

                print(
                    f"[HTTP ERROR] "
                    f"attempt={attempt}/{retry}: {exc}"
                )

                if exc.response is not None:
                    print(
                        "STATUS   :",
                        exc.response.status_code,
                    )
                    print(
                        "URL      :",
                        exc.request.url,
                    )
                    print(
                        "RESPONSE :",
                        exc.response.text[:2000],
                    )

                if attempt >= retry:
                    raise

                delay = min(2 ** attempt, 15)
                time.sleep(delay)

        raise RuntimeError(
            "POST SIGA gagal setelah seluruh percobaan."
        )

    def extract_list(self, response: dict) -> list:

        if response is None:
            return []

        if isinstance(response, list):
            return response

        if not isinstance(response, dict):
            return []

        for key in (
            "data",
            "content",
            "result",
            "results",
            "rows",
            "list",
            "items",
        ):
            value = response.get(key)

            if isinstance(value, list):
                return value

        for value in response.values():

            if isinstance(value, dict):
                for key in (
                    "data",
                    "content",
                    "result",
                    "results",
                    "rows",
                    "list",
                    "items",
                ):
                    nested = value.get(key)

                    if isinstance(nested, list):
                        return nested

        return []