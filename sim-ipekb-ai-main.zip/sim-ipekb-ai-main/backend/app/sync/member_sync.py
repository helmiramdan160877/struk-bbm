from __future__ import annotations

import logging

from app.models.family import Family
from app.repositories.family_member_repository import (
    FamilyMemberRepository,
)

from .base_api_sync import BaseApiSync


logger = logging.getLogger(__name__)


class MemberSync(BaseApiSync):
    """
    FULL SYNC anggota keluarga dari SIGA.

    Alur:

        SEMUA KK di database
                ↓
        childRekapPK SIGA
                ↓
        SEMUA anggota
                ↓
        NIK sudah ada  → UPDATE
        NIK belum ada  → INSERT

    Tidak lagi mencari hanya KK yang belum mempunyai anggota.
    """

    ENDPOINT = (
        "/rekapitulasi-data-keluarga/siga/rekap/"
        "childRekapPK"
    )

    def __init__(self, db, session):
        super().__init__(db, session)

        self.member_repo = FamilyMemberRepository(db)

    # =========================================================
    # FORMAT NO KELUARGA
    # =========================================================

    @staticmethod
    def format_no_keluarga(value: str) -> str:
        """
        Format nomor keluarga untuk request SIGA.

        23 digit:
            32031720080005002023023

        menjadi:

            32031720080005      002023023
        """

        if value is None:
            return ""

        value = str(value).strip()

        if not value:
            return ""

        if " " in value:
            return value

        if len(value) == 23 and value.isdigit():
            return (
                value[:14]
                + (" " * 6)
                + value[14:]
            )

        return value

    # =========================================================
    # AMBIL ANGGOTA DARI SIGA
    # =========================================================

    def get_members(
        self,
        no_keluarga: str,
        bulan: int,
        tahun: int,
    ):
        original = str(
            no_keluarga or ""
        ).strip()

        formatted = self.format_no_keluarga(
            original
        )

        logger.info(
            "[MEMBER] Ambil anggota KK dari SIGA"
        )

        logger.info(
            "[MEMBER] noKeluarga lokal : %s",
            original,
        )

        logger.info(
            "[MEMBER] noKeluarga SIGA  : %s",
            repr(formatted),
        )

        return self.get_json(
            endpoint=self.ENDPOINT,
            params={
                "bulan": bulan,
                "tahun": tahun,
                "noKeluarga": formatted,
            },
        )

    # =========================================================
    # EXTRACT RESPONSE
    # =========================================================

    def extract_member_rows(self, response):
        """
        Menangani beberapa bentuk response SIGA.
        """

        if response is None:
            return []

        # -----------------------------------------------------
        # LIST LANGSUNG
        # -----------------------------------------------------

        if isinstance(response, list):
            return [
                item
                for item in response
                if isinstance(item, dict)
            ]

        # -----------------------------------------------------
        # HARUS DICTIONARY
        # -----------------------------------------------------

        if not isinstance(response, dict):
            return []

        keys = [
            "data",
            "content",
            "result",
            "results",
            "rows",
            "list",
            "items",
        ]

        for key in keys:

            value = response.get(key)

            if isinstance(value, list):
                return [
                    item
                    for item in value
                    if isinstance(item, dict)
                ]

            if isinstance(value, dict):
                nested = self.extract_member_rows(
                    value
                )

                if nested:
                    return nested

        # -----------------------------------------------------
        # CARI LIST DI VALUE
        # -----------------------------------------------------

        for value in response.values():

            if isinstance(value, list):

                rows = [
                    item
                    for item in value
                    if isinstance(item, dict)
                ]

                if rows:
                    return rows

        return []

    # =========================================================
    # VALIDASI
    # =========================================================

    @staticmethod
    def valid_nik(nik: str) -> bool:

        if not nik:
            return False

        nik = str(nik).strip()

        if len(nik) != 16:
            return False

        if not nik.isdigit():
            return False

        if nik in {
            "0000000000000000",
            "1111111111111111",
            "2222222222222222",
            "3333333333333333",
            "4444444444444444",
            "5555555555555555",
            "6666666666666666",
            "7777777777777777",
            "8888888888888888",
            "9999999999999999",
        }:
            return False

        return True

    # =========================================================
    # FULL SYNC
    # =========================================================

    def run(
        self,
        bulan: int,
        tahun: int,
        district_id=None,
        village_siga_ids: list[str] | None = None,
    ):
        """
        FULL SYNC.

        Semua KK yang sudah ada di database akan diproses.

        TIDAK ADA lagi:

            WHERE family_members.id IS NULL

        sehingga KK yang sudah mempunyai anggota tetap
        diproses ulang dari SIGA.
        """

        total_family = 0
        total_member = 0
        total_empty = 0
        total_skipped = 0
        total_failed = 0

        # =====================================================
        # AMBIL SEMUA KK
        # =====================================================

        query = self.db.query(Family)

        # -----------------------------------------------------
        # FILTER WILAYAH
        # -----------------------------------------------------

        if district_id is not None:

            from app.models.village import Village

            query = (
                query
                .join(
                    Village,
                    Family.village_id
                    == Village.id,
                )
                .filter(
                    Village.district_id
                    == district_id
                )
            )

        if village_siga_ids is not None:
            from app.models.village import Village
            if district_id is None:
                query = query.join(Village, Family.village_id == Village.id)
            query = query.filter(Village.siga_id.in_([str(v) for v in village_siga_ids if v]))

        families = query.all()

        logger.info(
            "=" * 70
        )

        logger.info(
            "[MEMBER FULL SYNC]"
        )

        logger.info(
            "Total KK yang akan diproses : %s",
            len(families),
        )

        logger.info(
            "Periode : %02d/%d",
            bulan,
            tahun,
        )

        logger.info(
            "=" * 70
        )

        # =====================================================
        # LOOP SEMUA KK
        # =====================================================

        for index, family in enumerate(
            families,
            start=1,
        ):

            try:

                if not family.siga_id:

                    total_skipped += 1

                    logger.warning(
                        "[%s/%s] KK tidak memiliki siga_id",
                        index,
                        len(families),
                    )

                    continue

                # -------------------------------------------------
                # REQUEST KE SIGA
                # -------------------------------------------------

                response = self.get_members(
                    family.siga_id,
                    bulan,
                    tahun,
                )

                rows = self.extract_member_rows(
                    response
                )

                # -------------------------------------------------
                # TIDAK ADA ANGGOTA
                # -------------------------------------------------

                if not rows:

                    total_empty += 1

                    logger.info(
                        "[%s/%s] KK %s → 0 anggota",
                        index,
                        len(families),
                        family.family_card_number,
                    )

                    continue

                # -------------------------------------------------
                # PROSES SEMUA ANGGOTA
                # -------------------------------------------------

                family_member_count = 0

                for row in rows:

                    nik = (
                        row.get("nik")
                        or row.get("NIK")
                        or row.get("noNik")
                    )

                    if not self.valid_nik(nik):

                        total_skipped += 1

                        logger.warning(
                            "[%s/%s] NIK tidak valid pada KK %s",
                            index,
                            len(families),
                            family.family_card_number,
                        )

                        continue

                    member = self.member_repo.save(
                        family,
                        row,
                    )

                    if member is None:
                        total_skipped += 1
                        continue

                    total_member += 1
                    family_member_count += 1

                total_family += 1

                # -------------------------------------------------
                # COMMIT SETIAP 100 KK
                # -------------------------------------------------

                if index % 100 == 0:

                    self.db.commit()

                    logger.info(
                        "COMMIT setelah %s KK",
                        index,
                    )

                logger.info(
                    "[%s/%s] KK %s → %s anggota",
                    index,
                    len(families),
                    family.family_card_number,
                    family_member_count,
                )

            except Exception as exc:

                total_failed += 1

                logger.exception(
                    "Gagal sync KK %s : %s",
                    family.family_card_number,
                    exc,
                )

                self.db.rollback()

        # =====================================================
        # COMMIT TERAKHIR
        # =====================================================

        self.db.commit()

        # =====================================================
        # HASIL
        # =====================================================

        logger.info(
            "=" * 70
        )

        logger.info(
            "[MEMBER FULL SYNC SELESAI]"
        )

        logger.info(
            "Total KK diproses : %s",
            total_family,
        )

        logger.info(
            "Total anggota     : %s",
            total_member,
        )

        logger.info(
            "KK tanpa anggota  : %s",
            total_empty,
        )

        logger.info(
            "Data dilewati     : %s",
            total_skipped,
        )

        logger.info(
            "KK gagal          : %s",
            total_failed,
        )

        logger.info(
            "=" * 70
        )

        return {
            "success": True,
            "family": total_family,
            "member": total_member,
            "empty": total_empty,
            "skipped": total_skipped,
            "failed": total_failed,
        }