from __future__ import annotations

from datetime import datetime

from app.repositories.siga_account_repository import (
    SigaAccountRepository,
)

from app.sync.parent_sync import ParentSync
from app.sync.region_sync import RegionSync
from app.sync.member_sync import MemberSync

from .base_sync import BaseSync


class SyncManager(BaseSync):

    def run(
        self,
        username_siga: str,
        password_siga: str,
        bulan: int,
        tahun: int,
        village_siga_ids: list[str] | None = None,
    ):

        session = self.login(
            username=username_siga,
            password=password_siga,
        )

        try:

            siga_repo = SigaAccountRepository(
                self.db
            )

            siga_account = (
                siga_repo.get_by_username(
                    username_siga
                )
            )

            if siga_account is None:
                raise Exception(
                    f"Akun SIGA '{username_siga}' "
                    "tidak ditemukan."
                )

            if not siga_account.is_active:
                raise Exception(
                    "Akun SIGA tidak aktif."
                )

            district_id = (
                siga_account.district_id
            )

            if district_id is None:
                raise Exception(
                    "Akun SIGA belum memiliki "
                    "district_id."
                )

            print(
                "\n"
                + "=" * 70
            )

            print(
                "SINKRONISASI FULL SIGA"
            )

            print(
                "Username SIGA :",
                username_siga,
            )

            print(
                "District ID   :",
                district_id,
            )

            print(
                "Periode       :",
                f"{bulan}/{tahun}",
            )

            print(
                "=" * 70
                + "\n"
            )

            # =================================================
            # REGION
            # =================================================

            region_result = RegionSync(
                self.db,
                session,
            ).run()

            # =================================================
            # SEMUA KK
            # =================================================

            parent_result = ParentSync(
                self.db,
                session,
            ).run(
                bulan=bulan,
                tahun=tahun,
                village_siga_ids=village_siga_ids,
            )

            # =================================================
            # SEMUA ANGGOTA
            # =================================================

            member_result = MemberSync(
                self.db,
                session,
            ).run(
                bulan=bulan,
                tahun=tahun,
                district_id=district_id,
                village_siga_ids=village_siga_ids,
            )

            # =================================================
            # LAST SYNC
            # =================================================

            siga_account.last_sync_at = (
                datetime.now()
            )

            self.db.add(
                siga_account
            )

            self.db.commit()

            self.db.refresh(
                siga_account
            )

            return {
                "success": True,
                "message": (
                    "Full sinkronisasi SIGA selesai."
                ),
                "region": region_result,
                "parent": parent_result,
                "member": member_result,
                "scope": {
                    "village_count": len(village_siga_ids or []),
                    "village_siga_ids": village_siga_ids or [],
                },
            }

        except Exception:

            self.db.rollback()

            raise

        finally:

            session.close()