from __future__ import annotations

import logging

from app.repositories.siga_account_repository import (
    SigaAccountRepository,
)

from app.sync.base_api_sync import BaseApiSync


logger = logging.getLogger(__name__)


class LoginSync(BaseApiSync):

    def __init__(self, db):
        super().__init__(db)

        self.repo = SigaAccountRepository(db)

    # =========================================================
    # AMBIL PROFILE + WILAYAH DARI RESPONSE LOGIN SIGA
    # =========================================================

    @staticmethod
    def extract_profile(result: dict) -> dict:

        profile = {
            "nama": None,
            "level": None,

            "id_provinsi": None,
            "id_kabupaten": None,
            "id_kecamatan": None,

            "id_kelurahan": None,
        }

        authorities = result.get(
            "authorities",
            []
        )

        if not authorities:
            return profile

        authority = authorities[0]

        attributes = authority.get(
            "attributes",
            {}
        )

        user = attributes.get(
            "user",
            {}
        )

        # =====================================================
        # IDENTITAS
        # =====================================================

        profile["nama"] = (
            user.get("namaLengkap")
        )

        profile["level"] = (
            user.get("namaLevelWilayah")
            or authority.get("authority")
        )

        # =====================================================
        # PROVINSI
        # =====================================================

        provinsi = user.get(
            "wilProvinsi",
            {}
        )

        if isinstance(
            provinsi,
            dict
        ):
            profile["id_provinsi"] = (
                provinsi.get("id_provinsi")
            )

        # =====================================================
        # KABUPATEN
        # =====================================================

        kabupaten = user.get(
            "wilKabupaten",
            {}
        )

        if isinstance(
            kabupaten,
            dict
        ):
            profile["id_kabupaten"] = (
                kabupaten.get("id_kabupaten")
            )

        # =====================================================
        # KECAMATAN
        # =====================================================

        kecamatan = user.get(
            "wilKecamatan",
            {}
        )

        if isinstance(
            kecamatan,
            dict
        ):
            profile["id_kecamatan"] = (
                kecamatan.get("id_kecamatan")
            )

        # =====================================================
        # KELURAHAN
        # =====================================================

        kelurahan = user.get(
            "wilKelurahan",
            {}
        )

        if isinstance(
            kelurahan,
            dict
        ):
            profile["id_kelurahan"] = (
                kelurahan.get("id_kelurahan")
            )

        return profile

    # =========================================================
    # LOGIN
    # =========================================================

    def login(
        self,
        username,
        password,
    ):

        logger.info(
            "[SIGA LOGIN] Username: %s",
            username
        )

        result = self.post_json(
            "/auth/login",
            {
                "username": username,
                "password": password,
            },
        )

        # =====================================================
        # TOKEN
        # =====================================================

        token = (
            result.get("token")
            or result.get("accessToken")
            or result.get("access_token")
        )

        if not token:

            raise Exception(
                "Token SIGA tidak ditemukan "
                "pada response login."
            )

        refresh = (
            result.get("refreshToken")
            or result.get("refresh_token")
        )

        # =====================================================
        # SIMPAN TOKEN
        # =====================================================

        self.repo.save_token(
            username=username,
            token=token,
            refresh_token=refresh,
        )

        # =====================================================
        # PROFILE + WILAYAH
        # =====================================================

        profile = self.extract_profile(
            result
        )

        logger.info(
            "[SIGA PROFILE] nama=%s",
            profile.get("nama")
        )

        logger.info(
            "[SIGA PROFILE] level=%s",
            profile.get("level")
        )

        logger.info(
            "[SIGA PROFILE] provinsi=%s",
            profile.get("id_provinsi")
        )

        logger.info(
            "[SIGA PROFILE] kabupaten=%s",
            profile.get("id_kabupaten")
        )

        logger.info(
            "[SIGA PROFILE] kecamatan=%s",
            profile.get("id_kecamatan")
        )

        # =====================================================
        # UPDATE PROFILE
        # =====================================================

        self.repo.update_profile(
            username=username,
            profile=profile,
        )

        return result