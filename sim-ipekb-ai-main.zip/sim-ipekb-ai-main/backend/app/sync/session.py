from __future__ import annotations

from .client import SigaClient


class SigaSession:
    """
    Menyimpan session HTTP yang sudah berhasil login ke SIGA.
    """

    def __init__(
        self,
        client: SigaClient,
        token: str,
        level: str | None = None,
        province_id: str | None = None,
        regency_id: str | None = None,
        district_id: str | None = None,
    ):
        self.client = client
        self.token = token

        self.level = level
        self.province_id = str(province_id) if province_id else None
        self.regency_id = str(regency_id) if regency_id else None
        self.district_id = str(district_id) if district_id else None

    def get(self, *args, **kwargs):
        return self.client.get(*args, **kwargs)

    def post(self, *args, **kwargs):
        return self.client.post(*args, **kwargs)

    def close(self):
        self.client.close()