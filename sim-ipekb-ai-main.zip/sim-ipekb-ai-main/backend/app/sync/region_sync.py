from __future__ import annotations

import logging
import time
import traceback

from .base_api_sync import BaseApiSync
from .location_sync import LocationSync
from .session import SigaSession

from app.repositories.province_repository import ProvinceRepository
from app.repositories.regency_repository import RegencyRepository
from app.repositories.district_repository import DistrictRepository
from app.repositories.village_repository import VillageRepository

logger = logging.getLogger(__name__)


class RegionSync(BaseApiSync):

    def __init__(
        self,
        db,
        session: SigaSession,
    ):
        super().__init__(
            db,
            session,
        )

        self.location = LocationSync(
            db,
            session,
        )

        self.province_repo = ProvinceRepository(db)
        self.regency_repo = RegencyRepository(db)
        self.district_repo = DistrictRepository(db)
        self.village_repo = VillageRepository(db)

    def run(self):

        print("\n==============================")
        print(">>> REGION SYNC MASUK <<<")
        print("==============================\n")

        try:

            started = time.time()

            logger.info("=" * 80)
            logger.info("SYNC MASTER WILAYAH DIMULAI")
            logger.info("=" * 80)

            province_id = str(self.session.province_id)
            regency_id = str(self.session.regency_id)
            district_id = str(self.session.district_id)

            logger.info(
                "LEVEL=%s PROV=%s KAB=%s KEC=%s",
                self.session.level,
                province_id,
                regency_id,
                district_id,
            )

            province_total = 0
            regency_total = 0
            district_total = 0
            village_total = 0

            #
            # PROVINSI
            #
            provinces = self.location.get_provinces()

            province_data = next(
                (
                    p
                    for p in provinces
                    if str(p["id_provinsi"]) == province_id
                ),
                None,
            )

            if province_data is None:
                raise RuntimeError(
                    f"Provinsi {province_id} tidak ditemukan."
                )

            province = self.province_repo.save(
                province_data
            )

            self.db.flush()

            province_total += 1

            logger.info(
                "PROVINSI : %s",
                province.name,
            )

            #
            # KABUPATEN
            #
            regencies = self.location.get_regencies(
                province_id
            )

            regency_data = next(
                (
                    r
                    for r in regencies
                    if str(r["id_kabupaten"]) == regency_id
                ),
                None,
            )

            if regency_data is None:
                raise RuntimeError(
                    f"Kabupaten {regency_id} tidak ditemukan."
                )

            regency = self.regency_repo.save(
                province,
                regency_data,
            )

            self.db.flush()

            regency_total += 1

            logger.info(
                "KABUPATEN : %s",
                regency.name,
            )

            #
            # KECAMATAN
            #
            districts = self.location.get_districts(
                regency_id
            )

            district_data = next(
                (
                    d
                    for d in districts
                    if str(d["id_kecamatan"]) == district_id
                ),
                None,
            )

            if district_data is None:
                raise RuntimeError(
                    f"Kecamatan {district_id} tidak ditemukan."
                )

            district = self.district_repo.save(
                regency,
                district_data,
            )

            self.db.flush()

            district_total += 1

            logger.info(
                "KECAMATAN : %s",
                district.name,
            )

            #
            # DESA
            #
            villages = self.location.get_villages(
                district_id
            )

            logger.info(
                "TOTAL DESA : %s",
                len(villages),
            )

            for village_data in villages:

                self.village_repo.save(
                    district,
                    village_data,
                )

                self.db.flush()

                village_total += 1

            self.db.commit()

            elapsed = round(time.time() - started, 2)

            logger.info("=" * 80)
            logger.info("SYNC MASTER WILAYAH SELESAI")
            logger.info("=" * 80)

            return {
                "success": True,
                "province": province_total,
                "regency": regency_total,
                "district": district_total,
                "village": village_total,
                "duration": elapsed,
            }

        except Exception:

            print("\n========== ERROR ==========")
            traceback.print_exc()
            print("===========================\n")

            self.db.rollback()
            raise