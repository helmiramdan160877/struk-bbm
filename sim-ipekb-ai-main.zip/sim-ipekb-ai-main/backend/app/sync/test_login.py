from sqlalchemy.orm import Session

from app.platform.siga_accounts.repository import SigaAccountRepository
from app.sync.auth import SigaAuthService


def test_login(db: Session):

    repo = SigaAccountRepository()

    accounts = repo.get_active_accounts(db)

    if not accounts:
        raise Exception("Tidak ada akun SIGA aktif.")

    account = accounts[0]

    auth = SigaAuthService()

    session = auth.login(account)

    return {
        "success": True,
        "username": account.username,
        "district_id": str(account.district_id),
        "token_preview": session.token[:40] + "...",
    }