from __future__ import annotations

from app.repositories.family_repository import FamilyRepository
from app.repositories.village_repository import VillageRepository

from .base_api_sync import BaseApiSync


class ParentSync(BaseApiSync):
    """
    Sinkronisasi data Kepala Keluarga (KK)
    dari endpoint parentRekapPK.

    Versi diagnosis:
    menampilkan parameter request dan response SIGA
    secara langsung di terminal.
    """

    ENDPOINT = "/rekapitulasi-data-keluarga/siga/rekap/parentRekapPK"

    def __init__(self, db, session):
        super().__init__(db, session)

        self.family_repo = FamilyRepository(db)
        self.village_repo = VillageRepository(db)

    def get_parent(
        self,
        bulan: int,
        tahun: int,
        page: int = 1,
        record_per_page: int = 500,
        village_siga_id: str | None = None,
    ) -> dict | list:

        params = {
            "bulan": bulan,
            "tahun": tahun,
            "page": page,
            "recordPerPage": record_per_page,
            "idProvinsi": self.session.province_id,
            "idKabupaten": self.session.regency_id,
            "idKecamatan": self.session.district_id,
        }

        if village_siga_id:
            params["idKelurahan"] = str(village_siga_id)

        print()
        print("=" * 80)
        print("                 DEBUG PARENT SYNC SIGA")
        print("=" * 80)

        print(f"Endpoint       : {self.ENDPOINT}")
        print(f"Bulan          : {bulan}")
        print(f"Tahun          : {tahun}")
        print(f"Page           : {page}")
        print(f"Record/Page    : {record_per_page}")
        print(f"ID Provinsi    : {self.session.province_id}")
        print(f"ID Kabupaten   : {self.session.regency_id}")
        print(f"ID Kecamatan   : {self.session.district_id}")
        print(f"ID Kelurahan   : {village_siga_id or 'SEMUA DESA BINAAAN'}")

        print("-" * 80)
        print("PARAMETER YANG DIKIRIM:")
        print(params)

        print("-" * 80)
        print("MENGIRIM REQUEST KE SIGA...")

        response = self.get_json(
            endpoint=self.ENDPOINT,
            params=params,
        )

        print("-" * 80)
        print("RESPONSE SIGA:")
        print(response)

        print("-" * 80)

        if isinstance(response, dict):

            print(f"success      : {response.get('success')}")
            print(f"message      : {response.get('message')}")
            print(f"totalRecord  : {response.get('totalRecord')}")
            print(f"total        : {response.get('total')}")

            data = response.get("data", [])

            print(f"jumlah data  : {len(data)}")

            if data:
                print("-" * 80)
                print("CONTOH DATA KK PERTAMA:")
                print(data[0])
            else:
                print("-" * 80)
                print("⚠️ DATA KK DARI SIGA KOSONG")

        print("=" * 80)
        print()

        return response

    def run(
        self,
        bulan: int,
        tahun: int,
        village_siga_ids: list[str] | None = None,
    ):
        total = 0
        villages = [str(v) for v in (village_siga_ids or []) if v]
        if not villages:
            villages = [None]

        print()
        print("=" * 80)
        print("           MULAI SINKRONISASI DATA KELUARGA")
        print(f"                    PERIODE {bulan}/{tahun}")
        print(f"                    DESA BINAAAN: {len([v for v in villages if v]) if village_siga_ids else 'SEMUA'}")
        print("=" * 80)

        for village_siga_id in villages:
            page = 1
            while True:
                response = self.get_parent(
                    bulan=bulan,
                    tahun=tahun,
                    page=page,
                    record_per_page=500,
                    village_siga_id=village_siga_id,
                )

                rows = self.extract_list(response)
                if not rows:
                    break

                print(f"✓ Desa SIGA {village_siga_id or 'semua'} Page {page}: {len(rows)} KK")

                for row in rows:
                    kelurahan_id = row.get("kelurahanId") or village_siga_id
                    if not kelurahan_id:
                        continue

                    village = self.village_repo.get_by_siga_id(kelurahan_id)
                    if village is None:
                        print(f"⚠️ Kelurahan SIGA {kelurahan_id} tidak ditemukan di database.")
                        continue

                    try:
                        self.family_repo.save(village, row)
                        total += 1
                    except Exception as e:
                        print("❌ GAGAL MENYIMPAN DATA KK")
                        print(f"Error : {e}")
                        print(f"Data  : {row}")
                        raise

                self.db.commit()

                total_record = None
                if isinstance(response, dict):
                    raw_total = response.get("totalRecord") or response.get("total")
                    try:
                        total_record = int(raw_total) if raw_total is not None else None
                    except (TypeError, ValueError):
                        total_record = None

                if total_record is not None and page * 500 >= total_record:
                    break
                if len(rows) < 500:
                    break
                page += 1

        print()
        print("=" * 80)
        print("              HASIL PARENT SYNC")
        print("=" * 80)
        print(f"Total KK tersimpan : {total}")
        print("=" * 80)
        print()

        return {"success": True, "total": total, "village_count": len(village_siga_ids or [])}

