from __future__ import annotations

from .base_sync import BaseSync
from .region_sync import RegionSync
from .parent_sync import ParentSync
from .member_sync import MemberSync


class SyncManager(BaseSync):

    def run(
        self,
        username_siga: str,
        password_siga: str,
        bulan: int,
        tahun: int,
    ):

        session = self.login(
            username=username_siga,
            password=password_siga,
        )

        try:

            RegionSync(
                self.db,
                session,
            ).run()

            ParentSync(
                self.db,
                session,
            ).run(
                bulan=bulan,
                tahun=tahun,
            )

            MemberSync(
                self.db,
                session,
            ).run(
                bulan=bulan,
                tahun=tahun,
                district_id=session.district_id,
            )

            return {
                "success": True,
                "message": "Sinkronisasi selesai."
            }

        finally:
            session.close()