class SigaAuthenticationError(Exception):
    """Login SIGA gagal."""


class SigaRequestError(Exception):
    """Request ke SIGA gagal."""