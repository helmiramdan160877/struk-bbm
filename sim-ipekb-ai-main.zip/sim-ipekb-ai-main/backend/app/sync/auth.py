from __future__ import annotations

from .client import SigaClient
from .session import SigaSession
from .exceptions import (
    SigaAuthenticationError,
    SigaRequestError,
)


class SigaAuthService:
    """
    Service autentikasi SIGA.
    """

    LOGIN_ENDPOINT = "/sigaauthorizationservice/auth/signin"

    def __init__(self) -> None:
        self.client = SigaClient()

    def login(
        self,
        username: str,
        password: str,
        timeout: float | None = None,
    ) -> SigaSession:

        payload = {
            "username": username.strip(),
            "password": password.strip(),
            "idAplikasi": 2,
        }

        headers = {
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "Authorization": "Bearer null",
            "Origin": "https://newsiga-siga.bkkbn.go.id",
            "Referer": "https://newsiga-siga.bkkbn.go.id/",
            "User-Agent": (
                "Mozilla/5.0 "
                "(Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 "
                "(KHTML, like Gecko) "
                "Chrome/138.0 Safari/537.36"
            ),
        }

        response = self.client.post(
            self.LOGIN_ENDPOINT,
            json=payload,
            headers=headers,
            **({"timeout": timeout} if timeout is not None else {}),
        )

        print("\n" + "=" * 80)
        print("SIGA LOGIN")
        print("=" * 80)
        print("URL      :", f"{self.client.client.base_url}{self.LOGIN_ENDPOINT}")
        print("USERNAME :", username)
        print("STATUS   :", response.status_code)
        print("BODY     :")
        print(response.text)
        print("=" * 80 + "\n")

        if response.status_code != 200:
            raise SigaAuthenticationError(
                f"Login gagal ({response.status_code}) : {response.text}"
            )

        try:
            data = response.json()
        except Exception as exc:
            raise SigaRequestError(
                "Response login bukan JSON."
            ) from exc

        token = (
            data.get("token")
            or data.get("accessToken")
            or data.get("jwt")
            or data.get("access_token")
            or data.get("data", {}).get("token")
            or data.get("data", {}).get("accessToken")
            or data.get("data", {}).get("jwt")
        )

        if not token:
            raise SigaAuthenticationError(
                f"Token tidak ditemukan. Response: {data}"
            )

        authority = (data.get("authorities") or [{}])[0]
        attrs = authority.get("attributes", {})
        user = attrs.get("user", {})

        level = user.get("namaLevelWilayah")

        province = user.get("wilProvinsi", {})
        regency = user.get("wilKabupaten", {})
        district = user.get("wilKecamatan", {})

        self.client.set_headers(
            {
                "Authorization": f"Bearer {token}",
                "Accept": "application/json, text/plain, */*",
            }
        )

        return SigaSession(
            client=self.client,
            token=token,
            level=level,
            province_id=province.get("id_provinsi"),
            regency_id=regency.get("id_kabupaten"),
            district_id=district.get("id_kecamatan"),
        )