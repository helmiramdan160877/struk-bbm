from __future__ import annotations

import logging

from .base_api_sync import BaseApiSync
from .session import SigaSession

logger = logging.getLogger(__name__)


class LocationSync(BaseApiSync):
    """
    Mengambil master wilayah SIGA.
    """

    PROVINCES = "/location-service/siga/location/getListProvinsi"
    REGENCIES = "/location-service/siga/location/getListKabupatenByIdProvinsi"
    DISTRICTS = "/location-service/siga/location/getListKecamatanByIdKabupaten"
    VILLAGES = "/location-service/siga/location/getListKelurahanByIdKecamatan"
    RWS = "/location-service/siga/location/getListRwByIdKelurahan"
    RTS = "/location-service/siga/location/getListRtByIdRw"

    def __init__(
        self,
        db,
        session: SigaSession,
    ):
        super().__init__(
            db,
            session,
        )

    def get_provinces(self) -> list:
        logger.info("Mengambil master provinsi...")
        return self.extract_list(
            self.get_json(self.PROVINCES)
        )

    def get_regencies(self, province_id: str) -> list:
        logger.info("Mengambil kabupaten provinsi %s", province_id)

        return self.extract_list(
            self.get_json(
                self.REGENCIES,
                {
                    "id_provinsi": province_id,
                },
            )
        )

    def get_districts(self, regency_id: str) -> list:
        logger.info("Mengambil kecamatan kabupaten %s", regency_id)

        return self.extract_list(
            self.get_json(
                self.DISTRICTS,
                {
                    "id_kabupaten": regency_id,
                },
            )
        )

    def get_villages(self, district_id: str) -> list:
        logger.info("Mengambil kelurahan kecamatan %s", district_id)

        return self.extract_list(
            self.get_json(
                self.VILLAGES,
                {
                    "id_kecamatan": district_id,
                },
            )
        )

    def get_rws(self, village_id: str) -> list:
        logger.info("Mengambil RW kelurahan %s", village_id)

        return self.extract_list(
            self.get_json(
                self.RWS,
                {
                    "id_kelurahan": village_id,
                },
            )
        )

    def get_rts(self, rw_id: str) -> list:
        logger.info("Mengambil RT RW %s", rw_id)

        return self.extract_list(
            self.get_json(
                self.RTS,
                {
                    "id_rw": rw_id,
                },
            )
        )