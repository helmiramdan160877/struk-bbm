from __future__ import annotations

from sqlalchemy.orm import Session

from app.repositories.siga_account_repository import (
    SigaAccountRepository,
)

from .auth import SigaAuthService
from .session import SigaSession


class BaseSync:
    """
    Base class seluruh proses sinkronisasi SIGA.
    """

    def __init__(self, db: Session):
        self.db = db
        self.auth_service = SigaAuthService()
        self.siga_account_repo = SigaAccountRepository(db)

    def login(
        self,
        username: str,
        password: str,
        timeout: float | None = None,
    ) -> SigaSession:

        # =====================================================
        # LOGIN KE SIGA
        # =====================================================

        session = self.auth_service.login(
            username=username,
            password=password,
            timeout=timeout,
        )

        # =====================================================
        # SIMPAN TOKEN + WILAYAH KE DATABASE
        # =====================================================

        account = (
            self.siga_account_repo.get_by_username(
                username
            )
        )

        if account is not None:

            # -------------------------------------------------
            # Token
            # -------------------------------------------------

            account.token = session.token

            # -------------------------------------------------
            # Wilayah dari response login SIGA
            # -------------------------------------------------

            if session.province_id is not None:
                account.siga_province_id = str(
                    session.province_id
                )

            if session.regency_id is not None:
                account.siga_regency_id = str(
                    session.regency_id
                )

            if session.district_id is not None:
                account.siga_district_id = str(
                    session.district_id
                )

            # -------------------------------------------------
            # Commit
            # -------------------------------------------------

            self.db.commit()
            self.db.refresh(account)

            print(
                "\n"
                + "=" * 80
            )

            print(
                "SIGA PROFILE TERSIMPAN"
            )

            print(
                "USERNAME    :",
                username,
            )

            print(
                "PROVINSI    :",
                account.siga_province_id,
            )

            print(
                "KABUPATEN   :",
                account.siga_regency_id,
            )

            print(
                "KECAMATAN   :",
                account.siga_district_id,
            )

            print(
                "=" * 80
                + "\n"
            )

        else:

            print(
                "\n"
                + "=" * 80
            )

            print(
                "PERINGATAN:"
            )

            print(
                f"Akun SIGA '{username}' "
                "tidak ditemukan di database."
            )

            print(
                "=" * 80
                + "\n"
            )

        # =====================================================
        # RETURN SESSION
        # =====================================================

        return session