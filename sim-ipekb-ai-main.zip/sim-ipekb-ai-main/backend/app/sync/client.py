from __future__ import annotations

import httpx

from app.core.config import settings


class SigaClient:
    """
    HTTP Client untuk komunikasi dengan SIGA.

    Timeout dibuat terpisah:
    - connect : 30 detik
    - read    : 180 detik
    - write   : 60 detik
    - pool    : 30 detik

    Read timeout dibuat lebih panjang karena endpoint SIGA
    tertentu bisa membutuhkan waktu cukup lama.
    """

    def __init__(self):

        timeout = httpx.Timeout(
            connect=30.0,
            read=180.0,
            write=60.0,
            pool=30.0,
        )

        limits = httpx.Limits(
            max_connections=10,
            max_keepalive_connections=5,
        )

        self.client = httpx.Client(
            base_url=settings.SIGA_BASE_URL,
            timeout=timeout,
            limits=limits,
            follow_redirects=True,
        )

    def get(
        self,
        url: str,
        **kwargs,
    ):

        return self.client.get(
            url,
            **kwargs,
        )

    def post(
        self,
        url: str,
        **kwargs,
    ):

        return self.client.post(
            url,
            **kwargs,
        )

    def set_headers(
        self,
        headers: dict,
    ):

        self.client.headers.update(
            headers
        )

    def set_cookies(
        self,
        cookies,
    ):

        self.client.cookies.update(
            cookies
        )

    def clear_headers(self):

        self.client.headers.clear()

    def clear_cookies(self):

        self.client.cookies.clear()

    def close(self):

        self.client.close()