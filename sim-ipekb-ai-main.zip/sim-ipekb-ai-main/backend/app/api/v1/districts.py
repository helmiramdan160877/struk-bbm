from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import require_roles
from app.platform.districts.repository import DistrictRepository
from app.platform.districts.service import DistrictService
from app.schemas.district import (
    DistrictCreate,
    DistrictUpdate,
    DistrictResponse,
)

router = APIRouter()


@router.get("/", response_model=list[DistrictResponse])
def get_districts(
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PENGURUS", "PKB", "KADER", "OPERATOR", "BENDAHARA", "PIMPINAN", "VIEWER", "ANGGOTA")),
):
    repository = DistrictRepository(db)
    service = DistrictService(repository)

    return service.get_all_districts()


@router.get("/{district_id}", response_model=DistrictResponse)
def get_district(
    district_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PENGURUS", "PKB", "KADER", "OPERATOR", "BENDAHARA", "PIMPINAN", "VIEWER", "ANGGOTA")),
):
    repository = DistrictRepository(db)
    service = DistrictService(repository)

    district = service.get_district_by_id(district_id)

    if district is None:
        raise HTTPException(
            status_code=404,
            detail="Kecamatan tidak ditemukan",
        )

    return district


@router.post("/", response_model=DistrictResponse)
def create_district(
    data: DistrictCreate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = DistrictRepository(db)
    service = DistrictService(repository)

    try:
        return service.create_district(
            regency_id=data.regency_id,
            code=data.code,
            name=data.name,
        )
    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


@router.put("/{district_id}", response_model=DistrictResponse)
def update_district(
    district_id: UUID,
    data: DistrictUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = DistrictRepository(db)
    service = DistrictService(repository)

    district = service.get_district_by_id(district_id)

    if district is None:
        raise HTTPException(
            status_code=404,
            detail="Kecamatan tidak ditemukan",
        )

    return service.update_district(
        district=district,
        regency_id=data.regency_id,
        code=data.code,
        name=data.name,
        is_active=data.is_active,
    )


@router.delete("/{district_id}")
def delete_district(
    district_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = DistrictRepository(db)
    service = DistrictService(repository)

    district = service.get_district_by_id(district_id)

    if district is None:
        raise HTTPException(
            status_code=404,
            detail="Kecamatan tidak ditemukan",
        )

    service.delete_district(district)

    return {
        "message": "Kecamatan berhasil dihapus"
    }