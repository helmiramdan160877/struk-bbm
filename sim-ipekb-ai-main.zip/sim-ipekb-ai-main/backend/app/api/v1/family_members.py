from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import require_roles
from app.platform.auth.village_scope import get_user_village_ids
from app.platform.family_members.repository import FamilyMemberRepository
from app.platform.family_members.service import FamilyMemberService
from app.schemas.family_member import (
    FamilyMemberCreate,
    FamilyMemberUpdate,
    FamilyMemberResponse,
)

router = APIRouter()


@router.get("/", response_model=list[FamilyMemberResponse])
def get_family_members(
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PKB", "KADER")),
    village_ids: list[UUID] | None = Depends(get_user_village_ids),
):
    repository = FamilyMemberRepository(db)
    service = FamilyMemberService(repository)
    return service.get_all(village_ids=village_ids)


@router.get("/{member_id}", response_model=FamilyMemberResponse)
def get_family_member(
    member_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PKB", "KADER")),
    village_ids: list[UUID] | None = Depends(get_user_village_ids),
):
    repository = FamilyMemberRepository(db)
    service = FamilyMemberService(repository)
    member = service.get_by_id(member_id, village_ids=village_ids)
    if member is None:
        raise HTTPException(status_code=404, detail="Data anggota keluarga tidak ditemukan atau di luar wilayah binaan")
    return member


@router.post("/", response_model=FamilyMemberResponse)
def create_family_member(
    data: FamilyMemberCreate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PKB")),
    village_ids: list[UUID] | None = Depends(get_user_village_ids),
):
    repository = FamilyMemberRepository(db)
    service = FamilyMemberService(repository)
    try:
        return service.create(data, village_ids=village_ids)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.put("/{member_id}", response_model=FamilyMemberResponse)
def update_family_member(
    member_id: UUID,
    data: FamilyMemberUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PKB")),
    village_ids: list[UUID] | None = Depends(get_user_village_ids),
):
    repository = FamilyMemberRepository(db)
    service = FamilyMemberService(repository)
    member = service.get_by_id(member_id, village_ids=village_ids)
    if member is None:
        raise HTTPException(status_code=404, detail="Data anggota keluarga tidak ditemukan atau di luar wilayah binaan")
    try:
        return service.update(member, data, village_ids=village_ids)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.delete("/{member_id}")
def delete_family_member(
    member_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PKB")),
    village_ids: list[UUID] | None = Depends(get_user_village_ids),
):
    repository = FamilyMemberRepository(db)
    service = FamilyMemberService(repository)
    member = service.get_by_id(member_id, village_ids=village_ids)
    if member is None:
        raise HTTPException(status_code=404, detail="Data anggota keluarga tidak ditemukan atau di luar wilayah binaan")
    service.delete(member)
    return {"message": "Data anggota keluarga berhasil dihapus"}
