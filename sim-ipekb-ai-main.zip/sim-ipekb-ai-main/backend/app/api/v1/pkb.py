from uuid import UUID

from fastapi import APIRouter, Body, Depends, HTTPException
from sqlalchemy.orm import Session
from app.models.regency import Regency
from app.api.deps import get_db
from app.models.user import User
from app.models.pkb import PKB
from app.models.user_village import UserVillage
from app.models.village import Village
from app.models.siga_account import SigaAccount
from app.models.district import District
from app.core.encryption import encryption_service
from app.sync.base_sync import BaseSync
from app.sync.location_sync import LocationSync
from app.platform.auth.dependencies import require_roles, get_current_user
from app.platform.auth.village_scope import get_user_village_ids
from app.platform.pkb.repository import PKBRepository
from app.platform.pkb.service import PKBService
from app.schemas.pkb import (
    PKBCreate,
    PKBUpdate,
    PKBResponse,
)


router = APIRouter(tags=["PKB"])


# =========================================================
# SERVICE
# =========================================================

def get_service(db: Session):
    repository = PKBRepository(db)
    return PKBService(repository)


# =========================================================
# GET SEMUA PKB (SCOPED BY USER)
# =========================================================

@router.get(
    "",
    response_model=list[PKBResponse],
)
def get_all(
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles(
            "SUPER_ADMIN",
            "ADMIN",
            "PENGURUS",
            "PKB",
            "OPERATOR",
            "PIMPINAN",
            "BENDAHARA",
        )
    ),
    village_ids: list[UUID] | None = Depends(get_user_village_ids),
):
    service = get_service(db)

    # Jika user adalah SUPER_ADMIN atau ADMIN tanpa village scope, tampilkan semua
    if village_ids is None or len(village_ids) == 0:
        return service.get_all()
    
    # Untuk user dengan village scope (PKB, KADER), tampilkan hanya PKB di wilayah mereka
    return service.get_all_by_villages(village_ids)


def _sync_siga_account_region(db: Session, account: SigaAccount):
    """
    Jadikan wilayah hasil login SIGA sebagai sumber kebenaran.
    district_id lokal tidak boleh menentukan kecamatan SIGA.
    """
    session = None
    try:
        password = encryption_service.decrypt(account.password_encrypted)
        session = BaseSync(db).login(account.username, password, timeout=30)

        if session.province_id:
            account.siga_province_id = str(session.province_id)
        if session.regency_id:
            account.siga_regency_id = str(session.regency_id)
        if session.district_id:
            account.siga_district_id = str(session.district_id)

            district = (
                db.query(District)
                .filter(
                    District.siga_id == str(session.district_id),
                    District.is_active.is_(True),
                )
                .first()
            )
            if district:
                account.district_id = district.id

        db.add(account)
        db.commit()
        db.refresh(account)
        return session
    except Exception:
        db.rollback()
        raise
@router.get("/siga-accounts", response_model=list[dict])
def get_siga_accounts_for_master_pkb(
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN", "ADMIN")),
):
    accounts = (
        db.query(SigaAccount)
        .filter(SigaAccount.is_active.is_(True))
        .order_by(SigaAccount.username.asc())
        .all()
    )

    result = []
    for account in accounts:
        # Selalu validasi wilayah dari SIGA agar akun lama yang salah
        # kecamatan otomatis dibetulkan.
        try:
            _sync_siga_account_region(db, account)
        except Exception:
            # Jika SIGA sedang tidak tersedia, tampilkan data terakhir.
            pass

        result.append(
            {
                "id": str(account.id),
                "username": account.username,
                "district_id": str(account.district_id) if account.district_id else None,
                "district_name": account.district.name if account.district else None,
                "siga_district_id": account.siga_district_id,
                "is_active": account.is_active,
            }
        )

    return result


@router.get("/siga-villages/{siga_account_id}", response_model=list[dict])
def get_siga_villages_for_master_pkb(
    siga_account_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN", "ADMIN")),
):
    """
    Ambil DESA LANGSUNG dari SIGA berdasarkan akun SIGA.
    Desa lokal hanya dipakai sebagai cache/relasi UUID aplikasi.
    """
    account = (
        db.query(SigaAccount)
        .filter(
            SigaAccount.id == siga_account_id,
            SigaAccount.is_active.is_(True),
        )
        .first()
    )
    if account is None:
        raise HTTPException(status_code=404, detail="Akun SIGA tidak ditemukan atau tidak aktif.")

    try:
        session = _sync_siga_account_region(db, account)
        location_sync = LocationSync(db, session)

        district_siga_id = (
            session.district_id
            or account.siga_district_id
        )

        if not district_siga_id:
            raise HTTPException(
                status_code=422,
                detail="Kecamatan SIGA tidak ditemukan."
            )

        raw_villages = location_sync.get_villages(
            str(district_siga_id)
        )
        if not district_siga_id:
            raise HTTPException(
                status_code=422,
                detail="SIGA tidak mengembalikan ID kecamatan untuk akun tersebut.",
            )

        raw_villages = LocationSync(db, session).get_villages(str(district_siga_id))
       
                # Ambil district lokal berdasarkan SIGA ID
        district = (
            db.query(District)
            .filter(
                District.siga_id == str(district_siga_id),
            )
            .first()
        )

        # Jika belum ada, ambil data district dari SIGA lalu simpan
        if district is None:
            districts = location_sync.get_districts(
                str(session.regency_id)
            )

            siga_district = next(
                (
                    item for item in districts
                    if str(
                        item.get("id_kecamatan")
                        or item.get("idKecamatan")
                        or item.get("id")
                    ) == str(district_siga_id)
                ),
                None,
            )

            if siga_district is None:
                raise HTTPException(
                    status_code=422,
                    detail=f"Kecamatan SIGA {district_siga_id} tidak ditemukan."
                )

            regency = (
                db.query(Regency)
                .filter(
                    Regency.siga_id == str(session.regency_id)
                )
                .first()
            )

            if regency is None:
                raise HTTPException(
                    status_code=422,
                    detail="Kabupaten SIGA belum tersedia."
                )

            district = District(
                regency_id=regency.id,
                code=str(district_siga_id),
                name=(
                    siga_district.get("nama_kecamatan")
                    or siga_district.get("nama")
                    or str(district_siga_id)
                ),
                siga_id=str(district_siga_id),
                is_active=True,
            )

            db.add(district)
            db.flush()
        result = []
        for item in raw_villages:
            if not isinstance(item, dict):
                continue

            siga_id = (
                item.get("id_kelurahan")
                or item.get("idKelurahan")
                or item.get("siga_id")
                or item.get("id")
            )
            name = (
                item.get("nama_kelurahan")
                or item.get("namaKelurahan")
                or item.get("nama")
                or item.get("name")
            )
            code = (
                item.get("kode_kelurahan")
                or item.get("kodeKelurahan")
                or item.get("code")
                or siga_id
            )

            if siga_id is None or not name:
                continue

            siga_id = str(siga_id)

            village = (
                db.query(Village)
                .filter(
                    Village.siga_id == siga_id,
                    Village.district_id == district.id
                )
                .first()
            )

            if village is None:
                village = Village(
                    district_id=district.id,
                    siga_id=siga_id,
                    code=str(code or siga_id),
                    name=str(name).strip(),
                    is_active=True,
                )
                db.add(village)
                db.flush()
            else:
                # SIGA adalah sumber nama/kecamatan.
                village.district_id = district.id
                village.code = str(code or village.code or siga_id)
                village.name = str(name).strip()
                village.is_active = True

            result.append(
                {
                    "id": str(village.id),
                    "siga_id": village.siga_id,
                    "code": village.code,
                    "name": village.name,
                    "district_id": str(district.id),
                    "district_name": district.name,
                }
            )

        db.commit()
        return sorted(result, key=lambda row: row["name"].lower())

    except HTTPException:
        raise
    except Exception as exc:
        db.rollback()
        raise HTTPException(
            status_code=502,
            detail=f"Gagal mengambil desa dari SIGA: {exc}",
        )


# =========================================================
# SUMMARY
# =========================================================

@router.get(
    "/summary",
)
def summary(
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles(
            "SUPER_ADMIN",
            "ADMIN",
            "PENGURUS",
            "PKB",
            "OPERATOR",
            "PIMPINAN",
        )
    ),
):
    service = get_service(db)

    return service.summary()


# =========================================================
# SEARCH
# =========================================================

@router.get(
    "/search/{keyword}",
    response_model=list[PKBResponse],
)
def search(
    keyword: str,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles(
            "SUPER_ADMIN",
            "ADMIN",
            "PENGURUS",
            "PKB",
            "OPERATOR",
            "PIMPINAN",
        )
    ),
):
    service = get_service(db)

    return service.search(keyword)


# =========================================================
# GET PKB BY ID
# =========================================================

@router.get(
    "/{pkb_id}",
    response_model=PKBResponse,
)
def get_by_id(
    pkb_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles(
            "SUPER_ADMIN",
            "ADMIN",
            "PENGURUS",
            "PKB",
            "OPERATOR",
            "PIMPINAN",
        )
    ),
):
    service = get_service(db)
    pkb = service.get_by_id(pkb_id)

    if not pkb:
        raise HTTPException(
            status_code=404,
            detail="Data PKB tidak ditemukan",
        )

    return pkb


# =========================================================
# CREATE
# HANYA SUPER ADMIN
# =========================================================

def _validate_siga_village(
    db: Session,
    siga_account_id: UUID | None,
    village_id: UUID | None
):
    if siga_account_id is None:
        raise HTTPException(
            status_code=400,
            detail="Master PKB wajib memilih Akun SIGA."
        )

    account = (
        db.query(SigaAccount)
        .filter(
            SigaAccount.id == siga_account_id,
            SigaAccount.is_active.is_(True)
        )
        .first()
    )

    if account is None:
        raise HTTPException(
            status_code=400,
            detail="Akun SIGA tidak ditemukan atau tidak aktif."
        )

    if village_id is not None:

        village = (
            db.query(Village)
            .filter(
                Village.id == village_id,
                Village.is_active.is_(True)
            )
            .first()
        )

        if village is None:
            raise HTTPException(
                status_code=400,
                detail="Desa SIGA tidak ditemukan atau tidak aktif."
            )


        # validasi berdasarkan kecamatan SIGA
        # validasi desa harus sesuai kecamatan akun SIGA
        if account.siga_district_id:

            if village.district and str(village.district.siga_id) != str(account.siga_district_id):

                print("DEBUG VALIDASI SIGA")
                print("AKUN:", account.username)
                print("SIGA DISTRICT:", account.siga_district_id)
                print("VILLAGE:", village.name)
                print("VILLAGE DISTRICT SIGA:", village.district.siga_id)

                raise HTTPException(
                    status_code=400,
                    detail="Desa wilayah binaan tidak sesuai Kecamatan Akun SIGA."
                )

    return account


@router.post(
    "",
    response_model=PKBResponse,
)
def create(
    payload: PKBCreate,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN")
    ),
):
    service = get_service(db)
    _validate_siga_village(db, payload.siga_account_id, payload.village_id)

    try:
        return service.create(
            nip=payload.nip,
            nik=payload.nik,
            nama=payload.nama,
            tempat_lahir=payload.tempat_lahir,
            tanggal_lahir=payload.tanggal_lahir,
            jenis_kelamin=payload.jenis_kelamin,
            agama=payload.agama,
            pendidikan=payload.pendidikan,
            jabatan=payload.jabatan,
            status_asn=payload.status_asn,
            golongan=payload.golongan,
            email=payload.email,
            phone=payload.phone,
            alamat=payload.alamat,
            photo=payload.photo,
            kecamatan=payload.kecamatan,
            desa=payload.desa,
            wilayah_binaan=payload.wilayah_binaan,
            village_id=payload.village_id,
            siga_account_id=payload.siga_account_id,
            status=payload.status or "AKTIF",
        )

    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )


# =========================================================
# UPDATE
# HANYA SUPER ADMIN
# =========================================================

@router.put(
    "/{pkb_id}",
    response_model=PKBResponse,
)
def update(
    pkb_id: UUID,
    payload: PKBUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN")
    ),
):
    service = get_service(db)

    pkb = service.get_by_id(pkb_id)

    if not pkb:
        raise HTTPException(
            status_code=404,
            detail="Data PKB tidak ditemukan",
        )

    effective_siga_account_id = payload.siga_account_id if payload.siga_account_id is not None else pkb.siga_account_id
    effective_village_id = payload.village_id
    _validate_siga_village(db, effective_siga_account_id, effective_village_id)

    try:
        return service.update(
            pkb,
            nip=payload.nip,
            nik=payload.nik,
            nama=payload.nama,
            tempat_lahir=payload.tempat_lahir,
            tanggal_lahir=payload.tanggal_lahir,
            jenis_kelamin=payload.jenis_kelamin,
            agama=payload.agama,
            pendidikan=payload.pendidikan,
            jabatan=payload.jabatan,
            status_asn=payload.status_asn,
            golongan=payload.golongan,
            email=payload.email,
            phone=payload.phone,
            alamat=payload.alamat,
            photo=payload.photo,
            kecamatan=payload.kecamatan,
            desa=payload.desa,
            wilayah_binaan=payload.wilayah_binaan,
            village_id=payload.village_id,
            siga_account_id=payload.siga_account_id,
            status=payload.status,
        )

    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )


# =========================================================
# GANTI DESA BINAAN PKB
# TIDAK MENGUBAH MENU/FUNGSI LAIN
# =========================================================

@router.put(
    "/{pkb_id}/wilayah-binaan",
)
def update_wilayah_binaan(
    pkb_id: UUID,
    payload: dict = Body(...),
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    pkb = db.query(PKB).filter(PKB.id == pkb_id).first()
    if pkb is None:
        raise HTTPException(status_code=404, detail="Data PKB tidak ditemukan")

    raw_ids = payload.get("village_ids") or []
    try:
        village_ids = list(dict.fromkeys(UUID(str(value)) for value in raw_ids))
    except (ValueError, TypeError):
        raise HTTPException(status_code=400, detail="ID desa binaan tidak valid")

    if not village_ids:
        raise HTTPException(status_code=400, detail="Pilih minimal satu desa binaan")

    villages = (
        db.query(Village)
        .filter(Village.id.in_(village_ids), Village.is_active.is_(True))
        .all()
    )
    if len(villages) != len(village_ids):
        raise HTTPException(status_code=400, detail="Satu atau lebih desa binaan tidak ditemukan")

    user = db.query(User).filter(User.pkb_id == pkb_id).first()
    if user is None:
        raise HTTPException(status_code=409, detail="PKB belum memiliki akun user yang terhubung")

    # Pastikan semua desa berada pada kecamatan PKB yang sama.
    district_ids = {v.district_id for v in villages}
    if len(district_ids) != 1:
        raise HTTPException(status_code=400, detail="Desa binaan harus berada dalam satu kecamatan")

    db.query(UserVillage).filter(UserVillage.user_id == user.id).delete(synchronize_session=False)
    for village in villages:
        db.add(UserVillage(user_id=user.id, village_id=village.id))

    # Pertahankan village_id lama sebagai desa utama/kompatibilitas.
    pkb.village_id = villages[0].id
    pkb.desa = ", ".join(v.name for v in villages)
    pkb.kecamatan = villages[0].district.name if getattr(villages[0], "district", None) else pkb.kecamatan
    pkb.wilayah_binaan = ", ".join(v.name for v in villages)

    db.add(pkb)
    db.commit()
    db.refresh(pkb)

    return {
        "success": True,
        "message": "Desa binaan PKB berhasil diperbarui",
        "pkb_id": str(pkb_id),
        "user_id": str(user.id),
        "village_ids": [str(v.id) for v in villages],
        "villages": [
            {"id": str(v.id), "name": v.name, "code": v.code, "district_id": str(v.district_id)}
            for v in villages
        ],
    }


# =========================================================
# DELETE
# HANYA SUPER ADMIN
# =========================================================

@router.delete(
    "/{pkb_id}",
)
def delete(
    pkb_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN")
    ),
):
    service = get_service(db)

    pkb = service.get_by_id(pkb_id)

    if not pkb:
        raise HTTPException(
            status_code=404,
            detail="Data PKB tidak ditemukan",
        )

    linked = db.query(User).filter(User.pkb_id == pkb_id).first()
    if linked:
        raise HTTPException(
            status_code=409,
            detail="Master PKB sudah dipakai oleh akun user. Nonaktifkan master bila tidak digunakan.",
        )

    service.delete_by_id(pkb_id)

    return {
        "message": "Master PKB berhasil dihapus",
    }