from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.models.ai_message import AiMessage
from app.platform.auth.dependencies import get_current_user
from app.services.gemini_ai_service import gemini_ai_service
from app.services.siga_ai_data_service import build_context

router = APIRouter()


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    context: str | None = Field(default=None, max_length=30000)
    conversation_id: UUID | None = None
    image_data: str | None = Field(default=None, max_length=11000000)
    image_mime_type: str | None = Field(default=None, max_length=50)
    file_name: str | None = Field(default=None, max_length=255)


@router.get("/history")
def get_history(
    conversation_id: UUID | None = None,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    query = db.query(AiMessage).filter(AiMessage.user_id == current_user.id)
    if conversation_id is not None:
        query = query.filter(AiMessage.conversation_id == conversation_id)
    messages = query.order_by(AiMessage.created_at.asc()).limit(100).all()
    return {
        "success": True,
        "conversation_id": conversation_id,
        "messages": [
            {"id": item.id, "conversation_id": item.conversation_id, "role": item.role, "content": item.content}
            for item in messages
        ],
    }


@router.delete("/history")
def delete_history(
    conversation_id: UUID | None = None,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    query = db.query(AiMessage).filter(AiMessage.user_id == current_user.id)
    if conversation_id is not None:
        query = query.filter(AiMessage.conversation_id == conversation_id)
    query.delete(synchronize_session=False)
    db.commit()
    return {"success": True}


@router.post("/chat")
def chat(
    data: ChatRequest,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Chat Gemini dengan konteks live SIGA yang sudah dibatasi scope user."""
    conversation_id = data.conversation_id or uuid4()
    previous_messages = (
        db.query(AiMessage)
        .filter(
            AiMessage.user_id == current_user.id,
            AiMessage.conversation_id == conversation_id,
        )
        .order_by(AiMessage.created_at.asc())
        .limit(20)
        .all()
    )
    try:
        siga_context = build_context(db, current_user, data.message)
    except Exception as exc:
        # SIGA gagal/timed-out tidak boleh membuat endpoint AI menggantung.
        siga_context = f"STATUS SIGA: gagal mengambil data live ({type(exc).__name__}). Gunakan data lokal/cache bila tersedia."

    combined = []
    if siga_context:
        combined.append(siga_context)
    if data.context:
        # Context frontend hanya metadata non-rahasia; data SIGA tetap dibuat server-side.
        combined.append("Metadata akun SIM IPEKB:\n" + data.context)
    if previous_messages:
        combined.append(
            "RIWAYAT PERCAKAPAN SEBELUMNYA:\n"
            + "\n".join(f"{item.role.upper()}: {item.content}" for item in previous_messages[-12:])
        )

    result = gemini_ai_service.chat(
        data.message,
        "\n\n".join(combined) if combined else None,
        image_data=data.image_data,
        image_mime_type=data.image_mime_type,
        file_name=data.file_name,
    )
    db.add_all([
        AiMessage(user_id=current_user.id, conversation_id=conversation_id, role="user", content=data.message),
        AiMessage(
            user_id=current_user.id,
            conversation_id=conversation_id,
            role="assistant",
            content=result.get("answer") or result.get("message") or "AI tidak memberikan jawaban.",
        ),
    ])
    db.commit()
    result["conversation_id"] = conversation_id
    return result
