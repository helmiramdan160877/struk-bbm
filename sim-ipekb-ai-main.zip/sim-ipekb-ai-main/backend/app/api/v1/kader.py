from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.models.kader import Kader
from app.models.user import User
from app.models.user_village import UserVillage
from app.models.village import Village
from app.platform.auth.dependencies import require_roles
from app.schemas.kader import KaderCreate, KaderResponse, KaderUpdate

router = APIRouter(tags=["Master Kader"])

READ_ROLES = ("SUPER_ADMIN", "ADMIN", "PENGURUS", "PKB", "KADER", "OPERATOR", "PIMPINAN")
MANAGE_ROLES = ("SUPER_ADMIN", "ADMIN")


def _role_name(user: User) -> str:
    return ((user.role.name if user.role else "") or "").strip().upper()


def _scope_query(db: Session, current_user: User):
    query = db.query(Kader)
    role = _role_name(current_user)
    if role == "SUPER_ADMIN":
        return query
    if role == "ADMIN":
        if current_user.district_id is None:
            return query.filter(Kader.id.is_(None))
        return query.join(Village, Kader.village_id == Village.id, isouter=True).filter(Village.district_id == current_user.district_id)
    if role in {"PKB", "KADER"}:
        village_ids = [row.village_id for row in db.query(UserVillage).filter(UserVillage.user_id == current_user.id).all()]
        if not village_ids:
            return query.filter(Kader.id.is_(None))
        return query.filter(Kader.village_id.in_(village_ids))
    return query


def _validate_village(db: Session, current_user: User, village_id: UUID | None):
    if village_id is None:
        return None
    village = db.query(Village).filter(Village.id == village_id, Village.is_active.is_(True)).first()
    if village is None:
        raise HTTPException(status_code=400, detail="Desa Kader tidak ditemukan pada data SIGA")
    if _role_name(current_user) == "ADMIN" and village.district_id != current_user.district_id:
        raise HTTPException(status_code=403, detail="Desa Kader berada di luar kecamatan binaan Anda")
    return village


@router.get("", response_model=list[KaderResponse])
def list_kader(
    q: str | None = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*READ_ROLES)),
):
    query = _scope_query(db, current_user)
    if q:
        needle = f"%{q.strip()}%"
        query = query.filter(or_(Kader.nama.ilike(needle), Kader.nik.ilike(needle), Kader.phone.ilike(needle)))
    return query.order_by(Kader.nama.asc()).all()


@router.post("", response_model=KaderResponse, status_code=201)
def create_kader(
    payload: KaderCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    if payload.village_id is None:
        raise HTTPException(status_code=400, detail="Master Kader wajib memiliki desa binaan dari data SIGA")
    _validate_village(db, current_user, payload.village_id)
    if db.query(Kader).filter(Kader.nik == payload.nik.strip()).first():
        raise HTTPException(status_code=409, detail="NIK Kader sudah terdaftar")
    item = Kader(**payload.model_dump())
    item.nik = item.nik.strip()
    item.nama = item.nama.strip()
    item.status = (item.status or "AKTIF").upper()
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@router.put("/{kader_id}", response_model=KaderResponse)
def update_kader(
    kader_id: UUID,
    payload: KaderUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGE_ROLES)),
):
    item = _scope_query(db, current_user).filter(Kader.id == kader_id).first()
    if item is None:
        raise HTTPException(status_code=404, detail="Data Kader tidak ditemukan")
    data = payload.model_dump(exclude_unset=True)
    if "village_id" in data:
        _validate_village(db, current_user, data["village_id"])
    if "nik" in data and data["nik"]:
        duplicate = db.query(Kader).filter(Kader.nik == data["nik"].strip(), Kader.id != kader_id).first()
        if duplicate:
            raise HTTPException(status_code=409, detail="NIK Kader sudah digunakan")
        data["nik"] = data["nik"].strip()
    if "nama" in data and data["nama"]:
        data["nama"] = data["nama"].strip()
    if "status" in data and data["status"]:
        data["status"] = data["status"].upper()
    for key, value in data.items():
        setattr(item, key, value)
    db.commit()
    db.refresh(item)
    return item


@router.delete("/{kader_id}")
def delete_kader(
    kader_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("SUPER_ADMIN")),
):
    item = db.query(Kader).filter(Kader.id == kader_id).first()
    if item is None:
        raise HTTPException(status_code=404, detail="Data Kader tidak ditemukan")
    linked = db.query(User).filter(User.kader_id == kader_id).first()
    if linked:
        raise HTTPException(status_code=409, detail="Kader sudah dipakai oleh akun user. Nonaktifkan master bila tidak digunakan.")
    db.delete(item)
    db.commit()
    return {"success": True, "message": "Master Kader berhasil dihapus"}
