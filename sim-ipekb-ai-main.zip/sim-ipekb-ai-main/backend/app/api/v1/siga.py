from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.sync.login_sync import LoginSync

router = APIRouter()


@router.post("/login")
def login(
    username: str,
    password: str,
    db: Session = Depends(get_db),
):

    return LoginSync(db).login(
        username,
        password,
    )