from uuid import UUID

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import require_roles
from app.platform.roles.permission_service import (
    RolePermissionService,
)

router = APIRouter()


@router.get("/{role_id}")
def get_permissions(
    role_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    service = RolePermissionService(db)

    return service.get_permissions(role_id)


@router.post("/{role_id}")
def set_permissions(
    role_id: UUID,
    permission_ids: list[UUID],
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    service = RolePermissionService(db)

    role = service.set_permissions(
        role_id,
        permission_ids,
    )

    return {
        "success": True,
        "total_permission": len(role.permissions),
    }


@router.post("/{role_id}/{permission_id}")
def add_permission(
    role_id: UUID,
    permission_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    service = RolePermissionService(db)

    service.add_permission(
        role_id,
        permission_id,
    )

    return {
        "success": True,
    }


@router.delete("/{role_id}/{permission_id}")
def remove_permission(
    role_id: UUID,
    permission_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    service = RolePermissionService(db)

    service.remove_permission(
        role_id,
        permission_id,
    )

    return {
        "success": True,
    }