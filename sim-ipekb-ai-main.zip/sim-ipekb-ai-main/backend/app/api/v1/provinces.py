from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import require_roles
from app.platform.provinces.repository import ProvinceRepository
from app.platform.provinces.service import ProvinceService
from app.schemas.province import (
    ProvinceCreate,
    ProvinceUpdate,
    ProvinceResponse,
)

router = APIRouter()


@router.get("/", response_model=list[ProvinceResponse])
def get_provinces(
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PENGURUS", "PKB", "KADER", "OPERATOR", "BENDAHARA", "PIMPINAN", "VIEWER", "ANGGOTA")),
):
    repository = ProvinceRepository(db)
    service = ProvinceService(repository)

    return service.get_all_provinces()


@router.get("/{province_id}", response_model=ProvinceResponse)
def get_province(
    province_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PENGURUS", "PKB", "KADER", "OPERATOR", "BENDAHARA", "PIMPINAN", "VIEWER", "ANGGOTA")),
):
    repository = ProvinceRepository(db)
    service = ProvinceService(repository)

    province = service.get_province_by_id(province_id)

    if province is None:
        raise HTTPException(
            status_code=404,
            detail="Provinsi tidak ditemukan",
        )

    return province


@router.post("/", response_model=ProvinceResponse)
def create_province(
    data: ProvinceCreate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = ProvinceRepository(db)
    service = ProvinceService(repository)

    try:
        return service.create_province(
            code=data.code,
            name=data.name,
        )
    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


@router.put("/{province_id}", response_model=ProvinceResponse)
def update_province(
    province_id: UUID,
    data: ProvinceUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = ProvinceRepository(db)
    service = ProvinceService(repository)

    province = service.get_province_by_id(province_id)

    if province is None:
        raise HTTPException(
            status_code=404,
            detail="Provinsi tidak ditemukan",
        )

    return service.update_province(
        province=province,
        code=data.code,
        name=data.name,
        is_active=data.is_active,
    )


@router.delete("/{province_id}")
def delete_province(
    province_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = ProvinceRepository(db)
    service = ProvinceService(repository)

    province = service.get_province_by_id(province_id)

    if province is None:
        raise HTTPException(
            status_code=404,
            detail="Provinsi tidak ditemukan",
        )

    service.delete_province(province)

    return {
        "message": "Provinsi berhasil dihapus"
    }