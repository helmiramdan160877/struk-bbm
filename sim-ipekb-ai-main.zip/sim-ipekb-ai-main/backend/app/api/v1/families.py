from uuid import UUID

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Query,
)
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import require_roles
from app.platform.auth.village_scope import (
    get_user_village_ids,
    require_user_village,
)

from app.platform.families.repository import (
    FamilyRepository,
)

from app.platform.families.service import (
    FamilyService,
)

from app.schemas.family import (
    FamilyCreate,
    FamilyUpdate,
    FamilyResponse,
    FamilyListResponse,
)


router = APIRouter()


# =============================================================
# LIST KELUARGA
# =============================================================

@router.get(
    "/",
    response_model=FamilyListResponse,
)
def get_families(
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=100),

    db: Session = Depends(get_db),

    current_user=Depends(
        require_roles("ADMIN", "PKB", "KADER")
    ),

    village_ids: list[UUID] | None = Depends(
        get_user_village_ids
    ),
):

    repository = FamilyRepository(db)

    service = FamilyService(repository)

    return service.get_families(
        village_ids=village_ids,
        page=page,
        limit=limit,
    )


# =============================================================
# DETAIL KELUARGA
# =============================================================

@router.get(
    "/{family_id}",
    response_model=FamilyResponse,
)
def get_family(
    family_id: UUID,

    db: Session = Depends(get_db),

    current_user=Depends(
        require_roles("ADMIN", "PKB", "KADER")
    ),

    village_ids: list[UUID] | None = Depends(
        get_user_village_ids
    ),
):

    repository = FamilyRepository(db)

    service = FamilyService(repository)

    family = service.get_family_by_id(
        family_id=family_id,
        village_ids=village_ids,
    )

    if family is None:
        raise HTTPException(
            status_code=404,
            detail=(
                "Data keluarga tidak ditemukan "
                "atau Anda tidak memiliki akses."
            ),
        )

    return family


# =============================================================
# TAMBAH KELUARGA
# =============================================================

@router.post(
    "/",
    response_model=FamilyResponse,
)
def create_family(
    data: FamilyCreate,

    db: Session = Depends(get_db),

    current_user=Depends(
        require_roles("ADMIN", "PKB")
    ),
):

    # Pastikan desa tujuan boleh diakses
    require_user_village(
        village_id=data.village_id,
        db=db,
        current_user=current_user,
    )

    repository = FamilyRepository(db)

    service = FamilyService(repository)

    try:

        return service.create_family(
            village_id=data.village_id,
            family_card_number=data.family_card_number,
            head_of_family=data.head_of_family,
            address=data.address,
            rt=data.rt,
            rw=data.rw,
            postal_code=data.postal_code,
        )

    except ValueError as e:

        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


# =============================================================
# UPDATE KELUARGA
# =============================================================

@router.put(
    "/{family_id}",
    response_model=FamilyResponse,
)
def update_family(
    family_id: UUID,

    data: FamilyUpdate,

    db: Session = Depends(get_db),

    current_user=Depends(
        require_roles("ADMIN", "PKB")
    ),
):

    # ---------------------------------------------------------
    # Cek desa lama
    # ---------------------------------------------------------

    repository = FamilyRepository(db)

    service = FamilyService(repository)

    family = service.get_family_by_id(
        family_id=family_id,
        village_ids=get_user_village_ids(
            db=db,
            current_user=current_user,
        ),
    )

    if family is None:

        raise HTTPException(
            status_code=404,
            detail=(
                "Data keluarga tidak ditemukan "
                "atau Anda tidak memiliki akses."
            ),
        )

    # ---------------------------------------------------------
    # Cek desa baru
    # ---------------------------------------------------------

    require_user_village(
        village_id=data.village_id,
        db=db,
        current_user=current_user,
    )

    try:

        return service.update_family(
            family=family,
            village_id=data.village_id,
            family_card_number=data.family_card_number,
            head_of_family=data.head_of_family,
            address=data.address,
            rt=data.rt,
            rw=data.rw,
            postal_code=data.postal_code,
            is_active=data.is_active,
        )

    except ValueError as e:

        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


# =============================================================
# DELETE KELUARGA
# =============================================================

@router.delete(
    "/{family_id}"
)
def delete_family(
    family_id: UUID,

    db: Session = Depends(get_db),

    current_user=Depends(
        require_roles("ADMIN", "PKB")
    ),
):

    village_ids = get_user_village_ids(
        db=db,
        current_user=current_user,
    )

    repository = FamilyRepository(db)

    service = FamilyService(repository)

    family = service.get_family_by_id(
        family_id=family_id,
        village_ids=village_ids,
    )

    if family is None:

        raise HTTPException(
            status_code=404,
            detail=(
                "Data keluarga tidak ditemukan "
                "atau Anda tidak memiliki akses."
            ),
        )

    service.delete_family(family)

    return {
        "success": True,
        "message": "Data keluarga berhasil dihapus",
    }