from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.api.deps import get_db
from app.models.berita import Berita

router = APIRouter()

@router.get("")
def list_berita(db: Session = Depends(get_db)):
    return db.query(Berita).order_by(Berita.created_at.desc()).limit(6).all()
