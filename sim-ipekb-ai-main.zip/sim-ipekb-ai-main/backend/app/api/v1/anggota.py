from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from fastapi import HTTPException
from app.api.deps import get_db
from app.models.anggota import Anggota
from app.schemas.anggota import (
    AnggotaCreate,
    AnggotaUpdate,
    AnggotaResponse
)


router = APIRouter(
    tags=["Master Anggota"]
)



@router.get(
    "",
    response_model=list[AnggotaResponse]
)
def list_anggota(
    db: Session = Depends(get_db)
):

    return (
        db.query(Anggota)
        .order_by(Anggota.nama.asc())
        .all()
    )



@router.post(
    "",
    response_model=AnggotaResponse,
    status_code=201
)
def create_anggota(
    payload: AnggotaCreate,
    db: Session = Depends(get_db)
):

    if payload.nip:

        exists = (
            db.query(Anggota)
            .filter(
                Anggota.nip == payload.nip
            )
            .first()
        )

        if exists:
            raise HTTPException(
                status_code=400,
                detail="Data anggota dengan NIP tersebut sudah ada"
            )


    anggota = Anggota(
        nama=payload.nama,
        nip=payload.nip,
        phone=payload.phone,
        status=payload.status
    )


    db.add(anggota)
    db.commit()
    db.refresh(anggota)

    return anggota



@router.put(
    "/{anggota_id}",
    response_model=AnggotaResponse
)
def update_anggota(
    anggota_id: UUID,
    payload: AnggotaUpdate,
    db: Session = Depends(get_db)
):

    item = (
        db.query(Anggota)
        .filter(
            Anggota.id == anggota_id
        )
        .first()
    )


    if not item:
        raise HTTPException(
            status_code=404,
            detail="Data anggota tidak ditemukan"
        )


    for key,value in payload.model_dump(
        exclude_unset=True
    ).items():

        setattr(
            item,
            key,
            value
        )


    db.commit()
    db.refresh(item)

    return item



@router.delete(
    "/{anggota_id}"
)
def delete_anggota(
    anggota_id: UUID,
    db: Session = Depends(get_db)
):

    item = (
        db.query(Anggota)
        .filter(
            Anggota.id == anggota_id
        )
        .first()
    )


    if not item:
        raise HTTPException(
            status_code=404,
            detail="Data anggota tidak ditemukan"
        )


    db.delete(item)
    db.commit()


    return {
        "success":True,
        "message":"Anggota berhasil dihapus"
    }