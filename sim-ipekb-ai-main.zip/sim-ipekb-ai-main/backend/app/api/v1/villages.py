from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import require_roles
from app.platform.auth.village_scope import get_user_village_ids, require_user_village
from app.platform.villages.repository import VillageRepository
from app.platform.villages.service import VillageService
from app.schemas.village import (
    VillageCreate,
    VillageUpdate,
    VillageResponse,
)

router = APIRouter()


@router.get("/", response_model=list[VillageResponse])
def get_villages(
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PENGURUS", "PKB", "KADER", "OPERATOR", "BENDAHARA", "PIMPINAN", "VIEWER", "ANGGOTA")),
):
    repository = VillageRepository(db)
    service = VillageService(repository)
    villages = service.get_all_villages()
    role_name = ((getattr(getattr(current_user, "role", None), "name", "") or "").strip().upper())
    if role_name in {"ADMIN", "PKB", "KADER"}:
        allowed = get_user_village_ids(db=db, current_user=current_user)
        allowed_set = set(allowed or [])
        villages = [v for v in villages if v.id in allowed_set]
    return villages


@router.get("/{village_id}", response_model=VillageResponse)
def get_village(
    village_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PENGURUS", "PKB", "KADER", "OPERATOR", "BENDAHARA", "PIMPINAN", "VIEWER", "ANGGOTA")),
):
    repository = VillageRepository(db)
    service = VillageService(repository)

    village = service.get_village_by_id(village_id)

    if village is None:
        raise HTTPException(
            status_code=404,
            detail="Desa/Kelurahan tidak ditemukan",
        )

    role_name = ((getattr(getattr(current_user, "role", None), "name", "") or "").strip().upper())
    if role_name in {"ADMIN", "PKB", "KADER"}:
        require_user_village(village_id=village_id, db=db, current_user=current_user)

    return village


@router.post("/", response_model=VillageResponse)
def create_village(
    data: VillageCreate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = VillageRepository(db)
    service = VillageService(repository)

    try:
        return service.create_village(
            district_id=data.district_id,
            code=data.code,
            name=data.name,
        )
    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


@router.put("/{village_id}", response_model=VillageResponse)
def update_village(
    village_id: UUID,
    data: VillageUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = VillageRepository(db)
    service = VillageService(repository)

    village = service.get_village_by_id(village_id)

    if village is None:
        raise HTTPException(
            status_code=404,
            detail="Desa/Kelurahan tidak ditemukan",
        )

    return service.update_village(
        village=village,
        district_id=data.district_id,
        code=data.code,
        name=data.name,
        is_active=data.is_active,
    )


@router.delete("/{village_id}")
def delete_village(
    village_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = VillageRepository(db)
    service = VillageService(repository)

    village = service.get_village_by_id(village_id)

    if village is None:
        raise HTTPException(
            status_code=404,
            detail="Desa/Kelurahan tidak ditemukan",
        )

    service.delete_village(village)

    return {
        "message": "Desa/Kelurahan berhasil dihapus"
    }