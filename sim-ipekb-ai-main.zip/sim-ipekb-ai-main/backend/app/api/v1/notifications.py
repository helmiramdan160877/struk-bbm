from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.models.iuran import IuranNotification
from app.models.user import User
from app.platform.auth.dependencies import get_current_user, require_roles
from app.services.iuran_notification_service import generate_monthly_iuran_notifications, jakarta_today

router = APIRouter(tags=["Notifications"])


def _serialize(item: IuranNotification):
    return {
        "id": str(item.id),
        "year": item.year,
        "month": item.month,
        "kind": item.kind,
        "title": item.title,
        "message": item.message,
        "outstanding_amount": float(item.outstanding_amount or 0),
        "is_read": item.is_read,
        "whatsapp_status": item.whatsapp_status,
        "created_at": item.created_at,
    }


@router.get("")
def my_notifications(
    unread_only: bool = Query(default=False),
    limit: int = Query(default=20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Setelah tanggal 25, endpoint juga memastikan reminder bulan berjalan tetap terbentuk
    # bila server sempat mati ketika scheduler seharusnya berjalan.
    today = jakarta_today()
    if today.day >= 25:
        generate_monthly_iuran_notifications(db, today, send_wa=False)

    query = db.query(IuranNotification).filter(IuranNotification.user_id == current_user.id)
    if unread_only:
        query = query.filter(IuranNotification.is_read.is_(False))
    items = query.order_by(IuranNotification.created_at.desc()).limit(limit).all()
    return {
        "unread_count": db.query(IuranNotification).filter(IuranNotification.user_id == current_user.id, IuranNotification.is_read.is_(False)).count(),
        "items": [_serialize(item) for item in items],
    }


@router.patch("/{notification_id}/read")
def mark_read(
    notification_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    item = db.query(IuranNotification).filter(IuranNotification.id == notification_id, IuranNotification.user_id == current_user.id).first()
    if item is None:
        raise HTTPException(status_code=404, detail="Notifikasi tidak ditemukan")
    item.is_read = True
    db.commit()
    return {"success": True}


@router.post("/run-iuran")
def run_iuran_reminder(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("BENDAHARA", "ADMIN")),
):
    return generate_monthly_iuran_notifications(db, jakarta_today(), send_wa=True)
