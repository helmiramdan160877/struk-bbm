from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.models.siga_account import SigaAccount
from app.models.user import User
from app.models.user_village import UserVillage
from app.models.village import Village
from app.models.district import District
from app.core.encryption import encryption_service
from app.sync.base_sync import BaseSync
from app.sync.base_api_sync import BaseApiSync
from app.platform.auth.dependencies import require_roles
from app.platform.siga_accounts.scope import (
    get_accessible_siga_accounts,
    get_role_name,
    reconcile_user_siga_accounts,
)
from app.platform.siga_accounts.service import siga_account_service
from app.schemas.siga_account import (
    SigaAccountCreate,
    SigaAccountResponse,
    SigaAccountUpdate,
)

router = APIRouter()


def _get_siga_district_name(db: Session, account: SigaAccount) -> str:
    """
    Mengambil nama kecamatan langsung dari API SIGA.
    """
    try:
        password = encryption_service.decrypt(
            account.password_encrypted
        )

        session = BaseSync(db).login(
            account.username,
            password,
            timeout=30,
        )

        api = BaseApiSync(db, session)

        response = api.get_json(
            "https://siga-api-gateway.bkkbn.go.id/location-service/siga/location/getListKecamatanByIdKabupaten",
            params={
                "id_kabupaten": session.regency_id
            },
        )
        print("RESPONSE KECAMATAN SIGA:", response)
        print("SIGA DISTRICT ID AKUN:", account.siga_district_id)

        items = api.extract_list(response)

        for item in items:
            print(
            "CEK ITEM:",
            item.get("id_kecamatan"),
            item.get("originalNama")
        )
            item_id = (
                item.get("id_kecamatan")
                or item.get("originalID")
                or item.get("id")
            )

            if str(item_id) == str(account.siga_district_id):
                return (
                    item.get("originalNama")
                    or item.get("nama_kecamatan")
                    or item.get("nama")
                )

    except Exception as e:
        print("ERROR GET NAMA KECAMATAN SIGA:", e)

    return "Belum dipetakan"



def _refresh_account_region_from_siga(db: Session, account: SigaAccount) -> None:
    """
    Verifikasi wilayah akun langsung dari response login SIGA.
    Ini memperbaiki data lama yang district_id lokalnya salah.
    """
    session = None
    try:
        password = encryption_service.decrypt(account.password_encrypted)
        session = BaseSync(db).login(account.username, password, timeout=30)

        if session.province_id:
            account.siga_province_id = str(session.province_id)
        if session.regency_id:
            account.siga_regency_id = str(session.regency_id)
        if session.district_id:
            account.siga_district_id = str(session.district_id)

            district = (
                db.query(District)
                .filter(
                    District.siga_id == str(session.district_id),
                    District.is_active.is_(True),
                )
                .first()
            )
            if district:
                account.district_id = district.id

        db.add(account)
        db.commit()
        db.refresh(account)
    except Exception:
        db.rollback()
    finally:
        if session is not None:
            try:
                session.close()
            except Exception:
                pass


def _assert_manage_scope(current_user, account: SigaAccount) -> None:
    """
    Memastikan user hanya dapat mengelola Akun SIGA
    sesuai kecamatan binaannya.

    SUPER_ADMIN dapat mengelola seluruh Akun SIGA.
    """
    if get_role_name(current_user) == "SUPER_ADMIN":
        return

    district_id = getattr(current_user, "district_id", None)

    if district_id is None or account.district_id != district_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Akun SIGA berada di luar kecamatan binaan Anda.",
        )


def _reconcile_district_links(
    db: Session,
    district_id: UUID | None,
) -> None:
    """
    Sinkronisasi relasi User ↔ Akun SIGA berdasarkan
    wilayah user.

    Fungsi ini dipertahankan untuk kompatibilitas data lama.
    Jalur baru PKB tetap menggunakan:

        Akun SIGA → Master PKB → User PKB
    """
    if district_id is None:
        return

    user_ids = {
        row[0]
        for row in (
            db.query(UserVillage.user_id)
            .join(
                Village,
                Village.id == UserVillage.village_id,
            )
            .filter(
                Village.district_id == district_id,
            )
            .distinct()
            .all()
        )
    }

    for user_id in user_ids:
        reconcile_user_siga_accounts(
            db,
            user_id,
        )


@router.post(
    "",
    response_model=SigaAccountResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_account(
    data: SigaAccountCreate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN", "ADMIN")),
):
    """Buat akun SIGA. Kecamatan ditentukan 100% dari hasil login SIGA."""
    username = data.username.strip()
    password = data.password.strip()
    if not username or not password:
        raise HTTPException(status_code=400, detail="Username dan password SIGA wajib diisi.")

    if db.query(SigaAccount).filter(SigaAccount.username == username).first():
        raise HTTPException(status_code=409, detail="Username SIGA sudah terdaftar.")

    current_district_id = getattr(current_user, "district_id", None)
    session = None
    account = None
    try:
        session = BaseSync(db).auth_service.login(username, password, timeout=30)
        if not session.district_id:
            raise HTTPException(status_code=422, detail="Login SIGA berhasil tetapi ID kecamatan tidak dikembalikan SIGA.")

        district = (
            db.query(District)
            .filter(
                District.siga_id == str(session.district_id),
                District.is_active.is_(True),
            )
            .first()
        )

        # Mapping master wilayah lokal tidak wajib tersedia.
        district_id = district.id if district else None

        if get_role_name(current_user) == "ADMIN" and current_district_id != district.id:
            raise HTTPException(status_code=403, detail=f"Akun SIGA tersebut berada di Kecamatan {district.name}, bukan kecamatan ADMIN.")

        account = siga_account_service.create(
            db,
            data.model_copy(
                update={
                    "district_id": district_id,
                    "username": username,
                }
            ),
        )
        account.siga_province_id = str(session.province_id) if session.province_id else None
        account.siga_regency_id = str(session.regency_id) if session.regency_id else None
        account.siga_district_id = str(session.district_id)
        account.token = session.token
        db.add(account)
        db.commit()
        db.refresh(account)
        return account
    except HTTPException:
        db.rollback()
        if account is not None:
            try: db.delete(account); db.commit()
            except Exception: db.rollback()
        raise
    except Exception as exc:
        db.rollback()
        if account is not None:
            try: db.delete(account); db.commit()
            except Exception: db.rollback()
        raise HTTPException(status_code=422, detail=f"Akun SIGA tidak dapat diverifikasi: {exc}")
    finally:
        if session is not None:
            try: session.close()
            except Exception: pass


@router.get(
    "",
    response_model=list[SigaAccountResponse],
)
def get_accounts(
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles(
            "SUPER_ADMIN",
            "ADMIN",
            "PKB",
        )
    ),
):
    """
    Menampilkan Akun SIGA yang dapat diakses user.

    Untuk PKB, Akun SIGA digunakan sebagai sumber
    wilayah pada Master PKB.
    """
    role_name = get_role_name(current_user)

    # SUPER_ADMIN dapat memperbaiki seluruh mapping akun lama sekaligus.
    # Untuk role lain hanya akun yang memang berada dalam scope yang diverifikasi.
    accounts = (
        db.query(SigaAccount)
        .filter(SigaAccount.is_active.is_(True))
        .order_by(SigaAccount.username.asc())
        .all()
        if role_name == "SUPER_ADMIN"
        else get_accessible_siga_accounts(db, current_user)
    )

    for account in accounts:
        _refresh_account_region_from_siga(db, account)
        account.district_name = _get_siga_district_name(db, account)
        print(
        "HASIL DISTRICT NAME:",
        account.username,
        account.district_name
        )
    if role_name == "SUPER_ADMIN":
        return accounts

    # Scope dihitung ulang setelah mapping SIGA diperbaiki.
    return get_accessible_siga_accounts(db, current_user)


@router.get(
    "/{account_id}",
    response_model=SigaAccountResponse,
)
def get_account(
    account_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles(
            "SUPER_ADMIN",
            "ADMIN",
            "PKB",
        )
    ),
):
    """
    Mengambil satu Akun SIGA.
    """

    account = siga_account_service.get_by_id(
        db,
        account_id,
    )

    if account is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Akun SIGA tidak ditemukan.",
        )

    _assert_manage_scope(
        current_user,
        account,
    )

    return account


@router.put(
    "/{account_id}",
    response_model=SigaAccountResponse,
)
def update_account(
    account_id: UUID,
    data: SigaAccountUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles(
            "SUPER_ADMIN",
            "ADMIN",
        )
    ),
):
    """
    Mengubah Akun SIGA.

    Yang dapat diubah:
    - username
    - password
    - status aktif
    """

    account = siga_account_service.get_by_id(
        db,
        account_id,
    )

    if account is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Akun SIGA tidak ditemukan.",
        )

    _assert_manage_scope(
        current_user,
        account,
    )

    # Cek username jika username diubah.
    if (
        data.username is not None
        and data.username != account.username
    ):
        existing = (
            db.query(SigaAccount)
            .filter(
                SigaAccount.district_id == account.district_id,
                SigaAccount.username == data.username,
                SigaAccount.id != account.id,
            )
            .first()
        )

        if existing:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Username Akun SIGA pada kecamatan tersebut sudah digunakan.",
            )

    updated = siga_account_service.update(
        db,
        account_id,
        data,
    )

    if updated is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Akun SIGA tidak ditemukan.",
        )

    return updated


@router.delete(
    "/{account_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_account(
    account_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles(
            "SUPER_ADMIN",
            "ADMIN",
        )
    ),
):
    """
    Menghapus Akun SIGA.

    Jika Akun SIGA sudah digunakan oleh Master PKB,
    relasinya mengikuti konfigurasi ForeignKey yang ada
    pada tabel PKB.
    """

    account = siga_account_service.get_by_id(
        db,
        account_id,
    )

    if account is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Akun SIGA tidak ditemukan.",
        )

    _assert_manage_scope(
        current_user,
        account,
    )

    district_id = account.district_id

    siga_account_service.delete(
        db,
        account_id,
    )

    # Pertahankan rekonsiliasi data lama.
    _reconcile_district_links(
        db,
        district_id,
    )

    return None