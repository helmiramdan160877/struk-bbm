from fastapi import APIRouter

from app.api.v1 import sync
from app.api.v1 import dashboard
from app.api.v1 import users


api_router = APIRouter()


# =========================================================
# USERS
# =========================================================

api_router.include_router(
    users.router,
    prefix="/users",
    tags=["Users"],
)


# =========================================================
# SYNC
# =========================================================

api_router.include_router(
    sync.router,
    prefix="/sync",
    tags=["Sync"],
)


# =========================================================
# DASHBOARD
# =========================================================

api_router.include_router(
    dashboard.router,
    prefix="/dashboard",
    tags=["Dashboard"],
)