from datetime import datetime, date, timedelta
import calendar
import json
from html.parser import HTMLParser
import re

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import get_current_user

from app.models.siga_account import SigaAccount
from app.models.user_siga_account import UserSigaAccount
from app.models.family import Family
from app.models.family_member import FamilyMember
from app.models.village import Village
from app.models.user_village import UserVillage
from app.platform.siga_accounts.scope import get_role_name
from app.core.encryption import encryption_service
from app.sync.base_sync import BaseSync
from app.sync.base_api_sync import BaseApiSync
from app.sync.location_sync import LocationSync


router = APIRouter()


# ============================================================
# USER HELPER
# ============================================================

def get_current_username(current_user):
    """
    Mengambil username user aplikasi yang sedang login.
    """

    if current_user is None:
        return None

    username = getattr(
        current_user,
        "username",
        None,
    )

    if username:
        return str(username).strip()

    if isinstance(current_user, dict):
        username = current_user.get(
            "username"
        )

        if username:
            return str(
                username
            ).strip()

    return None


# ============================================================
# AMBIL AKUN SIGA USER
# ============================================================

def get_siga_account(db: Session, current_user):
    """Ambil akun SIGA yang secara eksplisit terhubung ke user login."""
    current_username = get_current_username(current_user)
    if not current_username:
        raise HTTPException(status_code=401, detail="Username user aplikasi tidak ditemukan.")

    linked = (
        db.query(SigaAccount)
        .join(UserSigaAccount, UserSigaAccount.siga_account_id == SigaAccount.id)
        .filter(
            UserSigaAccount.user_id == current_user.id,
            SigaAccount.is_active.is_(True),
        )
        .order_by(SigaAccount.username.asc())
        .all()
    )
    if not linked:
        raise HTTPException(
            status_code=404,
            detail=f"User '{current_username}' belum memiliki akun SIGA yang terhubung. Hubungkan melalui menu Administrasi → Akun SIGA.",
        )
    return linked[0]


# ============================================================
# DASHBOARD SUMMARY
# ============================================================

@router.get(
    "/summary",
    summary="Dashboard Summary",
)
def dashboard_summary(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """
    Dashboard berdasarkan wilayah binaan
    akun SIGA user yang sedang login.
    """

    # ========================================================
    # AKUN SIGA
    # ========================================================

    siga_account = get_siga_account(
        db,
        current_user,
    )

    # ========================================================
    # DISTRICT LOKAL
    # ========================================================

    district_id = getattr(
        siga_account,
        "district_id",
        None,
    )

    if district_id is None:
        raise HTTPException(
            status_code=400,
            detail=(
                "Akun SIGA belum memiliki "
                "district_id wilayah binaan."
            ),
        )

    # ========================================================
    # TOTAL DESA
    # ========================================================

    total_village = (
        db.query(
            func.count(Village.id)
        )
        .filter(
            Village.district_id
            == district_id
        )
        .scalar()
        or 0
    )

    # ========================================================
    # TOTAL FAMILY
    # ========================================================

    total_family = (
        db.query(
            func.count(Family.id)
        )
        .join(
            Village,
            Family.village_id
            == Village.id,
        )
        .filter(
            Village.district_id
            == district_id
        )
        .scalar()
        or 0
    )

    # ========================================================
    # TOTAL MEMBER
    # ========================================================

    total_member = (
        db.query(
            func.count(FamilyMember.id)
        )
        .join(
            Family,
            FamilyMember.family_id
            == Family.id,
        )
        .join(
            Village,
            Family.village_id
            == Village.id,
        )
        .filter(
            Village.district_id
            == district_id
        )
        .scalar()
        or 0
    )

    # ========================================================
    # ALIVE
    # ========================================================

    alive = (
        db.query(
            func.count(FamilyMember.id)
        )
        .join(
            Family,
            FamilyMember.family_id
            == Family.id,
        )
        .join(
            Village,
            Family.village_id
            == Village.id,
        )
        .filter(
            Village.district_id
            == district_id,
            FamilyMember.is_alive.is_(True),
        )
        .scalar()
        or 0
    )

    # ========================================================
    # DEAD
    # ========================================================

    dead = (
        db.query(
            func.count(FamilyMember.id)
        )
        .join(
            Family,
            FamilyMember.family_id
            == Family.id,
        )
        .join(
            Village,
            Family.village_id
            == Village.id,
        )
        .filter(
            Village.district_id
            == district_id,
            FamilyMember.is_alive.is_(False),
        )
        .scalar()
        or 0
    )

    # ========================================================
    # MATCHED
    # ========================================================

    matched = (
        db.query(
            func.count(FamilyMember.id)
        )
        .join(
            Family,
            FamilyMember.family_id
            == Family.id,
        )
        .join(
            Village,
            Family.village_id
            == Village.id,
        )
        .filter(
            Village.district_id
            == district_id,
            FamilyMember.is_matched.is_(True),
        )
        .scalar()
        or 0
    )

    # ========================================================
    # UNMATCHED
    # ========================================================

    unmatched = (
        db.query(
            func.count(FamilyMember.id)
        )
        .join(
            Family,
            FamilyMember.family_id
            == Family.id,
        )
        .join(
            Village,
            Family.village_id
            == Village.id,
        )
        .filter(
            Village.district_id
            == district_id,
            FamilyMember.is_matched.is_(False),
        )
        .scalar()
        or 0
    )

    # ========================================================
    # RESPONSE
    # ========================================================

    return {
        "username_user": get_current_username(
            current_user
        ),

        "username_siga": (
            siga_account.username
        ),

        "wilayah": {
            "district_id": str(
                siga_account.district_id
            ),

            "siga_province_id": (
                str(
                    siga_account.siga_province_id
                )
                if siga_account.siga_province_id
                is not None
                else None
            ),

            "siga_regency_id": (
                str(
                    siga_account.siga_regency_id
                )
                if siga_account.siga_regency_id
                is not None
                else None
            ),

            "siga_district_id": (
                str(
                    siga_account.siga_district_id
                )
                if siga_account.siga_district_id
                is not None
                else None
            ),
        },

        "total_family": int(
            total_family
        ),

        "total_member": int(
            total_member
        ),

        "alive": int(
            alive
        ),

        "dead": int(
            dead
        ),

        "matched": int(
            matched
        ),

        "unmatched": int(
            unmatched
        ),

        "province": 1,

        "regency": 1,

        "district": 1,

        "village": int(
            total_village
        ),
    }


# ============================================================
# DASHBOARD WILAYAH
# ============================================================

@router.get(
    "/wilayah",
    summary="Dashboard Wilayah",
)
def dashboard_wilayah(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """
    Informasi akun SIGA dan wilayah binaan
    user yang sedang login.
    """

    siga_account = get_siga_account(
        db,
        current_user,
    )

    district_id = getattr(
        siga_account,
        "district_id",
        None,
    )

    if district_id is None:
        raise HTTPException(
            status_code=400,
            detail=(
                "district_id akun SIGA "
                "belum tersedia."
            ),
        )

    # ========================================================
    # TOTAL DESA
    # ========================================================

    total_village = (
        db.query(
            func.count(Village.id)
        )
        .filter(
            Village.district_id
            == district_id
        )
        .scalar()
        or 0
    )

    # ========================================================
    # RESPONSE
    # ========================================================

    return {
        "username_user": (
            get_current_username(
                current_user
            )
        ),

        "username_siga": (
            siga_account.username
        ),

        "account_id": str(
            siga_account.id
        ),

        "district_id": str(
            district_id
        ),

        "is_active": bool(
            siga_account.is_active
        ),

        "siga_province_id": (
            str(
                siga_account.siga_province_id
            )
            if siga_account.siga_province_id
            is not None
            else None
        ),

        "siga_regency_id": (
            str(
                siga_account.siga_regency_id
            )
            if siga_account.siga_regency_id
            is not None
            else None
        ),

        "siga_district_id": (
            str(
                siga_account.siga_district_id
            )
            if siga_account.siga_district_id
            is not None
            else None
        ),

        "total_village": int(
            total_village
        ),
    }

# ============================================================
# LANDING PAGE - SIGA LIVE KABUPATEN CIANJUR
# ============================================================

_CIANJUR_SIGA_PROVINCE_ID = "12"
_CIANJUR_SIGA_REGENCY_ID = "149"


def _landing_siga_id(item, *keys):
    if not isinstance(item, dict):
        return None
    for key in keys:
        value = item.get(key)
        if value not in (None, ""):
            return str(value)
    return None


def _landing_village_name(item):
    if not isinstance(item, dict):
        return ""
    for key in ("nama", "namaKelurahan", "namaDesa", "name", "label"):
        value = item.get(key)
        if value not in (None, ""):
            return str(value).strip()
    return ""


def _landing_village_code(item):
    if not isinstance(item, dict):
        return None
    for key in ("kode", "kodeKelurahan", "kodeDesa", "code"):
        value = item.get(key)
        if value not in (None, ""):
            return str(value).strip()
    return None


def _landing_live_villages(session, district_id=None):
    location = LocationSync(None, session)
    district_id = district_id or session.district_id
    rows = location.get_villages(str(district_id))
    result = []
    for item in rows:
        siga_id = _landing_siga_id(
            item,
            "id",
            "idKelurahan",
            "id_kelurahan",
            "idDesa",
            "id_desa",
        )
        if not siga_id:
            continue
        result.append({
            "siga_id": siga_id,
            "name": _landing_village_name(item) or siga_id,
            "code": _landing_village_code(item),
            "district_id": str(district_id),
        })
    return result


def _landing_live_districts(session):
    location = LocationSync(None, session)
    rows = location.get_districts(_CIANJUR_SIGA_REGENCY_ID)
    result = []
    seen = set()
    for item in rows:
        district_id = _landing_siga_id(
            item,
            "id",
            "idKecamatan",
            "id_kecamatan",
        )
        if not district_id or district_id in seen:
            continue
        seen.add(district_id)
        result.append(district_id)
    return result


@router.get(
    "/public-siga-cianjur",
    summary="Data SIGA live untuk Landing Page Kabupaten Cianjur",
)
def public_siga_cianjur(
    bulan: int | None = None,
    tahun: int | None = None,
    db: Session = Depends(get_db),
):
    """Landing Page memakai scope seluruh Kabupaten Cianjur, bukan scope user login."""
    bulan = bulan or datetime.now().month
    tahun = tahun or datetime.now().year
    if not 1 <= bulan <= 12:
        raise HTTPException(status_code=400, detail="Bulan harus 1-12.")
    if not 2000 <= tahun <= 2100:
        raise HTTPException(status_code=400, detail="Tahun tidak valid.")

    accounts = (
        db.query(SigaAccount)
        .filter(SigaAccount.is_active.is_(True))
        .order_by(SigaAccount.username.asc())
        .all()
    )
    if not accounts:
        raise HTTPException(status_code=404, detail="Belum ada akun SIGA aktif untuk Landing Page.")

    totals = {
        "total_family": 0,
        "total_member": 0,
        "total_pus": 0,
        "total_unmet_need": 0,
        "pus_not_kb": 0,
        "bkb_members": 0,
        "bkr_members": 0,
        "bkl_members": 0,
        "uppka_members": 0,
        "poktan_members": 0,
    }
    seen_villages = set()
    seen_location_villages = set()
    processed_accounts = []
    account_errors = []
    village_count = 0
    location_village_count = 0

    for account in accounts:
        session = None
        try:
            session = _dashboard_login(db, account)
            if str(session.province_id) != _CIANJUR_SIGA_PROVINCE_ID or str(session.regency_id) != _CIANJUR_SIGA_REGENCY_ID:
                continue

            processed_accounts.append(account.username)

            # Jumlah desa Landing harus mengikuti master wilayah SIGA
            # Kabupaten Cianjur, bukan jumlah desa yang kebetulan termuat
            # dari akun SIGA yang aktif.
            try:
                district_ids = _landing_live_districts(session)
                for district_id in district_ids:
                    for location_village in _landing_live_villages(session, district_id):
                        location_village_key = location_village["siga_id"]
                        if location_village_key not in seen_location_villages:
                            seen_location_villages.add(location_village_key)
                            location_village_count += 1
            except Exception as location_exc:
                account_errors.append({
                    "username": account.username,
                    "error": f"Master wilayah SIGA: {location_exc}",
                })

            # Data agregat tetap dihitung dari desa yang dapat diakses
            # oleh akun SIGA tersebut.
            live_villages = _landing_live_villages(session)
            for village in live_villages:
                siga_id = village["siga_id"]
                if siga_id in seen_villages:
                    continue
                seen_villages.add(siga_id)
                village_count += 1

                summary = _dashboard_summary_for_village(
                    session,
                    siga_id,
                    bulan,
                    tahun,
                )
                totals["total_family"] += _dashboard_number(summary.get("jumlahKeluarga"))
                totals["total_member"] += _dashboard_number(summary.get("jumlahJiwa"))
                totals["total_pus"] += _dashboard_number(summary.get("jumlahPus"))
                totals["total_unmet_need"] += _dashboard_number(summary.get("jumlahUnmetNeed"))
                totals["pus_not_kb"] += _dashboard_number(summary.get("pusBukanPesertaKb"))
                totals["bkb_members"] += _dashboard_number(summary.get("jumlahKesertaanBkb"))
                totals["bkr_members"] += _dashboard_number(summary.get("jumlahKesertaanBkr"))
                totals["bkl_members"] += _dashboard_number(summary.get("jumlahKesertaanBkl"))
                totals["uppka_members"] += _dashboard_number(summary.get("jumlahKesertaanUppka"))
                totals["poktan_members"] += _dashboard_number(summary.get("kesertaanPoktan"))
        except Exception as exc:
            account_errors.append({"username": account.username, "error": str(exc)})
        finally:
            if session is not None:
                try:
                    session.close()
                except Exception:
                    pass

    if not processed_accounts:
        detail = "Tidak ada akun SIGA aktif dengan scope Kabupaten Cianjur (Provinsi 12, Kabupaten 149)."
        if account_errors:
            detail += f" Gagal memuat {len(account_errors)} akun."
        raise HTTPException(status_code=502, detail=detail)

    return {
        "generated_at": datetime.now().isoformat(),
        "period": {"bulan": bulan, "tahun": tahun},
        "scope": {
            "province_id": _CIANJUR_SIGA_PROVINCE_ID,
            "regency_id": _CIANJUR_SIGA_REGENCY_ID,
            "regency_name": "Kabupaten Cianjur",
            "village_count": location_village_count or village_count,
        },
        "source": "SIGA LIVE",
        "totals": totals,
        "accounts_available": len(processed_accounts),
        "accounts_with_error": len(account_errors),
        "complete": bool(village_count) and not account_errors,
        "account_errors": account_errors,
    }


# ============================================================
# DASHBOARD SIGA LIVE - PKB / ADMIN KECAMATAN
# ============================================================

def _dashboard_scope_villages(db: Session, current_user, siga_account):
    """Wilayah dashboard mengikuti akun SIGA + hak desa user."""
    role = get_role_name(current_user)

    query = (
        db.query(Village)
        .filter(
            Village.is_active.is_(True),
            Village.district_id == siga_account.district_id,
            Village.siga_id.is_not(None),
        )
    )

    if role == "PKB":
        query = (
            query
            .join(UserVillage, UserVillage.village_id == Village.id)
            .filter(UserVillage.user_id == current_user.id)
        )
    elif role != "ADMIN":
        raise HTTPException(
            status_code=403,
            detail="Dashboard SIGA ini hanya untuk PKB dan ADMIN Kecamatan.",
        )

    return query.order_by(Village.name.asc()).all()


def _dashboard_payload_list(payload):
    if isinstance(payload, list):
        return payload
    if not isinstance(payload, dict):
        return []
    for key in ("data", "content", "result", "results", "rows", "list", "items"):
        value = payload.get(key)
        if isinstance(value, list):
            return value
    return []


def _dashboard_number(value):
    try:
        if value is None or value == "":
            return 0
        return int(float(str(value).replace(",", ".").strip()))
    except (TypeError, ValueError):
        return 0


def _dashboard_login(db: Session, account):
    password = encryption_service.decrypt(account.password_encrypted)
    return BaseSync(db).login(account.username, password, timeout=15)


def _dashboard_summary_for_village(session, village_id, bulan, tahun):
    params = {
        "bulan": bulan,
        "tahun": tahun,
        "idProvinsi": session.province_id,
        "idKabupaten": session.regency_id,
        "idKecamatan": session.district_id,
        "idKelurahan": str(village_id),
    }
    api = BaseApiSync(None, session)
    payload = api.get_json(
        "/rekapitulasi-data-keluarga/siga/rekap/getRingkasanRekapPK",
        params=params,
        retry=2,
        timeout=15,
    )
    rows = _dashboard_payload_list(payload)
    return rows[0] if rows else {}


def _dashboard_kb_for_village(session, village_id, bulan, tahun):
    params = {
        "bulan": bulan,
        "tahun": tahun,
        "idProvinsi": session.province_id,
        "idKabupaten": session.regency_id,
        "idKecamatan": session.district_id,
        "idKelurahan": str(village_id),
    }
    api = BaseApiSync(None, session)
    payload = api.get_json(
        "/rekapitulasi-data-keluarga/siga/rekap/getRingkasanKbAktifRekapPK",
        params=params,
        retry=2,
        timeout=15,
    )
    return _dashboard_payload_list(payload)


class _DashboardTableParser(HTMLParser):
    """Parser kecil tanpa dependency tambahan untuk report HTML SIGA."""

    def __init__(self):
        super().__init__()
        self.rows = []
        self.current_row = None
        self.current_cell = None
        self.parts = []

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag == "tr":
            self.current_row = []
        elif tag == "td" and self.current_row is not None:
            self.current_cell = []
            self.parts = []

    def handle_data(self, data):
        if self.current_cell is not None:
            self.parts.append(data)

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag == "td" and self.current_row is not None and self.current_cell is not None:
            value = " ".join("".join(self.parts).split())
            self.current_row.append(value)
            self.current_cell = None
            self.parts = []
        elif tag == "tr" and self.current_row is not None:
            if self.current_row:
                self.rows.append(self.current_row)
            self.current_row = None
            self.current_cell = None
            self.parts = []


def _dashboard_report_rows(html_text):
    parser = _DashboardTableParser()
    parser.feed(html_text or "")
    result = []
    for row in parser.rows:
        # Report SIGA memiliki kolom layout kosong di kiri/kanan.
        row = list(row)
        while row and not row[0].strip():
            row.pop(0)
        while row and not row[-1].strip():
            row.pop()
        # Data Tabel 4A mempunyai kode desa, nama desa, lalu 14 kolom data.
        if len(row) < 15:
            continue
        code = row[0].strip()
        name = row[1].strip()
        if not re.fullmatch(r"\d{3,10}", code):
            continue
        values = row[2:]
        if not any(re.search(r"\d", item or "") for item in values):
            continue
        result.append({
            "village_code": code,
            "village_name": name,
            "bkr_exists": _dashboard_number(values[0]) if len(values) > 0 else 0,
            "bkr_reports": _dashboard_number(values[1]) if len(values) > 1 else 0,
            "bkr_report_percent": float(values[2].replace(",", ".")) if len(values) > 2 and re.fullmatch(r"\d+(?:[.,]\d+)?", values[2].strip()) else 0,
            "pkbr": _dashboard_number(values[3]) if len(values) > 3 else 0,
            "kb_repro": _dashboard_number(values[4]) if len(values) > 4 else 0,
            "other_material": _dashboard_number(values[5]) if len(values) > 5 else 0,
            "meetings": _dashboard_number(values[6]) if len(values) > 6 else 0,
            "face_to_face": _dashboard_number(values[7]) if len(values) > 7 else 0,
            "virtual": _dashboard_number(values[8]) if len(values) > 8 else 0,
            "bkr_families": _dashboard_number(values[9]) if len(values) > 9 else 0,
            "bkr_attended": _dashboard_number(values[10]) if len(values) > 10 else 0,
            "status_pus": _dashboard_number(values[11]) if len(values) > 11 else 0,
            "status_kb": _dashboard_number(values[12]) if len(values) > 12 else 0,
            "pkbr_attended": _dashboard_number(values[13]) if len(values) > 13 else 0,
        })
    return result


def _dashboard_bkr_report(session, bulan, tahun, allowed_villages):
    """Ambil Tabel4A dan batasi hasil sesuai desa akun/user."""
    filter_pencarian = {
        "tahun": str(tahun),
        "bulan": bulan,
        "provinsiId": str(session.province_id),
        "kabupatenId": str(session.regency_id),
        "kecamatanId": str(session.district_id),
        "reportName": "Tabel4A",
        "reportType": "html",
        "reportCategory": "Dallap-Bulanan",
    }
    response = session.get(
        "/report-siga-dallap-ocp/viewReport",
        params={"filterPencarian": __import__("json").dumps(filter_pencarian, separators=(",", ":"))},
        timeout=20,
    )
    response.raise_for_status()

    report_text = response.text
    try:
        decoded = response.json()
        if isinstance(decoded, str):
            report_text = decoded
        elif isinstance(decoded, dict):
            for key in ("data", "html", "content", "result"):
                if isinstance(decoded.get(key), str):
                    report_text = decoded[key]
                    break
    except ValueError:
        pass

    rows = _dashboard_report_rows(report_text)
    allowed_codes = {str(v.code).strip() for v in allowed_villages if v.code}
    allowed_names = {str(v.name).strip().casefold() for v in allowed_villages if v.name}

    filtered = [
        row for row in rows
        if row["village_code"] in allowed_codes
        or row["village_name"].casefold() in allowed_names
    ]

    totals = {
        "bkr_exists": sum(row["bkr_exists"] for row in filtered),
        "bkr_reports": sum(row["bkr_reports"] for row in filtered),
        "meetings": sum(row["meetings"] for row in filtered),
        "face_to_face": sum(row["face_to_face"] for row in filtered),
        "virtual": sum(row["virtual"] for row in filtered),
        "bkr_families": sum(row["bkr_families"] for row in filtered),
        "bkr_attended": sum(row["bkr_attended"] for row in filtered),
        "pkbr_attended": sum(row["pkbr_attended"] for row in filtered),
    }
    totals["attendance_percent"] = (
        round(totals["bkr_attended"] / totals["bkr_families"] * 100, 2)
        if totals["bkr_families"] else 0
    )
    totals["report_percent"] = (
        round(totals["bkr_reports"] / totals["bkr_exists"] * 100, 2)
        if totals["bkr_exists"] else 0
    )
    return totals, filtered



# ============================================================
# POKTAN + KEHADIRAN SIGA
# ============================================================

_DASHBOARD_POKTAN_TABLES = {
    "bkb": {
        "label": "BKB",
        "report": "Tabel3B",
        "attendance_index": 4,
        "meetings_index": 0,
        "member_index": 3,
    },
    "bkr": {
        "label": "BKR",
        "report": "Tabel4A",
        "attendance_index": 10,
        "meetings_index": 6,
        "member_index": 9,
    },
    "bkl": {
        "label": "BKL",
        "report": "Tabel5A",
        "attendance_index": 13,
        "meetings_index": 9,
        "member_index": 12,
    },
    "uppka": {
        "label": "UPPKA",
        "report": "Tabel6B",
        "attendance_index": 4,
        "meetings_index": 0,
        "member_index": 3,
    },
    "pikr": {
        "label": "PIK Remaja",
        "report": "Tabel7A",
        "attendance_index": 6,
        "meetings_index": 3,
        "member_index": 6,
    },
}


def _dashboard_html_report_rows(html_text):
    """Ambil baris report SIGA tanpa mengikat ke satu tabel tertentu."""
    parser = _DashboardTableParser()
    parser.feed(html_text or "")
    result = []
    for row in parser.rows:
        row = list(row)
        while row and not row[0].strip():
            row.pop(0)
        while row and not row[-1].strip():
            row.pop()
        if len(row) < 3:
            continue

        code = row[0].strip()
        name = row[1].strip()
        # Kode desa SIGA umumnya numerik; hindari baris header/subtotal.
        if not re.fullmatch(r"\d{3,15}", code):
            continue

        values = row[2:]
        result.append({
            "village_code": code,
            "village_name": name,
            "values": values,
        })
    return result


def _dashboard_monthly_report(session, table_name, bulan, tahun):
    filter_pencarian = {
        "tahun": str(tahun),
        "bulan": bulan,
        "provinsiId": str(session.province_id),
        "kabupatenId": str(session.regency_id),
        "kecamatanId": str(session.district_id),
        "reportName": table_name,
        "reportType": "html",
        "reportCategory": "Dallap-Bulanan",
    }
    response = session.get(
        "/report-siga-dallap-ocp/viewReport",
        params={
            "filterPencarian": json.dumps(
                filter_pencarian,
                separators=(",", ":"),
            )
        },
        timeout=20,
    )
    response.raise_for_status()

    report_text = response.text
    try:
        decoded = response.json()
        if isinstance(decoded, str):
            report_text = decoded
        elif isinstance(decoded, dict):
            for key in ("data", "html", "content", "result"):
                if isinstance(decoded.get(key), str):
                    report_text = decoded[key]
                    break
    except ValueError:
        pass

    return _dashboard_html_report_rows(report_text)


def _dashboard_attendance_rows(session, jenis, bulan, tahun, allowed_villages):
    cfg = _DASHBOARD_POKTAN_TABLES[jenis]
    rows = _dashboard_monthly_report(
        session,
        cfg["report"],
        bulan,
        tahun,
    )

    allowed_codes = {str(v.code).strip() for v in allowed_villages if v.code}
    allowed_names = {str(v.name).strip().casefold() for v in allowed_villages if v.name}
    filtered = [
        row for row in rows
        if row["village_code"] in allowed_codes
        or row["village_name"].casefold() in allowed_names
    ]

    result = []
    total_meetings = total_members = total_attended = 0
    for row in filtered:
        values = row["values"]
        meetings = _dashboard_number(values[cfg["meetings_index"]]) if len(values) > cfg["meetings_index"] else 0
        members = _dashboard_number(values[cfg["member_index"]]) if len(values) > cfg["member_index"] else 0
        attended = _dashboard_number(values[cfg["attendance_index"]]) if len(values) > cfg["attendance_index"] else 0

        # Untuk tabel 4A/5A, kolom jumlah anggota/hadir memang berada
        # lebih jauh setelah kolom materi; os índices di atas mengikuti
        # struktur laporan mensal resmi.
        total_meetings += meetings
        total_members += members
        total_attended += attended
        result.append({
            "village_code": row["village_code"],
            "village_name": row["village_name"],
            "meetings": meetings,
            "members": members,
            "attended": attended,
            "attendance_percent": (
                round(attended / members * 100, 2)
                if members and jenis != "pikr"
                else 0
            ),
            "percentage_available": bool(members and jenis != "pikr"),
        })

    return {
        "jenis": jenis,
        "label": cfg["label"],
        "report": cfg["report"],
        "meetings": total_meetings,
        "members": total_members,
        "attended": total_attended,
        "attendance_percent": (
            round(total_attended / total_members * 100, 2)
            if total_members and jenis != "pikr"
            else 0
        ),
        "percentage_available": bool(total_members and jenis != "pikr"),
        "villages": result,
    }


def _dashboard_detail_records(payload):
    """Normalisasi payload getDetailPoktanKegiatan menjadi list record."""
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ("data", "content", "result", "results", "rows", "list", "items"):
            value = payload.get(key)
            if isinstance(value, list):
                return value
            if isinstance(value, dict):
                nested = _dashboard_detail_records(value)
                if nested:
                    return nested
    return []


def _dashboard_field(obj, keys):
    if not isinstance(obj, dict):
        return None
    lowered = {str(k).replace("_", "").lower(): v for k, v in obj.items()}
    for key in keys:
        value = lowered.get(key.replace("_", "").lower())
        if value not in (None, ""):
            return value
    return None


def _dashboard_poktan_detail_item(item, village, jenis, tanggal):
    if not isinstance(item, dict):
        return None

    name = _dashboard_field(item, [
        "namaPoktan", "namaKelompok", "namaPoktanKelompok",
        "poktanName", "nama_poktan", "nama",
    ])
    if not name:
        # Kadang payload detail membungkus identitas di object poktan.
        nested = _dashboard_field(item, ["poktan", "kelompok"])
        if isinstance(nested, dict):
            name = _dashboard_field(nested, [
                "namaPoktan", "namaKelompok", "poktanName", "nama"
            ])

    if not name:
        return None

    hadir = _dashboard_field(item, [
        "jumlahHadir", "jumlahPesertaHadir", "pesertaHadir",
        "anggotaHadir", "jumlahAnggotaHadir", "jumlahKeluargaHadir",
        "jumlahRemajaHadir", "hadir",
    ])
    anggota = _dashboard_field(item, [
        "jumlahAnggota", "totalAnggota", "jumlahPeserta",
        "peserta", "jumlahKeluarga", "jumlahAnggotaPoktan",
    ])

    return {
        "nama_poktan": str(name).strip(),
        "jenis": jenis,
        "village_code": str(getattr(village, "code", "") or ""),
        "village_name": str(getattr(village, "name", "") or ""),
        "tanggal_kegiatan": str(
            _dashboard_field(item, [
                "tanggalKegiatan", "tanggal", "tglKegiatan", "date"
            ]) or tanggal
        ),
        "anggota": _dashboard_number(anggota),
        "hadir": _dashboard_number(hadir),
    }


def _dashboard_poktan_names(session, jenis, bulan, tahun, allowed_villages, attendance_villages):
    """
    Ambil nama poktan yang mempunyai kegiatan pada periode.
    Endpoint detail SIGA yang dipakai:
    /poktan/siga/poktan/getDetailPoktanKegiatan
    """
    # Baca jumlah pertemuan dari report agar pencarian tanggal bisa berhenti
    # setelah jumlah kegiatan yang dilaporkan tercapai.
    target_by_village = {
        str(row["village_code"]): int(row.get("meetings") or 0)
        for row in attendance_villages
    }

    days = calendar.monthrange(tahun, bulan)[1]
    api = BaseApiSync(None, session)
    found = {}

    for village in allowed_villages:
        village_code = str(getattr(village, "code", "") or "").strip()
        target = target_by_village.get(village_code, 0)
        if target <= 0:
            continue

        # SIGA menerima tanggal DD-MM-YYYY, sesuai endpoint yang dipakai
        # pada integrasi SIGA.
        for day in range(1, days + 1):
            tanggal = f"{day:02d}-{bulan:02d}-{tahun}"
            try:
                response = api.session.get(
                    "/poktan/siga/poktan/getDetailPoktanKegiatan",
                    params={
                        "id": village_code,
                        "tanggalKegiatan": tanggal,
                        "jenisPoktan": jenis,
                    },
                    timeout=12,
                )
                if response.status_code == 404:
                    continue
                response.raise_for_status()
                payload = response.json()
            except Exception:
                continue

            records = _dashboard_detail_records(payload)
            for item in records:
                normalized = _dashboard_poktan_detail_item(
                    item, village, jenis, tanggal
                )
                if normalized:
                    key = (
                        normalized["village_code"],
                        normalized["nama_poktan"],
                        normalized["tanggal_kegiatan"],
                    )
                    found[key] = normalized

            # Jika jumlah record kegiatan yang ditemukan sudah memenuhi
            # jumlah pertemuan pada report, lanjut ke desa berikutnya.
            village_found = sum(
                1 for key in found
                if key[0] == village_code
            )
            if village_found >= target:
                break

    return sorted(
        found.values(),
        key=lambda row: (
            row["village_name"],
            row["nama_poktan"],
            row["tanggal_kegiatan"],
        ),
    )



@router.get(
    "/siga-poktan-attendance",
    summary="Rekap kehadiran seluruh Poktan SIGA",
)
def dashboard_siga_poktan_attendance(
    bulan: int | None = None,
    tahun: int | None = None,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Rekap bulanan BKB, BKR, BKL, UPPKA dan PIK Remaja."""
    role = get_role_name(current_user)
    if role not in "Anda tidak memiliki akses dashboard SIGA":
        raise HTTPException(
            status_code=403,
            detail="Data kehadiran Poktan ini hanya untuk PKB dan ADMIN Kecamatan.",
        )

    account = get_siga_account(db, current_user)
    villages = _dashboard_scope_villages(db, current_user, account)
    if not villages:
        raise HTTPException(
            status_code=404,
            detail="Belum ada desa SIGA yang sesuai dengan akun/hak akses user.",
        )

    bulan = bulan or datetime.now().month
    tahun = tahun or datetime.now().year
    if not 1 <= bulan <= 12:
        raise HTTPException(status_code=400, detail="Bulan harus 1-12.")
    if not 2000 <= tahun <= 2100:
        raise HTTPException(status_code=400, detail="Tahun tidak valid.")

    session = None
    try:
        session = _dashboard_login(db, account)
        items = []
        for jenis in ("bkb", "bkr", "bkl", "uppka", "pikr"):
            items.append(
                _dashboard_attendance_rows(
                    session,
                    jenis,
                    bulan,
                    tahun,
                    villages,
                )
            )

        return {
            "generated_at": datetime.now().isoformat(),
            "period": {"bulan": bulan, "tahun": tahun},
            "scope": {
                "village_count": len(villages),
                "village_names": [v.name for v in villages],
            },
            "items": items,
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Rekap kehadiran Poktan SIGA tidak dapat dimuat: {exc}",
        ) from exc
    finally:
        if session is not None:
            try:
                session.close()
            except Exception:
                pass


@router.get(
    "/siga-poktan",
    summary="Kehadiran Poktan BKB, BKR, BKL, UPPKA dan PIK Remaja",
)
def dashboard_siga_poktan(
    jenis: str = "bkb",
    bulan: int | None = None,
    tahun: int | None = None,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    role = get_role_name(current_user)
    if role not in {"PKB", "ADMIN", "SUPERADMIN"}:
        raise HTTPException(
            status_code=403,
            detail="Data Poktan SIGA ini hanya untuk PKB dan ADMIN Kecamatan.",
        )

    jenis = (jenis or "").strip().lower().replace("-", "")
    if jenis not in _DASHBOARD_POKTAN_TABLES:
        raise HTTPException(
            status_code=400,
            detail="Jenis Poktan harus bkb, bkr, bkl, uppka, atau pikr.",
        )

    account = get_siga_account(db, current_user)
    villages = _dashboard_scope_villages(db, current_user, account)
    if not villages:
        raise HTTPException(
            status_code=404,
            detail="Belum ada desa SIGA yang sesuai dengan akun/hak akses user.",
        )

    bulan = bulan or datetime.now().month
    tahun = tahun or datetime.now().year
    if not 1 <= bulan <= 12:
        raise HTTPException(status_code=400, detail="Bulan harus 1-12.")
    if not 2000 <= tahun <= 2100:
        raise HTTPException(status_code=400, detail="Tahun tidak valid.")

    session = None
    try:
        session = _dashboard_login(db, account)
        attendance = _dashboard_attendance_rows(
            session, jenis, bulan, tahun, villages
        )
        names = _dashboard_poktan_names(
            session,
            jenis,
            bulan,
            tahun,
            villages,
            attendance["villages"],
        )
        return {
            "generated_at": datetime.now().isoformat(),
            "period": {"bulan": bulan, "tahun": tahun},
            "jenis": jenis,
            "label": _DASHBOARD_POKTAN_TABLES[jenis]["label"],
            "scope": {
                "village_count": len(villages),
                "village_names": [v.name for v in villages],
            },
            "attendance": attendance,
            "poktan": names,
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Data {jenis.upper()} SIGA tidak dapat dimuat: {exc}",
        ) from exc
    finally:
        if session is not None:
            try:
                session.close()
            except Exception:
                pass


@router.get(
    "/siga-stats",
    summary="Dashboard SIGA PKB/Admin",
)
def dashboard_siga_stats(
    bulan: int | None = None,
    tahun: int | None = None,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    role = get_role_name(current_user)
    if role not in {"PKB", "ADMIN", "SUPERADMIN"}:
        raise HTTPException(
            status_code=403,
            detail="Dashboard SIGA ini hanya untuk PKB dan ADMIN Kecamatan.",
        )

    account = get_siga_account(db, current_user)
    villages = _dashboard_scope_villages(db, current_user, account)
    if not villages:
        raise HTTPException(
            status_code=404,
            detail="Belum ada desa SIGA yang sesuai dengan akun/hak akses user.",
        )

    bulan = bulan or datetime.now().month
    tahun = tahun or datetime.now().year
    if not 1 <= bulan <= 12:
        raise HTTPException(status_code=400, detail="Bulan harus 1-12.")
    if not 2000 <= tahun <= 2100:
        raise HTTPException(status_code=400, detail="Tahun tidak valid.")

    session = None
    try:
        session = _dashboard_login(db, account)

        village_data = []
        kb_totals = {}
        total = {
            "total_family": 0,
            "total_member": 0,
            "total_pus": 0,
            "total_pregnant": 0,
            "total_unmet_need": 0,
            "pus_not_kb": 0,
            "ingin_anak": 0,
            "ingin_anak_ditunda": 0,
            "tidak_ingin_anak_lagi": 0,
            "poktan_target": 0,
            "bkb_target": 0,
            "bkr_target": 0,
            "bkl_target": 0,
            "bkb_participation": 0,
            "bkr_participation": 0,
            "bkl_participation": 0,
            "uppka_participation": 0,
            "poktan_participation": 0,
        }

        for village in villages:
            sid = str(village.siga_id)
            summary = _dashboard_summary_for_village(session, sid, bulan, tahun)
            item = {
                "village_id": str(village.id),
                "village_name": village.name,
                "village_code": village.code,
                "siga_id": sid,
                "total_family": _dashboard_number(summary.get("jumlahKeluarga")),
                "total_member": _dashboard_number(summary.get("jumlahJiwa")),
                "total_pus": _dashboard_number(summary.get("jumlahPus")),
                "total_pregnant": _dashboard_number(summary.get("jumlahWanitaHamil")),
                "total_unmet_need": _dashboard_number(summary.get("jumlahUnmetNeed")),
                "pus_not_kb": _dashboard_number(summary.get("pusBukanPesertaKb")),
                "ingin_anak": _dashboard_number(summary.get("inginAnak")),
                "ingin_anak_ditunda": _dashboard_number(summary.get("inginAnakDitunda")),
                "tidak_ingin_anak_lagi": _dashboard_number(summary.get("tidakInginAnakLagi")),
                "poktan_target": _dashboard_number(summary.get("sasaranPoktan")),
                "bkb_target": _dashboard_number(summary.get("jumlahSasaranBkb")),
                "bkr_target": _dashboard_number(summary.get("jumlahSasaranBkr")),
                "bkl_target": _dashboard_number(summary.get("jumlahSasaranBkl")),
                "bkb_participation": _dashboard_number(summary.get("jumlahKesertaanBkb")),
                "bkr_participation": _dashboard_number(summary.get("jumlahKesertaanBkr")),
                "bkl_participation": _dashboard_number(summary.get("jumlahKesertaanBkl")),
                "uppka_participation": _dashboard_number(summary.get("jumlahKesertaanUppka")),
                "poktan_participation": _dashboard_number(summary.get("kesertaanPoktan")),
            }
            for key in total:
                total[key] += item[key]

            kb_rows = _dashboard_kb_for_village(session, sid, bulan, tahun)
            village_kb = []
            for kb in kb_rows:
                method = str(kb.get("metodeKontrasepsi") or "LAINNYA").strip().upper()
                row = {
                    "metode_kontrasepsi": method,
                    "pemerintah": _dashboard_number(kb.get("pemerintah")),
                    "swasta": _dashboard_number(kb.get("swasta")),
                    "lainnya": _dashboard_number(kb.get("lainnya")),
                    "jumlah": _dashboard_number(kb.get("jumlah")),
                }
                village_kb.append(row)
                if method not in kb_totals:
                    kb_totals[method] = {"pemerintah": 0, "swasta": 0, "lainnya": 0, "jumlah": 0}
                for key in ("pemerintah", "swasta", "lainnya", "jumlah"):
                    kb_totals[method][key] += row[key]

            item["kb_aktif"] = village_kb
            village_data.append(item)

        bkr_totals, bkr_villages = _dashboard_bkr_report(
            session, bulan, tahun, villages
        )

        return {
            "generated_at": datetime.now().isoformat(),
            "period": {"bulan": bulan, "tahun": tahun},
            "role": role,
            "username_user": get_current_username(current_user),
            "username_siga": account.username,
            "siga_account_id": str(account.id),
            "wilayah": {
                "siga_province_id": account.siga_province_id,
                "siga_regency_id": account.siga_regency_id,
                "siga_district_id": account.siga_district_id,
            },
            "scope": {
                "village_count": len(villages),
                "village_names": [v.name for v in villages],
            },
            "totals": total,
            "kb_aktif": [
                {"metode_kontrasepsi": method, **values}
                for method, values in sorted(kb_totals.items())
            ],
            "bkr": {
                "bkr_exists": bkr_totals["bkr_exists"],
                "bkr_reports": bkr_totals["bkr_reports"],
                "report_percent": bkr_totals["report_percent"],
                "meetings": bkr_totals["meetings"],
                "face_to_face": bkr_totals["face_to_face"],
                "virtual": bkr_totals["virtual"],
                "bkr_families": bkr_totals["bkr_families"],
                "bkr_attended": bkr_totals["bkr_attended"],
                "attendance_percent": bkr_totals["attendance_percent"],
                "pkbr_attended": bkr_totals["pkbr_attended"],
                "villages": bkr_villages,
            },
            "villages": village_data,
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Data SIGA tidak dapat dimuat untuk akun '{account.username}': {exc}",
        ) from exc
    finally:
        if session is not None:
            try:
                session.close()
            except Exception:
                pass


# ============================================================
# DASHBOARD REKAP SIGA (SNAPSHOT HASIL SYNC)
# ============================================================

@router.get(
    "/siga-recap",
    summary="Rekap hasil sinkronisasi SIGA sesuai akun",
)
def dashboard_siga_recap(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """Rekap snapshot lokal yang hanya mengambil desa dalam scope akun SIGA user."""
    role = get_role_name(current_user)
    if role not in {"PKB", "ADMIN", "SUPERADMIN"}:
        raise HTTPException(
            status_code=403,
            detail="Rekap SIGA ini hanya untuk PKB dan ADMIN Kecamatan.",
        )

    account = get_siga_account(db, current_user)
    villages = _dashboard_scope_villages(db, current_user, account)

    rows = []
    total_family = total_member = matched = unmatched = 0

    for village in villages:
        family_count = (
            db.query(func.count(Family.id))
            .filter(Family.village_id == village.id)
            .scalar()
            or 0
        )
        member_count = (
            db.query(func.count(FamilyMember.id))
            .join(Family, FamilyMember.family_id == Family.id)
            .filter(Family.village_id == village.id)
            .scalar()
            or 0
        )
        matched_count = (
            db.query(func.count(FamilyMember.id))
            .join(Family, FamilyMember.family_id == Family.id)
            .filter(
                Family.village_id == village.id,
                FamilyMember.is_matched.is_(True),
            )
            .scalar()
            or 0
        )
        unmatched_count = (
            db.query(func.count(FamilyMember.id))
            .join(Family, FamilyMember.family_id == Family.id)
            .filter(
                Family.village_id == village.id,
                FamilyMember.is_matched.is_(False),
            )
            .scalar()
            or 0
        )

        total_family += family_count
        total_member += member_count
        matched += matched_count
        unmatched += unmatched_count

        rows.append({
            "village_id": str(village.id),
            "village_name": village.name,
            "village_code": village.code,
            "siga_id": str(village.siga_id) if village.siga_id else None,
            "district_id": str(village.district_id),
            "total_family": int(family_count),
            "total_member": int(member_count),
            "matched": int(matched_count),
            "unmatched": int(unmatched_count),
        })

    return {
        "generated_at": datetime.now().isoformat(),
        "last_sync_at": account.last_sync_at.isoformat() if account.last_sync_at else None,
        "siga_account_count": 1,
        "totals": {
            "village": len(villages),
            "total_family": int(total_family),
            "total_member": int(total_member),
            "matched": int(matched),
            "unmatched": int(unmatched),
        },
        "villages": rows,
    }
