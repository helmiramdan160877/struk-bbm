from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import require_roles
from app.platform.permissions.repository import PermissionRepository
from app.platform.permissions.service import PermissionService
from app.schemas.permission import (
    PermissionCreate,
    PermissionUpdate,
    PermissionResponse,
)

router = APIRouter()


@router.get("/", response_model=list[PermissionResponse])
def get_permissions(
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = PermissionRepository(db)
    service = PermissionService(repository)

    return service.get_all_permissions()


@router.get("/{permission_id}", response_model=PermissionResponse)
def get_permission(
    permission_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = PermissionRepository(db)
    service = PermissionService(repository)

    permission = service.get_permission_by_id(permission_id)

    if permission is None:
        raise HTTPException(
            status_code=404,
            detail="Permission tidak ditemukan",
        )

    return permission


@router.post("/", response_model=PermissionResponse)
def create_permission(
    data: PermissionCreate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    repository = PermissionRepository(db)
    service = PermissionService(repository)

    try:
        return service.create_permission(
            name=data.name,
            description=data.description,
        )
    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


@router.put("/{permission_id}", response_model=PermissionResponse)
def update_permission(
    permission_id: UUID,
    data: PermissionUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    repository = PermissionRepository(db)
    service = PermissionService(repository)

    permission = service.get_permission_by_id(permission_id)

    if permission is None:
        raise HTTPException(
            status_code=404,
            detail="Permission tidak ditemukan",
        )

    return service.update_permission(
        permission=permission,
        name=data.name,
        description=data.description,
        is_active=data.is_active,
    )


@router.delete("/{permission_id}")
def delete_permission(
    permission_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    repository = PermissionRepository(db)
    service = PermissionService(repository)

    permission = service.get_permission_by_id(permission_id)

    if permission is None:
        raise HTTPException(
            status_code=404,
            detail="Permission tidak ditemukan",
        )

    service.delete_permission(permission)

    return {
        "message": "Permission berhasil dihapus"
    }