from datetime import date, datetime, timezone
from decimal import Decimal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session, joinedload

from app.api.deps import get_db
from app.models.iuran import IuranPayment, IuranSetting
from app.models.pkb import PKB
from app.models.role import Role
from app.models.user import User
from app.platform.auth.dependencies import get_current_user, require_roles
from app.schemas.iuran import (
    IuranMemberSummary,
    IuranMonthStatus,
    IuranMySummary,
    IuranPaymentCreate,
    IuranPaymentResponse,
    IuranSettingResponse,
    IuranSettingUpsert,
)
from app.services.iuran_notification_service import chargeable_month, jakarta_today

router = APIRouter(tags=["Kas & Iuran IPKB"])

MONTHS = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember",
]

MANAGER_ROLES = ("BENDAHARA", "ADMIN")
VIEW_ALL_ROLES = ("BENDAHARA", "ADMIN", "PENGURUS")


def _role_name(user: User) -> str:
    return ((user.role.name if user.role else "") or "").strip().upper()


def _get_setting(db: Session, year: int) -> IuranSetting | None:
    return db.query(IuranSetting).filter(IuranSetting.year == year).first()


def _monthly_amount(db: Session, year: int) -> Decimal:
    setting = _get_setting(db, year)
    return Decimal(setting.monthly_amount) if setting and setting.is_active else Decimal("0")


def _build_summary(db: Session, user: User, year: int, through_month_override: int | None = None) -> IuranMySummary:
    monthly = _monthly_amount(db, year)
    through_month = min(chargeable_month(year), through_month_override) if through_month_override else chargeable_month(year)
    payments = (
        db.query(IuranPayment)
        .filter(
            IuranPayment.user_id == user.id,
            IuranPayment.year == year,
            IuranPayment.status == "VERIFIED",
        )
        .all()
    )
    by_month = {p.month: p for p in payments}
    months: list[IuranMonthStatus] = []
    total_paid_chargeable = Decimal("0")
    paid_months_chargeable = 0

    for month in range(1, 13):
        payment = by_month.get(month)
        paid = Decimal(payment.amount) if payment else Decimal("0")
        chargeable = month <= through_month
        if chargeable:
            total_paid_chargeable += paid

        if not chargeable:
            status = "BELUM DITAGIH"
        elif payment:
            status = "LUNAS" if paid >= monthly else "KURANG"
        else:
            status = "BELUM BAYAR"

        if chargeable and status == "LUNAS":
            paid_months_chargeable += 1

        months.append(
            IuranMonthStatus(
                month=month,
                month_name=MONTHS[month - 1],
                expected_amount=monthly if chargeable else Decimal("0"),
                paid_amount=paid,
                status=status,
                paid_at=payment.paid_at if payment else None,
                payment_method=payment.payment_method if payment else None,
                reference_no=payment.reference_no if payment else None,
            )
        )

    total_expected = monthly * through_month
    total_outstanding = max(total_expected - total_paid_chargeable, Decimal("0"))
    unpaid_months = max(through_month - paid_months_chargeable, 0)

    return IuranMySummary(
        year=year,
        monthly_amount=monthly,
        total_expected=total_expected,
        total_paid=total_paid_chargeable,
        total_outstanding=total_outstanding,
        paid_months=paid_months_chargeable,
        unpaid_months=unpaid_months,
        charged_through_month=through_month,
        charged_through_month_name=MONTHS[through_month - 1] if through_month else None,
        months=months,
    )


@router.get("/me", response_model=IuranMySummary)
def my_iuran(
    year: int = Query(default=jakarta_today().year, ge=2020, le=2100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _build_summary(db, current_user, year)


@router.get("/settings/{year}", response_model=IuranSettingResponse | None)
def get_setting(
    year: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _get_setting(db, year)


@router.put("/settings/{year}", response_model=IuranSettingResponse)
def upsert_setting(
    year: int,
    payload: IuranSettingUpsert,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGER_ROLES)),
):
    if payload.year != year:
        raise HTTPException(status_code=400, detail="Tahun pada URL dan payload harus sama")

    setting = _get_setting(db, year)
    if setting is None:
        setting = IuranSetting(year=year, monthly_amount=payload.monthly_amount, due_day=25, is_active=True)
        db.add(setting)
    else:
        setting.monthly_amount = payload.monthly_amount
        # Penagihan otomatis ditetapkan tanggal 25 sesuai kebijakan aplikasi.
        setting.due_day = 25
        setting.is_active = True

    db.commit()
    db.refresh(setting)
    return setting


@router.get("/members", response_model=list[IuranMemberSummary])
def members_summary(
    year: int = Query(default=jakarta_today().year, ge=2020, le=2100),
    month: int | None = Query(default=None, ge=1, le=12),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*VIEW_ALL_ROLES)),
):
    members = (
        db.query(PKB, User)
        .outerjoin(User, User.pkb_id == PKB.id)
        .outerjoin(Role, User.role_id == Role.id)
        .filter(PKB.status == "AKTIF")
        .filter((User.id.is_(None)) | ((Role.name == "ANGGOTA") & User.is_active.is_(True)))
        .order_by(PKB.nama.asc())
        .all()
    )

    result: list[IuranMemberSummary] = []
    through_month = min(chargeable_month(year), month) if month else chargeable_month(year)
    monthly = _monthly_amount(db, year)
    for pkb, member in members:
        summary = _build_summary(db, member, year, month) if member else None
        result.append(
            IuranMemberSummary(
                user_id=member.id if member else None,
                pkb_id=pkb.id,
                full_name=pkb.nama,
                username=member.username if member else pkb.nip,
                nip=pkb.nip,
                phone=member.phone if member else pkb.phone,
                year=year,
                total_expected=summary.total_expected if summary else monthly * through_month,
                total_paid=summary.total_paid if summary else 0,
                total_outstanding=summary.total_outstanding if summary else monthly * through_month,
                paid_months=summary.paid_months if summary else 0,
                unpaid_months=summary.unpaid_months if summary else through_month,
            )
        )
    return result


@router.get("/member/{user_id}", response_model=IuranMySummary)
def member_detail(
    user_id: UUID,
    year: int = Query(default=jakarta_today().year, ge=2020, le=2100),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*VIEW_ALL_ROLES)),
):
    user = db.query(User).options(joinedload(User.role)).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="Anggota tidak ditemukan")
    if _role_name(user) != "ANGGOTA":
        raise HTTPException(status_code=400, detail="User yang dipilih bukan role ANGGOTA")
    return _build_summary(db, user, year)


@router.post("/payments", response_model=IuranPaymentResponse)
def record_payment(
    payload: IuranPaymentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGER_ROLES)),
):
    member = db.query(User).options(joinedload(User.role)).filter(User.id == payload.user_id).first()
    if member is None:
        raise HTTPException(status_code=404, detail="Anggota tidak ditemukan")
    if _role_name(member) != "ANGGOTA":
        raise HTTPException(status_code=400, detail="Pembayaran iuran hanya untuk role ANGGOTA")

    current_chargeable = chargeable_month(payload.year)
    if payload.month > current_chargeable:
        raise HTTPException(status_code=400, detail="Bulan tersebut belum masuk periode tagihan")

    existing = (
        db.query(IuranPayment)
        .filter(
            IuranPayment.user_id == payload.user_id,
            IuranPayment.year == payload.year,
            IuranPayment.month == payload.month,
        )
        .first()
    )
    if existing:
        raise HTTPException(status_code=409, detail="Iuran bulan tersebut sudah tercatat")

    amount = payload.amount if payload.amount is not None else _monthly_amount(db, payload.year)
    if Decimal(amount) <= 0:
        raise HTTPException(status_code=400, detail="Nominal iuran belum diatur atau jumlah pembayaran tidak valid")

    payment = IuranPayment(
        user_id=payload.user_id,
        year=payload.year,
        month=payload.month,
        amount=amount,
        paid_at=payload.paid_at or jakarta_today(),
        payment_method=(payload.payment_method or "TUNAI").upper(),
        reference_no=payload.reference_no,
        notes=payload.notes,
        status="VERIFIED",
        verified_by_user_id=current_user.id,
        verified_at=datetime.now(timezone.utc),
    )
    db.add(payment)
    db.commit()
    db.refresh(payment)
    return payment


@router.delete("/payments/{payment_id}")
def delete_payment(
    payment_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles(*MANAGER_ROLES)),
):
    payment = db.query(IuranPayment).filter(IuranPayment.id == payment_id).first()
    if payment is None:
        raise HTTPException(status_code=404, detail="Pembayaran tidak ditemukan")
    db.delete(payment)
    db.commit()
    return {"success": True, "message": "Pembayaran iuran berhasil dihapus"}
