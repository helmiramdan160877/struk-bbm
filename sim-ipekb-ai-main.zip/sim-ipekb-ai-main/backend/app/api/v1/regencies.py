from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import require_roles
from app.platform.regencies.repository import RegencyRepository
from app.platform.regencies.service import RegencyService
from app.schemas.regency import (
    RegencyCreate,
    RegencyUpdate,
    RegencyResponse,
)

router = APIRouter()


@router.get("/", response_model=list[RegencyResponse])
def get_regencies(
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PENGURUS", "PKB", "KADER", "OPERATOR", "BENDAHARA", "PIMPINAN", "VIEWER", "ANGGOTA")),
):
    repository = RegencyRepository(db)
    service = RegencyService(repository)

    return service.get_all_regencies()


@router.get("/{regency_id}", response_model=RegencyResponse)
def get_regency(
    regency_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN", "PENGURUS", "PKB", "KADER", "OPERATOR", "BENDAHARA", "PIMPINAN", "VIEWER", "ANGGOTA")),
):
    repository = RegencyRepository(db)
    service = RegencyService(repository)

    regency = service.get_regency_by_id(regency_id)

    if regency is None:
        raise HTTPException(
            status_code=404,
            detail="Kabupaten/Kota tidak ditemukan",
        )

    return regency


@router.post("/", response_model=RegencyResponse)
def create_regency(
    data: RegencyCreate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = RegencyRepository(db)
    service = RegencyService(repository)

    try:
        return service.create_regency(
            province_id=data.province_id,
            code=data.code,
            name=data.name,
        )
    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


@router.put("/{regency_id}", response_model=RegencyResponse)
def update_regency(
    regency_id: UUID,
    data: RegencyUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = RegencyRepository(db)
    service = RegencyService(repository)

    regency = service.get_regency_by_id(regency_id)

    if regency is None:
        raise HTTPException(
            status_code=404,
            detail="Kabupaten/Kota tidak ditemukan",
        )

    return service.update_regency(
        regency=regency,
        province_id=data.province_id,
        code=data.code,
        name=data.name,
        is_active=data.is_active,
    )


@router.delete("/{regency_id}")
def delete_regency(
    regency_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = RegencyRepository(db)
    service = RegencyService(repository)

    regency = service.get_regency_by_id(regency_id)

    if regency is None:
        raise HTTPException(
            status_code=404,
            detail="Kabupaten/Kota tidak ditemukan",
        )

    service.delete_regency(regency)

    return {
        "message": "Kabupaten/Kota berhasil dihapus"
    }