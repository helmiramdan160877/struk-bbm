from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import require_roles
from app.platform.roles.repository import RoleRepository
from app.platform.roles.service import RoleService
from app.schemas.role import (
    RoleCreate,
    RoleUpdate,
    RoleResponse,
)

router = APIRouter()


# =====================================================
# GET ALL
# =====================================================

@router.get("/", response_model=list[RoleResponse])
def get_roles(
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = RoleRepository(db)
    service = RoleService(repository)

    return service.get_all_roles()


# =====================================================
# GET BY ID
# =====================================================

@router.get("/{role_id}", response_model=RoleResponse)
def get_role(
    role_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("ADMIN")),
):
    repository = RoleRepository(db)
    service = RoleService(repository)

    role = service.get_role_by_id(role_id)

    if role is None:
        raise HTTPException(
            status_code=404,
            detail="Role tidak ditemukan",
        )

    return role


# =====================================================
# CREATE
# =====================================================

@router.post("/", response_model=RoleResponse)
def create_role(
    data: RoleCreate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    repository = RoleRepository(db)
    service = RoleService(repository)

    try:
        return service.create_role(
            name=data.name,
            description=data.description,
        )

    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


# =====================================================
# UPDATE
# =====================================================

@router.put("/{role_id}", response_model=RoleResponse)
def update_role(
    role_id: UUID,
    data: RoleUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    repository = RoleRepository(db)
    service = RoleService(repository)

    role = service.get_role_by_id(role_id)

    if role is None:
        raise HTTPException(
            status_code=404,
            detail="Role tidak ditemukan",
        )

    try:
        return service.update_role(
            role=role,
            name=data.name,
            description=data.description,
            is_active=data.is_active,
        )

    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail=str(e),
        )


# =====================================================
# ACTIVATE
# =====================================================

@router.patch("/{role_id}/activate")
def activate_role(
    role_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    repository = RoleRepository(db)
    service = RoleService(repository)

    role = service.get_role_by_id(role_id)

    if role is None:
        raise HTTPException(
            status_code=404,
            detail="Role tidak ditemukan",
        )

    service.activate(role)

    return {
        "success": True,
        "message": "Role berhasil diaktifkan",
    }


# =====================================================
# DEACTIVATE
# =====================================================

@router.patch("/{role_id}/deactivate")
def deactivate_role(
    role_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    repository = RoleRepository(db)
    service = RoleService(repository)

    role = service.get_role_by_id(role_id)

    if role is None:
        raise HTTPException(
            status_code=404,
            detail="Role tidak ditemukan",
        )

    service.deactivate(role)

    return {
        "success": True,
        "message": "Role berhasil dinonaktifkan",
    }


# =====================================================
# DELETE
# =====================================================

@router.delete("/{role_id}")
def delete_role(
    role_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    repository = RoleRepository(db)
    service = RoleService(repository)

    role = service.get_role_by_id(role_id)

    if role is None:
        raise HTTPException(
            status_code=404,
            detail="Role tidak ditemukan",
        )

    service.delete_role(role)

    return {
        "success": True,
        "message": "Role berhasil dihapus",
    }