import logging
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.models.user_village import UserVillage
from app.models.village import Village
from app.platform.auth.dependencies import require_roles
from app.platform.siga_accounts.scope import (
    get_accessible_siga_accounts,
    get_role_name,
)
from app.repositories.siga_account_repository import SigaAccountRepository
from app.sync.base_sync import BaseSync
from app.sync.manager import SyncManager
from app.sync.member_sync import MemberSync


router = APIRouter()
logger = logging.getLogger(__name__)


# ============================================================
# HELPER
# ============================================================

def _assert_sync_scope(
    db: Session,
    current_user,
    username_siga: str,
):
    """
    Memastikan akun SIGA yang digunakan memang berada
    dalam wilayah akses user yang sedang login.
    """

    username_siga = str(username_siga or "").strip()

    if not username_siga:
        raise HTTPException(
            status_code=400,
            detail="username_siga wajib diisi.",
        )

    repo = SigaAccountRepository(db)

    account = repo.get_by_username(username_siga)

    if account is None:
        raise HTTPException(
            status_code=404,
            detail=(
                f"Akun SIGA '{username_siga}' "
                "belum terdaftar."
            ),
        )

    allowed_ids = {
        item.id
        for item in get_accessible_siga_accounts(
            db,
            current_user,
            active_only=True,
        )
    }

    if account.id not in allowed_ids:
        raise HTTPException(
            status_code=403,
            detail=(
                "Akun SIGA berada di luar wilayah "
                "akses Anda atau sedang nonaktif."
            ),
        )

    return account


def _get_sync_village_siga_ids(db: Session, current_user, account) -> list[str]:
    """Return the exact SIGA villages that this sync is allowed to pull."""
    role_name = get_role_name(current_user)

    query = (
        db.query(Village.siga_id)
        .filter(
            Village.is_active.is_(True),
            Village.district_id == account.district_id,
            Village.siga_id.isnot(None),
        )
    )

    if role_name in {"PKB", "KADER", "PPKBD", "ANGGOTA"}:
        query = (
            query
            .join(UserVillage, UserVillage.village_id == Village.id)
            .filter(UserVillage.user_id == current_user.id)
        )

    return [str(row[0]) for row in query.distinct().all() if row[0] is not None]


# ============================================================
# REQUEST SYNC PENUH
# ============================================================

class SyncRequest(BaseModel):
    username_siga: str
    password_siga: str
    bulan: int | None = None
    tahun: int | None = None


# ============================================================
# REQUEST SYNC ANGGOTA
# ============================================================

class MemberSyncRequest(BaseModel):
    username_siga: str
    password_siga: str
    bulan: int | None = None
    tahun: int | None = None


# ============================================================
# REQUEST TEST 1 KK
# ============================================================

class MemberTestRequest(BaseModel):
    username_siga: str
    password_siga: str


# ============================================================
# SYNC FULL
# ============================================================

@router.post(
    "/run",
    summary="Run Full SIGA Sync",
    description=(
        "Sinkronisasi penuh SIGA: "
        "wilayah, kepala keluarga, dan anggota keluarga."
    ),
)
def run_sync(
    request: SyncRequest,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN", "PKB", "OPERATOR")
    ),
):
    """
    Sinkronisasi penuh:

        Login SIGA
            ↓
        RegionSync
            ↓
        ParentSync
            ↓
        MemberSync
    """

    now = datetime.now()

    bulan = request.bulan or now.month
    tahun = request.tahun or now.year

    # ========================================================
    # VALIDASI PERIODE
    # ========================================================

    if bulan < 1 or bulan > 12:
        raise HTTPException(
            status_code=400,
            detail="Bulan harus antara 1 sampai 12.",
        )

    if tahun < 2000 or tahun > 2100:
        raise HTTPException(
            status_code=400,
            detail="Tahun tidak valid.",
        )

    # ========================================================
    # VALIDASI AKUN SIGA
    # ========================================================

    account = _assert_sync_scope(
        db,
        current_user,
        request.username_siga,
    )

    village_siga_ids = _get_sync_village_siga_ids(
        db, current_user, account
    )

    if not village_siga_ids:
        raise HTTPException(
            status_code=400,
            detail="Tidak ada desa binaan SIGA yang aktif untuk disinkronkan.",
        )

    # ========================================================
    # JALANKAN SYNC MANAGER
    # ========================================================

    manager = SyncManager(db)

    try:
        return manager.run(
            username_siga=request.username_siga.strip(),
            password_siga=request.password_siga,
            bulan=bulan,
            tahun=tahun,
            village_siga_ids=village_siga_ids,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Sinkronisasi SIGA gagal")
        raise HTTPException(
            status_code=502,
            detail=f"Sinkronisasi SIGA gagal: {exc}",
        ) from exc


# ============================================================
# SYNC ANGGOTA SAJA
# ============================================================

@router.post(
    "/members",
    summary="Run Member Sync Only",
    description=(
        "Sinkronisasi anggota keluarga langsung dari SIGA "
        "menggunakan endpoint childRekapPK. "
        "Tidak menjalankan RegionSync atau ParentSync."
    ),
)
def run_member_sync(
    request: MemberSyncRequest,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN", "PKB", "OPERATOR")
    ),
):
    """
    Sinkronisasi anggota keluarga saja.

    Alur:

        Login SIGA
            ↓
        Ambil akun SIGA
            ↓
        Ambil district_id
            ↓
        Ambil Family dari PostgreSQL
            ↓
        childRekapPK
            ↓
        Simpan ke family_members
    """

    # ========================================================
    # PERIODE
    # ========================================================

    now = datetime.now()

    bulan = request.bulan or now.month
    tahun = request.tahun or now.year

    if bulan < 1 or bulan > 12:
        raise HTTPException(
            status_code=400,
            detail="Bulan harus antara 1 sampai 12.",
        )

    if tahun < 2000 or tahun > 2100:
        raise HTTPException(
            status_code=400,
            detail="Tahun tidak valid.",
        )

    # ========================================================
    # AKUN SIGA
    # ========================================================

    account = _assert_sync_scope(
        db,
        current_user,
        request.username_siga,
    )

    village_siga_ids = _get_sync_village_siga_ids(
        db, current_user, account
    )

    if not village_siga_ids:
        raise HTTPException(
            status_code=400,
            detail="Tidak ada desa binaan SIGA yang aktif untuk disinkronkan.",
        )

    # ========================================================
    # CEK AKTIF
    # ========================================================

    if not account.is_active:
        raise HTTPException(
            status_code=403,
            detail=(
                f"Akun SIGA '{request.username_siga}' "
                "tidak aktif."
            ),
        )

    # ========================================================
    # CEK WILAYAH
    # ========================================================

    if account.district_id is None:
        raise HTTPException(
            status_code=400,
            detail=(
                "Akun SIGA belum memiliki "
                "district_id wilayah binaan."
            ),
        )

    # ========================================================
    # LOGIN SIGA
    # ========================================================

    base_sync = BaseSync(db)

    session = None

    try:

        session = base_sync.login(
            username=request.username_siga.strip(),
            password=request.password_siga,
        )

        # ====================================================
        # MEMBER SYNC
        # ====================================================

        member_sync = MemberSync(
            db,
            session,
        )

        result = member_sync.run(
            bulan=bulan,
            tahun=tahun,
            district_id=account.district_id,
            village_siga_ids=village_siga_ids,
        )

        # ====================================================
        # UPDATE LAST SYNC
        # ====================================================

        account.last_sync_at = datetime.now()

        db.add(account)
        db.commit()
        db.refresh(account)

        # ====================================================
        # RESPONSE
        # ====================================================

        return {
            "success": True,
            "message": (
                "Sinkronisasi anggota selesai."
            ),
            "username_siga": request.username_siga,
            "district_id": str(
                account.district_id
            ),
            "bulan": bulan,
            "tahun": tahun,
            "last_sync_at": account.last_sync_at,
            "result": result,
        }

    except HTTPException:
        raise

    except Exception as exc:

        db.rollback()

        raise HTTPException(
            status_code=500,
            detail=(
                "Sinkronisasi anggota gagal: "
                f"{str(exc)}"
            ),
        )

    finally:

        if session is not None:
            try:
                session.close()
            except Exception:
                pass


# ============================================================
# TEST 1 KK LANGSUNG DARI SIGA
# ============================================================

@router.post(
    "/members/test",
    summary="Test One Family Members From SIGA",
    description=(
        "Mengambil data anggota satu KK langsung dari SIGA "
        "melalui endpoint childRekapPK. "
        "Parameter no_keluarga harus berasal dari "
        "field noKeluarga pada hasil parentRekapPK. "
        "Endpoint ini TIDAK menyimpan data ke database."
    ),
)
def test_member_from_siga(
    no_keluarga: str,
    request: MemberTestRequest,
    bulan: int = 6,
    tahun: int = 2026,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("ADMIN", "OPERATOR")
    ),
):
    """
    Test mengambil anggota satu KK langsung dari SIGA.

    PENTING:

    no_keluarga BUKAN username SIGA.

    no_keluarga harus berasal dari:

        parentRekapPK
             ↓
        data[].noKeluarga
             ↓
        childRekapPK

    Contoh:

        no_keluarga=32030110060001 001001001
        bulan=8
        tahun=2026
    """

    # ========================================================
    # NORMALISASI
    # ========================================================

    no_keluarga = str(
        no_keluarga or ""
    ).strip()

    if not no_keluarga:
        raise HTTPException(
            status_code=400,
            detail="no_keluarga wajib diisi.",
        )

    # ========================================================
    # VALIDASI PERIODE
    # ========================================================

    if bulan < 1 or bulan > 12:
        raise HTTPException(
            status_code=400,
            detail="Bulan harus antara 1 sampai 12.",
        )

    if tahun < 2000 or tahun > 2100:
        raise HTTPException(
            status_code=400,
            detail="Tahun tidak valid.",
        )

    # ========================================================
    # VALIDASI AKUN SIGA
    # ========================================================

    _assert_sync_scope(
        db,
        current_user,
        request.username_siga,
    )

    # ========================================================
    # LOGIN SIGA
    # ========================================================

    base_sync = BaseSync(db)

    session = None

    try:

        session = base_sync.login(
            username=request.username_siga.strip(),
            password=request.password_siga,
        )

        # ====================================================
        # MEMBER SYNC OBJECT
        # ====================================================

        member_sync = MemberSync(
            db,
            session,
        )

        # ====================================================
        # PANGGIL childRekapPK
        # ====================================================

        response = member_sync.get_members(
            no_keluarga=no_keluarga,
            bulan=bulan,
            tahun=tahun,
        )

        # ====================================================
        # RETURN DATA SIGA
        # ====================================================

        return {
            "success": True,
            "message": (
                "Data anggota berhasil "
                "diambil dari SIGA."
            ),
            "no_keluarga": no_keluarga,
            "username_siga": request.username_siga,
            "bulan": bulan,
            "tahun": tahun,
            "data": response,
        }

    except HTTPException:
        raise

    except Exception as exc:

        raise HTTPException(
            status_code=502,
            detail=(
                "Gagal mengambil anggota "
                f"dari SIGA: {str(exc)}"
            ),
        )

    finally:

        if session is not None:
            try:
                session.close()
            except Exception:
                pass