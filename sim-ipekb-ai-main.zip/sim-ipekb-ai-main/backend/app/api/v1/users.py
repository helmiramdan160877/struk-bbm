from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import or_
from sqlalchemy.orm import Session, joinedload

from app.api.deps import get_db
from app.models.district import District
from app.models.kader import Kader
from app.models.pkb import PKB
from app.models.role import Role
from app.models.user import User
from app.models.user_village import UserVillage
from app.models.siga_account import SigaAccount
from app.models.user_siga_account import UserSigaAccount
from app.models.village import Village
from app.platform.auth.dependencies import require_roles
from app.platform.auth.hash import hash_password
from app.platform.users.repository import UserRepository
from app.platform.users.service import UserService
from app.platform.user_villages.repository import UserVillageRepository
from app.platform.user_villages.service import UserVillageService
from app.platform.siga_accounts.scope import reconcile_user_siga_accounts
from app.schemas.user import (
    ManageableVillageResponse,
    PasswordReset,
    UserCreate,
    UserResponse,
    UserUpdate,
    UserMasterSourceResponse,
    SubscriptionUpdate,
)
from app.schemas.user_village import UserVillageCreate, UserVillageResponse


router = APIRouter()


# =========================================================
# KONFIGURASI ROLE & PAKET
# =========================================================

ADMIN_CREATABLE_ROLES = {
    "PKB",
    "KADER",
    "PPKBD",
    "UPPKA",
    "ANGGOTA",
    "REDAKTUR",
    "ADMIN_KABUPATEN",
}

PLAN_TYPES = {
    "FREE",
    "PAID",
}

VILLAGE_REQUIRED_ROLES = {
    "PKB",
    "KADER",
    "PPKBD",
    "UPPKA",
    "ANGGOTA",
}


# =========================================================
# HELPER ROLE
# =========================================================

def _role_name(user) -> str:
    role = getattr(user, "role", None)

    return (
        (getattr(role, "name", "") or "")
        .strip()
        .upper()
    )


# =========================================================
# GET ROLE
# =========================================================

def _get_role(
    db: Session,
    role_id: UUID,
) -> Role:

    role = (
        db.query(Role)
        .filter(
            Role.id == role_id,
            Role.is_active.is_(True),
        )
        .first()
    )

    if role is None:
        raise HTTPException(
            status_code=400,
            detail="Role tidak ditemukan atau tidak aktif",
        )

    return role


# =========================================================
# VALIDASI PAKET
# =========================================================

def _validate_plan(
    plan_type: str | None,
) -> str:

    value = (
        plan_type or "FREE"
    ).strip().upper()

    if value not in PLAN_TYPES:
        raise HTTPException(
            status_code=400,
            detail="plan_type harus FREE atau PAID",
        )

    return value


def _normalize_email(
    email_value: str | None,
    username: str | None = None,
) -> str:
    candidate = (email_value or "").strip()
    if candidate and "@" in candidate:
        return candidate

    base = (username or "").strip()
    if not base:
        raise HTTPException(
            status_code=400,
            detail="Email wajib diisi atau username harus tersedia untuk membuat email otomatis.",
        )

    return f"{base}@ipekb.local"


# =========================================================
# GET DESA AKTIF
# =========================================================

def _get_active_villages(
    db: Session,
    village_ids: list[UUID],
) -> list[Village]:

    unique_ids = list(
        dict.fromkeys(village_ids)
    )

    if not unique_ids:
        return []

    villages = (
        db.query(Village)
        .options(
            joinedload(Village.district)
        )
        .filter(
            Village.id.in_(unique_ids),
            Village.is_active.is_(True),
        )
        .all()
    )

    if len(villages) != len(unique_ids):
        raise HTTPException(
            status_code=400,
            detail=(
                "Satu atau lebih desa binaan "
                "tidak ditemukan pada data SIGA"
            ),
        )

    return villages


# =========================================================
# VALIDASI SCOPE PEMBUATAN USER
# =========================================================

def _validate_creation_scope(
    db: Session,
    current_user: User,
    target_role: Role,
    data: UserCreate,
) -> tuple[UUID | None, list[Village]]:

    creator_role = _role_name(
        current_user
    )

    target_name = (
        target_role.name or ""
    ).strip().upper()

    plan_type = _validate_plan(
        data.plan_type
    )

    villages = _get_active_villages(
        db,
        data.village_ids,
    )

    # FREE maksimal satu desa
    if (
        plan_type == "FREE"
        and len(villages) > 1
    ):
        raise HTTPException(
            status_code=400,
            detail=(
                "Paket FREE maksimal 1 desa binaan. "
                "Ubah ke PAID untuk multi-desa."
            ),
        )

    # =====================================================
    # ADMIN
    # =====================================================

    if creator_role == "ADMIN":

        if target_name not in ADMIN_CREATABLE_ROLES:

            allowed = ", ".join(
                sorted(
                    ADMIN_CREATABLE_ROLES
                )
            )

            raise HTTPException(
                status_code=403,
                detail=(
                    f"ADMIN hanya dapat membuat role: "
                    f"{allowed}"
                ),
            )

        if current_user.district_id is None:
            raise HTTPException(
                status_code=403,
                detail=(
                    "Akun ADMIN belum memiliki "
                    "kecamatan binaan"
                ),
            )

        if not villages:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Pilih minimal satu desa binaan "
                    "dari data SIGA"
                ),
            )

        if any(
            village.district_id
            != current_user.district_id
            for village in villages
        ):
            raise HTTPException(
                status_code=403,
                detail=(
                    "ADMIN hanya dapat memilih desa "
                    "di kecamatan binaannya"
                ),
            )

        return (
            current_user.district_id,
            villages,
        )
    # =====================================================
    # ADMIN KABUPATEN
    # =====================================================

    if creator_role == "ADMIN_KABUPATEN":

        if current_user.district_id is None:
            raise HTTPException(
                status_code=403,
                detail="Admin Kabupaten belum memiliki kecamatan induk"
            )

        if not villages:
            raise HTTPException(
                status_code=400,
                detail="Pilih minimal satu desa binaan"
            )

        current_district = (
            db.query(District)
            .filter(
                District.id == current_user.district_id
            )
            .first()
        )

        if current_district is None:
            raise HTTPException(
                status_code=400,
                detail="Kecamatan induk tidak ditemukan"
            )

        if any(
            village.district.regency_id
            != current_district.regency_id
            for village in villages
        ):
            raise HTTPException(
                status_code=403,
                detail="Desa berada di luar kabupaten admin"
            )

        return (
            current_user.district_id,
            villages,
        )
    # =====================================================
    # SUPER ADMIN
    # =====================================================

    if target_name == "ADMIN":
        if data.district_id is None:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Role ADMIN wajib memiliki "
                    "kecamatan binaan"
                ),
            )

        district = (
            db.query(District)
            .filter(
                District.id == data.district_id,
                District.is_active.is_(True),
            )
            .first()
        )

        if district is None:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Kecamatan tidak ditemukan "
                    "pada data SIGA"
                ),
            )

        return (
            data.district_id,
            [],
        )

    if target_name == "ADMIN_KABUPATEN":
    
        if data.siga_account_id is None:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Role ADMIN_KABUPATEN wajib memiliki "
                    "akun SIGA"
                ),
            )

        siga_account = (
            db.query(SigaAccount)
            .filter(
                SigaAccount.id == data.siga_account_id
            )
            .first()
        )

        if siga_account is None:
            raise HTTPException(
                status_code=404,
                detail=(
                    "Akun SIGA tidak ditemukan"
                ),
            )

        return (
            siga_account.district_id,
            [],
        )
        if data.district_id is None:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Role ADMIN_KABUPATEN wajib memiliki "
                    "kecamatan induk"
                ),
            )

        district = (
            db.query(District)
            .filter(
                District.id == data.district_id,
                District.is_active.is_(True),
            )
            .first()
        )

        if district is None:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Kecamatan tidak ditemukan "
                    "pada data SIGA"
                ),
            )

        return (
            data.district_id,
            [],
        )

    if (
        target_name in VILLAGE_REQUIRED_ROLES
        and not villages
    ):
        raise HTTPException(
            status_code=400,
            detail=(
                "Role ini wajib memiliki "
                "minimal satu desa binaan"
            ),
        )

    district_id = data.district_id

    district_ids = {
        village.district_id
        for village in villages
    }

    if len(district_ids) == 1:
        district_id = next(
            iter(district_ids)
        )

    return (
        district_id,
        villages,
    )


# =========================================================
# MASTER SOURCE
# =========================================================

def _resolve_master_source(
    db: Session,
    target_role: Role,
    data: UserCreate,
):

    target_name = (
        target_role.name or ""
    ).strip().upper()

    if target_name not in {
        "PKB",
        "KADER",
        "UPPKA",
        "PPKBD",
        "ANGGOTA",
    }:
        return None, None, None

    if data.master_source_id is None:

        label = (
            "Master Kader"
            if target_name ==  {"KADER", "UPPKA", "PPKBD"}
            else "Master PKB"
        )

        raise HTTPException(
            status_code=400,
            detail=(
                f"Role {target_name} wajib dipilih "
                f"dari {label}"
            ),
        )

    # =====================================================
    # KADER
    # =====================================================

    if target_name in {"KADER", "UPPKA", "PPKBD"}:

        source = (
            db.query(Kader)
            .filter(
                Kader.id
                == data.master_source_id,
                Kader.status == "AKTIF",
            )
            .first()
        )

        if source is None:
            raise HTTPException(
                status_code=404,
                detail=(
                    "Master Kader tidak ditemukan "
                    "atau tidak aktif"
                ),
            )

        duplicate = (
            db.query(User)
            .join(
                Role,
                User.role_id == Role.id,
            )
            .filter(
                User.kader_id == source.id,
                Role.name == target_name,
            )
            .first()
        )

        if duplicate:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Master Kader ini sudah "
                    "mempunyai akun KADER"
                ),
            )

        return (
            source,
            None,
            source.id,
        )

    # =====================================================
    # PKB / ANGGOTA
    # =====================================================

    source = (
        db.query(PKB)
        .filter(
            PKB.id
            == data.master_source_id,
            PKB.status == "AKTIF",
        )
        .first()
    )

    if source is None:
        raise HTTPException(
            status_code=404,
            detail=(
                "Master PKB tidak ditemukan "
                "atau tidak aktif"
            ),
        )

    duplicate = (
        db.query(User)
        .join(
            Role,
            User.role_id == Role.id,
        )
        .filter(
            User.pkb_id == source.id,
            Role.name == target_name,
        )
        .first()
    )

    if duplicate:
        raise HTTPException(
            status_code=409,
            detail=(
                f"Master PKB ini sudah mempunyai "
                f"akun {target_name}"
            ),
        )

    return (
        source,
        source.id,
        None,
    )


# =========================================================
# SOURCE IDENTITY
# =========================================================

def _source_identity(
    target_role: Role,
    source,
    data: UserCreate,
):

    target_name = (
        target_role.name or ""
    ).strip().upper()
    normalized_email = _normalize_email(
        data.email,
        data.username,
    )

    if source is None:

        return (
            data.full_name.strip(),
            normalized_email,
            data.nip,
            data.phone,
        )

    if target_name in {"KADER", "UPPKA", "PPKBD"}:

        return (
            source.nama.strip(),
            normalized_email,
            source.nik,
            source.phone,
        )

    return (
        source.nama.strip(),
        normalized_email,
        source.nip,
        source.phone,
    )


# =========================================================
# CEK KEWENANGAN USER
# =========================================================

def _admin_can_manage_target(
    db: Session,
    current_user: User,
    target: User,
) -> bool:

    current_role = _role_name(current_user)

    # SUPER ADMIN
    if current_role == "SUPER_ADMIN":
        return True


    # Role target yang boleh dikelola
    if (
        _role_name(target)
        not in ADMIN_CREATABLE_ROLES
    ):
        return False


    # ADMIN KECAMATAN
    if current_role == "ADMIN":

        if current_user.district_id is None:
            return False

        if (
            target.district_id
            == current_user.district_id
        ):
            return True

        return (
            db.query(UserVillage)
            .join(
                Village,
                Village.id
                == UserVillage.village_id,
            )
            .filter(
                UserVillage.user_id
                == target.id,
                Village.district_id
                == current_user.district_id,
            )
            .first()
            is not None
        )


    # ADMIN KABUPATEN
    if current_role == "ADMIN_KABUPATEN":

        if current_user.district_id is None:
            return False

        current_district = (
            db.query(District)
            .filter(
                District.id
                == current_user.district_id
            )
            .first()
        )

        if current_district is None:
            return False


        # Target punya kecamatan
        if target.district_id:

            target_district = (
                db.query(District)
                .filter(
                    District.id
                    == target.district_id
                )
                .first()
            )

            if target_district:
                return (
                    target_district.regency_id
                    ==
                    current_district.regency_id
                )


        # Cek dari desa binaan
        return (
            db.query(UserVillage)
            .join(
                Village,
                Village.id
                == UserVillage.village_id,
            )
            .join(
                District,
                District.id
                == Village.district_id,
            )
            .filter(
                UserVillage.user_id
                == target.id,
                District.regency_id
                ==
                current_district.regency_id,
            )
            .first()
            is not None
        )


    return False

def _assert_can_manage_target(
    db: Session,
    current_user: User,
    target: User,
):

    if not _admin_can_manage_target(
        db,
        current_user,
        target,
    ):
        raise HTTPException(
            status_code=403,
            detail=(
                "User berada di luar "
                "kewenangan Anda"
            ),
        )


# =========================================================
# GANTI DESA USER
# =========================================================

def _replace_user_villages(
    db: Session,
    user_id: UUID,
    villages: list[Village],
):

    db.query(UserVillage).filter(
        UserVillage.user_id == user_id
    ).delete(
        synchronize_session=False
    )

    for village in villages:

        db.add(
            UserVillage(
                user_id=user_id,
                village_id=village.id,
            )
        )

    db.commit()

    reconcile_user_siga_accounts(
        db,
        user_id,
    )


# =========================================================
# MANAGEABLE ROLES
# =========================================================

@router.get(
    "/manageable-roles",
    response_model=list[dict],
)
def get_manageable_roles(
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    roles = (
        db.query(Role)
        .filter(
            Role.is_active.is_(True)
        )
        .order_by(Role.name.asc())
        .all()
    )

    if (
        _role_name(current_user)
        == "ADMIN"
    ):

        roles = [
            role
            for role in roles
            if (
                role.name or ""
            ).strip().upper()
            in ADMIN_CREATABLE_ROLES
        ]

    return [
        {
            "id": str(role.id),
            "name": role.name,
            "description": role.description,
            "is_active": role.is_active,
        }
        for role in roles
    ]


# =========================================================
# AVAILABLE SIGA ACCOUNTS FOR USER CREATION
# =========================================================

@router.get("/available-siga-accounts", response_model=list[dict])
def get_available_siga_accounts(
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")),
):
    query = db.query(SigaAccount).filter(SigaAccount.is_active.is_(True))
    if _role_name(current_user) == "ADMIN":
        if current_user.district_id is None:
            return []
        query = query.filter(SigaAccount.district_id == current_user.district_id)
    return [
        {
            "id": str(item.id),
            "username": item.username,
            "nama": item.nama,
            "district_name": item.district.name if item.district else None,
            "district_id": str(item.district_id) if item.district_id else None,
            "siga_province_id": item.siga_province_id,
            "siga_regency_id": item.siga_regency_id,
            "siga_district_id": item.siga_district_id,
            "is_active": item.is_active,
        }
        for item in query.order_by(SigaAccount.username.asc()).all()
    ]


# =========================================================
# AVAILABLE VILLAGES
# =========================================================

@router.get(
    "/available-villages",
    response_model=list[
        ManageableVillageResponse
    ],
)
def get_available_villages(
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    query = (
        db.query(Village)
        .options(
            joinedload(
                Village.district
            )
        )
        .filter(
            Village.is_active.is_(True)
        )
    )

    if (
        _role_name(current_user)
        == "ADMIN"
    ):
        if current_user.district_id is None:
            raise HTTPException(
                status_code=403,
                detail=(
                    "Akun ADMIN belum memiliki "
                    "kecamatan binaan"
                ),
            )

        query = query.filter(
            Village.district_id
            == current_user.district_id
        )

    villages = (
        query
        .order_by(Village.name.asc())
        .all()
    )

    return [
        ManageableVillageResponse(
            id=village.id,
            code=village.code,
            name=village.name,
            district_id=village.district_id,
            district_name=(
                village.district.name
                if village.district
                else "-"
            ),
            siga_id=village.siga_id,
            source="SIGA",
        )
        for village in villages
    ]


# =========================================================
# MASTER SOURCES
# =========================================================

@router.get(
    "/master-sources",
    response_model=list[
        UserMasterSourceResponse
    ],
)
def get_master_sources(
    role_name: str = Query(...),
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles(
            "SUPER_ADMIN",
            "ADMIN",
            "ADMIN_KABUPATEN"
        )
    ),
):


    name = (
        role_name
        .strip()
        .upper()
    )

    if name not in {
        "PKB",
        "KADER",
        "UPPKA",
        "PPKBD",
        "ANGGOTA",
    }:
        return []

    results: list[
        UserMasterSourceResponse
    ] = []

    # =====================================================
    # KADER
    # =====================================================

    if name in {"KADER", "UPPKA", "PPKBD"}:
        query = (
            db.query(Kader)
            .options(
                joinedload(
                    Kader.village
                )
            )
            .filter(
                Kader.status
                == "AKTIF"
            )
        )

        if (
            _role_name(current_user)
            == "ADMIN"
        ):

            query = (
                query
                .join(
                    Village,
                    Kader.village_id
                    == Village.id,
                )
                .filter(
                    Village.district_id
                    == current_user.district_id
                )
            )

        for item in (
            query
            .order_by(
                Kader.nama.asc()
            )
            .all()
        ):

            village = item.village

            results.append(
                UserMasterSourceResponse(
                    id=item.id,
                    source_type="KADER",
                    code=item.nik,
                    name=item.nama,
                    email=item.email,
                    phone=item.phone,
                    village_id=item.village_id,
                    village_name=(
                        village.name
                        if village
                        else None
                    ),
                    district_id=(
                        village.district_id
                        if village
                        else None
                    ),
                    siga_account_id=None,
                    status=item.status,
                )
            )

        return results

    # =====================================================
    # PKB
    # =====================================================

    query = (
        db.query(PKB)
        .options(
            joinedload(
                PKB.village
            )
        )
        .filter(
            PKB.status == "AKTIF"
        )
    )

    if (
        _role_name(current_user)
        == "ADMIN"
    ):

        query = (
            query
            .join(
                Village,
                PKB.village_id
                == Village.id,
            )
            .filter(
                Village.district_id
                == current_user.district_id
            )
        )

    for item in (
        query
        .order_by(
            PKB.nama.asc()
        )
        .all()
    ):

        village = item.village

        results.append(
            UserMasterSourceResponse(
                id=item.id,
                source_type="PKB",
                code=item.nip,
                name=item.nama,
                email=item.email,
                phone=item.phone,
                village_id=item.village_id,
                village_name=(
                    village.name
                    if village
                    else item.desa
                ),
                district_id=(
                    village.district_id
                    if village
                    else None
                ),
                siga_account_id=item.siga_account_id,
                status=item.status,
            )
        )

    return results


# =========================================================
# GET KADERS
# =========================================================

@router.get(
    "/kaders",
    response_model=list[UserResponse],
)
def get_kaders(
    search: str | None = Query(None),
    active: bool | None = Query(None),
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles(
            "ADMIN",
            "PENGURUS",
            "PKB",
            "KADER",
            "OPERATOR",
            "PIMPINAN",
        )
    ),
):

    users = (
        db.query(User)
        .options(
            joinedload(User.role),
            joinedload(
                User.user_villages
            ).joinedload(
                UserVillage.village
            ),
        )
        .join(
            Role,
            User.role_id == Role.id,
        )
        .filter(
            Role.name == "KADER"
        )
        .order_by(
            User.full_name.asc()
        )
        .all()
    )

    current_role = _role_name(
        current_user
    )

    if (
        current_role == "ADMIN"
        and current_user.district_id
    ):

        users = [
            user
            for user in users
            if _admin_can_manage_target(
                db,
                current_user,
                user,
            )
        ]

    elif current_role in {
        "PKB",
        "KADER",
    }:

        current_village_ids = {
            row.village_id
            for row in (
                db.query(UserVillage)
                .filter(
                    UserVillage.user_id
                    == current_user.id
                )
                .all()
            )
        }

        if not current_village_ids:
            users = []

        else:

            users = [
                user
                for user in users
                if any(
                    link.village_id
                    in current_village_ids
                    for link
                    in (
                        user.user_villages
                        or []
                    )
                )
            ]

    if search:

        keyword = (
            search
            .lower()
            .strip()
        )

        users = [
            user
            for user in users
            if (
                keyword
                in user.username.lower()
                or keyword
                in user.full_name.lower()
                or keyword
                in user.email.lower()
            )
        ]

    if active is not None:

        users = [
            user
            for user in users
            if user.is_active == active
        ]

    return users


# =========================================================
# GET USERS
# =========================================================

@router.get(
    "/",
    response_model=list[UserResponse],
)
def get_users(
    search: str | None = Query(None),
    active: bool | None = Query(None),
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    query = (
        db.query(User)
        .options(
            joinedload(User.role),
            joinedload(
                User.user_villages
            ).joinedload(
                UserVillage.village
            ),
        )
    )

    if (
        _role_name(current_user)
        == "ADMIN"
    ):
    

        if current_user.district_id is None:
            return []

        local_user_ids = (
            db.query(
                UserVillage.user_id
            )
            .join(
                Village,
                Village.id
                == UserVillage.village_id,
            )
            .filter(
                Village.district_id
                == current_user.district_id
            )
            .subquery()
        )

        query = (
            query
            .join(
                Role,
                User.role_id
                == Role.id,
            )
            .filter(
                Role.name.in_(
                    ADMIN_CREATABLE_ROLES
                ),
                or_(
                    User.district_id
                    == current_user.district_id,
                    User.id.in_(
                        local_user_ids
                    ),
                ),
            )
        )
        query = (
            query
            .join(...)
            .filter(...)
        )


    # TAMBAHKAN DI SINI
    if (
        _role_name(current_user)
        == "ADMIN_KABUPATEN"
    ):

        if current_user.district_id is None:
            return []

        current_district = (
            db.query(District)
            .filter(
                District.id
                == current_user.district_id
            )
            .first()
        )

        if current_district is None:
            return []

        query = (
            query
            .join(
                District,
                User.district_id == District.id,
                isouter=True,
            )
            .join(
                Role,
                User.role_id == Role.id,
            )
            .filter(
                Role.name.in_(
                    ADMIN_CREATABLE_ROLES
                ),
                District.regency_id
                ==
                current_district.regency_id,
            )
        )
    users = (
        query
        .order_by(
            User.full_name.asc()
        )
        .all()
    )

    if search:

        keyword = (
            search
            .lower()
            .strip()
        )

        users = [
            user
            for user in users
            if (
                keyword
                in user.username.lower()
                or keyword
                in user.full_name.lower()
                or keyword
                in user.email.lower()
            )
        ]

    if active is not None:

        users = [
            user
            for user in users
            if user.is_active == active
        ]

    return users


# =========================================================
# VALIDASI & HUBUNGKAN AKUN SIGA
# =========================================================

def _validate_siga_link(
    db: Session,
    target_role: Role,
    data: UserCreate,
    villages: list[Village],
) -> SigaAccount | None:
    target_name = (target_role.name or "").strip().upper()
    if target_name not in {"PKB", "PPKBD", "ADMIN"}:
        return None

    if data.siga_account_id is None:
        raise HTTPException(
            status_code=400,
            detail=f"User {target_name} wajib dikaitkan dengan Akun SIGA.",
        )

    account = (
        db.query(SigaAccount)
        .filter(
            SigaAccount.id == data.siga_account_id,
            SigaAccount.is_active.is_(True),
        )
        .first()
    )
    if account is None:
        raise HTTPException(status_code=404, detail="Akun SIGA tidak ditemukan atau tidak aktif.")

    if villages and any(v.district_id != account.district_id for v in villages):
        raise HTTPException(
            status_code=403,
            detail="Desa binaan user harus berada di kecamatan yang sama dengan Akun SIGA.",
        )

    return account


def _link_user_siga_account(db: Session, user_id: UUID, account_id: UUID) -> None:
    exists = (
        db.query(UserSigaAccount)
        .filter(
            UserSigaAccount.user_id == user_id,
            UserSigaAccount.siga_account_id == account_id,
        )
        .first()
    )
    if exists is None:
        db.add(UserSigaAccount(user_id=user_id, siga_account_id=account_id))
        db.commit()


def _replace_user_siga_account(
    db: Session,
    user_id: UUID,
    account_id: UUID | None,
) -> None:
    db.query(UserSigaAccount).filter(
        UserSigaAccount.user_id == user_id,
    ).delete(synchronize_session=False)
    if account_id is not None:
        db.add(
            UserSigaAccount(
                user_id=user_id,
                siga_account_id=account_id,
            )
        )
    db.commit()


# =========================================================
# CREATE USER
# =========================================================

@router.post(
    "/",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_user(
    data: UserCreate,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    data.email = _normalize_email(
        data.email,
        data.username,
    )

    target_role = _get_role(
        db,
        data.role_id,
    )

    if (
        _role_name(current_user)
        not in {
            "SUPER_ADMIN",
            "ADMIN",
        }
    ):
        raise HTTPException(
            status_code=403,
            detail=(
                "Pembuatan user hanya dapat "
                "dilakukan ADMIN/SUPER_ADMIN"
            ),
        )

    source, pkb_id, kader_id = (
        _resolve_master_source(
            db,
            target_role,
            data,
        )
    )

    # Master PKB adalah sumber utama akun SIGA jika form tidak mengirim ulang
    # pilihan akun secara eksplisit.
    if data.siga_account_id is None and source is not None:
        data.siga_account_id = getattr(source, "siga_account_id", None)

    if (
        source is not None
        and not data.village_ids
        and getattr(
            source,
            "village_id",
            None,
        )
    ):

        data.village_ids = [
            source.village_id
        ]

    district_id, villages = (
        _validate_creation_scope(
            db,
            current_user,
            target_role,
            data,
        )
    )

    siga_account = _validate_siga_link(
        db,
        target_role,
        data,
        villages,
    )

    full_name, email, nip, phone = (
        _source_identity(
            target_role,
            source,
            data,
        )
    )

    service = UserService(
        UserRepository(db)
    )

    try:

        plan = _validate_plan(
            data.plan_type
        )

        created = service.create_user(
            username=data.username.strip(),
            email=email,
            full_name=full_name,
            password=data.password,
            role_id=data.role_id,
            nip=nip,
            phone=phone,
            district_id=district_id,
            pkb_id=pkb_id,
            kader_id=kader_id,
            plan_type=plan,
            plan_expires_at=(
                data.plan_expires_at
                if plan == "PAID"
                else None
            ),
        )

        # Pastikan paket benar-benar disimpan
        created.plan_type = plan
        created.plan_expires_at = (
            data.plan_expires_at
            if plan == "PAID"
            else None
        )

        db.add(created)
        db.commit()
        db.refresh(created)

        if villages:

            _replace_user_villages(
                db,
                created.id,
                villages,
            )

        if siga_account is not None:
            _replace_user_siga_account(
                db,
                created.id,
                siga_account.id,
            )

        return (
            db.query(User)
            .options(
                joinedload(User.role),
                joinedload(
                    User.user_villages
                ).joinedload(
                    UserVillage.village
                ),
            )
            .filter(
                User.id == created.id
            )
            .first()
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc


# =========================================================
# ANGGOTA DARI MASTER PKB
# =========================================================

@router.post(
    "/anggota-from-pkb",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_anggota_from_pkb(
    data: dict,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("BENDAHARA")
    ),
):

    pkb_id = data.get(
        "pkb_id"
    )

    if not pkb_id:

        raise HTTPException(
            status_code=400,
            detail="pkb_id wajib diisi",
        )

    try:

        pkb_uuid = UUID(
            str(pkb_id)
        )

    except ValueError:

        raise HTTPException(
            status_code=400,
            detail="PKB tidak valid",
        )

    pkb = (
        db.query(PKB)
        .filter(
            PKB.id == pkb_uuid,
            PKB.status == "AKTIF",
        )
        .first()
    )

    if pkb is None:

        raise HTTPException(
            status_code=404,
            detail=(
                "Master PKB tidak ditemukan "
                "atau tidak aktif"
            ),
        )

    role = (
        db.query(Role)
        .filter(
            Role.name == "ANGGOTA",
            Role.is_active.is_(True),
        )
        .first()
    )

    if role is None:

        raise HTTPException(
            status_code=500,
            detail=(
                "Role ANGGOTA belum tersedia"
            ),
        )

    duplicate = (
        db.query(User)
        .filter(
            User.pkb_id == pkb.id,
            User.role_id == role.id,
        )
        .first()
    )

    if duplicate:

        raise HTTPException(
            status_code=409,
            detail=(
                "PKB ini sudah mempunyai "
                "akun ANGGOTA"
            ),
        )

    plan = _validate_plan(
        data.get("plan_type")
    )

    expires = (
        data.get("plan_expires_at")
        if plan == "PAID"
        else None
    )

    username = str(
        data.get("username")
        or pkb.nip
        or ""
    ).strip()

    password = str(
        data.get("password")
        or ""
    )

    if not username or not password:

        raise HTTPException(
            status_code=400,
            detail=(
                "Username dan password "
                "wajib diisi"
            ),
        )

    if len(password) < 6:

        raise HTTPException(
            status_code=400,
            detail=(
                "Password minimal "
                "6 karakter"
            ),
        )

    service = UserService(
        UserRepository(db)
    )

    try:

        created = service.create_user(
            username=username,
            email=(
                f"{username}@anggota.local"
            ),
            full_name=pkb.nama.strip(),
            password=password,
            role_id=role.id,
            nip=pkb.nip,
            phone=pkb.phone,
            district_id=(
                pkb.village.district_id
                if getattr(
                    pkb,
                    "village",
                    None,
                )
                else None
            ),
            pkb_id=pkb.id,
            plan_type=plan,
            plan_expires_at=expires,
        )

        created.plan_type = plan
        created.plan_expires_at = expires

        db.add(created)
        db.commit()
        db.refresh(created)

        if getattr(
            pkb,
            "village_id",
            None,
        ):

            village = (
                db.query(Village)
                .filter(
                    Village.id
                    == pkb.village_id
                )
                .first()
            )

            if village:

                _replace_user_villages(
                    db,
                    created.id,
                    [village],
                )

        return (
            db.query(User)
            .options(
                joinedload(User.role),
                joinedload(
                    User.user_villages
                ).joinedload(
                    UserVillage.village
                ),
            )
            .filter(
                User.id == created.id
            )
            .first()
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc


# =========================================================
# GET USER DETAIL
# =========================================================

@router.get(
    "/{user_id}",
    response_model=UserResponse,
)
def get_user(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    user = (
        db.query(User)
        .options(
            joinedload(User.role),
            joinedload(
                User.user_villages
            ).joinedload(
                UserVillage.village
            ),
        )
        .filter(
            User.id == user_id
        )
        .first()
    )

    if user is None:

        raise HTTPException(
            status_code=404,
            detail="User tidak ditemukan",
        )

    _assert_can_manage_target(
        db,
        current_user,
        user,
    )

    return user


# =========================================================
# UPDATE USER
# =========================================================

@router.put(
    "/{user_id}",
    response_model=UserResponse,
)
def update_user(
    user_id: UUID,
    data: UserUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    service = UserService(
        UserRepository(db)
    )

    user = service.get_user_by_id(
        user_id
    )

    if user is None:

        raise HTTPException(
            status_code=404,
            detail="User tidak ditemukan",
        )

    _assert_can_manage_target(
        db,
        current_user,
        user,
    )

    if data.email is not None:
        data.email = _normalize_email(
            data.email,
            user.username,
        )

    current_role = _role_name(
        current_user
    )

    # =====================================================
    # PAKET
    # =====================================================

    requested_plan = None

    if data.plan_type is not None:

        requested_plan = _validate_plan(
            data.plan_type
        )

    # Hanya SUPER_ADMIN yang boleh
    # mengubah paket.
    if (
        current_role != "SUPER_ADMIN"
        and (
            data.plan_type is not None
            or data.plan_expires_at
            is not None
        )
    ):

        raise HTTPException(
            status_code=403,
            detail=(
                "Perubahan paket hanya dapat "
                "dilakukan SUPER_ADMIN"
            ),
        )

    # =====================================================
    # ROLE
    # =====================================================

    target_role = (
        _get_role(
            db,
            data.role_id,
        )
        if data.role_id
        else user.role
    )

    target_role_name = (
        target_role.name or ""
    ).strip().upper()

    if (
        current_role == "ADMIN"
        and target_role_name
        not in ADMIN_CREATABLE_ROLES
    ):

        raise HTTPException(
            status_code=403,
            detail=(
                "ADMIN tidak boleh memberikan "
                "role administratif/global"
            ),
        )

    # =====================================================
    # DESA BINAAN
    # =====================================================

    villages = None

    if data.village_ids is not None:

        villages = _get_active_villages(
            db,
            data.village_ids,
        )

        if requested_plan is not None:

            effective_plan = (
                requested_plan
            )

        else:

            effective_plan = (
                "PAID"
                if user.has_active_paid_plan
                else "FREE"
            )

        # FREE maksimal 1 desa
        if (
            effective_plan == "FREE"
            and len(villages) > 1
        ):

            raise HTTPException(
                status_code=400,
                detail=(
                    "Paket FREE maksimal "
                    "1 desa binaan. "
                    "Ubah paket ke PAID "
                    "terlebih dahulu."
                ),
            )

        # ADMIN hanya desa di wilayahnya
        if current_role == "ADMIN":

            if not villages:

                raise HTTPException(
                    status_code=400,
                    detail=(
                        "Pilih minimal "
                        "satu desa binaan"
                    ),
                )

            if any(
                village.district_id
                != current_user.district_id
                for village in villages
            ):

                raise HTTPException(
                    status_code=403,
                    detail=(
                        "Desa berada di luar "
                        "kecamatan binaan Anda"
                    ),
                )

    current_villages = villages
    if current_villages is None:
        current_villages = [link.village for link in user.user_villages]

    if data.siga_account_id is None and target_role_name == "PKB" and user.pkb_id:
        pkb_source = db.query(PKB).filter(PKB.id == user.pkb_id).first()
        data.siga_account_id = getattr(pkb_source, "siga_account_id", None)

    siga_account = _validate_siga_link(
        db,
        target_role,
        data,
        current_villages,
    )

    # =====================================================
    # UPDATE DATA USER
    # =====================================================

    updated = service.update_user(
        user=user,
        email=data.email,
        full_name=data.full_name,
        password=data.password,
        role_id=data.role_id,
        is_active=data.is_active,
        nip=data.nip,
        phone=data.phone,
        district_id=data.district_id,
        plan_type=requested_plan,
        plan_expires_at=(
            data.plan_expires_at
            if requested_plan == "PAID"
            else None
        ),
    )

    # =====================================================
    # PAKSA SIMPAN PAKET KE DATABASE
    # =====================================================

    if requested_plan is not None:

        updated.plan_type = (
            requested_plan
        )

        if requested_plan == "PAID":

            updated.plan_expires_at = (
                data.plan_expires_at
            )

        else:

            updated.plan_expires_at = None

        db.add(updated)

        db.commit()

        db.refresh(updated)

    # =====================================================
    # DESA BINAAN
    # =====================================================

    if villages is not None:

        _replace_user_villages(
            db,
            updated.id,
            villages,
        )

    else:

        reconcile_user_siga_accounts(
            db,
            updated.id,
        )

    if siga_account is not None:
        _replace_user_siga_account(
            db,
            updated.id,
            siga_account.id,
        )

    # =====================================================
    # AMBIL ULANG USER
    # =====================================================

    result = (
        db.query(User)
        .options(
            joinedload(User.role),
            joinedload(
                User.user_villages
            ).joinedload(
                UserVillage.village
            ),
        )
        .filter(
            User.id == updated.id
        )
        .first()
    )

    return result


# =========================================================
# RESET PASSWORD
# =========================================================

@router.patch(
    "/{user_id}/password"
)
def reset_user_password(
    user_id: UUID,
    data: PasswordReset,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    user = (
        UserRepository(db)
        .get_by_id(user_id)
    )

    if user is None:

        raise HTTPException(
            status_code=404,
            detail="User tidak ditemukan",
        )

    _assert_can_manage_target(
        db,
        current_user,
        user,
    )

    user.hashed_password = (
        hash_password(
            data.new_password
        )
    )

    db.add(user)

    db.commit()

    return {
        "success": True,
        "message": (
            "Password berhasil direset"
        ),
    }


# =========================================================
# AKTIFKAN USER
# =========================================================

@router.patch(
    "/{user_id}/activate"
)
def activate_user(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    service = UserService(
        UserRepository(db)
    )

    user = service.get_user_by_id(
        user_id
    )

    if user is None:

        raise HTTPException(
            status_code=404,
            detail="User tidak ditemukan",
        )

    _assert_can_manage_target(
        db,
        current_user,
        user,
    )

    service.update_user(
        user=user,
        is_active=True,
    )

    return {
        "success": True,
        "message": (
            "User berhasil diaktifkan"
        ),
    }


# =========================================================
# NONAKTIFKAN USER
# =========================================================

@router.patch(
    "/{user_id}/deactivate"
)
def deactivate_user(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    service = UserService(
        UserRepository(db)
    )

    user = service.get_user_by_id(
        user_id
    )

    if user is None:

        raise HTTPException(
            status_code=404,
            detail="User tidak ditemukan",
        )

    if user.id == current_user.id:

        raise HTTPException(
            status_code=400,
            detail=(
                "Tidak dapat menonaktifkan "
                "akun sendiri"
            ),
        )

    _assert_can_manage_target(
        db,
        current_user,
        user,
    )

    service.update_user(
        user=user,
        is_active=False,
    )

    return {
        "success": True,
        "message": (
            "User berhasil dinonaktifkan"
        ),
    }


# =========================================================
# DELETE USER
# =========================================================

@router.delete(
    "/{user_id}"
)
def delete_user(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    service = UserService(
        UserRepository(db)
    )

    user = service.get_user_by_id(
        user_id
    )

    if user is None:

        raise HTTPException(
            status_code=404,
            detail="User tidak ditemukan",
        )

    if user.id == current_user.id:

        raise HTTPException(
            status_code=400,
            detail=(
                "Tidak dapat menghapus "
                "akun sendiri"
            ),
        )

    _assert_can_manage_target(
        db,
        current_user,
        user,
    )

    service.delete_user(user)

    return {
        "success": True,
        "message": (
            "User berhasil dihapus"
        ),
    }


# =========================================================
# UPDATE SUBSCRIPTION
# KHUSUS SUPER ADMIN
# =========================================================

@router.patch(
    "/{user_id}/subscription",
    response_model=UserResponse,
)
def update_subscription(
    user_id: UUID,
    data: SubscriptionUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN")
    ),
):

    user = (
        db.query(User)
        .options(
            joinedload(User.role),
            joinedload(
                User.user_villages
            ).joinedload(
                UserVillage.village
            ),
        )
        .filter(
            User.id == user_id
        )
        .first()
    )

    if user is None:

        raise HTTPException(
            status_code=404,
            detail="User tidak ditemukan",
        )

    plan = _validate_plan(
        data.plan_type
    )

    # FREE tidak boleh lebih dari
    # satu desa.
    if (
        plan == "FREE"
        and len(user.user_villages) > 1
    ):

        raise HTTPException(
            status_code=400,
            detail=(
                "User memiliki lebih dari "
                "1 desa. Kurangi desa binaan "
                "sebelum mengubah ke FREE."
            ),
        )

    user.plan_type = plan

    user.plan_expires_at = (
        data.plan_expires_at
        if plan == "PAID"
        else None
    )

    db.add(user)

    db.commit()

    db.refresh(user)

    return user


# =========================================================
# GET USER VILLAGES
# =========================================================

@router.get(
    "/{user_id}/villages",
    response_model=list[
        UserVillageResponse
    ],
)
def get_user_villages(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    user = (
        UserRepository(db)
        .get_by_id(user_id)
    )

    if user is None:

        raise HTTPException(
            status_code=404,
            detail="User tidak ditemukan",
        )

    _assert_can_manage_target(
        db,
        current_user,
        user,
    )

    return (
        UserVillageService(
            UserVillageRepository(db)
        )
        .get_by_user(user_id)
    )


# =========================================================
# TAMBAH DESA USER
# =========================================================

@router.post(
    "/{user_id}/villages",
    response_model=UserVillageResponse,
)
def assign_village(
    user_id: UUID,
    data: UserVillageCreate,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    user = (
        UserRepository(db)
        .get_by_id(user_id)
    )

    if user is None:

        raise HTTPException(
            status_code=404,
            detail="User tidak ditemukan",
        )

    _assert_can_manage_target(
        db,
        current_user,
        user,
    )

    if (
        not user.has_active_paid_plan
        and len(user.user_villages) >= 1
    ):

        raise HTTPException(
            status_code=400,
            detail=(
                "Paket FREE maksimal "
                "1 desa binaan. "
                "Ubah paket ke PAID "
                "terlebih dahulu."
            ),
        )

    villages = _get_active_villages(
        db,
        [data.village_id],
    )

    if (
        _role_name(current_user)
        == "ADMIN"
        and villages[0].district_id
        != current_user.district_id
    ):

        raise HTTPException(
            status_code=403,
            detail=(
                "Desa berada di luar "
                "kecamatan binaan Anda"
            ),
        )

    try:

        assigned = (
            UserVillageService(
                UserVillageRepository(db)
            ).assign(
                user_id=user_id,
                village_id=data.village_id,
            )
        )

        reconcile_user_siga_accounts(
            db,
            user_id,
        )

        return assigned

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        ) from exc


# =========================================================
# HAPUS DESA USER
# =========================================================

@router.delete(
    "/{user_id}/villages/{village_id}"
)
def remove_village(
    user_id: UUID,
    village_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(
        require_roles("SUPER_ADMIN", "ADMIN","ADMIN_KABUPATEN")
    ),
):

    user = (
        UserRepository(db)
        .get_by_id(user_id)
    )

    if user is None:

        raise HTTPException(
            status_code=404,
            detail="User tidak ditemukan",
        )

    _assert_can_manage_target(
        db,
        current_user,
        user,
    )

    deleted = (
        UserVillageService(
            UserVillageRepository(db)
        ).remove(
            user_id=user_id,
            village_id=village_id,
        )
    )

    if not deleted:

        raise HTTPException(
            status_code=404,
            detail=(
                "Desa binaan tidak ditemukan"
            ),
        )

    reconcile_user_siga_accounts(
        db,
        user_id,
    )

    return {
        "success": True,
        "message": (
            "Desa binaan berhasil dihapus"
        ),
    }