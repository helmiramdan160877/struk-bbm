from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.service import AuthService
from app.platform.users.repository import UserRepository
from app.platform.users.service import UserService
from app.schemas.auth import TokenResponse
from pydantic import BaseModel, EmailStr
from app.platform.auth.dependencies import get_current_user
from app.models.user import User
from fastapi.security import OAuth2PasswordRequestForm



router = APIRouter()

class ProfileUpdate(BaseModel):
    full_name: str | None = None
    email: EmailStr | None = None
    phone: str | None = None
    photo: str | None = None
    password: str | None = None


@router.post("/login", response_model=TokenResponse)
def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db),
):
    repository = UserRepository(db)
    user_service = UserService(repository)
    auth_service = AuthService(user_service)

    token = auth_service.login(
        form_data.username,
        form_data.password,
    )

    if token is None:
        raise HTTPException(
            status_code=401,
            detail="Username atau password salah",
        )

    return TokenResponse(
        access_token=token,
    )

@router.get("/me")
def me(
    current_user: User = Depends(get_current_user),
):
    return {
        "id": str(current_user.id),
        "username": current_user.username,
        "email": current_user.email,
        "full_name": current_user.full_name,
        "nip": current_user.nip,
        "phone": current_user.phone,
        "photo": current_user.photo,
        "district_id": str(current_user.district_id) if current_user.district_id else None,
        "role": current_user.role.name,
        "plan_type": current_user.plan_type,
        "plan_expires_at": current_user.plan_expires_at.isoformat() if current_user.plan_expires_at else None,
        "plan_active": current_user.plan_active,
    }

@router.patch("/me")
def update_me(data: ProfileUpdate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if data.full_name is not None: current_user.full_name = data.full_name.strip()
    if data.email is not None: current_user.email = data.email
    if data.phone is not None: current_user.phone = data.phone.strip() or None
    if data.photo is not None: current_user.photo = data.photo
    if data.password is not None:
        from app.platform.auth.hash import hash_password
        if len(data.password) < 6: raise HTTPException(status_code=400, detail="Password minimal 6 karakter")
        current_user.hashed_password = hash_password(data.password)
    db.add(current_user); db.commit(); db.refresh(current_user)
    return {"id": str(current_user.id), "username": current_user.username, "email": current_user.email, "full_name": current_user.full_name, "nip": current_user.nip, "phone": current_user.phone, "photo": current_user.photo, "district_id": str(current_user.district_id) if current_user.district_id else None, "role": current_user.role.name, "plan_type": current_user.plan_type, "plan_expires_at": current_user.plan_expires_at.isoformat() if current_user.plan_expires_at else None, "plan_active": current_user.plan_active}
