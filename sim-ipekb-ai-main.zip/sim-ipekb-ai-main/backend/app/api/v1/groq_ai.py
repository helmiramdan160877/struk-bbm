from fastapi import APIRouter
from pydantic import BaseModel
from app.services.groq_ai_service import groq_ai_service

router = APIRouter()

class ChatRequest(BaseModel):
    message: str
    context: str | None = None

@router.post("/chat")
def chat(data: ChatRequest):
    return groq_ai_service.chat(data.message, data.context)
