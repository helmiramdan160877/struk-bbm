from sqlalchemy.orm import Session

from app.models.siga_account import SigaAccount


class SigaAccountRepository:

    def __init__(self, db: Session):
        self.db = db

    def get_active(self):
        return (
            self.db.query(SigaAccount)
            .filter(SigaAccount.is_active.is_(True))
            .first()
        )

    def get_by_username(self, username: str):
        return (
            self.db.query(SigaAccount)
            .filter(SigaAccount.username == username)
            .first()
        )

    def save_token(
        self,
        username: str,
        token: str,
        refresh_token: str | None = None,
    ):
        account = self.get_by_username(username)

        if account is None:
            raise Exception(
                f"Akun SIGA {username} belum terdaftar."
            )

        account.token = token
        account.refresh_token = refresh_token

        self.db.commit()
        self.db.refresh(account)

        return account

    def update_profile(
        self,
        username: str,
        profile: dict,
    ):
        account = self.get_by_username(username)

        if account is None:
            raise Exception(
                f"Akun SIGA {username} belum terdaftar."
            )

        account.nama = profile.get("nama")
        account.level = profile.get("level")

        province_id = (
            profile.get("id_provinsi")
            or profile.get("provinsiId")
        )

        regency_id = (
            profile.get("id_kabupaten")
            or profile.get("kabupatenId")
        )

        district_id = (
            profile.get("id_kecamatan")
            or profile.get("kecamatanId")
        )

        account.siga_province_id = (
            str(province_id)
            if province_id is not None
            else None
        )

        account.siga_regency_id = (
            str(regency_id)
            if regency_id is not None
            else None
        )

        account.siga_district_id = (
            str(district_id)
            if district_id is not None
            else None
        )

        self.db.commit()
        self.db.refresh(account)

        return account