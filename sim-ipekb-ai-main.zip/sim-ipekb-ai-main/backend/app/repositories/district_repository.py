from __future__ import annotations

from app.models.district import District

from .base_repository import BaseRepository


class DistrictRepository(BaseRepository):

    def get_by_siga_id(self, siga_id: str):

        return (
            self.db.query(District)
            .filter(District.siga_id == str(siga_id))
            .first()
        )

    def save(self, regency, data: dict):
    
        district = self.get_by_siga_id(data["id_kecamatan"])

        if district is None:
            district = District()
            self.db.add(district)

        district.regency_id = regency.id
        district.siga_id = str(data["id_kecamatan"])
        district.code = data["kodeDepdagri"]
        district.name = data["nama_kecamatan"]

        return district