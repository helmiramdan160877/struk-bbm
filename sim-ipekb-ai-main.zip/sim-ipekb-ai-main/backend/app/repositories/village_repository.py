from app.models.village import Village

from .base_repository import BaseRepository


class VillageRepository(BaseRepository):

    def get_by_siga_id(self, siga_id):

        return (
            self.db.query(Village)
            .filter(Village.siga_id == str(siga_id))
            .first()
        )

    def save(self, district, data):

        village = self.get_by_siga_id(
            data["id_kelurahan"]
        )

        if village is None:
            village = Village()
            self.db.add(village)

        village.district_id = district.id

        village.siga_id = str(data["id_kelurahan"])

        # isi kolom code agar tidak NULL
        village.code = str(data["id_kelurahan"])

        village.name = data["nama_kelurahan"]

        return village