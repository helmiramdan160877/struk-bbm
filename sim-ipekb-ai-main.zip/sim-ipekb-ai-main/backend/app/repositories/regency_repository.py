from __future__ import annotations

from app.models.regency import Regency

from .base_repository import BaseRepository


class RegencyRepository(BaseRepository):

    def get_by_siga_id(self, siga_id: str):

        return (
            self.db.query(Regency)
            .filter(Regency.siga_id == str(siga_id))
            .first()
        )

    def save(self, province, data: dict):
    
        regency = self.get_by_siga_id(data["id_kabupaten"])

        if regency is None:
            regency = Regency()
            self.db.add(regency)

        regency.province_id = province.id
        regency.siga_id = str(data["id_kabupaten"])
        regency.code = data["kodeDepdagri"]
        regency.name = data["nama_kabupaten"]

        return regency