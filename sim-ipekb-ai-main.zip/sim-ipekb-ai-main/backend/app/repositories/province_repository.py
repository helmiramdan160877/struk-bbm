from __future__ import annotations

import logging

from app.models.province import Province
from .base_repository import BaseRepository

logger = logging.getLogger(__name__)


class ProvinceRepository(BaseRepository):

    def get_by_siga_id(self, siga_id: str):
        logger.info("CHECK PROVINCE %s", siga_id)

        return (
            self.db.query(Province)
            .filter(Province.siga_id == str(siga_id))
            .first()
        )

    def save(self, data: dict):

        logger.info("SAVE %s", data["nama"])

        province = self.get_by_siga_id(data["id_provinsi"])

        if province is None:
            logger.info("INSERT BARU")
            province = Province()
            self.db.add(province)
        else:
            logger.info("UPDATE")

        province.siga_id = str(data["id_provinsi"])
        province.code = data["kodeDepdagri"]
        province.name = data["nama"]

        return province