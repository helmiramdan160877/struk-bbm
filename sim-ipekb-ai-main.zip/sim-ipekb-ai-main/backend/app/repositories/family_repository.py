from uuid import UUID

from sqlalchemy.orm import Session

from app.models.family import Family
from app.models.village import Village
from app.models.user_village import UserVillage

from .base_repository import BaseRepository


class FamilyRepository(BaseRepository):

    # =========================================================
    # CARI KK BERDASARKAN SIGA ID
    # =========================================================

    def get_by_siga_id(self, siga_id: str):

        return (
            self.db.query(Family)
            .filter(
                Family.siga_id == str(siga_id)
            )
            .first()
        )

    # =========================================================
    # SIMPAN / UPDATE KK HASIL SINKRONISASI SIGA
    # =========================================================

    def save(self, village, data: dict):
        self.db.flush()

        no_keluarga = "".join(
            str(data.get("noKeluarga", "")).split()
        )

        family = self.get_by_siga_id(
            no_keluarga
        )

        if family is None:
            family = Family()
            self.db.add(family)

        family.village_id = village.id

        family.siga_id = no_keluarga

        family.family_card_number = no_keluarga

        family.head_of_family = (
            data.get("nama")
            or "-"
        )

        family.address = (
            data.get("alamat")
            or "-"
        )

        family.phone_number = data.get(
            "noTelepon"
        )

        family.is_active = (
            data.get("mutasiKeluarga") is None
        )

        return family

    # =========================================================
    # SUPER ADMIN
    # SEMUA KK
    # =========================================================

    def get_all(self):

        return (
            self.db.query(Family)
            .join(
                Village,
                Village.id == Family.village_id,
            )
            .order_by(
                Village.name,
                Family.head_of_family,
            )
            .all()
        )

    # =========================================================
    # ADMIN
    # SEMUA DESA DALAM SATU KECAMATAN
    # =========================================================

    def get_by_district(
        self,
        district_id: UUID,
    ):

        return (
            self.db.query(Family)
            .join(
                Village,
                Village.id == Family.village_id,
            )
            .filter(
                Village.district_id == district_id
            )
            .order_by(
                Village.name,
                Family.head_of_family,
            )
            .all()
        )

    # =========================================================
    # PKB / KADER
    # HANYA DESA BINAAN
    # =========================================================

    def get_by_villages(
        self,
        village_ids: list[UUID],
    ):

        if not village_ids:
            return []

        return (
            self.db.query(Family)
            .filter(
                Family.village_id.in_(village_ids)
            )
            .order_by(
                Family.head_of_family
            )
            .all()
        )

    # =========================================================
    # SATU KK BERDASARKAN ID
    # =========================================================

    def get_by_id(
        self,
        family_id: UUID,
    ):

        return (
            self.db.query(Family)
            .filter(
                Family.id == family_id
            )
            .first()
        )