from datetime import datetime

from app.models.family import Family
from app.models.family_member import FamilyMember

from .base_repository import BaseRepository


class FamilyMemberRepository(BaseRepository):

    INVALID_NIKS = {
        "",
        "0",
        "0000000000000000",
        "1111111111111111",
        "9999999999999999",
    }

    # =========================================================
    # NORMALISASI NIK
    # =========================================================

    @classmethod
    def normalize_nik(cls, value):

        if value is None:
            return ""

        nik = str(value).strip()

        return nik

    # =========================================================
    # VALIDASI NIK
    # =========================================================

    @classmethod
    def is_valid_nik(cls, nik):

        nik = cls.normalize_nik(nik)

        if nik in cls.INVALID_NIKS:
            return False

        if len(nik) != 16:
            return False

        if not nik.isdigit():
            return False

        return True

    # =========================================================
    # GET BY NIK
    # =========================================================

    def get_by_nik(self, nik: str):

        nik = self.normalize_nik(nik)

        if not nik:
            return None

        return (
            self.db.query(FamilyMember)
            .filter(
                FamilyMember.nik == nik
            )
            .first()
        )

    # =========================================================
    # GET BY FAMILY
    # =========================================================

    def get_by_family(self, family: Family):

        return (
            self.db.query(FamilyMember)
            .filter(
                FamilyMember.family_id == family.id
            )
            .all()
        )

    # =========================================================
    # GET BY NIK + FAMILY
    # =========================================================

    def get_by_nik_and_family(
        self,
        nik: str,
        family_id,
    ):

        nik = self.normalize_nik(nik)

        if not nik:
            return None

        return (
            self.db.query(FamilyMember)
            .filter(
                FamilyMember.nik == nik,
                FamilyMember.family_id == family_id,
            )
            .first()
        )

    # =========================================================
    # PARSE BOOLEAN
    # =========================================================

    @staticmethod
    def parse_bool(value):

        if value is None:
            return False

        if isinstance(value, bool):
            return value

        if isinstance(value, int):
            return value == 1

        text = str(value).strip().lower()

        return text in {
            "1",
            "true",
            "yes",
            "ya",
            "y",
            "matched",
            "padan",
        }

    # =========================================================
    # PARSE DATE
    # =========================================================

    @staticmethod
    def parse_date(value):

        if not value:
            return None

        if hasattr(value, "year"):
            return value

        value = str(value).strip()

        formats = [
            "%Y-%m-%d",
            "%d-%m-%Y",
            "%d/%m/%Y",
            "%Y/%m/%d",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%dT%H:%M:%S.%f",
        ]

        for fmt in formats:
            try:
                return datetime.strptime(
                    value,
                    fmt,
                ).date()
            except Exception:
                continue

        return None

    # =========================================================
    # UPDATE FIELD MEMBER
    # =========================================================

    def _fill_member(
        self,
        member: FamilyMember,
        family: Family,
        data: dict,
    ):

        # -----------------------------------------------------
        # FAMILY
        # -----------------------------------------------------

        member.family_id = family.id

        # -----------------------------------------------------
        # NIK
        # -----------------------------------------------------

        nik = self.normalize_nik(
            data.get("nik")
            or data.get("NIK")
            or data.get("noNik")
        )

        member.nik = nik

        # -----------------------------------------------------
        # NAMA
        # -----------------------------------------------------

        member.full_name = (
            data.get("nama")
            or data.get("namaLengkap")
            or data.get("fullName")
            or "-"
        )

        # -----------------------------------------------------
        # GENDER
        # -----------------------------------------------------

        member.gender = (
            data.get("jenisKelamin")
            or data.get("gender")
            or data.get("jk")
            or None
        )

        # -----------------------------------------------------
        # TEMPAT LAHIR
        # -----------------------------------------------------

        member.birth_place = (
            data.get("tempatLahir")
            or data.get("birthPlace")
            or None
        )

        # -----------------------------------------------------
        # TANGGAL LAHIR
        # -----------------------------------------------------

        member.birth_date = self.parse_date(
            data.get("tanggalLahir")
            or data.get("birthDate")
        )

        # -----------------------------------------------------
        # UMUR
        # -----------------------------------------------------

        age = (
            data.get("usia")
            or data.get("umur")
            or data.get("age")
        )

        try:
            member.age = (
                int(age)
                if age is not None
                else None
            )
        except Exception:
            member.age = None

        # -----------------------------------------------------
        # TELEPON
        # -----------------------------------------------------

        member.phone = (
            data.get("noTelepon")
            or data.get("nomorTelepon")
            or data.get("phone")
            or None
        )

        # -----------------------------------------------------
        # AGAMA
        # -----------------------------------------------------

        member.religion = (
            data.get("agama")
            or data.get("religion")
            or None
        )

        # -----------------------------------------------------
        # PENDIDIKAN
        # -----------------------------------------------------

        member.education = (
            data.get("pendidikan")
            or data.get("education")
            or None
        )

        # -----------------------------------------------------
        # PEKERJAAN
        # -----------------------------------------------------

        member.occupation = (
            data.get("pekerjaan")
            or data.get("occupation")
            or None
        )

        # -----------------------------------------------------
        # STATUS PERKAWINAN
        # -----------------------------------------------------

        member.marital_status = (
            data.get("statusPerkawinan")
            or data.get("statusKawin")
            or data.get("maritalStatus")
            or None
        )

        # -----------------------------------------------------
        # HUBUNGAN DENGAN KK
        # -----------------------------------------------------

        member.relationship_to_head = (
            data.get("hubunganDenganKk")
            or data.get("hubunganDenganKK")
            or data.get("hubunganKeluarga")
            or data.get("statusHubungan")
            or data.get("hubungan")
            or "-"
        )

        # -----------------------------------------------------
        # SUMBER DATA
        # -----------------------------------------------------

        member.data_source = (
            data.get("sumberData")
            or data.get("dataSource")
            or None
        )

        # -----------------------------------------------------
        # STATUS SIAK
        # -----------------------------------------------------

        member.siak_status = str(
            data.get("statusPadananSiak")
            or data.get("statusSIAK")
            or data.get("siakStatus")
            or ""
        )

        # -----------------------------------------------------
        # MATCHED
        # -----------------------------------------------------

        if "flagPadan" in data:
            flag_padan = data.get("flagPadan")
        else:
            flag_padan = data.get("isMatched")

        member.is_matched = self.parse_bool(
            flag_padan
        )

        # -----------------------------------------------------
        # ALIVE
        # -----------------------------------------------------

        mutasi = (
            data.get("mutasiIndidvidu")
            or data.get("mutasiIndividu")
            or data.get("mutasiIndividuId")
            or data.get("statusMutasi")
        )

        member.is_alive = (
            mutasi is None
            or str(mutasi).strip() == ""
        )

    # =========================================================
    # SAVE
    # =========================================================

    def save(
        self,
        family: Family,
        data: dict,
    ):

        nik = self.normalize_nik(
            data.get("nik")
            or data.get("NIK")
            or data.get("noNik")
        )

        # -----------------------------------------------------
        # NIK INVALID / DUMMY
        # -----------------------------------------------------

        if not self.is_valid_nik(nik):

            return None

        # -----------------------------------------------------
        # CARI DATA EXISTING
        # -----------------------------------------------------

        member = self.get_by_nik(
            nik
        )

        # -----------------------------------------------------
        # JIKA ADA → UPDATE
        # -----------------------------------------------------

        if member is not None:

            self._fill_member(
                member,
                family,
                data,
            )

            return member

        # -----------------------------------------------------
        # JIKA BELUM ADA → INSERT
        # -----------------------------------------------------

        member = FamilyMember()

        self._fill_member(
            member,
            family,
            data,
        )

        self.db.add(
            member
        )

        return member