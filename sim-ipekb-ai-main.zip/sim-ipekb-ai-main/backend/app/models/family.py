from uuid import UUID

from sqlalchemy import Boolean, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class Family(BaseModel):
    __tablename__ = "families"

    village_id: Mapped[UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("villages.id"),
        nullable=False,
    )

    siga_id: Mapped[str] = mapped_column(
        String(40),
        unique=True,
        nullable=False,
        index=True,
    )

    family_card_number: Mapped[str] = mapped_column(
        String(40),
        unique=True,
        nullable=False,
        index=True,
    )

    head_of_family: Mapped[str] = mapped_column(
        String(150),
        nullable=False,
    )

    address: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )

    rt: Mapped[str] = mapped_column(
        String(3),
        nullable=True,
    )

    rw: Mapped[str] = mapped_column(
        String(3),
        nullable=True,
    )

    postal_code: Mapped[str] = mapped_column(
        String(5),
        nullable=True,
    )

    phone_number: Mapped[str] = mapped_column(
        String(20),
        nullable=True,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
        nullable=False,
    )

    village = relationship(
        "Village",
        back_populates="families",
    )

    members = relationship(
        "FamilyMember",
        back_populates="family",
        cascade="all, delete-orphan",
    )