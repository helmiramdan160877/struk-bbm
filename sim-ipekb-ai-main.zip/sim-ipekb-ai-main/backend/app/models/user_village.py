from uuid import UUID

from sqlalchemy import ForeignKey, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class UserVillage(BaseModel):
    __tablename__ = "user_villages"

    __table_args__ = (
        UniqueConstraint(
            "user_id",
            "village_id",
            name="uq_user_village",
        ),
    )

    # ==========================================
    # USER
    # ==========================================

    user_id: Mapped[UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey(
            "users.id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    # ==========================================
    # DESA BINAAN
    # ==========================================

    village_id: Mapped[UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey(
            "villages.id",
            ondelete="CASCADE",
        ),
        nullable=False,
        index=True,
    )

    # ==========================================
    # RELATIONSHIP USER
    # ==========================================

    user = relationship(
        "User",
        back_populates="user_villages",
    )

    # ==========================================
    # RELATIONSHIP VILLAGE
    # ==========================================

    village = relationship(
        "Village",
        back_populates="user_villages",
    )