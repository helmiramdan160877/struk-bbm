from sqlalchemy import String, Text
from sqlalchemy.orm import Mapped, mapped_column
from app.models.base import BaseModel

class Berita(BaseModel):
    __tablename__ = "berita"
    judul: Mapped[str] = mapped_column(String(255), nullable=False)
    kategori: Mapped[str] = mapped_column(String(100), default="Informasi")
    isi: Mapped[str] = mapped_column(Text, default="")
