from uuid import UUID

from sqlalchemy import Boolean, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class District(BaseModel):
    __tablename__ = "districts"

    regency_id: Mapped[UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("regencies.id"),
        nullable=False,
    )

    code: Mapped[str] = mapped_column(
        String(13),
        nullable=False,
    )

    name: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )

    regency = relationship(
        "Regency",
        back_populates="districts",
    )
    villages = relationship(
    "Village",
    back_populates="district",
)
    siga_id: Mapped[str] = mapped_column(
    String(20),
    unique=True,
    nullable=True,
    index=True,
)