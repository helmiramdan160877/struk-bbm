from sqlalchemy import Boolean, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class Role(BaseModel):
    __tablename__ = "roles"

    name: Mapped[str] = mapped_column(
        String(50),
        unique=True,
        nullable=False,
    )

    description: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )

    # ======================================================
    # USERS
    # ======================================================

    users = relationship(
        "User",
        back_populates="role",
    )

    # ======================================================
    # PERMISSIONS
    # ======================================================

    permissions = relationship(
        "Permission",
        secondary="role_permissions",
        back_populates="roles",
    )