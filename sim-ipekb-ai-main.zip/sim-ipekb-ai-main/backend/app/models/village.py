from uuid import UUID

from sqlalchemy import Boolean, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class Village(BaseModel):
    __tablename__ = "villages"

    district_id: Mapped[UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("districts.id"),
        nullable=False,
    )

    code: Mapped[str] = mapped_column(
        String(13),
        nullable=False,
    )

    name: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )

    district = relationship(
        "District",
        back_populates="villages",
    )

    families = relationship(
        "Family",
        back_populates="village",
    )

    user_villages = relationship(
        "UserVillage",
        back_populates="village",
        cascade="all, delete-orphan",
    )

    pkbs = relationship(
        "PKB",
        back_populates="village",
    )

    siga_id: Mapped[str | None] = mapped_column(
        String(20),
        unique=True,
        nullable=True,
        index=True,
    )