from sqlalchemy import Boolean, String
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.orm import relationship
from app.models.base import BaseModel


class Province(BaseModel):
    __tablename__ = "provinces"

    code: Mapped[str] = mapped_column(
        String(5),
        unique=True,
        nullable=False,
    )

    name: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )
    regencies = relationship(
        "Regency",
        back_populates="province",
    )
    siga_id: Mapped[str] = mapped_column(
    String(20),
    unique=True,
    nullable=True,
    index=True,
)