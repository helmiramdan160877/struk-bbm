
from datetime import datetime
from datetime import datetime, timezone
from sqlalchemy import Boolean, DateTime, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel
from app.models.user_siga_account import UserSigaAccount


class User(BaseModel):
    __tablename__ = "users"

    username: Mapped[str] = mapped_column(
        String(50),
        unique=True,
        nullable=False,
    )

    email: Mapped[str] = mapped_column(
        String(120),
        unique=True,
        nullable=False,
    )

    full_name: Mapped[str] = mapped_column(
        String(150),
        nullable=False,
    )

    hashed_password: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
        nullable=False,
    )

    # ==========================================
    # PAKET AKUN
    # ==========================================

    plan_type: Mapped[str] = mapped_column(
        String(20),
        default="FREE",
        server_default="FREE",
        nullable=False,
        index=True,
    )

    # Wajib karena kolom ini ada di database
    # dan nullable=False.
    account_plan: Mapped[str] = mapped_column(
        String(20),
        default="FREE",
        server_default="FREE",
        nullable=False,
    )
    access_started_at: Mapped[datetime] = mapped_column(
    DateTime(timezone=True),
    default=lambda: datetime.now(timezone.utc),
    nullable=False,
)

    plan_expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )

    @property
    def has_active_paid_plan(self) -> bool:
        if (self.plan_type or "FREE").upper() != "PAID":
            return False

        if self.plan_expires_at is None:
            return True

        return self.plan_expires_at > datetime.now(
            self.plan_expires_at.tzinfo
        )

    @property
    def plan_active(self) -> bool:
        if self.plan_expires_at is None:
            return (self.plan_type or "FREE").upper() == "PAID"
        now = datetime.now(self.plan_expires_at.tzinfo) if self.plan_expires_at.tzinfo else datetime.now()
        return self.plan_expires_at > now

    # ==========================================
    # NIP PKB / KADER
    # ==========================================

    nip: Mapped[str | None] = mapped_column(
        String(30),
        nullable=True,
    )

    # ==========================================
    # NOMOR HP
    # ==========================================

    phone: Mapped[str | None] = mapped_column(
        String(20),
        nullable=True,
    )

    # ==========================================
    # FOTO
    # ==========================================

    photo: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    # ==========================================
    # MASTER DATA
    # ==========================================

    pkb_id: Mapped[UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("pkbs.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    kader_id: Mapped[UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("kaders.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    pkb = relationship(
        "PKB",
        foreign_keys=[pkb_id],
    )

    kader = relationship(
        "Kader",
        foreign_keys=[kader_id],
    )

    # ==========================================
    # ROLE
    # ==========================================

    role_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("roles.id"),
        nullable=False,
    )

    role = relationship(
        "Role",
        back_populates="users",
    )

    # ==========================================
    # KECAMATAN / DISTRICT
    # ==========================================

    district_id: Mapped[UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("districts.id"),
        nullable=True,
        index=True,
    )

    district = relationship(
        "District",
        foreign_keys=[district_id],
    )

    # ==========================================
    # DESA BINAAN
    # ==========================================

    user_villages = relationship(
        "UserVillage",
        back_populates="user",
        cascade="all, delete-orphan",
    )

    # ==========================================
    # AKUN SIGA
    # ==========================================

    user_siga_accounts = relationship(
        "UserSigaAccount",
        back_populates="user",
        cascade="all, delete-orphan",
    )

    siga_accounts = relationship(
        "SigaAccount",
        secondary=UserSigaAccount.__table__,
        back_populates="users",
        overlaps="user_siga_accounts,user,siga_account",
    )

    @property
    def siga_account_id(self):
        account = self.siga_accounts[0] if self.siga_accounts else None
        return account.id if account else None
