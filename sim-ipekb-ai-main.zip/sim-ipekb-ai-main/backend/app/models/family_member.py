from __future__ import annotations

from datetime import date
from uuid import UUID

from sqlalchemy import Boolean, Date, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class FamilyMember(BaseModel):
    __tablename__ = "family_members"

    family_id: Mapped[UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("families.id", ondelete="CASCADE"),
        nullable=False,
    )

    nik: Mapped[str] = mapped_column(
        String(16),
        unique=True,
        nullable=False,
        index=True,
    )

    full_name: Mapped[str] = mapped_column(
        String(150),
        nullable=False,
    )

    gender: Mapped[str | None] = mapped_column(
        String(20),
        nullable=True,
    )

    birth_place: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
    )

    birth_date: Mapped[date | None] = mapped_column(
        Date,
        nullable=True,
    )

    age: Mapped[int | None] = mapped_column(
        Integer,
        nullable=True,
    )

    phone: Mapped[str | None] = mapped_column(
        String(25),
        nullable=True,
    )

    religion: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True,
    )

    education: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
    )

    occupation: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
    )

    marital_status: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True,
    )

    relationship_to_head: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
    )

    data_source: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True,
    )

    siak_status: Mapped[str | None] = mapped_column(
        String(20),
        nullable=True,
    )

    is_matched: Mapped[bool | None] = mapped_column(
        Boolean,
        nullable=True,
    )

    is_alive: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
        nullable=False,
    )

    family: Mapped["Family"] = relationship(
        "Family",
        back_populates="members",
    )

    @property
    def family_card_number(self) -> str | None:
        return self.family.family_card_number if self.family is not None else None
