from sqlalchemy import ForeignKey, PrimaryKeyConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base


class UserSigaAccount(Base):
    """
    Relasi many-to-many antara User dan SigaAccount.
    Memungkinkan user PKB dikaitkan dengan satu atau lebih akun SIGA.
    """

    __tablename__ = "user_siga_accounts"
    __table_args__ = (
        PrimaryKeyConstraint(
            "user_id",
            "siga_account_id",
            name="pk_user_siga_accounts",
        ),
    )

    user_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )

    siga_account_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("siga_accounts.id", ondelete="CASCADE"),
        nullable=False,
    )

    # Relationships
    user = relationship(
        "User",
        back_populates="user_siga_accounts",
    )

    siga_account = relationship(
        "SigaAccount",
        back_populates="user_siga_accounts",
    )
