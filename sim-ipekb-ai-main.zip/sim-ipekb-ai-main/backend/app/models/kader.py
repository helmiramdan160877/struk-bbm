from uuid import UUID

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class Kader(BaseModel):
    __tablename__ = "kaders"

    nik: Mapped[str] = mapped_column(String(20), nullable=False, unique=True, index=True)
    nama: Mapped[str] = mapped_column(String(150), nullable=False, index=True)
    email: Mapped[str | None] = mapped_column(String(150), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(30), nullable=True)
    alamat: Mapped[str | None] = mapped_column(Text, nullable=True)
    jabatan: Mapped[str | None] = mapped_column(String(100), nullable=True)
    village_id: Mapped[UUID | None] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("villages.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="AKTIF", server_default="AKTIF")

    village = relationship("Village")

    @property
    def village_name(self):
        return self.village.name if self.village else None

    @property
    def district_name(self):
        district = self.village.district if self.village else None
        return district.name if district else None
