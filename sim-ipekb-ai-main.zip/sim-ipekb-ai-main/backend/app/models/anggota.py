from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import BaseModel


class Anggota(BaseModel):
    __tablename__ = "anggota"


    nama: Mapped[str] = mapped_column(
        String(150),
        nullable=False
    )


    nip: Mapped[str | None] = mapped_column(
        String(20),
        nullable=True,
        unique=True,
        index=True
    )


    phone: Mapped[str | None] = mapped_column(
        String(30),
        nullable=True
    )


    status: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default="AKTIF",
        server_default="AKTIF"
    )