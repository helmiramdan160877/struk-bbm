from datetime import datetime
from uuid import UUID

from sqlalchemy import Boolean, DateTime, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel
from app.models.user_siga_account import UserSigaAccount


class SigaAccount(BaseModel):
    __tablename__ = "siga_accounts"

    district_id: Mapped[UUID | None] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("districts.id"),
        nullable=True,
    )

    username: Mapped[str] = mapped_column(
        String(100),
        unique=True,
        nullable=False,
    )

    password_encrypted: Mapped[str] = mapped_column(
        String(500),
        nullable=False,
    )

    token: Mapped[str | None] = mapped_column(
        String,
        nullable=True,
    )

    refresh_token: Mapped[str | None] = mapped_column(
        String,
        nullable=True,
    )

    nama: Mapped[str | None] = mapped_column(
        String(200),
        nullable=True,
    )

    level: Mapped[str | None] = mapped_column(
        String(30),
        nullable=True,
    )

    siga_province_id: Mapped[str | None] = mapped_column(
        String(10),
        nullable=True,
    )

    siga_regency_id: Mapped[str | None] = mapped_column(
        String(10),
        nullable=True,
    )

    siga_district_id: Mapped[str | None] = mapped_column(
        String(10),
        nullable=True,
    )

    token_expired_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
        nullable=False,
    )

    last_sync_at: Mapped[datetime | None] = mapped_column(
        DateTime,
        nullable=True,
    )

    # ==========================================
    # RELASI USER DENGAN AKUN SIGA
    # ==========================================

    user_siga_accounts = relationship(
        "UserSigaAccount",
        back_populates="siga_account",
        cascade="all, delete-orphan",
    )

    users = relationship(
        "User",
        secondary=UserSigaAccount.__table__,
        back_populates="siga_accounts",
        overlaps="user_siga_accounts,user,siga_account",
    )

    # ==========================================
    # RELASI MASTER DISTRICT LOKAL
    # ==========================================

    district = relationship(
        "District"
    )