from datetime import date
from uuid import UUID

from sqlalchemy import ForeignKey, String, Text, Date
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class PKB(BaseModel):
    __tablename__ = "pkbs"

    # =========================================================
    # IDENTITAS PKB
    # =========================================================

    nip: Mapped[str] = mapped_column(
        String(30),
        nullable=False,
        unique=True,
    )

    nik: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        unique=True,
    )

    nama: Mapped[str] = mapped_column(
        String(150),
        nullable=False,
    )

    tempat_lahir: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
    )

    tanggal_lahir: Mapped[date | None] = mapped_column(
        Date,
        nullable=True,
    )

    jenis_kelamin: Mapped[str | None] = mapped_column(
        String(20),
        nullable=True,
    )

    agama: Mapped[str | None] = mapped_column(
        String(30),
        nullable=True,
    )

    pendidikan: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
    )

    jabatan: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
    )

    status_asn: Mapped[str | None] = mapped_column(
        String(50),
        nullable=True,
    )

    golongan: Mapped[str | None] = mapped_column(
        String(20),
        nullable=True,
    )

    # =========================================================
    # KONTAK
    # =========================================================

    email: Mapped[str | None] = mapped_column(
        String(150),
        nullable=True,
    )

    phone: Mapped[str | None] = mapped_column(
        String(30),
        nullable=True,
    )

    alamat: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    photo: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
    )

    # =========================================================
    # WILAYAH
    # =========================================================

    kecamatan: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
    )

    desa: Mapped[str | None] = mapped_column(
        String(100),
        nullable=True,
    )

    wilayah_binaan: Mapped[str | None] = mapped_column(
        Text,
        nullable=True,
    )

    # =========================================================
    # AKUN SIGA SUMBER WILAYAH
    # =========================================================

    siga_account_id: Mapped[UUID | None] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("siga_accounts.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    siga_account = relationship("SigaAccount")

    # =========================================================
    # DESA BINAAN
    # =========================================================

    village_id: Mapped[UUID | None] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey(
            "villages.id",
            ondelete="SET NULL",
        ),
        nullable=True,
        index=True,
    )

    village = relationship(
        "Village",
        back_populates="pkbs",
    )

    # =========================================================
    # STATUS
    # =========================================================

    status: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        default="AKTIF",
        server_default="AKTIF",
    )