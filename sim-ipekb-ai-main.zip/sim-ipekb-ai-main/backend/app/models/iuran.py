from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, Date, DateTime, ForeignKey, Integer, Numeric, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel


class IuranSetting(BaseModel):
    __tablename__ = "iuran_settings"
    __table_args__ = (UniqueConstraint("year", name="uq_iuran_settings_year"),)

    year: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    monthly_amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False, default=0)
    due_day: Mapped[int] = mapped_column(Integer, nullable=False, default=25, server_default="25")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)


class IuranPayment(BaseModel):
    __tablename__ = "iuran_payments"
    __table_args__ = (
        UniqueConstraint("user_id", "year", "month", name="uq_iuran_payment_user_period"),
    )

    user_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    year: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    month: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    paid_at: Mapped[date] = mapped_column(Date, nullable=False, default=date.today)
    payment_method: Mapped[str | None] = mapped_column(String(30), nullable=True)
    reference_no: Mapped[str | None] = mapped_column(String(100), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="VERIFIED")
    verified_by_user_id: Mapped[UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    user = relationship("User", foreign_keys=[user_id])
    verified_by = relationship("User", foreign_keys=[verified_by_user_id])


class IuranNotification(BaseModel):
    __tablename__ = "iuran_notifications"
    __table_args__ = (
        UniqueConstraint("user_id", "year", "month", "kind", name="uq_iuran_notification_user_period_kind"),
    )

    user_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    year: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    month: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    kind: Mapped[str] = mapped_column(String(40), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(160), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    outstanding_amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False, default=0)
    is_read: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    whatsapp_status: Mapped[str] = mapped_column(String(20), nullable=False, default="PENDING")
    whatsapp_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    whatsapp_sent_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    user = relationship("User", foreign_keys=[user_id])
