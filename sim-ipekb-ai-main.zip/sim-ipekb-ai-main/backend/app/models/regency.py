from sqlalchemy import Boolean, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import BaseModel
from uuid import UUID
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import relationship

class Regency(BaseModel):
    __tablename__ = "regencies"

    province_id: Mapped[str] = mapped_column(
        ForeignKey("provinces.id"),
        nullable=False,
    )

    code: Mapped[str] = mapped_column(
        String(10),
        nullable=False,
    )

    name: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )

    province = relationship(
        "Province",
        back_populates="regencies",
    )
    districts = relationship(
    "District",
    back_populates="regency",
)
    
    siga_id: Mapped[str] = mapped_column(
    String(20),
    unique=True,
    nullable=True,
    index=True,
)
