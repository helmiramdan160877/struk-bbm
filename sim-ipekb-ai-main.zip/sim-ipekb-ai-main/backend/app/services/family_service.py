from app.repositories.family_repository import FamilyRepository
from app.repositories.family_member_repository import FamilyMemberRepository


class FamilyService:

    def __init__(self, db):
        self.db = db
        self.family_repo = FamilyRepository(db)
        self.member_repo = FamilyMemberRepository(db)


    def save_family_with_members(self, village, data: dict):

        # simpan keluarga
        family = self.family_repo.save(
            village,
            data
        )


        # simpan anggota keluarga
        members = data.get(
            "anggota",
            []
        )


        for member_data in members:

            self.member_repo.save(
                family,
                member_data
            )


        self.db.commit()


        return family