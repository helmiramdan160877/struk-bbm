from __future__ import annotations

import logging

from app.repositories.family_repository import FamilyRepository
from app.repositories.village_repository import VillageRepository

from .base_api_sync import BaseApiSync
from .session import SigaSession

logger = logging.getLogger(__name__)


class ParentSync(BaseApiSync):
    """
    Sinkronisasi data Kepala Keluarga (KK)
    dari endpoint parentRekapPK.
    """

    ENDPOINT = "/rekapitulasi-data-keluarga/siga/rekap/parentRekapPK"

    def __init__(
        self,
        db,
        session: SigaSession,
    ):
        super().__init__(
            db,
            session,
        )

        self.family_repo = FamilyRepository(db)
        self.village_repo = VillageRepository(db)

    def get_parent(
        self,
        bulan: int,
        tahun: int,
        page: int = 1,
        record_per_page: int = 500,
    ) -> dict:

        params = {
            "bulan": bulan,
            "tahun": tahun,
            "page": page,
            "recordPerPage": record_per_page,
            "idProvinsi": self.session.province_id,
            "idKabupaten": self.session.regency_id,
            "idKecamatan": self.session.district_id,
        }

        logger.info(
            "Mengambil daftar Kepala Keluarga (%s/%s) page %s",
            bulan,
            tahun,
            page,
        )

        return self.get_json(
            endpoint=self.ENDPOINT,
            params=params,
        )

    def run(
        self,
        bulan: int,
        tahun: int,
    ):

        page = 1
        total = 0

        while True:

            response = self.get_parent(
                bulan=bulan,
                tahun=tahun,
                page=page,
                record_per_page=500,
            )

            rows = response.get("data", [])

            if not rows:
                break

            for row in rows:

                village = self.village_repo.get_by_siga_id(
                    row["kelurahanId"]
                )

                if village is None:
                    logger.warning(
                        "Kelurahan %s tidak ditemukan.",
                        row["kelurahanId"],
                    )
                    continue

                self.family_repo.save(
                    village,
                    row,
                )

                total += 1

            self.db.commit()

            logger.info(
                "Page %s selesai (%s KK)",
                page,
                len(rows),
            )

            if len(rows) < 500:
                break

            page += 1

        logger.info(
            "Total KK tersinkronisasi: %s",
            total,
        )

        return {
            "success": True,
            "total": total,
        }