import os
from typing import Optional

try:
    from groq import Groq
except Exception:
    Groq = None


class GroqAIService:
    def chat(self, message: str, context: Optional[str] = None):
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key or Groq is None:
            return {"success": False, "message": "GROQ_API_KEY belum dikonfigurasi"}
        client = Groq(api_key=api_key)
        prompt = message
        if context:
            prompt = f"Data SIM IPEKB:\n{context}\n\nPertanyaan:\n{message}"
        result = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role":"user","content":prompt}],
        )
        return {"success": True, "answer": result.choices[0].message.content}


groq_ai_service = GroqAIService()
