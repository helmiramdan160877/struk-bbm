from sqlalchemy import func

from app.models.family import Family
from app.models.family_member import FamilyMember
from app.models.province import Province
from app.models.regency import Regency
from app.models.district import District
from app.models.village import Village


class DashboardService:

    def __init__(self, db):
        self.db = db

    def summary(self):

        return {

            "total_family":
                self.db.query(
                    func.count(Family.id)
                ).scalar(),

            "total_member":
                self.db.query(
                    func.count(FamilyMember.id)
                ).scalar(),

            "alive":
                self.db.query(
                    func.count(FamilyMember.id)
                ).filter(
                    FamilyMember.is_alive == True
                ).scalar(),

            "dead":
                self.db.query(
                    func.count(FamilyMember.id)
                ).filter(
                    FamilyMember.is_alive == False
                ).scalar(),

            "matched":
                self.db.query(
                    func.count(FamilyMember.id)
                ).filter(
                    FamilyMember.is_matched == True
                ).scalar(),

            "unmatched":
                self.db.query(
                    func.count(FamilyMember.id)
                ).filter(
                    FamilyMember.is_matched == False
                ).scalar(),

            "province":
                self.db.query(
                    func.count(Province.id)
                ).scalar(),

            "regency":
                self.db.query(
                    func.count(Regency.id)
                ).scalar(),

            "district":
                self.db.query(
                    func.count(District.id)
                ).scalar(),

            "village":
                self.db.query(
                    func.count(Village.id)
                ).scalar(),
        }