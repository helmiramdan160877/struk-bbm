import base64
import binascii
import time
from typing import Optional

from app.core.config import settings

try:
    from google import genai
    from google.genai import types
except Exception:
    genai = None
    types = None


class GeminiAIService:
    """Gemini service. Data SIM/SIGA diberikan oleh backend, bukan frontend."""

    def chat(
        self,
        message: str,
        context: Optional[str] = None,
        image_data: Optional[str] = None,
        image_mime_type: Optional[str] = None,
        file_name: Optional[str] = None,
    ):
        api_key = (settings.GEMINI_API_KEY or "").strip()
        if not api_key:
            return {"success": False, "message": "GEMINI_API_KEY belum dikonfigurasi di backend/.env"}
        if genai is None:
            return {"success": False, "message": "Package google-genai belum terpasang. Jalankan: pip install -r requirements.txt"}

        model = (settings.GEMINI_MODEL or "gemini-3.5-flash-lite").strip()
        prompt = (
            "Anda adalah Asisten AI resmi untuk aplikasi SIM IPEKB AI. "
            "Jawab dalam bahasa Indonesia yang jelas, praktis, dan profesional. "
            "Gunakan DATA SIGA yang diberikan backend sebagai sumber angka. "
            "Jangan mengarang angka. Jika data SIGA tidak tersedia atau gagal diambil, "
            "katakan dengan jelas. Jangan meminta, menampilkan, atau menebak NIK, password, "
            "token, atau data pribadi yang tidak diperlukan. Jika data yang diberikan adalah "
            "rekapitulasi, sebutkan periode dan wilayahnya.\n\n"
        )
        if context:
            prompt += f"DATA KONTEKS DARI BACKEND (SIM IPEKB + SIGA):\n{context}\n\n"
        prompt += f"PERTANYAAN PENGGUNA:\n{message}"

        image_bytes = None
        if image_data:
            supported_types = {
                "image/jpeg", "image/png", "image/webp", "image/gif",
                "application/pdf", "text/plain", "text/csv",
                "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            }
            if image_mime_type not in supported_types:
                return {"success": False, "message": "Format file tidak didukung. Gunakan gambar, PDF, Word, Excel, CSV, atau TXT."}
            try:
                image_bytes = base64.b64decode(image_data, validate=True)
            except (binascii.Error, ValueError):
                return {"success": False, "message": "Format file tidak valid."}
            if len(image_bytes) > 15 * 1024 * 1024:
                return {"success": False, "message": "Ukuran file maksimal 15 MB."}
            prompt += f"\n\nLAMPIRAN: {file_name or 'file pengguna'}. Analisis isi lampiran sesuai pertanyaan."

        try:
            client_kwargs = {"api_key": api_key}
            if types is not None:
                client_kwargs["http_options"] = types.HttpOptions(timeout=60000)
            client = genai.Client(**client_kwargs)
            contents = prompt
            if image_bytes is not None:
                if types is None:
                    return {"success": False, "message": "Package google-genai belum mendukung analisis foto."}
                contents = [
                    types.Part.from_text(text=prompt),
                    types.Part.from_bytes(
                        data=image_bytes,
                        mime_type=image_mime_type or "application/octet-stream",
                    ),
                ]
            kwargs = {"model": model, "contents": contents}
            if types is not None and model.startswith("gemini-3"):
                kwargs["config"] = types.GenerateContentConfig(
                    thinking_config=types.ThinkingConfig(thinking_level="low")
                )
            response = None
            for attempt in range(2):
                try:
                    response = client.models.generate_content(**kwargs)
                    break
                except Exception as exc:
                    error_text = str(exc).upper()
                    is_timeout = "DEADLINE_EXCEEDED" in error_text or "504" in error_text
                    if attempt == 1 or not is_timeout:
                        raise
                    time.sleep(0.5)
            answer = getattr(response, "text", None) or "Gemini tidak memberikan jawaban teks."
            return {"success": True, "answer": answer, "model": model}
        except Exception as exc:
            return {"success": False, "message": f"Gemini API gagal: {exc}"}


gemini_ai_service = GeminiAIService()
