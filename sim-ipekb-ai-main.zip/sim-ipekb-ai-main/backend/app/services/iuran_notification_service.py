from __future__ import annotations

from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo
from decimal import Decimal

import httpx
from sqlalchemy.orm import Session, joinedload

from app.core.config import settings
from app.models.iuran import IuranNotification, IuranPayment, IuranSetting
from app.models.role import Role
from app.models.user import User

JAKARTA = ZoneInfo("Asia/Jakarta")


def jakarta_today() -> date:
    return datetime.now(JAKARTA).date()


MONTHS = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember",
]


def chargeable_month(year: int, today: date | None = None) -> int:
    current = today or jakarta_today()
    if year < current.year:
        return 12
    if year > current.year:
        return 0
    return current.month


def monthly_amount(db: Session, year: int) -> Decimal:
    setting = db.query(IuranSetting).filter(IuranSetting.year == year, IuranSetting.is_active.is_(True)).first()
    return Decimal(setting.monthly_amount) if setting else Decimal("0")


def member_outstanding(db: Session, user_id, year: int, through_month: int) -> Decimal:
    amount = monthly_amount(db, year)
    if amount <= 0 or through_month <= 0:
        return Decimal("0")
    paid = Decimal("0")
    payments = (
        db.query(IuranPayment)
        .filter(
            IuranPayment.user_id == user_id,
            IuranPayment.year == year,
            IuranPayment.month <= through_month,
            IuranPayment.status == "VERIFIED",
        )
        .all()
    )
    for item in payments:
        paid += Decimal(item.amount)
    return max((amount * through_month) - paid, Decimal("0"))


def normalize_phone(value: str | None) -> str | None:
    if not value:
        return None
    digits = "".join(ch for ch in value if ch.isdigit())
    if digits.startswith("0"):
        digits = "62" + digits[1:]
    elif digits.startswith("8"):
        digits = "62" + digits
    return digits or None


def send_whatsapp(to_phone: str | None, message: str) -> tuple[str, str | None]:
    phone = normalize_phone(to_phone)
    if not phone:
        return "SKIPPED", "Nomor WhatsApp penerima belum tersedia"
    if not settings.WA_GATEWAY_URL:
        return "SKIPPED", "WA_GATEWAY_URL belum dikonfigurasi"

    headers = {"Content-Type": "application/json"}
    if settings.WA_GATEWAY_API_KEY:
        headers["Authorization"] = f"Bearer {settings.WA_GATEWAY_API_KEY}"

    payload = {
        "sender": normalize_phone(settings.WA_SENDER_NUMBER),
        "to": phone,
        "message": message,
    }
    try:
        with httpx.Client(timeout=settings.WA_GATEWAY_TIMEOUT_SECONDS) as client:
            response = client.post(settings.WA_GATEWAY_URL, json=payload, headers=headers)
            response.raise_for_status()
        return "SENT", None
    except Exception as exc:
        return "FAILED", str(exc)[:1000]


def _upsert_notice(
    db: Session,
    user: User,
    year: int,
    month: int,
    kind: str,
    title: str,
    message: str,
    outstanding: Decimal,
    send_wa: bool,
) -> IuranNotification:
    notice = (
        db.query(IuranNotification)
        .filter(
            IuranNotification.user_id == user.id,
            IuranNotification.year == year,
            IuranNotification.month == month,
            IuranNotification.kind == kind,
        )
        .first()
    )
    if notice is None:
        notice = IuranNotification(
            user_id=user.id,
            year=year,
            month=month,
            kind=kind,
            title=title,
            message=message,
            outstanding_amount=outstanding,
            is_read=False,
            whatsapp_status="PENDING",
        )
        db.add(notice)
    else:
        notice.title = title
        notice.message = message
        notice.outstanding_amount = outstanding

    db.flush()
    if send_wa and notice.whatsapp_status != "SENT":
        status, error = send_whatsapp(user.phone, message)
        notice.whatsapp_status = status
        notice.whatsapp_error = error
        notice.whatsapp_sent_at = datetime.now(timezone.utc) if status == "SENT" else None
    return notice


def generate_monthly_iuran_notifications(db: Session, run_date: date | None = None, send_wa: bool = True) -> dict:
    today = run_date or jakarta_today()
    year = today.year
    month = today.month
    amount = monthly_amount(db, year)
    if amount <= 0:
        return {"generated": 0, "members_unpaid": 0, "total_outstanding": 0, "reason": "Nominal iuran tahun berjalan belum diatur"}

    members = (
        db.query(User)
        .options(joinedload(User.role))
        .join(Role, User.role_id == Role.id)
        .filter(Role.name == "ANGGOTA", User.is_active.is_(True))
        .order_by(User.full_name.asc())
        .all()
    )
    unpaid: list[tuple[User, Decimal]] = []
    for member in members:
        outstanding = member_outstanding(db, member.id, year, month)
        if outstanding <= 0:
            continue
        unpaid.append((member, outstanding))
        formatted = f"Rp{outstanding:,.0f}".replace(",", ".")
        message = (
            f"Yth. {member.full_name}, tagihan Kas IPKB periode Januari sampai {MONTHS[month-1]} {year} "
            f"masih memiliki tunggakan {formatted}. Mohon melakukan pembayaran dan konfirmasi kepada bendahara."
        )
        _upsert_notice(
            db, member, year, month, "MEMBER_DUE",
            f"Tagihan Kas {MONTHS[month-1]} {year}", message, outstanding, send_wa,
        )

    total = sum((value for _, value in unpaid), Decimal("0"))
    treasurers = (
        db.query(User)
        .options(joinedload(User.role))
        .join(Role, User.role_id == Role.id)
        .filter(Role.name.in_(["BENDAHARA", "ADMIN"]), User.is_active.is_(True))
        .all()
    )
    if unpaid:
        formatted_total = f"Rp{total:,.0f}".replace(",", ".")
        message = (
            f"Rekap tagihan Kas IPKB per {today.strftime('%d-%m-%Y')}: {len(unpaid)} anggota belum lunas, "
            f"total tunggakan {formatted_total}, dihitung dari Januari sampai {MONTHS[month-1]} {year}."
        )
        for treasurer in treasurers:
            _upsert_notice(
                db, treasurer, year, month, "TREASURER_SUMMARY",
                f"Rekap Tunggakan {MONTHS[month-1]} {year}", message, total, send_wa,
            )

    db.commit()
    return {
        "generated": len(unpaid) + (len(treasurers) if unpaid else 0),
        "members_unpaid": len(unpaid),
        "total_outstanding": float(total),
        "sender": settings.WA_SENDER_NUMBER,
    }
