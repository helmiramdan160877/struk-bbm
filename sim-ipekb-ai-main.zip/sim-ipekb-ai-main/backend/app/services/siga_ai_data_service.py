from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime

from sqlalchemy.orm import Session

from app.core.encryption import encryption_service
from app.models.family import Family
from app.models.user_village import UserVillage
from app.models.village import Village
from app.platform.siga_accounts.scope import (
    get_role_name,
    get_preferred_siga_account,
)
from app.sync.base_sync import BaseSync


DATA_KEYWORDS = (
    "pus", "pasangan usia subur", "kk", "keluarga", "anggota",
    "peserta kb", "peserta keluarga berencana", "kb aktif", "rekap",
    "jumlah", "data siga", "desa", "kecamatan", "capaian",
    "wilayah", "kelurahan", "stunting",
)


def _needs_siga_data(message: str) -> bool:
    text = (message or "").lower()
    return any(keyword in text for keyword in DATA_KEYWORDS)


def _is_pus(value) -> bool:
    if value is True:
        return True
    if value in (1, "1"):
        return True
    if isinstance(value, str):
        normalized = value.strip().lower()
        return normalized in {"true", "yes", "ya", "pus", "1", "aktif"}
    return False


def _rows_from_response(response) -> list[dict]:
    if isinstance(response, list):
        return response
    if not isinstance(response, dict):
        return []
    value = response.get("data")
    if isinstance(value, list):
        return value
    for key in ("content", "result", "results", "rows", "list", "items"):
        value = response.get(key)
        if isinstance(value, list):
            return value
    return []


def _fetch_parent_rows(session, bulan: int, tahun: int) -> list[dict]:
    endpoint = "/rekapitulasi-data-keluarga/siga/rekap/parentRekapPK"
    rows: list[dict] = []
    page = 1

    while True:
        params = {
            "bulan": bulan,
            "tahun": tahun,
            "page": page,
            "recordPerPage": 500,
            "idProvinsi": session.province_id,
            "idKabupaten": session.regency_id,
            "idKecamatan": session.district_id,
        }
        # AI request tidak boleh menggantung selama mekanisme sync penuh.
        response = BaseSync.__new__(BaseSync)
        # Gunakan helper HTTP yang sama dengan modul sinkronisasi.
        from app.sync.base_api_sync import BaseApiSync
        api = BaseApiSync(None, session)
        payload = api.get_json(endpoint, params=params, retry=1, timeout=12)
        page_rows = _rows_from_response(payload)
        if not page_rows:
            break
        rows.extend(page_rows)
        if len(page_rows) < 500:
            break
        page += 1
        if page > 20:
            break
    return rows


def _local_family_rows(db: Session, user, account) -> list[dict]:
    """Read cached family data only inside the user's SIGA account scope."""
    query = (
        db.query(Family, Village.name, Village.siga_id)
        .join(Village, Village.id == Family.village_id)
        .filter(
            Family.is_active.is_(True),
            Village.is_active.is_(True),
            Village.district_id == account.district_id,
        )
    )

    role = get_role_name(user)
    if role in {"PKB", "KADER", "ANGGOTA"}:
        query = query.join(UserVillage, UserVillage.village_id == Village.id).filter(
            UserVillage.user_id == user.id,
        )

    return [
        {
            "namaKelurahan": village_name,
            "kelurahanId": village_siga_id,
        }
        for _, village_name, village_siga_id in query.all()
    ]


def _build_aggregate_context(rows: list[dict], source: str, role: str, account_username: str, bulan: int, tahun: int) -> str:
    village_counts: dict[str, int] = defaultdict(int)
    for row in rows:
        name = str(
            row.get("namaKelurahan")
            or row.get("kelurahan")
            or row.get("namaDesa")
            or row.get("kelurahanId")
            or "Tidak diketahui"
        )
        village_counts[name] += 1

    lines = [
        f"Sumber data: {source}.",
        f"Periode data yang diminta backend: {bulan:02d}/{tahun}.",
        f"Role user: {role or 'TIDAK DIKETAHUI'}.",
        f"Akun SIGA: {account_username}.",
        f"Total KK dari data SIGA yang masuk scope: {len(rows)}.",
        "Total PUS: tidak tersedia pada cache KK lokal maupun rekap endpoint ini.",
    ]
    if village_counts:
        lines.append("Rekap per desa/kelurahan:")
        for name, count in sorted(village_counts.items(), key=lambda item: (-item[1], item[0]))[:100]:
            lines.append(f"- {name}: KK={count}")
    return "\n".join(lines)


def build_context(db: Session, user, message: str) -> str | None:
    """Build aggregate SIGA context, preferring local data before live API."""
    if not _needs_siga_data(message):
        return None

    role = get_role_name(user)
    account = get_preferred_siga_account(db, user, active_only=True)
    if account is None:
        return "STATUS SIGA: tidak ada akun SIGA aktif yang dapat diakses user."

    bulan = datetime.now().month
    tahun = datetime.now().year

    allowed_village_siga_ids: set[str] | None = None
    if role in {"PKB", "KADER", "ANGGOTA"}:
        rows = (
            db.query(Village.siga_id)
            .join(UserVillage, UserVillage.village_id == Village.id)
            .filter(
                UserVillage.user_id == user.id,
                Village.is_active.is_(True),
                Village.siga_id.is_not(None),
            )
            .all()
        )
        allowed_village_siga_ids = {str(row[0]) for row in rows if row[0]}
        if not allowed_village_siga_ids:
            return "STATUS SIGA: user belum memiliki desa binaan dengan SIGA ID."

    local_rows = _local_family_rows(db, user, account)
    if local_rows:
        return _build_aggregate_context(
            local_rows,
            "database lokal SIM IPEKB (cache hasil sinkronisasi SIGA)",
            role,
            account.username,
            bulan,
            tahun,
        )

    session = None
    try:
        password = encryption_service.decrypt(account.password_encrypted)
        session = BaseSync(db).login(account.username, password, timeout=12)
        rows = _fetch_parent_rows(session, bulan, tahun)
        if allowed_village_siga_ids is not None:
            rows = [
                row for row in rows
                if str(row.get("kelurahanId") or row.get("idKelurahan") or row.get("idDesa"))
                in allowed_village_siga_ids
            ]
        return _build_aggregate_context(
            rows,
            "SIGA live melalui API karena data belum tersedia di database lokal",
            role,
            account.username,
            bulan,
            tahun,
        )
    finally:
        if session is not None:
            session.close()
