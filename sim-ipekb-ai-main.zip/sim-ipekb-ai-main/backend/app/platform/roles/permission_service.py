from app.platform.roles.repository import RoleRepository
from app.platform.permissions.repository import PermissionRepository


class RolePermissionService:

    def __init__(self, db):
        self.db = db
        self.role_repo = RoleRepository(db)
        self.permission_repo = PermissionRepository(db)

    # =====================================================
    # GET PERMISSION ROLE
    # =====================================================

    def get_permissions(self, role_id):

        role = self.role_repo.get_by_id(role_id)

        if role is None:
            raise ValueError("Role tidak ditemukan")

        return role.permissions

    # =====================================================
    # SET PERMISSION
    # =====================================================

    def set_permissions(
        self,
        role_id,
        permission_ids,
    ):

        role = self.role_repo.get_by_id(role_id)

        if role is None:
            raise ValueError("Role tidak ditemukan")

        role.permissions.clear()

        for permission_id in permission_ids:

            permission = self.permission_repo.get_by_id(
                permission_id
            )

            if permission:
                role.permissions.append(permission)

        self.db.commit()
        self.db.refresh(role)

        return role

    # =====================================================
    # ADD PERMISSION
    # =====================================================

    def add_permission(
        self,
        role_id,
        permission_id,
    ):

        role = self.role_repo.get_by_id(role_id)

        permission = self.permission_repo.get_by_id(
            permission_id
        )

        if role is None:
            raise ValueError("Role tidak ditemukan")

        if permission is None:
            raise ValueError("Permission tidak ditemukan")

        if permission not in role.permissions:
            role.permissions.append(permission)

        self.db.commit()

        return role

    # =====================================================
    # REMOVE PERMISSION
    # =====================================================

    def remove_permission(
        self,
        role_id,
        permission_id,
    ):

        role = self.role_repo.get_by_id(role_id)

        permission = self.permission_repo.get_by_id(
            permission_id
        )

        if (
            role
            and permission
            and permission in role.permissions
        ):
            role.permissions.remove(permission)

        self.db.commit()

        return role