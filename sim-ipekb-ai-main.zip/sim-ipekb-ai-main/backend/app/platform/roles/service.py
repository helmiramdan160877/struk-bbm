from app.models.role import Role


class RoleService:

    def __init__(self, repository):
        self.repository = repository

    # =====================================================
    # GET
    # =====================================================

    def get_all_roles(self):
        return self.repository.get_all()

    def get_role_by_id(self, role_id):
        return self.repository.get_by_id(role_id)

    def get_role_by_name(self, name):
        return self.repository.get_by_name(name)

    def count_roles(self):
        return self.repository.count()

    # =====================================================
    # CREATE
    # =====================================================

    def create_role(
        self,
        name,
        description=None,
    ):
        if self.repository.exists(name):
            raise ValueError("Role sudah ada")

        role = Role(
            name=name.strip(),
            description=description,
            is_active=True,
        )

        return self.repository.create(role)

    # =====================================================
    # UPDATE
    # =====================================================

    def update_role(
        self,
        role,
        name=None,
        description=None,
        is_active=None,
    ):
        if (
            name is not None
            and name != role.name
        ):
            old = self.repository.get_by_name(name)

            if old:
                raise ValueError("Nama role sudah digunakan")

            role.name = name.strip()

        if description is not None:
            role.description = description

        if is_active is not None:
            role.is_active = is_active

        return self.repository.update(role)

    # =====================================================
    # ACTIVE / INACTIVE
    # =====================================================

    def activate(self, role):
        role.is_active = True
        return self.repository.update(role)

    def deactivate(self, role):
        role.is_active = False
        return self.repository.update(role)

    # =====================================================
    # DELETE
    # =====================================================

    def delete_role(self, role):
        self.repository.delete(role)