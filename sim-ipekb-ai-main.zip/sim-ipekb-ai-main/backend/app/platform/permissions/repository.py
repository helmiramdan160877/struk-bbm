from sqlalchemy.orm import Session

from app.models.permission import Permission


class PermissionRepository:

    def __init__(self, db: Session):
        self.db = db

    def get_all(self):
        return (
            self.db.query(Permission)
            .order_by(Permission.name)
            .all()
        )

    def get_by_id(self, permission_id):
        return (
            self.db.query(Permission)
            .filter(Permission.id == permission_id)
            .first()
        )

    def get_by_name(self, name):
        return (
            self.db.query(Permission)
            .filter(Permission.name == name)
            .first()
        )

    def get_by_code(self, code):
        return (
            self.db.query(Permission)
            .filter(Permission.code == code)
            .first()
        )

    def create(self, permission):
        self.db.add(permission)
        self.db.commit()
        self.db.refresh(permission)
        return permission

    def update(self, permission):
        self.db.add(permission)
        self.db.commit()
        self.db.refresh(permission)
        return permission

    def delete(self, permission):
        self.db.delete(permission)
        self.db.commit()

    def count(self):
        return (
            self.db.query(Permission)
            .count()
        )