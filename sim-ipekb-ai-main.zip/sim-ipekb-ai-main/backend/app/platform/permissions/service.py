from app.models.permission import Permission


class PermissionService:

    def __init__(self, repository):
        self.repository = repository

    def get_all(self):
        return self.repository.get_all()

    def get_by_id(self, permission_id):
        return self.repository.get_by_id(permission_id)

    def create(
        self,
        name,
        code,
        description=None,
    ):
        if self.repository.get_by_code(code):
            raise ValueError("Code sudah digunakan")

        permission = Permission(
            name=name,
            code=code,
            description=description,
            is_active=True,
        )

        return self.repository.create(permission)

    def update(
        self,
        permission,
        name=None,
        code=None,
        description=None,
        is_active=None,
    ):
        if name is not None:
            permission.name = name

        if code is not None:
            permission.code = code

        if description is not None:
            permission.description = description

        if is_active is not None:
            permission.is_active = is_active

        return self.repository.update(permission)

    def delete(self, permission):
        self.repository.delete(permission)