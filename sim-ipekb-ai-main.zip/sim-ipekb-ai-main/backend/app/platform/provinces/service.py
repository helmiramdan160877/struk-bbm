from app.models.province import Province


class ProvinceService:

    def __init__(self, repository):
        self.repository = repository

    def get_all_provinces(self):
        return self.repository.get_all()

    def get_province_by_id(self, province_id):
        return self.repository.get_by_id(province_id)

    def create_province(self, code, name):
        if self.repository.get_by_code(code):
            raise ValueError("Kode provinsi sudah digunakan")

        province = Province(
            code=code,
            name=name,
            is_active=True,
        )

        return self.repository.create(province)

    def update_province(
        self,
        province,
        code=None,
        name=None,
        is_active=None,
    ):
        if code is not None:
            province.code = code

        if name is not None:
            province.name = name

        if is_active is not None:
            province.is_active = is_active

        self.repository.update()

        return province

    def delete_province(self, province):
        self.repository.delete(province)