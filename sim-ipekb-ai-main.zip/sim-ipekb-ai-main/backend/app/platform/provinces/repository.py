from sqlalchemy.orm import Session

from app.models.province import Province


class ProvinceRepository:

    def __init__(self, db: Session):
        self.db = db

    def get_all(self):
        return self.db.query(Province).all()

    def get_by_id(self, province_id):
        return (
            self.db.query(Province)
            .filter(Province.id == province_id)
            .first()
        )

    def get_by_code(self, code: str):
        return (
            self.db.query(Province)
            .filter(Province.code == code)
            .first()
        )

    def get_by_siga_id(self, siga_id: str):
        return (
            self.db.query(Province)
            .filter(Province.siga_id == siga_id)
            .first()
        )

    def save(
        self,
        *,
        siga_id: str,
        code: str,
        name: str,
        is_active: bool = True,
    ):
        province = self.get_by_siga_id(siga_id)

        if province:
            province.code = code
            province.name = name
            province.is_active = is_active
        else:
            province = Province(
                siga_id=siga_id,
                code=code,
                name=name,
                is_active=is_active,
            )
            self.db.add(province)

        self.db.commit()
        self.db.refresh(province)

        return province

    def create(self, province: Province):
        self.db.add(province)
        self.db.commit()
        self.db.refresh(province)
        return province

    def update(self):
        self.db.commit()

    def delete(self, province: Province):
        self.db.delete(province)
        self.db.commit()