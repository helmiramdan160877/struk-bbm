from uuid import UUID

from sqlalchemy.orm import Session

from app.models.user import User


class UserRepository:

    def __init__(self, db: Session):
        self.db = db

    # =====================================================
    # GET
    # =====================================================

    def get_all(self):
        return (
            self.db.query(User)
            .order_by(User.full_name.asc())
            .all()
        )

    def get_by_id(self, user_id: UUID):
        return (
            self.db.query(User)
            .filter(User.id == user_id)
            .first()
        )

    def get_by_username(self, username: str):
        return (
            self.db.query(User)
            .filter(User.username == username)
            .first()
        )

    def get_by_email(self, email: str):
        return (
            self.db.query(User)
            .filter(User.email == email)
            .first()
        )

    # =====================================================
    # CREATE
    # =====================================================

    def create(self, user: User):
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        return user

    # =====================================================
    # UPDATE
    # =====================================================

    def update(self, user: User):
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        return user

    # =====================================================
    # STATUS USER
    # =====================================================

    def activate(self, user_id: UUID):

        user = self.get_by_id(user_id)

        if user is None:
            return None

        user.is_active = True

        self.db.commit()
        self.db.refresh(user)

        return user

    def deactivate(self, user_id: UUID):

        user = self.get_by_id(user_id)

        if user is None:
            return None

        user.is_active = False

        self.db.commit()
        self.db.refresh(user)

        return user

    # =====================================================
    # CHANGE ROLE
    # =====================================================

    def change_role(
        self,
        user_id: UUID,
        role_id: UUID,
    ):

        user = self.get_by_id(user_id)

        if user is None:
            return None

        user.role_id = role_id

        self.db.commit()
        self.db.refresh(user)

        return user

    # =====================================================
    # CHANGE PASSWORD
    # =====================================================

    def change_password(
        self,
        user_id: UUID,
        hashed_password: str,
    ):

        user = self.get_by_id(user_id)

        if user is None:
            return None

        user.hashed_password = hashed_password

        self.db.commit()
        self.db.refresh(user)

        return user

    # =====================================================
    # DELETE
    # =====================================================

    def delete(self, user: User):

        self.db.delete(user)
        self.db.commit()

        return True