from uuid import UUID

from sqlalchemy.orm import Session

from app.models.user_village import UserVillage
from app.models.village import Village
from app.models.district import District


class UserVillageRepository:

    def __init__(self, db: Session):
        self.db = db

    def get_by_user(self, user_id: UUID):
        return (
            self.db.query(UserVillage)
            .join(Village, UserVillage.village_id == Village.id)
            .filter(UserVillage.user_id == user_id)
            .all()
        )

    def get_villages_by_user(self, user_id: UUID):
        return (
            self.db.query(Village)
            .join(
                UserVillage,
                UserVillage.village_id == Village.id,
            )
            .filter(
                UserVillage.user_id == user_id
            )
            .order_by(Village.name.asc())
            .all()
        )

    def get_district_ids_by_user(self, user_id: UUID):
        rows = (
            self.db.query(District.id)
            .join(
                Village,
                Village.district_id == District.id,
            )
            .join(
                UserVillage,
                UserVillage.village_id == Village.id,
            )
            .filter(
                UserVillage.user_id == user_id
            )
            .distinct()
            .all()
        )

        return [row[0] for row in rows]

    def exists(
        self,
        user_id: UUID,
        village_id: UUID,
    ):
        return (
            self.db.query(UserVillage)
            .filter(
                UserVillage.user_id == user_id,
                UserVillage.village_id == village_id,
            )
            .first()
        )

    def create(
        self,
        user_id: UUID,
        village_id: UUID,
    ):
        existing = self.exists(
            user_id,
            village_id,
        )

        if existing:
            return existing

        item = UserVillage(
            user_id=user_id,
            village_id=village_id,
        )

        self.db.add(item)
        self.db.commit()
        self.db.refresh(item)

        return item

    def delete(
        self,
        user_id: UUID,
        village_id: UUID,
    ):
        item = self.exists(
            user_id,
            village_id,
        )

        if not item:
            return False

        self.db.delete(item)
        self.db.commit()

        return True