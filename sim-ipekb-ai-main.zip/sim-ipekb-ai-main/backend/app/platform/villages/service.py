from app.models.village import Village


class VillageService:
    def __init__(self, repository):
        self.repository = repository

    def get_all_villages(self):
        return self.repository.get_all()

    def get_village_by_id(self, village_id):
        return self.repository.get_by_id(village_id)

    def create_village(
        self,
        district_id,
        code,
        name,
    ):
        if self.repository.get_by_code(code):
            raise ValueError("Kode desa sudah digunakan")

        village = Village(
            district_id=district_id,
            code=code,
            name=name,
        )

        return self.repository.create(village)

    def update_village(
        self,
        village,
        district_id=None,
        code=None,
        name=None,
        is_active=None,
    ):
        if district_id is not None:
            village.district_id = district_id

        if code is not None:
            village.code = code

        if name is not None:
            village.name = name

        if is_active is not None:
            village.is_active = is_active

        return self.repository.update(village)

    def delete_village(self, village):
        self.repository.delete(village)
    
    def get_by_siga_id(self, siga_id):
        return self.repository.get_by_siga_id(siga_id)