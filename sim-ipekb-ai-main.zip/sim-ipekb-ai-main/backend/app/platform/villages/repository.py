from sqlalchemy.orm import Session

from app.models.village import Village


class VillageRepository:

    def __init__(self, db: Session):
        self.db = db

    def get_all(self):
        return self.db.query(Village).all()

    def get_by_id(self, village_id):
        return (
            self.db.query(Village)
            .filter(Village.id == village_id)
            .first()
        )

    def get_by_code(self, code: str):
        return (
            self.db.query(Village)
            .filter(Village.code == code)
            .first()
        )

    def get_by_siga_id(self, siga_id: str):
        return (
            self.db.query(Village)
            .filter(Village.siga_id == siga_id)
            .first()
        )

    def save(
        self,
        *,
        district_id,
        siga_id: str,
        code: str,
        name: str,
        is_active: bool = True,
    ):
        village = self.get_by_siga_id(siga_id)

        if village:
            village.district_id = district_id
            village.code = code
            village.name = name
            village.is_active = is_active
        else:
            village = Village(
                district_id=district_id,
                siga_id=siga_id,
                code=code,
                name=name,
                is_active=is_active,
            )
            self.db.add(village)

        self.db.commit()
        self.db.refresh(village)

        return village

    def create(self, village: Village):
        self.db.add(village)
        self.db.commit()
        self.db.refresh(village)
        return village

    def update(self):
        self.db.commit()

    def delete(self, village: Village):
        self.db.delete(village)
        self.db.commit()