from uuid import UUID

from sqlalchemy.orm import Session

from app.models.pkb import PKB
from app.models.user_village import UserVillage


class PKBRepository:

    def __init__(self, db: Session):
        self.db = db

    # =========================================================
    # SEMUA PKB
    # =========================================================

    def get_all(self):
        return (
            self.db.query(PKB)
            .order_by(PKB.nama.asc())
            .all()
        )

    # =========================================================
    # PKB BERDASARKAN DESA BINAAN USER
    # =========================================================

    def get_all_by_user(self, user_id: UUID):
        return (
            self.db.query(PKB)
            .join(
                UserVillage,
                UserVillage.village_id == PKB.village_id,
            )
            .filter(
                UserVillage.user_id == user_id
            )
            .order_by(PKB.nama.asc())
            .all()
        )

    # =========================================================
    # PKB BERDASARKAN DAFTAR VILLAGE IDS
    # =========================================================

    def get_all_by_villages(self, village_ids: list[UUID]):
        """
        Ambil semua PKB yang berada di list village_ids.
        Digunakan untuk filter data PKB sesuai wilayah binaan user.
        """
        if not village_ids:
            return []
        return (
            self.db.query(PKB)
            .filter(PKB.village_id.in_(village_ids))
            .order_by(PKB.nama.asc())
            .all()
        )

    # =========================================================
    # GET BY ID
    # =========================================================

    def get_by_id(self, pkb_id: UUID):
        return (
            self.db.query(PKB)
            .filter(PKB.id == pkb_id)
            .first()
        )

    # =========================================================
    # GET BY ID + USER
    # =========================================================

    def get_by_id_for_user(
        self,
        pkb_id: UUID,
        user_id: UUID,
    ):
        return (
            self.db.query(PKB)
            .join(
                UserVillage,
                UserVillage.village_id == PKB.village_id,
            )
            .filter(
                PKB.id == pkb_id,
                UserVillage.user_id == user_id,
            )
            .first()
        )

    # =========================================================
    # GET BY NIP
    # =========================================================

    def get_by_nip(self, nip: str):
        return (
            self.db.query(PKB)
            .filter(PKB.nip == nip)
            .first()
        )

    # =========================================================
    # GET BY NIK
    # =========================================================

    def get_by_nik(self, nik: str):
        return (
            self.db.query(PKB)
            .filter(PKB.nik == nik)
            .first()
        )

    # =========================================================
    # SEARCH SEMUA
    # =========================================================

    def search(self, keyword: str):
        return (
            self.db.query(PKB)
            .filter(
                (PKB.nama.ilike(f"%{keyword}%"))
                | (PKB.nip.ilike(f"%{keyword}%"))
                | (PKB.nik.ilike(f"%{keyword}%"))
            )
            .order_by(PKB.nama.asc())
            .all()
        )

    # =========================================================
    # SEARCH BERDASARKAN DESA USER
    # =========================================================

    def search_by_user(
        self,
        keyword: str,
        user_id: UUID,
    ):
        return (
            self.db.query(PKB)
            .join(
                UserVillage,
                UserVillage.village_id == PKB.village_id,
            )
            .filter(
                UserVillage.user_id == user_id,
                (
                    (PKB.nama.ilike(f"%{keyword}%"))
                    | (PKB.nip.ilike(f"%{keyword}%"))
                    | (PKB.nik.ilike(f"%{keyword}%"))
                ),
            )
            .order_by(PKB.nama.asc())
            .all()
        )

    # =========================================================
    # CREATE
    # =========================================================

    def create(self, pkb: PKB):
        self.db.add(pkb)
        self.db.commit()
        self.db.refresh(pkb)

        return pkb

    # =========================================================
    # UPDATE
    # =========================================================

    def update(self, pkb: PKB):
        self.db.add(pkb)
        self.db.commit()
        self.db.refresh(pkb)

        return pkb

    # =========================================================
    # DELETE
    # =========================================================

    def delete(self, pkb: PKB):
        self.db.delete(pkb)
        self.db.commit()

    # =========================================================
    # TOTAL
    # =========================================================

    def total(self):
        return self.db.query(PKB).count()

    # =========================================================
    # TOTAL BERDASARKAN USER
    # =========================================================

    def total_by_user(self, user_id: UUID):
        return (
            self.db.query(PKB)
            .join(
                UserVillage,
                UserVillage.village_id == PKB.village_id,
            )
            .filter(
                UserVillage.user_id == user_id
            )
            .count()
        )

    # =========================================================
    # ACTIVE
    # =========================================================

    def total_active(self):
        return (
            self.db.query(PKB)
            .filter(PKB.status == "AKTIF")
            .count()
        )

    # =========================================================
    # ACTIVE BERDASARKAN USER
    # =========================================================

    def total_active_by_user(self, user_id: UUID):
        return (
            self.db.query(PKB)
            .join(
                UserVillage,
                UserVillage.village_id == PKB.village_id,
            )
            .filter(
                UserVillage.user_id == user_id,
                PKB.status == "AKTIF",
            )
            .count()
        )

    # =========================================================
    # INACTIVE
    # =========================================================

    def total_inactive(self):
        return (
            self.db.query(PKB)
            .filter(PKB.status != "AKTIF")
            .count()
        )

    # =========================================================
    # INACTIVE BERDASARKAN USER
    # =========================================================

    def total_inactive_by_user(self, user_id: UUID):
        return (
            self.db.query(PKB)
            .join(
                UserVillage,
                UserVillage.village_id == PKB.village_id,
            )
            .filter(
                UserVillage.user_id == user_id,
                PKB.status != "AKTIF",
            )
            .count()
        )