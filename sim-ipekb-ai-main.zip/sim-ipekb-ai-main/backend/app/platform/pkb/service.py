from uuid import UUID

from app.models.pkb import PKB


class PKBService:

    def __init__(self, repository):
        self.repository = repository

    # =========================================================
    # SUPER ADMIN
    # =========================================================

    def get_all(self):
        return self.repository.get_all()

    # =========================================================
    # PKB BERDASARKAN DAFTAR VILLAGE IDS
    # =========================================================

    def get_all_by_villages(self, village_ids: list[UUID]):
        """
        Ambil semua PKB yang berada di village_ids yang diberikan.
        Digunakan untuk filter data PKB sesuai wilayah binaan user.
        """
        if not village_ids:
            return []
        return self.repository.get_all_by_villages(village_ids)

    # =========================================================
    # USER BERDASARKAN DESA BINAAN
    # =========================================================

    def get_all_by_user(self, user_id: UUID):
        return self.repository.get_all_by_user(user_id)

    # =========================================================
    # GET BY ID
    # =========================================================

    def get_by_id(self, pkb_id):
        return self.repository.get_by_id(pkb_id)

    # =========================================================
    # GET BY ID BERDASARKAN WILAYAH USER
    # =========================================================

    def get_by_id_for_user(
        self,
        pkb_id,
        user_id,
    ):
        return self.repository.get_by_id_for_user(
            pkb_id,
            user_id,
        )

    # =========================================================
    # SEARCH
    # =========================================================

    def search(self, keyword):
        return self.repository.search(keyword)

    # =========================================================
    # SEARCH USER
    # =========================================================

    def search_by_user(
        self,
        keyword,
        user_id,
    ):
        return self.repository.search_by_user(
            keyword,
            user_id,
        )

    # =========================================================
    # CREATE
    # =========================================================

    def create(
        self,
        nip,
        nik,
        nama,
        tempat_lahir=None,
        tanggal_lahir=None,
        jenis_kelamin=None,
        agama=None,
        pendidikan=None,
        jabatan=None,
        status_asn=None,
        golongan=None,
        email=None,
        phone=None,
        alamat=None,
        photo=None,
        kecamatan=None,
        desa=None,
        wilayah_binaan=None,
        village_id=None,
        siga_account_id=None,
        status="AKTIF",
    ):

        if self.repository.get_by_nip(nip):
            raise ValueError("NIP sudah digunakan")

        if self.repository.get_by_nik(nik):
            raise ValueError("NIK sudah digunakan")

        pkb = PKB(
            nip=nip,
            nik=nik,
            nama=nama,
            tempat_lahir=tempat_lahir,
            tanggal_lahir=tanggal_lahir,
            jenis_kelamin=jenis_kelamin,
            agama=agama,
            pendidikan=pendidikan,
            jabatan=jabatan,
            status_asn=status_asn,
            golongan=golongan,
            email=email,
            phone=phone,
            alamat=alamat,
            photo=photo,
            kecamatan=kecamatan,
            desa=desa,
            wilayah_binaan=wilayah_binaan,
            village_id=village_id,
            siga_account_id=siga_account_id,
            status=status or "AKTIF",
        )

        return self.repository.create(pkb)

    # =========================================================
    # UPDATE
    # =========================================================

    def update(
        self,
        pkb,
        nip=None,
        nik=None,
        nama=None,
        tempat_lahir=None,
        tanggal_lahir=None,
        jenis_kelamin=None,
        agama=None,
        pendidikan=None,
        jabatan=None,
        status_asn=None,
        golongan=None,
        email=None,
        phone=None,
        alamat=None,
        photo=None,
        kecamatan=None,
        desa=None,
        wilayah_binaan=None,
        village_id=None,
        siga_account_id=None,
        status=None,
    ):

        if nip is not None and nip != pkb.nip:
            existing = self.repository.get_by_nip(nip)

            if existing and existing.id != pkb.id:
                raise ValueError("NIP sudah digunakan")

            pkb.nip = nip

        if nik is not None and nik != pkb.nik:
            existing = self.repository.get_by_nik(nik)

            if existing and existing.id != pkb.id:
                raise ValueError("NIK sudah digunakan")

            pkb.nik = nik

        if nama is not None:
            pkb.nama = nama

        if tempat_lahir is not None:
            pkb.tempat_lahir = tempat_lahir

        if tanggal_lahir is not None:
            pkb.tanggal_lahir = tanggal_lahir

        if jenis_kelamin is not None:
            pkb.jenis_kelamin = jenis_kelamin

        if agama is not None:
            pkb.agama = agama

        if pendidikan is not None:
            pkb.pendidikan = pendidikan

        if jabatan is not None:
            pkb.jabatan = jabatan

        if status_asn is not None:
            pkb.status_asn = status_asn

        if golongan is not None:
            pkb.golongan = golongan

        if email is not None:
            pkb.email = email

        if phone is not None:
            pkb.phone = phone

        if alamat is not None:
            pkb.alamat = alamat

        if photo is not None:
            pkb.photo = photo

        if kecamatan is not None:
            pkb.kecamatan = kecamatan

        if desa is not None:
            pkb.desa = desa

        if wilayah_binaan is not None:
            pkb.wilayah_binaan = wilayah_binaan

        if village_id is not None:
            pkb.village_id = village_id

        if siga_account_id is not None:
            pkb.siga_account_id = siga_account_id

        if status is not None:
            pkb.status = status

        return self.repository.update(pkb)

    # =========================================================
    # DELETE
    # =========================================================

    def delete_by_id(self, pkb_id):
        pkb = self.repository.get_by_id(pkb_id)

        if not pkb:
            return False

        self.repository.delete(pkb)

        return True

    # =========================================================
    # SUMMARY SUPER ADMIN
    # =========================================================

    def summary(self):
        return {
            "total": self.repository.total(),
            "active": self.repository.total_active(),
            "inactive": self.repository.total_inactive(),
        }

    # =========================================================
    # SUMMARY USER
    # =========================================================

    def summary_by_user(self, user_id):
        return {
            "total": self.repository.total_by_user(user_id),
            "active": self.repository.total_active_by_user(user_id),
            "inactive": self.repository.total_inactive_by_user(user_id),
        }