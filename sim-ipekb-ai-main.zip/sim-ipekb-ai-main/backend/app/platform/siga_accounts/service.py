from uuid import UUID

from sqlalchemy.orm import Session

from app.core.encryption import encryption_service
from app.models.siga_account import SigaAccount
from app.platform.siga_accounts.repository import SigaAccountRepository
from app.schemas.siga_account import (
    SigaAccountCreate,
    SigaAccountUpdate,
)


class SigaAccountService:

    def __init__(self):
        self.repository = SigaAccountRepository()

    def create(self, db: Session, data: SigaAccountCreate) -> SigaAccount:
        encrypted_password = encryption_service.encrypt(data.password)

        account = SigaAccount(
            district_id=data.district_id,
            username=data.username.strip(),
            password_encrypted=encrypted_password,
            is_active=True,
        )

        return self.repository.create(db, account)

    def get_all(self, db: Session):
        return self.repository.get_all(db)

    def get_by_id(self, db: Session, account_id: UUID):
        return self.repository.get_by_id(db, account_id)

    def update(
        self,
        db: Session,
        account_id: UUID,
        data: SigaAccountUpdate,
    ):
        account = self.repository.get_by_id(db, account_id)

        if not account:
            return None

        if data.username is not None:
            account.username = data.username.strip()

        if data.password is not None:
            account.password_encrypted = encryption_service.encrypt(
                data.password
            )

        if data.is_active is not None:
            account.is_active = data.is_active

        return self.repository.update(db, account)

    def delete(self, db: Session, account_id: UUID):
        return self.repository.delete(db, account_id)


siga_account_service = SigaAccountService()