from __future__ import annotations

from uuid import UUID

from sqlalchemy.orm import Session

from app.models.siga_account import SigaAccount
from app.models.user_siga_account import UserSigaAccount
from app.models.user_village import UserVillage
from app.models.village import Village


def get_role_name(user) -> str:
    role = getattr(user, "role", None)
    role_name = (getattr(role, "name", "") or "").strip().upper()
    return "SUPER_ADMIN" if role_name == "SUPERADMIN" else role_name


def get_user_district_ids(db: Session, user) -> list[UUID]:
    """Return district IDs that belong to the user's operational scope."""

    role_name = get_role_name(user)

    if role_name == "ADMIN":
        district_id = getattr(user, "district_id", None)
        return [district_id] if district_id is not None else []

    if role_name in {"PKB", "KADER", "PPKBD", "ANGGOTA"}:
        rows = (
            db.query(Village.district_id)
            .join(UserVillage, UserVillage.village_id == Village.id)
            .filter(
                UserVillage.user_id == user.id,
                Village.is_active.is_(True),
            )
            .distinct()
            .all()
        )
        return [row[0] for row in rows]

    district_id = getattr(user, "district_id", None)
    return [district_id] if district_id is not None else []


def get_accessible_siga_accounts(
    db: Session,
    user,
    *,
    active_only: bool = False,
) -> list[SigaAccount]:
    """Return SIGA accounts visible to the current user.

    PKB/KADER access is derived from the districts of their assigned villages,
    so an account from another operational area is never exposed merely because
    it exists in the database.
    """

    role_name = get_role_name(user)
    query = db.query(SigaAccount)

    if active_only:
        query = query.filter(SigaAccount.is_active.is_(True))

    if role_name == "SUPER_ADMIN":
        return query.order_by(SigaAccount.username.asc()).all()

    if role_name == "ADMIN":
        district_ids = get_user_district_ids(db, user)
        if not district_ids:
            return []
        return (
            query.filter(SigaAccount.district_id.in_(district_ids))
            .order_by(SigaAccount.username.asc())
            .all()
        )

    if role_name in {"PKB", "KADER", "PPKBD"}:
        district_ids = get_user_district_ids(db, user)
        if not district_ids:
            return []
        return (
            query.filter(SigaAccount.district_id.in_(district_ids))
            .order_by(SigaAccount.username.asc())
            .all()
        )

    if role_name == "OPERATOR":
        district_ids = get_user_district_ids(db, user)
        if district_ids:
            query = query.filter(SigaAccount.district_id.in_(district_ids))
        return query.order_by(SigaAccount.username.asc()).all()

    return []


def get_preferred_siga_account(
    db: Session,
    user,
    *,
    active_only: bool = True,
) -> SigaAccount | None:
    """Select one deterministic SIGA account from the user's valid scope."""

    accounts = get_accessible_siga_accounts(db, user, active_only=active_only)
    if not accounts:
        return None

    current_username = (getattr(user, "username", "") or "").strip()
    if current_username:
        for account in accounts:
            if account.username == current_username:
                return account

    linked_ids = {
        row[0]
        for row in (
            db.query(UserSigaAccount.siga_account_id)
            .filter(UserSigaAccount.user_id == user.id)
            .all()
        )
    }
    for account in accounts:
        if account.id in linked_ids:
            return account

    return accounts[0]


def reconcile_user_siga_accounts(db: Session, user_id: UUID) -> None:
    """Keep UserSigaAccount links aligned with PKB/KADER village assignments.

    The dynamic scope remains the source of truth. These links are maintained as
    an explicit mapping so other modules can safely use the existing relation.
    """

    from app.models.user import User

    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        return

    role_name = get_role_name(user)
    existing = (
        db.query(UserSigaAccount)
        .filter(UserSigaAccount.user_id == user_id)
        .all()
    )

    # Jika user sudah memilih akun SIGA secara eksplisit, pilihan tersebut
    # menjadi sumber kebenaran dan tidak diganti otomatis saat desa berubah.
    if role_name in {"PKB", "KADER", "PPKBD"} and existing:
        return

    district_ids = get_user_district_ids(db, user) if role_name in {"PKB", "KADER", "PPKBD"} else []
    target_ids: set[UUID] = set()
    if district_ids:
        target_ids = {
            row[0]
            for row in (
                db.query(SigaAccount.id)
                .filter(
                    SigaAccount.district_id.in_(district_ids),
                    SigaAccount.is_active.is_(True),
                )
                .all()
            )
        }

    existing_ids = {row.siga_account_id for row in existing}
    for account_id in target_ids - existing_ids:
        db.add(UserSigaAccount(user_id=user_id, siga_account_id=account_id))
    db.commit()
