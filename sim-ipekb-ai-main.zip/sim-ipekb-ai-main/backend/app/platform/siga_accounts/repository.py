from uuid import UUID

from sqlalchemy.orm import Session

from app.models.siga_account import SigaAccount


class SigaAccountRepository:

    def create(self, db: Session, account: SigaAccount) -> SigaAccount:
        db.add(account)
        db.commit()
        db.refresh(account)
        return account

    def get_all(self, db: Session):
        return (
            db.query(SigaAccount)
            .order_by(SigaAccount.username)
            .all()
        )

    def get_active_accounts(
        self,
        db: Session,
    ) -> list[SigaAccount]:
        return (
            db.query(SigaAccount)
            .filter(SigaAccount.is_active.is_(True))
            .order_by(SigaAccount.username)
            .all()
        )

    def get_by_id(
        self,
        db: Session,
        account_id: UUID,
    ) -> SigaAccount | None:
        return (
            db.query(SigaAccount)
            .filter(SigaAccount.id == account_id)
            .first()
        )

    def get_by_username(
        self,
        db: Session,
        username: str,
    ) -> SigaAccount | None:
        return (
            db.query(SigaAccount)
            .filter(SigaAccount.username == username)
            .first()
        )

    def update(
        self,
        db: Session,
        account: SigaAccount,
    ) -> SigaAccount:
        db.commit()
        db.refresh(account)
        return account

    def delete(
        self,
        db: Session,
        account_id: UUID,
    ) -> bool:
        account = self.get_by_id(db, account_id)

        if account is None:
            return False

        db.delete(account)
        db.commit()

        return True