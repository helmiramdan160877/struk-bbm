from uuid import UUID

from app.models.family import Family


class FamilyService:

    def __init__(self, repository):
        self.repository = repository

    # =========================================================
    # GET FAMILIES
    # =========================================================

    def get_families(
        self,
        village_ids: list[UUID] | None = None,
        page: int = 1,
        limit: int = 50,
    ):
        items, total = self.repository.get_all(
            village_ids=village_ids,
            page=page,
            limit=limit,
        )

        total_pages = (
            (total + limit - 1) // limit
            if total > 0
            else 0
        )

        return {
            "items": items,
            "total": total,
            "page": page,
            "limit": limit,
            "total_pages": total_pages,
        }

    # =========================================================
    # GET BY ID
    # =========================================================

    def get_family_by_id(
        self,
        family_id: UUID,
        village_ids: list[UUID] | None = None,
    ):
        return self.repository.get_by_id_and_villages(
            family_id=family_id,
            village_ids=village_ids,
        )

    # =========================================================
    # CREATE
    # =========================================================

    def create_family(
        self,
        village_id: UUID,
        family_card_number: str,
        head_of_family: str,
        address: str,
        rt: str | None = None,
        rw: str | None = None,
        postal_code: str | None = None,
    ):

        existing = (
            self.repository
            .get_by_family_card_number(
                family_card_number
            )
        )

        if existing:
            raise ValueError(
                "Nomor KK sudah terdaftar."
            )

        family = Family(
            village_id=village_id,
            siga_id=family_card_number,
            family_card_number=family_card_number,
            head_of_family=head_of_family,
            address=address,
            rt=rt,
            rw=rw,
            postal_code=postal_code,
            is_active=True,
        )

        return self.repository.create(family)

    # =========================================================
    # UPDATE
    # =========================================================

    def update_family(
        self,
        family: Family,
        village_id: UUID,
        family_card_number: str,
        head_of_family: str,
        address: str,
        rt: str | None = None,
        rw: str | None = None,
        postal_code: str | None = None,
        is_active: bool = True,
    ):

        family.village_id = village_id
        family.family_card_number = family_card_number
        family.siga_id = family_card_number
        family.head_of_family = head_of_family
        family.address = address
        family.rt = rt
        family.rw = rw
        family.postal_code = postal_code
        family.is_active = is_active

        return self.repository.update(family)

    # =========================================================
    # DELETE
    # =========================================================

    def delete_family(
        self,
        family: Family,
    ):
        self.repository.delete(family)