from uuid import UUID

from sqlalchemy.orm import Session

from app.models.family import Family


class FamilyRepository:

    def __init__(self, db: Session):
        self.db = db

    # =========================================================
    # GET ALL
    # =========================================================

    def get_all(
        self,
        village_ids: list[UUID] | None = None,
        page: int = 1,
        limit: int = 50,
    ):
        query = self.db.query(Family)

        # =====================================================
        # FILTER WILAYAH
        # =====================================================

        if village_ids is not None:
            query = query.filter(
                Family.village_id.in_(village_ids)
            )

        # =====================================================
        # PAGINATION
        # =====================================================

        total = query.count()

        offset = (page - 1) * limit

        items = (
            query
            .order_by(Family.head_of_family.asc())
            .offset(offset)
            .limit(limit)
            .all()
        )

        return items, total

    # =========================================================
    # GET BY ID
    # =========================================================

    def get_by_id(
        self,
        family_id: UUID,
    ):
        return (
            self.db.query(Family)
            .filter(
                Family.id == family_id
            )
            .first()
        )

    # =========================================================
    # GET BY ID + VILLAGE SCOPE
    # =========================================================

    def get_by_id_and_villages(
        self,
        family_id: UUID,
        village_ids: list[UUID] | None = None,
    ):
        query = (
            self.db.query(Family)
            .filter(
                Family.id == family_id
            )
        )

        if village_ids is not None:
            query = query.filter(
                Family.village_id.in_(village_ids)
            )

        return query.first()

    # =========================================================
    # GET BY KK
    # =========================================================

    def get_by_family_card_number(
        self,
        family_card_number: str,
    ):
        return (
            self.db.query(Family)
            .filter(
                Family.family_card_number
                == family_card_number
            )
            .first()
        )

    # =========================================================
    # CREATE
    # =========================================================

    def create(
        self,
        family: Family,
    ):
        self.db.add(family)
        self.db.commit()
        self.db.refresh(family)

        return family

    # =========================================================
    # UPDATE
    # =========================================================

    def update(
        self,
        family: Family,
    ):
        self.db.commit()
        self.db.refresh(family)

        return family

    # =========================================================
    # DELETE
    # =========================================================

    def delete(
        self,
        family: Family,
    ):
        self.db.delete(family)
        self.db.commit()