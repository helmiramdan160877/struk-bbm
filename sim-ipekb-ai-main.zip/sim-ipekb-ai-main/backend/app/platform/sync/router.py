from fastapi import APIRouter, Depends

from sqlalchemy.orm import Session

from app.core.database import get_db

from app.sync.test_login import test_login


router = APIRouter(
    prefix="/sync",
    tags=["Sync"],
)


@router.get("/test-login")
def sync_test_login(
    db: Session = Depends(get_db)
):
    return test_login(db)