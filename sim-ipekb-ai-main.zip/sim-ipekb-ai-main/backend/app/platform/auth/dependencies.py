from typing import Callable

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.core.config import settings
from app.platform.users.repository import UserRepository


oauth2_scheme = OAuth2PasswordBearer(
    tokenUrl="/api/v1/auth/login",
)


def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Token tidak valid",
    )

    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM],
        )

        user_id = payload.get("sub")

        if user_id is None:
            raise credentials_exception

    except JWTError:
        raise credentials_exception

    repository = UserRepository(db)

    user = repository.get_by_id(user_id)

    if user is None:
        raise credentials_exception

    if not getattr(user, "is_active", False):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Akun tidak aktif",
        )

    return user


def require_roles(*roles: str) -> Callable:
    """
    Contoh:

    Depends(require_roles("SUPER_ADMIN"))
    Depends(require_roles("ADMIN"))
    """

    def checker(
        current_user=Depends(get_current_user),
    ):

        if current_user is None:
            raise HTTPException(
                status_code=401,
                detail="Unauthorized",
            )

        role = getattr(current_user, "role", None)

        if role is None:
            raise HTTPException(
                status_code=403,
                detail="User tidak memiliki role.",
            )

        if not getattr(role, "is_active", True):
            raise HTTPException(
                status_code=403,
                detail="Role user tidak aktif.",
            )

        role_name = (role.name or "").strip().upper()
        if role_name == "SUPERADMIN":
            role_name = "SUPER_ADMIN"

        # SUPER_ADMIN selalu boleh akses semua endpoint
        if role_name == "SUPER_ADMIN":
            return current_user

        allowed_roles = [
            "SUPER_ADMIN" if r.strip().upper() == "SUPERADMIN" else r.strip().upper()
            for r in roles
        ]

        if role_name not in allowed_roles:
            raise HTTPException(
                status_code=403,
                detail="Anda tidak memiliki hak akses.",
            )

        return current_user

    return checker