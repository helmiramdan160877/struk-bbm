from uuid import UUID

from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import get_current_user
from app.platform.user_villages.repository import UserVillageRepository
from app.models.village import Village


def get_user_village_ids(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
) -> list[UUID] | None:
    """Mengambil cakupan desa user.

    Return value sengaja dibedakan:
    - ``None`` = tanpa filter desa (SUPER_ADMIN).
    - ``[]`` = tidak mempunyai desa binaan, sehingga hasil data harus kosong.
    - ``[uuid, ...]`` = hanya desa tersebut.

    Pembedaan None dan [] penting agar akun KADER/PKB yang belum diberi
    wilayah tidak secara tidak sengaja dapat melihat seluruh data.
    """

    role = getattr(current_user, "role", None)
    role_name = ((getattr(role, "name", "") or "").strip().upper())

    if role_name == "SUPER_ADMIN":
        return None

    if role_name == "ADMIN":
        district_id = getattr(current_user, "district_id", None)
        if district_id is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Akun ADMIN belum memiliki kecamatan.",
            )

        villages = (
            db.query(Village)
            .filter(
                Village.district_id == district_id,
                Village.is_active.is_(True),
            )
            .all()
        )
        return [village.id for village in villages]

    repository = UserVillageRepository(db)
    user_villages = repository.get_by_user(current_user.id)
    return [item.village_id for item in user_villages]


def require_user_village(
    village_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
) -> UUID:
    """Memastikan user mempunyai akses ke desa tertentu."""

    role = getattr(current_user, "role", None)
    role_name = ((getattr(role, "name", "") or "").strip().upper())

    if role_name == "SUPER_ADMIN":
        return village_id

    if role_name == "ADMIN":
        district_id = getattr(current_user, "district_id", None)
        if district_id is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Akun ADMIN belum memiliki kecamatan.",
            )

        village = (
            db.query(Village)
            .filter(
                Village.id == village_id,
                Village.district_id == district_id,
                Village.is_active.is_(True),
            )
            .first()
        )
        if village is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Anda tidak memiliki akses ke desa ini.",
            )
        return village_id

    repository = UserVillageRepository(db)
    user_village = repository.get_by_user_village(
        user_id=current_user.id,
        village_id=village_id,
    )
    if user_village is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Anda tidak memiliki akses ke desa ini.",
        )
    return village_id
