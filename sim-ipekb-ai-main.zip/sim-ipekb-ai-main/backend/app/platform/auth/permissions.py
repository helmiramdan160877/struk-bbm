from fastapi import Depends, HTTPException, status

from app.platform.auth.dependencies import get_current_user


# =====================================================
# ROLE
# =====================================================

def require_roles(*roles):

    def checker(
        current_user=Depends(get_current_user),
    ):

        if current_user.role is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Role tidak ditemukan",
            )

        if current_user.role.name not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Anda tidak memiliki hak akses",
            )

        return current_user

    return checker


# =====================================================
# PERMISSION
# =====================================================

def has_permission(permission_code: str):

    def checker(
        current_user=Depends(get_current_user),
    ):

        if current_user.role is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Role tidak ditemukan",
            )

        permissions = {
            permission.code
            for permission in current_user.role.permissions
            if permission.is_active
        }

        if permission_code not in permissions:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Tidak memiliki permission '{permission_code}'",
            )

        return current_user

    return checker