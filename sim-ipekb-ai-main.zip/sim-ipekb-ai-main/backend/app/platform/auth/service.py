from app.platform.auth.hash import verify_password
from app.platform.auth.jwt import create_access_token


class AuthService:
    def __init__(self, user_service):
        self.user_service = user_service

    def login(self, username: str, password: str):

        user = self.user_service.get_user_by_username(username)

        if not user:
            return None

        if not verify_password(password, user.hashed_password):
            return None

        token = create_access_token(
            {
                "sub": str(user.id),
                "username": user.username,
                "role": user.role.name,
            }
        )

        return token