from uuid import UUID

from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import get_current_user
from app.platform.user_villages.repository import UserVillageRepository


def get_user_role(current_user):
    role = getattr(current_user, "role", None)

    if role is None:
        return ""

    return (role.name or "").strip().upper()


def get_allowed_village_ids(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
) -> list[UUID] | None:
    """
    Menentukan desa yang boleh diakses user.

    Return:
        None      = akses semua desa
        list[UUID] = hanya desa tertentu
    """

    role_name = get_user_role(current_user)

    # =====================================================
    # SUPER ADMIN
    # Semua kabupaten / kecamatan / desa
    # =====================================================

    if role_name == "SUPER_ADMIN":
        return None

    # =====================================================
    # ADMIN
    # Semua desa dalam kecamatan miliknya
    # =====================================================

    if role_name == "ADMIN":
        district_id = getattr(current_user, "district_id", None)

        if district_id is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admin belum memiliki kecamatan.",
            )

        return None

    # =====================================================
    # PKB / KADER
    # Hanya desa binaan
    # =====================================================

    if role_name in {"PKB", "KADER"}:
        repository = UserVillageRepository(db)

        user_villages = repository.get_by_user(
            current_user.id
        )

        return [
            item.village_id
            for item in user_villages
        ]

    # =====================================================
    # ROLE TIDAK DIKENAL
    # =====================================================

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Role user tidak memiliki akses wilayah.",
    )


def require_village_access(
    village_id: UUID,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
) -> UUID:
    """
    Memastikan user boleh mengakses desa tertentu.
    """

    role_name = get_user_role(current_user)

    # SUPER ADMIN
    if role_name == "SUPER_ADMIN":
        return village_id

    # ADMIN
    if role_name == "ADMIN":
        district_id = getattr(current_user, "district_id", None)

        if district_id is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admin belum memiliki kecamatan.",
            )

        from app.models.village import Village

        village = (
            db.query(Village)
            .filter(
                Village.id == village_id,
                Village.district_id == district_id,
            )
            .first()
        )

        if village is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Desa berada di luar kecamatan Anda.",
            )

        return village_id

    # PKB / KADER
    if role_name in {"PKB", "KADER"}:
        repository = UserVillageRepository(db)

        user_village = repository.get_by_user_village(
            user_id=current_user.id,
            village_id=village_id,
        )

        if user_village is None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Anda tidak memiliki akses ke desa ini.",
            )

        return village_id

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Role user tidak memiliki akses wilayah.",
    )