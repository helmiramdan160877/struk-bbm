from __future__ import annotations

from sqlalchemy.orm import Session

from app.platform.family.models import Family


class FamilyService:

    def __init__(self, db: Session):
        self.db = db

    def upsert(self, item: dict) -> Family:

        family = (
            self.db.query(Family)
            .filter(Family.no_keluarga == item["noKeluarga"])
            .first()
        )

        if family is None:
            family = Family(
                no_keluarga=item["noKeluarga"],
            )
            self.db.add(family)

        family.nik = item.get("nik")
        family.nama_kepala = item.get("nama")
        family.alamat = item.get("alamat")
        family.no_telepon = item.get("noTelepon")

        family.provinsi_id = item.get("provinsiId")
        family.kabupaten_id = item.get("kabupatenId")
        family.kecamatan_id = item.get("kecamatanId")
        family.kelurahan_id = item.get("kelurahanId")

        family.status_pus = item.get("statusPus")
        family.status_hamil = item.get("statusHamil")

        return family