class DashboardService:
    
    def __init__(self, repository):
        self.repository = repository

    def get_summary(self):
        return self.repository.summary()
    
    def get_chart(self):
        return self.repository.chart()