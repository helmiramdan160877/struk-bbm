from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import get_current_user

from app.platform.dashboard.repository import DashboardRepository
from app.platform.dashboard.service import DashboardService

router = APIRouter()


@router.get("/summary")
def summary(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):

    repository = DashboardRepository(db)

    service = DashboardService(repository)

    return service.get_summary()