from sqlalchemy.orm import Session

from app.models.user import User
from app.models.role import Role
from app.models.permission import Permission
from app.models.province import Province
from app.models.regency import Regency
from app.models.district import District
from app.models.village import Village
from app.models.family import Family
from app.models.family_member import FamilyMember


class DashboardRepository:

    def __init__(self, db: Session):
        self.db = db

    def summary(self):
        return {
            "users": self.db.query(User).count(),

            "active_users": self.db.query(User).filter(
                User.is_active.is_(True)
            ).count(),

            "inactive_users": self.db.query(User).filter(
                User.is_active.is_(False)
            ).count(),

            "roles": self.db.query(Role).count(),

            "permissions": self.db.query(Permission).count(),

            "province": self.db.query(Province).count(),

            "regency": self.db.query(Regency).count(),

            "district": self.db.query(District).count(),

            "village": self.db.query(Village).count(),

            "family": self.db.query(Family).count(),

            "member": self.db.query(FamilyMember).count(),

            "alive": self.db.query(FamilyMember).filter(
                FamilyMember.is_alive.is_(True)
            ).count(),

            "dead": self.db.query(FamilyMember).filter(
                FamilyMember.is_alive.is_(False)
            ).count(),

            "matched": self.db.query(FamilyMember).filter(
                FamilyMember.flag_padan.is_(True)
            ).count(),

            "unmatched": self.db.query(FamilyMember).filter(
                FamilyMember.flag_padan.is_(False)
            ).count(),
        }

    def chart(self):
        return {
            "labels": [
                "User Aktif",
                "User Nonaktif",
                "Keluarga",
                "Anggota",
                "Hidup",
                "Meninggal",
                "Padan",
                "Belum Padan",
            ],
            "series": [
                self.db.query(User).filter(
                    User.is_active.is_(True)
                ).count(),

                self.db.query(User).filter(
                    User.is_active.is_(False)
                ).count(),

                self.db.query(Family).count(),

                self.db.query(FamilyMember).count(),

                self.db.query(FamilyMember).filter(
                    FamilyMember.is_alive.is_(True)
                ).count(),

                self.db.query(FamilyMember).filter(
                    FamilyMember.is_alive.is_(False)
                ).count(),

                self.db.query(FamilyMember).filter(
                    FamilyMember.flag_padan.is_(True)
                ).count(),

                self.db.query(FamilyMember).filter(
                    FamilyMember.flag_padan.is_(False)
                ).count(),
            ]
        }