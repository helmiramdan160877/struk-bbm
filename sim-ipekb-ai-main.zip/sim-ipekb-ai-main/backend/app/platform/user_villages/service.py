from uuid import UUID

from app.models.user_village import UserVillage


class UserVillageService:

    def __init__(self, repository):
        self.repository = repository

    def exists(
        self,
        user_id: UUID,
        village_id: UUID,
    ):
        return self.repository.get_by_user_village(
            user_id,
            village_id,
        )

    def get_by_user(self, user_id: UUID):
        return self.repository.get_by_user(user_id)

    def assign(
        self,
        user_id: UUID,
        village_id: UUID,
    ):

        existing = self.exists(
            user_id,
            village_id,
        )

        if existing:
            raise ValueError(
                "Desa tersebut sudah menjadi desa binaan user"
            )

        user_village = UserVillage(
            user_id=user_id,
            village_id=village_id,
        )

        return self.repository.create(user_village)

    def remove(
        self,
        user_id: UUID,
        village_id: UUID,
    ):

        return self.repository.delete_by_user_village(
            user_id,
            village_id,
        )