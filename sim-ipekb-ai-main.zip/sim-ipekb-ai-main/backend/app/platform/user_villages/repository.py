from uuid import UUID

from sqlalchemy.orm import Session

from app.models.user_village import UserVillage


class UserVillageRepository:

    def __init__(self, db: Session):
        self.db = db

    def get_by_user_village(
        self,
        user_id: UUID,
        village_id: UUID,
    ):
        return (
            self.db.query(UserVillage)
            .filter(
                UserVillage.user_id == user_id,
                UserVillage.village_id == village_id,
            )
            .first()
        )

    def get_by_user(self, user_id: UUID):
        return (
            self.db.query(UserVillage)
            .filter(
                UserVillage.user_id == user_id
            )
            .all()
        )

    def create(self, user_village: UserVillage):
        self.db.add(user_village)
        self.db.commit()
        self.db.refresh(user_village)
        return user_village

    def delete(self, user_village: UserVillage):
        self.db.delete(user_village)
        self.db.commit()

    def delete_by_user_village(
        self,
        user_id: UUID,
        village_id: UUID,
    ) -> bool:

        user_village = self.get_by_user_village(
            user_id,
            village_id,
        )

        if not user_village:
            return False

        self.delete(user_village)

        return True