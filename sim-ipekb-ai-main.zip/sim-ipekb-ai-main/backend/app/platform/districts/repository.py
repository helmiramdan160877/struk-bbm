from sqlalchemy.orm import Session

from app.models.district import District


class DistrictRepository:

    def __init__(self, db: Session):
        self.db = db

    def get_all(self):
        return self.db.query(District).all()

    def get_by_id(self, district_id):
        return (
            self.db.query(District)
            .filter(District.id == district_id)
            .first()
        )

    def get_by_code(self, code: str):
        return (
            self.db.query(District)
            .filter(District.code == code)
            .first()
        )

    def get_by_siga_id(self, siga_id: str):
        return (
            self.db.query(District)
            .filter(District.siga_id == siga_id)
            .first()
        )

    def save(
        self,
        *,
        regency_id,
        siga_id: str,
        code: str,
        name: str,
        is_active: bool = True,
    ):
        district = self.get_by_siga_id(siga_id)

        if district:
            district.regency_id = regency_id
            district.code = code
            district.name = name
            district.is_active = is_active
        else:
            district = District(
                regency_id=regency_id,
                siga_id=siga_id,
                code=code,
                name=name,
                is_active=is_active,
            )
            self.db.add(district)

        self.db.commit()
        self.db.refresh(district)

        return district

    def create(self, district: District):
        self.db.add(district)
        self.db.commit()
        self.db.refresh(district)
        return district

    def update(self):
        self.db.commit()

    def delete(self, district: District):
        self.db.delete(district)
        self.db.commit()