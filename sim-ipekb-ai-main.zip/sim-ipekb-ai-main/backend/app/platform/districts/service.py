from app.models.district import District


class DistrictService:

    def __init__(self, repository):
        self.repository = repository

    def get_all_districts(self):
        return self.repository.get_all()

    def get_district_by_id(self, district_id):
        return self.repository.get_by_id(district_id)

    def create_district(
        self,
        regency_id,
        code,
        name,
    ):
        if self.repository.get_by_code(code):
            raise ValueError("Kode kecamatan sudah digunakan")

        district = District(
            regency_id=regency_id,
            code=code,
            name=name,
            is_active=True,
        )

        return self.repository.create(district)

    def update_district(
        self,
        district,
        regency_id=None,
        code=None,
        name=None,
        is_active=None,
    ):
        if regency_id is not None:
            district.regency_id = regency_id

        if code is not None:
            district.code = code

        if name is not None:
            district.name = name

        if is_active is not None:
            district.is_active = is_active

        self.repository.update()

        return district

    def delete_district(self, district):
        self.repository.delete(district)