from sqlalchemy.orm import Session

from app.models.regency import Regency


class RegencyRepository:

    def __init__(self, db: Session):
        self.db = db

    def get_all(self):
        return self.db.query(Regency).all()

    def get_by_id(self, regency_id):
        return (
            self.db.query(Regency)
            .filter(Regency.id == regency_id)
            .first()
        )

    def get_by_code(self, code: str):
        return (
            self.db.query(Regency)
            .filter(Regency.code == code)
            .first()
        )

    def get_by_siga_id(self, siga_id: str):
        return (
            self.db.query(Regency)
            .filter(Regency.siga_id == siga_id)
            .first()
        )

    def save(
        self,
        *,
        province_id,
        siga_id: str,
        code: str,
        name: str,
        is_active: bool = True,
    ):
        regency = self.get_by_siga_id(siga_id)

        if regency:
            regency.province_id = province_id
            regency.code = code
            regency.name = name
            regency.is_active = is_active
        else:
            regency = Regency(
                province_id=province_id,
                siga_id=siga_id,
                code=code,
                name=name,
                is_active=is_active,
            )
            self.db.add(regency)

        self.db.commit()
        self.db.refresh(regency)

        return regency

    def create(self, regency: Regency):
        self.db.add(regency)
        self.db.commit()
        self.db.refresh(regency)
        return regency

    def update(self):
        self.db.commit()

    def delete(self, regency: Regency):
        self.db.delete(regency)
        self.db.commit()