from app.models.regency import Regency


class RegencyService:

    def __init__(self, repository):
        self.repository = repository

    def get_all_regencies(self):
        return self.repository.get_all()

    def get_regency_by_id(self, regency_id):
        return self.repository.get_by_id(regency_id)

    def create_regency(
        self,
        province_id,
        code,
        name,
    ):
        if self.repository.get_by_code(code):
            raise ValueError("Kode kabupaten sudah digunakan")

        regency = Regency(
            province_id=province_id,
            code=code,
            name=name,
            is_active=True,
        )

        return self.repository.create(regency)

    def update_regency(
        self,
        regency,
        province_id=None,
        code=None,
        name=None,
        is_active=None,
    ):
        if province_id is not None:
            regency.province_id = province_id

        if code is not None:
            regency.code = code

        if name is not None:
            regency.name = name

        if is_active is not None:
            regency.is_active = is_active

        self.repository.update()

        return regency

    def delete_regency(self, regency):
        self.repository.delete(regency)