from uuid import UUID

from app.models.family_member import FamilyMember


class FamilyMemberService:

    def __init__(self, repository):
        self.repository = repository

    def get_all(self, village_ids: list[UUID] | None = None):
        return self.repository.get_all(village_ids=village_ids)

    def get_by_id(self, member_id, village_ids: list[UUID] | None = None):
        return self.repository.get_by_id(member_id, village_ids=village_ids)

    def create(self, data, village_ids: list[UUID] | None = None):
        if self.repository.get_by_nik(data.nik):
            raise ValueError("NIK sudah digunakan")
        if not self.repository.family_is_in_scope(data.family_id, village_ids):
            raise ValueError("Keluarga berada di luar wilayah binaan Anda")
        member = FamilyMember(**data.model_dump())
        return self.repository.create(member)

    def update(self, member, data, village_ids: list[UUID] | None = None):
        payload = data.model_dump(exclude_unset=True)
        target_family_id = payload.get("family_id")
        if target_family_id is not None and not self.repository.family_is_in_scope(target_family_id, village_ids):
            raise ValueError("Keluarga tujuan berada di luar wilayah binaan Anda")
        for key, value in payload.items():
            setattr(member, key, value)
        return self.repository.update(member)

    def delete(self, member):
        self.repository.delete(member)
