from uuid import UUID

from sqlalchemy.orm import Session

from app.models.family import Family
from app.models.family_member import FamilyMember


class FamilyMemberRepository:

    def __init__(self, db: Session):
        self.db = db

    def _scoped_query(self, village_ids: list[UUID] | None = None):
        query = self.db.query(FamilyMember).join(
            Family,
            FamilyMember.family_id == Family.id,
        )
        if village_ids is not None:
            query = query.filter(Family.village_id.in_(village_ids))
        return query

    def get_all(self, village_ids: list[UUID] | None = None):
        return self._scoped_query(village_ids).order_by(FamilyMember.full_name.asc()).all()

    def get_by_id(self, member_id, village_ids: list[UUID] | None = None):
        return (
            self._scoped_query(village_ids)
            .filter(FamilyMember.id == member_id)
            .first()
        )

    def get_by_nik(self, nik):
        return (
            self.db.query(FamilyMember)
            .filter(FamilyMember.nik == nik)
            .first()
        )

    def family_is_in_scope(self, family_id: UUID, village_ids: list[UUID] | None = None) -> bool:
        query = self.db.query(Family).filter(Family.id == family_id)
        if village_ids is not None:
            query = query.filter(Family.village_id.in_(village_ids))
        return query.first() is not None

    def create(self, member):
        self.db.add(member)
        self.db.commit()
        self.db.refresh(member)
        return member

    def update(self, member):
        self.db.commit()
        self.db.refresh(member)
        return member

    def delete(self, member):
        self.db.delete(member)
        self.db.commit()
