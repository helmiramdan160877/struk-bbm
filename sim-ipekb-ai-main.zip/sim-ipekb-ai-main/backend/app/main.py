from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings

from app.api.v1.auth import router as auth_router
from app.api.v1.users import router as users_router
from app.api.v1.roles import router as roles_router
from app.api.v1.permissions import router as permissions_router

from app.api.v1.provinces import router as provinces_router
from app.api.v1.regencies import router as regencies_router
from app.api.v1.districts import router as districts_router
from app.api.v1.villages import router as villages_router

from app.api.v1.families import router as families_router
from app.api.v1.family_members import router as family_members_router

from app.api.v1.siga_accounts import router as siga_account_router
from app.api.v1.sync import router as sync_router

from app.api.v1.dashboard import router as dashboard_router

from app.api.v1.pkb import router as pkb_router
from app.api.v1.iuran import router as iuran_router
from app.api.v1.kader import router as kader_router
from app.api.v1.anggota import router as anggota_router
from app.api.v1.notifications import router as notifications_router
from app.api.v1.gemini_ai import router as gemini_ai_router
from app.scheduler import start_scheduler, stop_scheduler
from app.admin_database import router as admin_database_router


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
)


@app.on_event("startup")
def _startup_scheduler():
    start_scheduler()


@app.on_event("shutdown")
def _shutdown_scheduler():
    stop_scheduler()


# ===========================================================
# CORS
# ===========================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ===========================================================
# ROOT
# ===========================================================

@app.get("/")
def root():
    return {
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
    }


# ===========================================================
# AUTH
# ===========================================================

app.include_router(
    auth_router,
    prefix="/api/v1/auth",
    tags=["Authentication"],
)


# ===========================================================
# USERS
# ===========================================================

app.include_router(
    users_router,
    prefix="/api/v1/users",
    tags=["Users"],
)


# ===========================================================
# ROLES
# ===========================================================

app.include_router(
    roles_router,
    prefix="/api/v1/roles",
    tags=["Roles"],
)


# ===========================================================
# PERMISSIONS
# ===========================================================

app.include_router(
    permissions_router,
    prefix="/api/v1/permissions",
    tags=["Permissions"],
)


# ===========================================================
# MASTER WILAYAH
# ===========================================================

app.include_router(
    provinces_router,
    prefix="/api/v1/provinces",
    tags=["Provinces"],
)

app.include_router(
    regencies_router,
    prefix="/api/v1/regencies",
    tags=["Regencies"],
)

app.include_router(
    districts_router,
    prefix="/api/v1/districts",
    tags=["Districts"],
)

app.include_router(
    villages_router,
    prefix="/api/v1/villages",
    tags=["Villages"],
)


# ===========================================================
# KELUARGA
# ===========================================================

app.include_router(
    families_router,
    prefix="/api/v1/families",
    tags=["Families"],
)

app.include_router(
    family_members_router,
    prefix="/api/v1/family-members",
    tags=["Family Members"],
)


# ===========================================================
# SIGA
# ===========================================================

app.include_router(
    siga_account_router,
    prefix="/api/v1/siga-accounts",
    tags=["SIGA Accounts"],
)

app.include_router(
    sync_router,
    prefix="/api/v1/sync",
    tags=["SIGA Sync"],
)


# ===========================================================
# DASHBOARD
# ===========================================================

app.include_router(
    dashboard_router,
    prefix="/api/v1/dashboard",
    tags=["Dashboard"],
)


# ===========================================================
# PKB
# ===========================================================

app.include_router(
    pkb_router,
    prefix="/api/v1/pkb",
    tags=["PKB"],
)

# ===========================================================
# KAS & IURAN IPKB
# ===========================================================

app.include_router(
    iuran_router,
    prefix="/api/v1/iuran",
    tags=["Kas & Iuran IPKB"],
)


# ===========================================================
# MASTER KADER & NOTIFICATIONS
# ===========================================================

app.include_router(
    kader_router, 
    prefix="/api/v1/kader", 
    tags=["Master Kader"]
)

app.include_router(
    anggota_router,
    prefix="/api/v1/anggota",
    tags=["Master Anggota"]
    
)
app.include_router(notifications_router, prefix="/api/v1/notifications", tags=["Notifications"])


app.include_router(admin_database_router, prefix="/api/v1/admin/database", tags=["SUPER_ADMIN Database"])


app.include_router(gemini_ai_router, prefix="/api/v1/ai", tags=["AI Assistant - Gemini"])
