from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.api.deps import get_db
from app.platform.auth.dependencies import require_roles

router = APIRouter()

# Data operasional yang aman untuk dihapus tanpa menghilangkan akun SUPER_ADMIN,
# role/permission, master wilayah, dan akun SIGA yang diperlukan untuk auto-sync.
RESETTABLE_TABLES = (
    "iuran_notifications",
    "iuran_payments",
    "family_members",
    "families",
    "pkbs",
    "kaders",
    "user_villages",
    "user_siga_accounts",
)


@router.post("/reset-data")
def reset_operational_database(
    confirmation: str,
    db: Session = Depends(get_db),
    current_user=Depends(require_roles("SUPER_ADMIN")),
):
    """Hapus data operasional. Hanya SUPER_ADMIN dan wajib konfirmasi eksplisit."""
    if confirmation != "HAPUS SEMUA DATA":
        raise HTTPException(
            status_code=400,
            detail='Konfirmasi salah. Gunakan persis: HAPUS SEMUA DATA',
        )

    try:
        existing = {
            row[0]
            for row in db.execute(
                text("SELECT tablename FROM pg_tables WHERE schemaname='public'")
            ).all()
        }
        tables = [name for name in RESETTABLE_TABLES if name in existing]
        if tables:
            # DELETE berurutan agar FK ON DELETE SET NULL pada users tetap aman.
            for name in tables:
                db.execute(text(f'DELETE FROM "{name}"'))
        db.commit()
        return {
            "success": True,
            "message": "Data operasional berhasil dihapus.",
            "tables_cleared": tables,
            "executed_at": datetime.now(timezone.utc),
            "executed_by": str(current_user.id),
        }
    except Exception as exc:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Gagal menghapus data: {exc}") from exc
