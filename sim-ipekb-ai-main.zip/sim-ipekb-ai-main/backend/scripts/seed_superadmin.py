from sqlalchemy.orm import Session

from app.db.database import SessionLocal
from app.models.role import Role
from app.models.user import User
from app.platform.auth.hash import hash_password


def seed():
    db: Session = SessionLocal()

    try:
        role = db.query(Role).filter(Role.name == "SUPER_ADMIN").first()

        if role is None:
            raise Exception("Role SUPER_ADMIN tidak ditemukan. Jalankan seed_roles.py terlebih dahulu.")

        user = (
            db.query(User)
            .filter(User.username == "superadmin")
            .first()
        )

        if user:
            print("ℹ️ Super Admin sudah ada")
            return

        user = User(
            username="superadmin",
            email="helmiramdan160877@gmail.com",
            full_name="System Administrator",
            hashed_password=hash_password("admin123"),
            role_id=role.id,
            is_active=True,
        )

        db.add(user)
        db.commit()

        print("✅ Super Admin berhasil dibuat")

    finally:
        db.close()


if __name__ == "__main__":
    seed()