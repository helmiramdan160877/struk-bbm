from app.db.database import SessionLocal
from app.models.role import Role


ROLES = [
    ("SUPER_ADMIN", "System Super Administrator"),
    ("ADMIN", "Administrator Kecamatan"),
    ("ADMIN_KABUPATEN", "Administrator Kabupaten"),
    ("PENGURUS", "Pengurus IPEKB"),
    ("PKB", "Penyuluh Keluarga Berencana"),
    ("KADER", "Kader Lapangan"),
    ("UPPKA", "Usaha Peningkatan Pendapatan Keluarga Akseptor"),
    ("PPKBD", "Pembantu Pembina Keluarga Berencana Desa"),
    ("OPERATOR", "Operator Data dan SIGA"),
    ("BENDAHARA", "Bendahara"),
    ("PIMPINAN", "Pimpinan / Monitoring"),
    ("VIEWER", "Pengguna Baca Saja"),
    ("ANGGOTA", "Anggota"),
    ("REDAKTUR", "Redaktur / Pengelola Berita"),
]


def seed():
    db = SessionLocal()
    try:
        for name, description in ROLES:
            role = db.query(Role).filter(Role.name == name).first()
            if role is None:
                db.add(Role(name=name, description=description, is_active=True))
                print(f"✅ {name} dibuat")
            else:
                role.description = description
                role.is_active = True
                print(f"ℹ️ {name} sudah ada")
        db.commit()
    finally:
        db.close()


if __name__ == "__main__":
    seed()
