from app.db.database import SessionLocal
from app.platform.users.repository import UserRepository
from app.platform.users.service import UserService
from app.platform.auth.service import AuthService


def main():
    db = SessionLocal()

    try:
        repository = UserRepository(db)
        user_service = UserService(repository)
        auth_service = AuthService(user_service)

        token = auth_service.login(
            "superadmin",
            "admin123",
        )

        if token:
            print("✅ LOGIN BERHASIL")
            print(token)
        else:
            print("❌ LOGIN GAGAL")

    finally:
        db.close()


if __name__ == "__main__":
    main()