from app.platform.auth.hash import hash_password

print(hash_password("admin123"))