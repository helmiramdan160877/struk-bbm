from app.platform.auth.jwt import create_access_token

token = create_access_token(
    {
        "sub": "superadmin",
        "role": "SUPER_ADMIN",
    }
)

print(token)