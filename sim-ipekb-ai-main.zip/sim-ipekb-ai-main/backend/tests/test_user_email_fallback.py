from app.api.v1.users import _normalize_email


def test_normalize_email_uses_username_when_blank():
    assert _normalize_email("", "demo") == "demo@ipekb.local"
    assert _normalize_email("user@example.com", "demo") == "user@example.com"
