from app.models.user import User
from app.platform.auth.hash import hash_password


class UserService:

    def __init__(self, repository):
        self.repository = repository

    # =====================================================
    # GET
    # =====================================================

    def get_all_users(self):
        return self.repository.get_all()

    def get_user_by_id(self, user_id):
        return self.repository.get_by_id(user_id)

    def get_user_by_username(self, username):
        return self.repository.get_by_username(username)

    def get_user_by_email(self, email):
        return self.repository.get_by_email(email)

    # =====================================================
    # CREATE
    # =====================================================

    def create_user(
        self,
        username,
        email,
        full_name,
        password,
        role_id,
        nip=None,
        phone=None,
        district_id=None,
        pkb_id=None,
        kader_id=None,
        plan_type="FREE",
        plan_expires_at=None,
    ):

        if self.repository.get_by_username(username):
            raise ValueError("Username sudah digunakan")

        if self.repository.get_by_email(email):
            raise ValueError("Email sudah digunakan")

        user = User(
            username=username,
            email=email,
            full_name=full_name,
            hashed_password=hash_password(password),
            role_id=role_id,
            nip=nip,
            phone=phone,
            district_id=district_id,
            pkb_id=pkb_id,
            kader_id=kader_id,
            is_active=True,
            plan_type=plan_type,
            plan_expires_at=plan_expires_at,
        )

        return self.repository.create(user)

    # =====================================================
    # UPDATE
    # =====================================================

    def update_user(
        self,
        user,
        email=None,
        full_name=None,
        password=None,
        role_id=None,
        is_active=None,
        nip=None,
        phone=None,
        district_id=None,
        plan_type=None,
        plan_expires_at=None,
    ):

        if email is not None:
            user.email = email

        if full_name is not None:
            user.full_name = full_name

        if password:
            user.hashed_password = hash_password(password)

        if role_id is not None:
            user.role_id = role_id

        if is_active is not None:
            user.is_active = is_active

        if nip is not None:
            user.nip = nip

        if phone is not None:
            user.phone = phone

        if district_id is not None:
            user.district_id = district_id

        if plan_type is not None:
            user.plan_type = plan_type

        if plan_expires_at is not None or plan_type == "FREE":
            user.plan_expires_at = plan_expires_at

        return self.repository.update(user)

    # =====================================================
    # AKTIFKAN USER
    # =====================================================

    def activate_user(self, user_id):
        return self.repository.activate(user_id)

    # =====================================================
    # NONAKTIFKAN USER
    # =====================================================

    def deactivate_user(self, user_id):
        return self.repository.deactivate(user_id)

    # =====================================================
    # RESET PASSWORD
    # =====================================================

    def reset_password(
        self,
        user_id,
        new_password,
    ):
        return self.repository.change_password(
            user_id=user_id,
            hashed_password=hash_password(new_password),
        )

    # =====================================================
    # GANTI ROLE
    # =====================================================

    def change_role(
        self,
        user_id,
        role_id,
    ):
        return self.repository.change_role(
            user_id,
            role_id,
        )

    # =====================================================
    # DELETE
    # =====================================================

    def delete_user(self, user):
        return self.repository.delete(user)